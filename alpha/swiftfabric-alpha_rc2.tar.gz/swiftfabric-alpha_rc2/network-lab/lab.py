"""Opt-in live L2, East/West ACL, and North/South NAT acceptance lab."""

import argparse
import base64
import concurrent.futures
import copy
import fcntl
import gzip
import ipaddress
import itertools
import json
import math
import os
from pathlib import Path
import re
import secrets
import select
import shlex
import subprocess
import struct
import sys
import threading
import time
import uuid

import requests
from guest import HELD_ECHO_FORMATS, held_summary
import reporting

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_installer"))
from deployment.proxmox_ca import ProxmoxCATrust
from deployment.api_retry import request_with_retry
from deployment.ssh import SSHCommandRunner
from main import _controller_vip, load_deployment_config
from proxmox.client import ProxmoxAPIError, ProxmoxClient

POLICY_KEYS = (
    "wan_ingress_rules", "wan_egress_rules", "inbound_port_mappings", "outbound_port_mappings",
    "masquerade_source_cidrs",
)
TCP_PORT = 18080
UDP_PORT = 18081
CONTINUITY_PROTOCOLS = {"both": ("tcp", "udp"), "tcp": ("tcp",), "udp": ("udp",)}
SSH_OPTIONS = (
    "-o", "BatchMode=yes", "-o", "IdentitiesOnly=yes",
    "-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=/dev/null",
    "-o", "GlobalKnownHostsFile=/dev/null", "-o", "ConnectTimeout=10",
)


class TrafficPhaseFailure(RuntimeError):
    pass


class SerialConnectionError(RuntimeError):
    pass


class LabAPIError(RuntimeError):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


def private_write(path, value):
    temporary = path.with_suffix(".tmp")
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            if isinstance(value, str):
                stream.write(value)
            else:
                json.dump(value, stream, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def segment_plan(specifications, run_id):
    if len(specifications) != 3:
        raise ValueError("exactly three segment ID:gateway/24 specifications are required")
    private = [ipaddress.ip_network(cidr) for cidr in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16")]
    result = []
    for index, specification in enumerate(specifications):
        identifier, cidr = specification.split(":", 1)
        identifier = int(identifier)
        gateway = ipaddress.IPv4Interface(cidr)
        if not 5000 <= identifier <= 50000:
            raise ValueError("segment IDs must be between 5000 and 50000")
        if gateway.network.prefixlen != 24 or not any(gateway.network.subnet_of(net) for net in private):
            raise ValueError("lab networks must be RFC1918 /24 networks")
        if gateway.ip in (gateway.network.network_address, gateway.network.broadcast_address):
            raise ValueError("gateway must be a usable host address")
        if 10 <= int(gateway.ip) - int(gateway.network.network_address) <= 12:
            raise ValueError("gateway cannot use the reserved VM addresses .10 through .12")
        if any(identifier == item["id"] or gateway.network.overlaps(ipaddress.ip_network(item["network"]))
               for item in result):
            raise ValueError("segment IDs and networks must be distinct")
        result.append({
            "id": identifier, "name": f"sf-lab-{run_id[:8]}-s{index + 1}",
            "gateway_cidr": str(gateway), "network": str(gateway.network), "created": False,
        })
    return result


def acl_rule(source, destination, protocol, destination_port="any", source_port="any"):
    return {
        "source": source, "destination": destination, "protocol": protocol,
        "source_port": source_port, "destination_port": destination_port,
    }


def segment_acl(segments, current, egress, ingress):
    result = {"egress": [], "ingress": []}
    for other in segments:
        if other["id"] == current["id"]:
            continue
        for protocol, port in (("tcp", str(TCP_PORT)), ("udp", str(UDP_PORT))):
            if egress:
                result["egress"].append(acl_rule(current["network"], other["network"], protocol, port))
            if ingress:
                result["ingress"].append(acl_rule(other["network"], current["network"], protocol, port))
    return result


def assert_vm_owner(configuration, vm, run_id):
    if (configuration.get("name") != vm["name"]
            or configuration.get("description") != f"SwiftFabric live network lab {run_id}"):
        raise RuntimeError(f"VM {vm['vmid']} ownership mismatch; refusing to modify it")
    network = dict(part.split("=", 1) for part in configuration.get("net0", "").split(",") if "=" in part)
    if network.get("bridge") != f"sf-br{vm['segment_id']}":
        raise RuntimeError(f"VM {vm['vmid']} bridge changed; refusing to modify it")


def assert_segment_owner(current, segment):
    if (current["name"] != segment["name"] or current["gateway_cidr"] != segment["gateway_cidr"]
            or ("tenant_id" in segment and current.get("tenant_id") != segment["tenant_id"])):
        raise RuntimeError(f"segment {segment['id']} ownership mismatch; refusing to modify it")


def encode(value):
    return base64.b64encode(gzip.compress(value)).decode("ascii")


def capture_filter(vms, plane):
    hosts = " or ".join(f"host {ipaddress.IPv4Address(vm['address'])}" for vm in vms)
    if not hosts:
        raise ValueError("packet capture requires owned lab VM addresses")
    ports = "tcp port 53 or udp port 53" if plane == "north-south" else (
        f"tcp port {TCP_PORT} or udp port {UDP_PORT}"
    )
    return f"({hosts}) and (arp or icmp or {ports})"


def pcap_packet_count(path):
    with path.open("rb") as stream:
        header = stream.read(24)
        endian = {
            b"\xd4\xc3\xb2\xa1": "<", b"\xa1\xb2\xc3\xd4": ">",
            b"\x4d\x3c\xb2\xa1": "<", b"\xa1\xb2\x3c\x4d": ">",
        }.get(header[:4])
        if len(header) != 24 or endian is None:
            raise RuntimeError(f"invalid PCAP header: {path}")
        major, minor, _, _, snaplen, _ = struct.unpack(endian + "HHIIII", header[4:])
        if (major, minor) != (2, 4) or not 0 < snaplen <= 1024**2:
            raise RuntimeError(f"unsupported PCAP header: {path}")
        count = 0
        while record := stream.read(16):
            if len(record) != 16:
                raise RuntimeError(f"truncated PCAP record: {path}")
            _, _, captured, original = struct.unpack(endian + "IIII", record)
            if not 0 < captured <= min(snaplen, original) or len(stream.read(captured)) != captured:
                raise RuntimeError(f"invalid or truncated PCAP packet: {path}")
            count += 1
        if not count:
            raise RuntimeError(f"PCAP contains no packets: {path}")
        return count


def validate_held_results(cases, results):
    if not isinstance(results, list) or len(results) != len(cases):
        raise ValueError("held-flow results do not match the requested matrix")
    for case, result in zip(cases, results):
        echo_format = case.get("echo_format", "observed-peer")
        if echo_format not in HELD_ECHO_FORMATS:
            raise ValueError("unknown held-flow echo format")
        if not isinstance(result, dict) or any(result.get(key) != value for key, value in case.items()):
            raise ValueError("held-flow identity does not match the requested matrix")
        samples = result.get("samples")
        elapsed = result.get("elapsed_seconds")
        error = result.get("error")
        if (not isinstance(samples, list) or len(samples) > case["duration_seconds"] * 4 + 1
                or type(elapsed) not in (int, float) or not math.isfinite(elapsed)
                or not 0 <= elapsed <= case["duration_seconds"] + 10
                or not isinstance(error, str)):
            raise ValueError("invalid held-flow observation shape")
        previous = 0.0
        sequences = set()
        for sample in samples:
            if not isinstance(sample, dict):
                raise ValueError("invalid held-flow sample")
            number = sample.get("sequence")
            sent = sample.get("sent_seconds")
            received = sample.get("received_seconds")
            peer = sample.get("peer")
            if (type(number) is not int or number < 0 or number in sequences
                    or type(sent) not in (int, float) or not math.isfinite(sent)
                    or type(received) not in (int, float) or not math.isfinite(received)
                    or not 0 <= sent <= received <= elapsed or received < previous):
                raise ValueError("invalid held-flow timing, sequence, or peer")
            if echo_format == "plain":
                if "peer" not in sample or peer is not None:
                    raise ValueError("plain echo cannot claim an observed NAT peer")
            else:
                if (not isinstance(peer, list) or len(peer) != 2
                        or not isinstance(peer[0], str) or type(peer[1]) is not int
                        or not 1 <= peer[1] <= 65535):
                    raise ValueError("invalid held-flow peer")
                ipaddress.IPv4Address(peer[0])
            sequences.add(number)
            previous = received
        expected = held_summary(case, samples, elapsed, error)
        if (type(result.get("passed")) is not bool
                or any(result.get(key) != expected[key] for key in
                       ("passed", "failures", "max_response_gap_seconds", "observed_peers"))
                or type(result.get("connected")) is not bool
                or (result["passed"] and not result["connected"])
                or any(type(result.get(key)) is not int or result[key] < 0 for key in (
                    "requests", "application_bytes_sent", "application_bytes_received",
                ))
                or result["requests"] < len(samples)
                or result["requests"] > case["duration_seconds"] * 4 + 1
                or any(sample["sequence"] >= result["requests"] for sample in samples)
                or (result["passed"] and (
                    result["application_bytes_sent"] == 0 or result["application_bytes_received"] == 0
                ))
                or type(result.get("started_epoch")) not in (int, float)
                or not math.isfinite(result["started_epoch"]) or result["started_epoch"] <= 0
                or type(result.get("started_monotonic")) not in (int, float)
                or not math.isfinite(result["started_monotonic"]) or result["started_monotonic"] < 0):
            raise ValueError("inconsistent held-flow summary or counters")


def continuity_event_report(manifest, event_start, event_end):
    if (any(type(value) not in (int, float) or not math.isfinite(value) or value <= 0
            for value in (event_start, event_end)) or event_end < event_start):
        raise ValueError("event requires ordered finite positive operator epoch timestamps")
    if not isinstance(manifest, dict):
        raise ValueError("event analysis requires a continuity manifest object")
    protocols = manifest.get("protocols", ["tcp", "udp"])
    if protocols not in (["tcp", "udp"], ["tcp"], ["udp"]):
        raise ValueError("invalid continuity protocol declaration")
    echo_format = manifest.get("echo_format", "observed-peer")
    if echo_format not in HELD_ECHO_FORMATS:
        raise ValueError("invalid continuity echo format declaration")
    expected_flows = 9 * len(protocols)
    results = manifest.get("results")
    if (manifest.get("completed") is not True or manifest.get("errors") != []
            or not isinstance(results, list) or len(results) != expected_flows):
        raise ValueError(f"event analysis requires a complete {expected_flows}-flow continuity manifest")
    identities = set()
    flows = []
    for result in results:
        keys = (
            "source", "source_port", "destination", "destination_port",
            "protocol", "duration_seconds", "expected_nat_address",
        )
        if not isinstance(result, dict) or any(key not in result for key in keys):
            raise ValueError("invalid held-flow identity in manifest")
        case = {key: result[key] for key in keys}
        if result.get("echo_format", "observed-peer") != echo_format:
            raise ValueError("flow echo format does not match manifest")
        if "echo_format" in result:
            case["echo_format"] = echo_format
        if (case["protocol"] not in protocols
                or type(case["duration_seconds"]) is not int or not 30 <= case["duration_seconds"] <= 600):
            raise ValueError("invalid held-flow protocol or duration in manifest")
        validate_held_results([case], [result])
        identity = (case["source"], case["protocol"])
        if identity in identities:
            raise ValueError("duplicate held flow in continuity manifest")
        identities.add(identity)
        bounds = result.get("operator_clock_offset_seconds")
        if (not isinstance(bounds, list) or len(bounds) != 2
                or any(type(value) not in (int, float) or not math.isfinite(value) for value in bounds)
                or bounds[0] > bounds[1]):
            raise ValueError("event analysis requires measured operator/guest monotonic clock bounds")
        samples = result["samples"]
        healthy_before = any(
            result["started_monotonic"] + sample["received_seconds"] + bounds[1] < event_start
            for sample in samples
        )
        healthy_after = any(
            result["started_monotonic"] + sample["received_seconds"] + bounds[0] > event_end
            for sample in samples
        )
        flows.append({
            "source": case["source"], "protocol": case["protocol"],
            "healthy_before": healthy_before, "healthy_after": healthy_after,
            "max_response_gap_seconds": result["max_response_gap_seconds"],
            "passed": result["passed"] and healthy_before and healthy_after,
            "failures": result["failures"] + (
                [] if healthy_before else ["no unambiguously pre-event verified response"]
            ) + ([] if healthy_after else ["no unambiguously post-event verified response"]),
        })
    if len({source for source, _ in identities}) != 9 or any(
        {protocol for address, protocol in identities if address == source} != set(protocols)
        for source, _ in identities
    ):
        raise ValueError("event analysis requires every declared protocol for each of nine sources")
    return {
        "event_start_epoch": event_start, "event_end_epoch": event_end,
        "protocols": protocols,
        "echo_format": echo_format,
        "nat_tuple_verified": echo_format == "observed-peer" and all(flow["passed"] for flow in flows),
        "scope": "same-socket flow overlap and response gaps; not proof of fault identity or kernel counters",
        "passed": all(flow["passed"] for flow in flows), "flows": flows,
    }


class LiveLab:
    def __init__(self, directory):
        self.directory = directory.resolve()
        self.path = self.directory / "state.json"
        self.state = json.loads(self.path.read_text(encoding="utf-8"))
        self.acceptance_assertion_count = None
        self.config = load_deployment_config(Path(self.state["config"]))
        self.proxmox_ca = ProxmoxCATrust(
            self.config["proxmox_cluster_ip"],
            self.config["proxmox_ssh_user"],
            self.config["proxmox_ssh_key"],
        )
        self.proxmox = ProxmoxClient(
            self.config["proxmox_cluster_ip"], port=self.config["proxmox_port"],
            user=self.config["proxmox_user"], token_name=self.config["proxmox_tokenname"],
            api_key=self.config["proxmox_apikey"],
            verify_ssl=self.proxmox_ca.ca_path,
        )
        self.proxmox_ca.verify_cluster_nodes(self.proxmox)
        self.api = requests.Session()
        self.api.trust_env = False
        ssh = SSHCommandRunner(self.config["controller_priv_key"], "ubuntu", "live network lab")
        first = self.config["ip_range_start"]
        certificate = ssh.run(first, "sudo -n cat /etc/swiftfabric/swiftfabric-ca.crt")
        certificate_path = self.directory / "controller-ca.crt"
        private_write(certificate_path, certificate)
        self.api.verify = str(certificate_path)
        token = ssh.run(first, "sudo -n cat /etc/swiftfabric/segment-manager.token").strip()
        self.api.headers["Authorization"] = f"Bearer {token}"
        self.base_url = f"https://{_controller_vip(self.config)}/api/v1"

    def save(self):
        private_write(self.path, self.state)

    def request(self, method, path, body=None):
        response = request_with_retry(self.api, method, self.base_url + path, json=body, timeout=(5, 120))
        if not response.ok:
            raise LabAPIError(
                response.status_code,
                f"{method} {path}: HTTP {response.status_code}: {response.text[:1000]}",
            )
        return response.json() if response.content else None

    def task(self, response):
        task = response["data"]
        if not isinstance(task, str) or not task.startswith("UPID:"):
            raise RuntimeError("Proxmox mutation did not return a task identifier")
        self.proxmox.wait_for_task(task, timeout=300)

    def router_policy(self):
        router = self.request("GET", f"/north-south-routers/{self.state['router']}")
        if (router["status"] != "active" or router.get("deployment_mode") != "standalone"
                or router.get("ha_state_sync_enabled")):
            raise RuntimeError("lab policy mutation requires an active standalone test router; HA lifecycle fences are not bypassed")
        return {key: router[key] for key in POLICY_KEYS}

    def set_wan(self, allowed, restore=False):
        router = self.request("GET", f"/north-south-routers/{self.state['router']}")
        if (router["status"] != "active" or router.get("deployment_mode") != "standalone"
                or router.get("ha_state_sync_enabled")):
            raise RuntimeError("lab policy mutation requires an active standalone test router; HA lifecycle fences are not bypassed")
        snapshot = self.request(
            "GET", f"/north-south-routers/{self.state['router']}/wan-policy",
        )
        current = {key: snapshot[key] for key in POLICY_KEYS}
        policy_version = snapshot["_version"]
        expected = self.state.get("last_wan_policy", self.state["original_wan_policy"])
        if current != expected:
            raise RuntimeError("router WAN policy changed outside the lab; refusing to overwrite it")
        policy = copy.deepcopy(self.state["original_wan_policy"])
        if not restore:
            for segment in self.state["segments"]:
                policy["masquerade_source_cidrs"].append(segment["network"])
        if allowed:
            for segment in self.state["segments"]:
                for protocol in ("tcp", "udp"):
                    policy["wan_egress_rules"].append(acl_rule(
                        segment["network"], f"{self.state['dns_address']}/32", protocol, "53",
                    ))
        policy["_version"] = policy_version
        updated = self.request("PUT", f"/north-south-routers/{self.state['router']}/wan-policy", policy)
        self.state["last_wan_policy"] = {key: updated[key] for key in POLICY_KEYS}
        self.save()

    def owned_segment(self, segment):
        matches = [
            current for current in self.request("GET", "/segments")
            if current["id"] == segment["id"]
        ]
        if not matches:
            raise LabAPIError(404, f"segment {segment['id']} no longer exists")
        if len(matches) != 1:
            raise RuntimeError(f"ambiguous segment {segment['id']}")
        current = matches[0]
        assert_segment_owner(current, segment)
        return current

    def set_acls(self, egress, ingress):
        for segment in self.state["segments"]:
            current = self.owned_segment(segment)
            current = self.request("GET", f"/segments/{segment['id']}/acl")
            policy = segment_acl(self.state["segments"], segment, egress, ingress)
            policy["_version"] = current["_version"]
            self.request("PUT", f"/segments/{segment['id']}/acl", policy)
        time.sleep(self.state["settle_seconds"])

    def vm_config(self, vm):
        config = self.proxmox.get(f"/nodes/{vm['node']}/qemu/{vm['vmid']}/config")["data"]
        assert_vm_owner(config, vm, self.state["run_id"])
        return config

    def serial(self, vm, command, timeout=120):
        self.vm_config(vm)
        nested = shlex.join(["ssh", "-tt", "-o", "BatchMode=yes", vm["node"], "qm", "terminal", str(vm["vmid"])])
        process = subprocess.Popen(
            ["ssh", "-tt", "-i", self.config["proxmox_ssh_key"], *SSH_OPTIONS,
             f"{self.config['proxmox_ssh_user']}@{self.config['proxmox_cluster_ip']}", nested],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        )
        assert process.stdin is not None and process.stdout is not None
        buffered = b""
        deadline = time.monotonic() + timeout
        stage = "login prompt"

        def send(value):
            try:
                process.stdin.write(value)
                process.stdin.flush()
            except BrokenPipeError as exc:
                raise SerialConnectionError(f"VM {vm['vmid']} serial connection closed during {stage}") from exc

        def expect(pattern):
            nonlocal buffered
            regex = re.compile(pattern)
            while time.monotonic() < deadline:
                match = regex.search(buffered)
                if match:
                    before, found = buffered[:match.start()], match.group()
                    buffered = buffered[match.end():]
                    return before, found
                ready, _, _ = select.select([process.stdout], [], [], 1)
                if ready:
                    chunk = os.read(process.stdout.fileno(), 8192)
                    if not chunk:
                        raise SerialConnectionError(f"VM {vm['vmid']} serial connection closed during {stage}")
                    buffered += chunk
            raise TimeoutError(f"VM {vm['vmid']} serial deadline exceeded during {stage}")

        logged_in = False
        try:
            send(b"\n")
            _, prompt = expect(rb"login: |ubuntu@[^ \r\n]+:[^\r\n]*\$ ")
            if prompt == b"login: ":
                send(b"ubuntu\n")
                stage = "password prompt"
                expect(rb"Password: ")
                send(self.state["console_password"].encode("ascii") + b"\n")
                stage = "shell prompt"
                expect(rb"ubuntu@[^ \r\n]+:[^\r\n]*\$ ")
            logged_in = True
            marker = uuid.uuid4().hex.encode("ascii")
            text = marker.decode("ascii")
            wrapped = (
                f"printf '{text}_BEGIN\\n'; sh -c " + shlex.quote(command)
                + f"; printf '\\n{text}_END%s\\n' \"$?\"\n"
            )
            stage = "command start"
            send(wrapped.encode("utf-8"))
            expect(marker + rb"_BEGIN[\r\n]+")
            stage = "command completion"
            output, _ = expect(rb"[\r\n]+" + marker + rb"_END")
            stage = "command exit status"
            status, _ = expect(rb"[\r\n]+")
            if status.strip() != b"0":
                raise RuntimeError(f"VM {vm['vmid']} command failed: {output.decode(errors='replace')}")
            send(b"exit\n")
            logged_in = False
            return output.decode("utf-8").strip()
        finally:
            if logged_in and process.poll() is None:
                try:
                    send(b"\nexit\n")
                except SerialConnectionError as exc:
                    print(f"Serial logout incomplete: {exc}", file=sys.stderr, flush=True)
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()

    def setup_serial(self, vm, command, timeout=120):
        for attempt in range(1, 4):
            try:
                return self.serial(vm, command, timeout=timeout)
            except (TimeoutError, SerialConnectionError) as exc:
                if attempt == 3:
                    raise type(exc)(f"VM {vm['vmid']} setup failed after 3 attempts: {exc}") from exc
                print(
                    f"VM {vm['vmid']} setup attempt {attempt}/3 failed: {exc}; "
                    "retry in 5 seconds.",
                    flush=True,
                )
                time.sleep(5)

    def _capture_host(self, node, directory, packet_filter, seconds, ready):
        command = shlex.join([
            "ssh", "-T", "-o", "BatchMode=yes", node,
            shlex.join([
                "timeout", "--kill-after=5s", str(seconds),
                "tcpdump", "-U", "-nn", "-i", "any", "-s", "0", "-w", "-", packet_filter,
            ]),
        ])
        pcap = directory / f"{node}.pcap"
        log = directory / f"{node}.log"
        descriptor = os.open(pcap, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, "wb") as output:
            descriptor = os.open(log, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(descriptor, "wb") as errors:
                process = subprocess.Popen(
                    ["ssh", *SSH_OPTIONS, "-i", self.config["proxmox_ssh_key"],
                     f"{self.config['proxmox_ssh_user']}@{self.config['proxmox_cluster_ip']}",
                     command],
                    stdout=output, stderr=subprocess.PIPE,
                )
                assert process.stderr is not None
                deadline = time.monotonic() + seconds + 20
                buffered = b""
                try:
                    while True:
                        if time.monotonic() >= deadline:
                            raise TimeoutError(f"{node} capture exceeded its deadline; inspect {log}")
                        if pcap.stat().st_size > 32 * 1024**2:
                            raise RuntimeError(f"{node} capture exceeded 32 MiB; inspect {log}")
                        if not select.select([process.stderr], [], [], 1)[0]:
                            continue
                        chunk = os.read(process.stderr.fileno(), 8192)
                        if not chunk:
                            break
                        errors.write(chunk)
                        errors.flush()
                        buffered = (buffered + chunk)[-8192:]
                        if b"listening on" in buffered:
                            ready.set()
                    status = process.wait(timeout=5)
                    if status not in (0, 124) or not ready.is_set() or pcap.stat().st_size <= 24:
                        raise RuntimeError(f"{node} capture failed (exit {status}); inspect {log}")
                    return {"packets": pcap_packet_count(pcap), "bytes": pcap.stat().st_size}
                finally:
                    if process.poll() is None:
                        process.terminate()
                        try:
                            process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait()
                    process.stderr.close()

    def capture(self, plane, expected, seconds):
        if (plane not in ("l2", "east-west", "north-south")
                or expected not in ("allow", "drop")
                or (plane == "l2" and expected != "allow") or not 30 <= seconds <= 120):
            raise ValueError("capture requires a valid plane/expectation and 30-120 seconds")
        if not self.state.get("ready") or len(self.state["vms"]) != 9:
            raise RuntimeError("lab provisioning is incomplete; inspect its state before capturing")
        nodes = self.state["nodes"]
        if (len(set(nodes)) != 3 or {vm["node"] for vm in self.state["vms"]} != set(nodes)
                or any(not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]*", node) for node in nodes)):
            raise RuntimeError("capture requires the three recorded lab hosts")
        for vm in self.state["vms"]:
            self.vm_config(vm)
        directory = self.directory / "captures" / uuid.uuid4().hex
        directory.mkdir(mode=0o700, parents=True)
        packet_filter = capture_filter(self.state["vms"], plane)
        start = len(self.state["results"])
        manifest = {
            "plane": plane, "expected": expected, "seconds": seconds, "nodes": nodes,
            "filter": packet_filter, "traffic_passed": False, "completed": False,
        }
        print(f"Captures: {directory}", flush=True)
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
                captures = [
                    (threading.Event(), node) for node in nodes
                ]
                futures = [
                    executor.submit(self._capture_host, node, directory, packet_filter, seconds, ready)
                    for ready, node in captures
                ]
                try:
                    for (ready, node), future in zip(captures, futures):
                        if not ready.wait(15):
                            if future.done():
                                future.result()
                            raise TimeoutError(f"{node} tcpdump did not become ready; inspect {directory}")
                    for future in futures:
                        if future.done():
                            future.result()
                            raise RuntimeError("capture ended before probes started; inspect capture logs")
                    if plane == "l2":
                        manifest["endpoints_before"] = self.endpoint_snapshots()
                        if not all(item.get("ready") for item in manifest["endpoints_before"].values()):
                            raise RuntimeError("lab endpoint readiness failed; inspect capture manifest")
                    self.probes(plane, 0, expected)
                    manifest["traffic_passed"] = True
                    if any(future.done() for future in futures):
                        raise RuntimeError("capture ended before probes finished; increase --capture-seconds")
                finally:
                    for (_ready, node), future in zip(captures, futures):
                        manifest.setdefault("captures", {})[node] = future.result()
            manifest["completed"] = True
        finally:
            manifest["results"] = self.state["results"][start:]
            if plane == "l2":
                manifest["endpoints_after"] = self.endpoint_snapshots()
                failed = [result for result in manifest["results"] if not result["passed"]]
                if failed:
                    logs = self.endpoint_logs()
                    manifest["failure_diagnostics"] = [{
                        "flow": result,
                        "pcaps": sorted({
                            f"{node}.pcap" for node in (result["source_node"], result["destination_node"])
                            if node in nodes
                        }),
                        "endpoint_events": [
                            event for events in logs.values() for event in events
                            if event.get("probe_id") == result.get("probe_id") and result.get("probe_id") is not None
                        ],
                    } for result in failed]
            private_write(directory / "manifest.json", manifest)

    def endpoint_snapshots(self):
        snapshots = {}
        for vm in self.state["vms"]:
            try:
                output = self.serial(vm, "python3 /opt/swiftfabric-network-lab.py endpoint-status "
                                     + shlex.quote(vm["address"]))
                status = json.loads(output)
                if (not isinstance(status, dict) or status.get("address") != vm["address"]
                        or type(status.get("ready")) is not bool):
                    raise ValueError("invalid endpoint readiness response; refresh owned guest fixture")
                snapshots[vm["address"]] = status
            except (RuntimeError, ValueError, OSError) as failure:
                snapshots[vm["address"]] = {"ready": False, "error": str(failure)[:512]}
        return snapshots

    def endpoint_logs(self):
        logs = {}
        fields = {"event", "protocol", "stage", "source", "source_port", "destination",
                  "destination_port", "probe_id", "bytes", "epoch"}
        for vm in self.state["vms"]:
            try:
                output = self.serial(vm, "sudo -n journalctl -u swiftfabric-network-lab "
                                     "--no-pager -o cat -n 200")
                events = []
                for line in output[-65536:].splitlines():
                    try:
                        event = json.loads(line)
                        if (isinstance(event, dict) and set(event) == fields
                                and event["event"] == "echo" and event["destination"] == vm["address"]):
                            events.append(event)
                    except ValueError:
                        continue
                logs[vm["address"]] = events[-200:]
            except (RuntimeError, ValueError, OSError):
                logs[vm["address"]] = []
        return logs

    def preflight(self):
        enrolled = {
            host["node"] for host in self.request("GET", "/hosts")
            if host["cluster"] == self.config["proxmox_cluster_name"] and host["status"] == "enrolled"
        }
        if not set(self.state["nodes"]).issubset(enrolled):
            raise RuntimeError("all three requested nodes must already be enrolled in this cluster")
        authorized = self.config.get("auto_enroll_host_list", "all")
        if isinstance(authorized, str) and authorized != "all":
            authorized = [node.strip() for node in authorized.split(",")]
        if authorized != "all" and not set(self.state["nodes"]).issubset(authorized):
            raise RuntimeError("requested nodes are outside auto_enroll_host_list")
        self.router_policy()
        existing, reserved = self.network_inventory()
        for segment in self.state["segments"]:
            network = ipaddress.ip_network(segment["network"])
            if any(network.overlaps(other) for other in reserved if other.version == network.version):
                raise RuntimeError(f"lab subnet {network} overlaps an existing network")
        for current in existing:
            if any(current["id"] == segment["id"] for segment in self.state["segments"]):
                raise RuntimeError(f"segment {current['id']} already exists; refusing to adopt it")
        for node in self.state["nodes"]:
            status = self.proxmox.get(f"/nodes/{node}/status")["data"]
            memory = status["memory"]
            if memory["total"] - memory["used"] < 4 * 1024**3:
                raise RuntimeError(f"{node} needs at least 4 GiB free before deploying three test VMs")
            images = self.proxmox.get(f"/nodes/{node}/storage/{self.state['storage']}/content")["data"]
            if not any(image["volid"] == self.state["image_volume"] for image in images):
                raise RuntimeError(f"configured cloud image is unavailable on {node}")

    def network_inventory(self):
        segments = self.request("GET", "/segments")
        management = ipaddress.ip_network(
            f"{self.config['ip_range_start']}/{self.config['cidr']}", strict=False,
        )
        underlay = ipaddress.ip_network(self.config["vtep_ip_range_cidr"], strict=False)
        reserved = [management, underlay,
                    ipaddress.ip_network(self.request("GET", "/vteps/pool")["cidr"], strict=False)]
        reserved.extend(ipaddress.ip_network(segment["gateway_cidr"], strict=False)
                        for segment in segments if segment.get("gateway_cidr"))
        for node in self.proxmox.get("/nodes")["data"]:
            for device in self.proxmox.get(f"/nodes/{node['node']}/network")["data"]:
                for field in ("cidr", "cidr6"):
                    if device.get(field):
                        reserved.append(ipaddress.ip_network(device[field], strict=False))
        return segments, reserved

    def select_segments(self, first_id, subnet_start, supernet):
        pool = ipaddress.ip_network(supernet)
        first = ipaddress.ip_network(subnet_start)
        private = [ipaddress.ip_network(cidr) for cidr in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16")]
        if (pool.version != 4 or first.version != 4 or first.prefixlen != 24
                or not first.subnet_of(pool) or not any(pool.subnet_of(network) for network in private)):
            raise ValueError("allocation requires an RFC1918 --supernet and an enclosed /24 --subnet-start")
        if not 5000 <= first_id <= 50000:
            raise ValueError("--first-segment-id must be between 5000 and 50000")
        existing, reserved = self.network_inventory()
        used = {segment["id"] for segment in existing}
        identifiers = list(itertools.islice(
            (identifier for identifier in itertools.chain(range(first_id, 50001), range(5000, first_id))
             if identifier not in used), 3,
        ))
        if len(identifiers) != 3:
            raise RuntimeError("fewer than three unused segment IDs available")
        addresses = itertools.chain(
            range(int(first.network_address), int(pool.broadcast_address) + 1, 256),
            range(int(pool.network_address), int(first.network_address), 256),
        )
        networks = []
        for address in addresses:
            candidate = ipaddress.ip_network((address, 24))
            if not any(candidate.overlaps(network) for network in reserved if network.version == 4):
                networks.append(candidate)
                if len(networks) == 3:
                    break
        if len(networks) != 3:
            raise RuntimeError(f"fewer than three non-overlapping /24s available in {pool}")
        self.state["segments"] = segment_plan(
            [f"{identifier}:{network.network_address + 1}/24"
             for identifier, network in zip(identifiers, networks)], self.state["run_id"],
        )
        self.save()
        for segment in self.state["segments"]:
            print(f"Selected segment {segment['id']}: {segment['network']}", flush=True)

    def run(self, first_id, subnet_start, supernet):
        self.state["report_api_start_index"] = len(self.state.get("api_results", []))
        self.state["report_started_epoch"] = time.time()
        try:
            if not self.state["segments"]:
                self.select_segments(first_id, subnet_start, supernet)
            self.create()
            self.acceptance_test()
        finally:
            print(f"Cleaning up owned integration resources; reports retained at {self.directory}", flush=True)
            self.destroy()
        print(f"Full integration suite passed and cleanup completed; reports: {self.directory}", flush=True)

    def create(self):
        self.preflight()
        self.state["original_wan_policy"] = self.router_policy()
        self.save()
        for segment in self.state["segments"]:
            segment["create_requested"] = True
            self.save()
            self.create_segment(segment)
            segment["created"] = True
            self.save()
        time.sleep(self.state["settle_seconds"])
        for segment in self.state["segments"]:
            for index, node in enumerate(self.state["nodes"]):
                vmid = int(self.proxmox.get("/cluster/nextid")["data"])
                network = ipaddress.ip_network(segment["network"])
                address = str(network.network_address + 10 + index)
                if address == segment["gateway_cidr"].split("/")[0]:
                    raise ValueError("lab gateway overlaps a reserved VM address (.10 through .12)")
                vm = {
                    "vmid": vmid, "node": node, "segment_id": segment["id"],
                    "address": address, "name": f"{segment['name']}-h{index + 1}",
                }
                self.prepare_vm(vm, segment, index)
                self.state["vms"].append(vm)
                self.save()
                self.task(self.proxmox.post(f"/nodes/{node}/qemu", data={
                    "vmid": vmid, "name": vm["name"],
                    "description": f"SwiftFabric live network lab {self.state['run_id']}",
                    "cores": 1, "memory": 1024, "onboot": 0, "ciupgrade": 0,
                    "net0": f"virtio,bridge=sf-br{segment['id']},firewall=1",
                    "scsihw": "virtio-scsi-pci",
                    "scsi0": f"{self.state['storage']}:0,import-from={self.state['image_volume']}",
                    "ide2": f"{self.state['storage']}:cloudinit",
                    "boot": "order=scsi0", "serial0": "socket", "vga": "serial0",
                    "ciuser": "ubuntu", "cipassword": self.state["console_password"],
                    "ipconfig0": f"ip={address}/24,gw={segment['gateway_cidr'].split('/')[0]}",
                    "nameserver": self.state["dns_address"],
                }))
                self.task(self.proxmox.post(f"/nodes/{node}/qemu/{vmid}/status/start"))
                print(f"Created {vm['name']} VM{vmid} on {node}, {address}", flush=True)
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
            list(executor.map(self.bootstrap, self.state["vms"]))
        self.configure()

    def create_segment(self, segment):
        return self.request("POST", "/segments", {
            key: value for key, value in segment.items()
            if key in ("id", "name", "gateway_cidr", "tenant_id")
        })

    def prepare_vm(self, vm, segment, index):
        pass

    def configure(self):
        if len(self.state["vms"]) != 9:
            raise RuntimeError("all nine VMs must exist before configuring the lab")
        for vm in self.state["vms"]:
            self.setup_serial(vm, "systemctl is-active --quiet swiftfabric-network-lab")
        for segment in self.state["segments"]:
            current = self.owned_segment(segment)
            self.request("PUT", f"/segments/{segment['id']}/north-south-router", {
                "router_id": self.state["router"], "_version": current["_version"],
            })
        self.set_wan(True)
        self.set_acls(True, True)
        self.state["ready"] = True
        self.save()

    def bootstrap(self, vm):
        payload = encode(Path(__file__).with_name("guest.py").read_bytes())
        program = (
            "import base64,gzip,pathlib;"
            f"pathlib.Path('/opt/swiftfabric-network-lab.py').write_bytes(gzip.decompress(base64.b64decode('{payload}')))"
        )
        command = (
            "if ! systemctl is-active --quiet swiftfabric-network-lab; then "
            + "sudo -n python3 -c " + shlex.quote(program)
            + " && sudo -n systemd-run --collect --unit swiftfabric-network-lab "
            + self.endpoint_command(vm)
            + "; fi && systemctl is-active --quiet swiftfabric-network-lab"
        )
        self.setup_serial(vm, command, timeout=300)

    def endpoint_command(self, vm):
        return "/usr/bin/python3 /opt/swiftfabric-network-lab.py serve " + vm["address"]

    def health_target(self, source):
        peers = [vm for vm in self.state["vms"] if vm["segment_id"] == source["segment_id"]]
        index = peers.index(source)
        for offset in range(1, len(peers)):
            target = peers[(index + offset) % len(peers)]
            if target["node"] != source["node"]:
                return target
        raise RuntimeError("endpoint health requires a same-segment peer on another host")

    def probes(self, plane, phase, expected):
        vms = self.state["vms"]
        grouped = []
        for source in vms:
            cases = []
            if plane == "north-south":
                destinations = [{"address": self.state["dns_address"], "segment_id": -1, "node": "WAN"}]
            elif plane == "health":
                destinations = [self.health_target(source)]
            else:
                destinations = [
                    target for target in vms if target != source
                    and ((target["segment_id"] == source["segment_id"]) == (plane == "l2"))
                ]
            for target in destinations:
                protocols = ("tcp", "udp", "icmp") if plane == "l2" else ("tcp", "udp")
                for protocol in protocols:
                    source_port = source.get("next_source_port", 20000)
                    if source_port > 65000:
                        raise RuntimeError("fresh source ports exhausted; create a new lab run")
                    source["next_source_port"] = source_port + 1
                    cases.append({
                        "plane": plane, "phase": phase, "expected": expected,
                        "source": source["address"], "destination": target["address"],
                        "source_node": source["node"], "destination_node": target["node"],
                        "source_address_role": "primary",
                        "destination_address_role": "dns" if plane == "north-south" else "primary",
                        "protocol": protocol, "dns": plane == "north-south",
                        "source_port": source_port,
                        "destination_port": 53 if plane == "north-south" else (TCP_PORT if protocol == "tcp" else UDP_PORT),
                    })
            grouped.append((source, cases))
        self.execute_probes(grouped, plane, phase)

    def execute_probes(self, grouped, plane, phase):
        if getattr(self, "acceptance_assertion_count", None) is not None:
            self.acceptance_assertion_count += sum(len(cases) for _, cases in grouped)
        for _, cases in grouped:
            for case in cases:
                case["traffic_path"] = reporting.traffic_path(case)
                case["purpose"] = reporting.purpose(case)
        recovery = getattr(self, "phase_recovery", None)
        deadline = time.monotonic() + 1800
        for attempt in range(31):
            start_index = len(self.state["results"])
            try:
                return self._execute_probes_once(grouped, plane, phase)
            except TrafficPhaseFailure:
                results = self.state["results"][start_index:]
                if (recovery is None or attempt == 30 or time.monotonic() >= deadline
                        or not recovery(plane, phase, results, attempt + 1, deadline)):
                    raise
                del self.state["results"][start_index:]
                self.save()
                private_write(self.directory / "results.json", self.state["results"])
                # Each replay gets new source ports, never old conntrack flows.
                for source, cases in grouped:
                    port = source.get("next_source_port", 20000)
                    for case in cases:
                        if port > 65000:
                            raise RuntimeError("fresh source ports exhausted during phase recovery")
                        case["source_port"] = port
                        port += 1
                    source["next_source_port"] = port

    def _execute_probes_once(self, grouped, plane, phase):
        self.save()

        def execute(item):
            source, cases = item
            value = encode(json.dumps(cases).encode("utf-8"))
            output = self.serial(source, f"python3 /opt/swiftfabric-network-lab.py probe {shlex.quote(value)}")
            results = json.loads(output)
            if len(results) != len(cases) or any(
                    {key: result[key] for key in case} != case for result, case in zip(results, cases)):
                raise RuntimeError("guest probe results do not match the requested test matrix")
            if any(result["passed"] != (result["outcome"] == case["expected"])
                   for result, case in zip(results, cases)):
                raise RuntimeError("guest probe pass/fail results are inconsistent")
            destinations = {
                vm["address"]: vm for vm in self.state["vms"]
                if vm.get("tenant_id") == source.get("tenant_id")
            }
            for result in results:
                destination = next((
                    vm for vm in self.state["vms"]
                    if vm.get("endpoint_identity", vm["name"]) == result.get("endpoint_identity")
                ), None) if result.get("endpoint_identity") else destinations.get(result["destination"])
                result.update(source_vm=source["name"], source_vmid=source["vmid"])
                if destination is not None:
                    result.update(destination_vm=destination["name"], destination_vmid=destination["vmid"])
            return results

        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
            results = [result for group in executor.map(execute, grouped) for result in group]
        self.state["results"].extend(results)
        self.save()
        private_write(self.directory / "results.json", self.state["results"])
        failed = [result for result in results if not result["passed"]]
        line = f"{plane} phase {phase}: {len(results) - len(failed)}/{len(results)} passed"
        self.state.setdefault("assertion_output", []).append({
            "epoch": time.time(), "line": line,
        })
        self.save()
        print(line, flush=True)
        for result in failed:
            print(json.dumps(result), flush=True)
        if failed:
            raise TrafficPhaseFailure(f"{plane} phase {phase}: {len(failed)} traffic assertions failed")

    def continuity(self, destination, expected_nat_address, seconds, tcp_port, udp_port, protocol="both",
                   echo_format="observed-peer"):
        if protocol not in CONTINUITY_PROTOCOLS:
            raise ValueError("continuity protocol must be both, tcp, or udp")
        if echo_format not in HELD_ECHO_FORMATS:
            raise ValueError("unknown held-flow echo format")
        protocols = CONTINUITY_PROTOCOLS[protocol]
        destination = str(ipaddress.IPv4Address(destination))
        expected_nat_address = str(ipaddress.IPv4Address(expected_nat_address))
        if (type(seconds) is not int or not 30 <= seconds <= 600
                or any(type(port) is not int or not 1 <= port <= 65535 for port in (tcp_port, udp_port))
                or destination == expected_nat_address):
            raise ValueError("continuity requires 30-600 seconds, valid ports, and distinct target/NAT IPs")
        if not self.state.get("ready") or len(self.state["vms"]) != 9:
            raise RuntimeError("lab provisioning is incomplete")
        nodes = self.state["nodes"]
        segments = self.state["segments"]
        if (len(nodes) != 3 or len(set(nodes)) != 3 or len(segments) != 3
                or len({segment["id"] for segment in segments}) != 3
                or {(vm["segment_id"], vm["node"]) for vm in self.state["vms"]}
                != {(segment["id"], node) for segment in segments for node in nodes}):
            raise RuntimeError("continuity requires one owned VM per segment on each of three hosts")
        if any(ipaddress.IPv4Address(destination) in ipaddress.IPv4Network(segment["network"])
               for segment in self.state["segments"]):
            raise ValueError("continuity target must be outside the tenant test segments")
        for vm in self.state["vms"]:
            self.vm_config(vm)
        router = self.request("GET", f"/north-south-routers/{self.state['router']}")
        if str(ipaddress.IPv4Interface(router["wan_address_cidr"]).ip) != expected_nat_address:
            raise RuntimeError("expected NAT address does not match the deployed router WAN address")
        groups = []
        for vm in self.state["vms"]:
            port = vm.get("next_source_port", 20000)
            if port + len(protocols) - 1 > 65000:
                raise RuntimeError("fresh source ports exhausted; create a new lab run")
            groups.append((vm, [
                {
                    "source": vm["address"], "source_port": port + index,
                    "destination": destination, "destination_port": destination_port,
                    "protocol": protocol, "duration_seconds": seconds,
                    "expected_nat_address": expected_nat_address,
                    "echo_format": echo_format,
                }
                for index, (protocol, destination_port) in enumerate(
                    (protocol, tcp_port if protocol == "tcp" else udp_port) for protocol in protocols
                )
            ]))
        for vm, _ in groups:
            vm["next_source_port"] = vm.get("next_source_port", 20000) + len(protocols)
        self.save()
        directory = self.directory / "continuity" / uuid.uuid4().hex
        directory.mkdir(mode=0o700, parents=True)
        report = {
            "completed": False, "passed": False, "results": [], "errors": [],
            "destination": destination, "expected_nat_address": expected_nat_address,
            "duration_seconds": seconds, "router": self.state["router"],
            "protocols": list(protocols),
            "echo_format": echo_format,
            "nat_tuple_verified": False,
            "scope": (
                "held sockets and observed NAT tuples; not replicated kernel counters or fault certification"
                if echo_format == "observed-peer" else
                "held sockets only; plain echo provides no NAT tuple or kernel-counter evidence"
            ),
        }
        private_write(directory / "manifest.json", report)
        source = encode((Path(__file__).with_name("guest.py")).read_bytes())

        def execute(vm, cases):
            def clock_sample():
                before = time.time()
                before_monotonic = time.monotonic()
                raw = self.serial(
                    vm, "python3 -c 'import time; print(time.monotonic())'", timeout=30,
                )
                after_monotonic = time.monotonic()
                after = time.time()
                guest_time = float(raw)
                if (not math.isfinite(guest_time) or guest_time < 0
                        or abs((after - before) - (after_monotonic - before_monotonic)) > 0.1):
                    raise ValueError("invalid clock sample or operator wall clock stepped")
                return {"guest_monotonic": guest_time, "operator_epoch_bounds": [before, after]}

            bootstrap = (
                "import base64,gzip,sys;"
                f"sys.argv=['held-probes','hold',{encode(json.dumps(cases).encode())!r}];"
                f"exec(compile(gzip.decompress(base64.b64decode({source!r})),"
                "'swiftfabric-network-lab-guest','exec'))"
            )
            command = "python3 -c " + "\\\n".join(
                shlex.quote(bootstrap[index:index + 512]) for index in range(0, len(bootstrap), 512)
            )
            before = clock_sample()
            raw = self.serial(vm, command, timeout=seconds + 90)
            private_write(directory / f"vm-{vm['vmid']}.json", raw)
            results = json.loads(raw)
            validate_held_results(cases, results)
            after = clock_sample()
            offsets = [
                epoch - clock["guest_monotonic"]
                for clock in (before, after) for epoch in clock["operator_epoch_bounds"]
            ]
            for result in results:
                if not (before["guest_monotonic"] <= result["started_monotonic"]
                        and result["started_monotonic"] + result["elapsed_seconds"] <= after["guest_monotonic"]):
                    raise ValueError("held observation lies outside its monotonic clock samples")
                result["operator_clock_offset_seconds"] = [min(offsets), max(offsets)]
            private_write(directory / f"vm-{vm['vmid']}.json", {
                "clock_before": before, "clock_after": after, "results": results,
            })
            return results

        print(f"Continuity reports: {directory}", flush=True)
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=9) as executor:
                futures = {executor.submit(execute, vm, cases): vm for vm, cases in groups}
                for future in concurrent.futures.as_completed(futures):
                    vm = futures[future]
                    try:
                        report["results"].extend(future.result())
                    except (RuntimeError, OSError, ValueError) as failure:
                        report["errors"].append({"vmid": vm["vmid"], "error": str(failure)})
                    private_write(directory / "manifest.json", report)
            report["completed"] = not report["errors"] and len(report["results"]) == 9 * len(protocols)
            report["passed"] = report["completed"] and all(result["passed"] for result in report["results"])
            report["nat_tuple_verified"] = report["passed"] and echo_format == "observed-peer"
        finally:
            private_write(directory / "manifest.json", report)
        passed = sum(result["passed"] for result in report["results"])
        print(
            f"held {'/'.join(protocols).upper()} continuity: {passed}/{9 * len(protocols)} passed "
            f"(response gap <=30 seconds; echo format {echo_format})", flush=True,
        )
        if not report["passed"]:
            raise RuntimeError(f"held-flow continuity failed; inspect {directory}")

    def acceptance_test(self):
        evidence = reporting.initial(self.state)
        evidence["api_start_index"] = self.state.pop(
            "report_api_start_index", evidence["api_start_index"],
        )
        evidence["started_epoch"] = self.state.pop("report_started_epoch", evidence["started_epoch"])
        self.state["results"] = []
        self.state["assertion_output"] = []
        self.state["test_complete"] = False
        self.acceptance_assertion_count = 0
        self.save()
        private_write(self.directory / "acceptance.json", {"complete": False})
        reporting.write_report(
            self.directory, evidence, [], self.state.get("api_results", []), private_write,
        )
        succeeded = False
        try:
            evidence.update(reporting.collect(self, ROOT))
            self.test()
            results = self.state["results"]
            apis = self.state.get("api_results", [])[evidence["api_start_index"]:]
            if (not results or len(results) != self.acceptance_assertion_count
                    or not all(r["passed"] for r in results + apis)):
                raise RuntimeError("acceptance results do not match the complete passing matrix")
            succeeded = True
        finally:
            self.state["test_complete"] = succeeded
            self.save()
            evidence.update(
                finished_epoch=time.time(), status="PASS" if succeeded else "FAILED / INCOMPLETE",
                assertion_output=self.state["assertion_output"],
            )
            private_write(self.directory / "acceptance.json", {
                "complete": succeeded, "traffic_assertions": len(self.state["results"]),
                "api_assertions": len(self.state.get("api_results", [])) - evidence["api_start_index"],
                "scope": ("two overlapping tenants; sequential shared standalone NSR"
                          if evidence["tenancy"] else "single tenant; nine VMs"),
                "simultaneous_dual_tenant_nat": False,
            })
            reporting.write_report(
                self.directory, evidence, self.state["results"],
                self.state.get("api_results", []), private_write,
            )
            print(f"Human-readable evidence: {self.directory / 'report.html'}", flush=True)
            self.acceptance_assertion_count = None

    def test(self):
        if not self.state.get("ready") or len(self.state["vms"]) != 9:
            raise RuntimeError("lab provisioning is incomplete; inspect its state before testing")
        self.state["results"] = []
        self.save()
        try:
            self.set_wan(True)
            self.set_acls(False, False)
            self.probes("l2", 1, "allow")
            for phase, (egress, ingress) in enumerate(
                    ((False, False), (True, False), (False, True), (True, True), (False, False)), start=2):
                self.set_acls(egress, ingress)
                if not (egress and ingress):
                    self.probes("health", phase + 10, "allow")
                self.probes("east-west", phase, "allow" if egress and ingress else "drop")
            self.probes("l2", 7, "allow")
            for segment in self.state["segments"]:
                routing = self.request("GET", f"/segments/{segment['id']}/routing")
                if routing["acl"] != {"egress": [], "ingress": []}:
                    raise RuntimeError("North/South acceptance requires empty East/West segment ACLs")
            self.probes("north-south", 8, "allow")
            self.set_wan(False)
            time.sleep(self.state["settle_seconds"])
            self.probes("north-south", 9, "drop")
            self.set_wan(True)
            time.sleep(self.state["settle_seconds"])
            self.probes("north-south", 10, "allow")
        finally:
            self.set_acls(True, True)
            self.set_wan(True)

    def destroy(self, *, router_retired=False):
        for vm in list(reversed(self.state["vms"])):
            try:
                self.vm_config(vm)
            except ProxmoxAPIError as failure:
                if failure.status_code != 404:
                    raise
            else:
                status = self.proxmox.get(f"/nodes/{vm['node']}/qemu/{vm['vmid']}/status/current")["data"]["status"]
                if status != "stopped":
                    self.task(self.proxmox.post(f"/nodes/{vm['node']}/qemu/{vm['vmid']}/status/stop"))
                self.task(self.proxmox.delete(f"/nodes/{vm['node']}/qemu/{vm['vmid']}"))
            self.state["vms"].remove(vm)
            self.save()
        if "original_wan_policy" in self.state and not router_retired:
            self.set_wan(False, restore=True)
        for segment in reversed(self.state["segments"]):
            if not segment.get("create_requested"):
                continue
            try:
                current = self.owned_segment(segment)
            except LabAPIError as failure:
                if failure.status != 404:
                    raise
                segment["created"] = False
                segment["create_requested"] = False
                self.save()
                continue
            if router_retired:
                if current.get("north_south_router") is not None:
                    raise RuntimeError("Retired router still has a segment attachment; refusing segment deletion")
            else:
                self.request("PUT", f"/segments/{segment['id']}/north-south-router", {
                    "router_id": None, "_version": current["_version"],
                })
                current = self.owned_segment(segment)
            self.request("DELETE", f"/segments/{segment['id']}?_version={current['_version']}")
            segment["created"] = False
            segment["create_requested"] = False
            self.save()
        self.state["ready"] = False
        self.save()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=(
        "run", "create", "configure", "test", "html-report", "capture", "continuity", "continuity-report", "destroy",
    ))
    parser.add_argument("--state", type=Path, help="private run directory outside this checkout")
    parser.add_argument("--config", type=Path, default=ROOT / "config.json")
    parser.add_argument("--nodes", nargs=3)
    parser.add_argument("--segments", nargs=3, metavar="ID:GATEWAY/24")
    parser.add_argument("--first-segment-id", type=int, default=49100, help="run: preferred first unused ID")
    parser.add_argument("--subnet-start", default="10.253.244.0/24", help="run: preferred first unused /24")
    parser.add_argument("--supernet", default="10.0.0.0/8", help="run: private subnet allocation pool")
    parser.add_argument("--router", help="existing disposable, deployed NSR ID")
    parser.add_argument("--tenancy", action="store_true",
                        help="run/create: two tenants, 18 VMs, sequential shared standalone NSR")
    parser.add_argument("--image-volume", help="existing Proxmox import volume, e.g. VMData:import/image.qcow2")
    parser.add_argument("--dns-address", default="1.1.1.1")
    parser.add_argument("--settle-seconds", type=int, default=35)
    parser.add_argument("--plane", choices=("l2", "east-west", "north-south"), default="l2")
    parser.add_argument("--expected", choices=("allow", "drop"), default="allow")
    parser.add_argument("--capture-seconds", type=int, default=60)
    parser.add_argument("--capture-batches", type=int, default=1, help="1-10 independent bounded capture batches")
    parser.add_argument("--continuity-target", help="controlled WAN held-echo endpoint IPv4 address")
    parser.add_argument(
        "--continuity-protocol", choices=tuple(CONTINUITY_PROTOCOLS), default="both",
        help="held-flow protocols (default: both); a single protocol does not certify the other",
    )
    parser.add_argument("--expected-nat-address", help="expected router WAN source IPv4 address")
    parser.add_argument("--duration-seconds", type=int, default=120)
    parser.add_argument(
        "--echo-format", choices=HELD_ECHO_FORMATS, default="observed-peer",
        help="plain supports ordinary nonce echo but cannot verify observed WAN NAT tuples",
    )
    parser.add_argument("--tcp-port", type=int, default=TCP_PORT)
    parser.add_argument("--udp-port", type=int, default=UDP_PORT)
    parser.add_argument("--report", type=Path, help="retained continuity manifest for offline event analysis")
    parser.add_argument("--event-start-epoch", type=float)
    parser.add_argument("--event-end-epoch", type=float)
    parser.add_argument("--yes", action="store_true", help="approve creation/deletion of owned test resources")
    args = parser.parse_args()
    if args.tenancy and args.action not in ("run", "create"):
        parser.error("--tenancy selects topology only for run/create; other actions use saved state")
    if args.action == "continuity-report":
        if args.report is None or args.event_start_epoch is None or args.event_end_epoch is None:
            parser.error("continuity-report requires --report, --event-start-epoch, and --event-end-epoch")
        report = continuity_event_report(
            json.loads(args.report.read_text()), args.event_start_epoch, args.event_end_epoch,
        )
        print(json.dumps(report, indent=2))
        if not report["passed"]:
            raise RuntimeError("held flows did not pass and unambiguously span the event window")
        return
    if args.action == "run" and args.state is None:
        args.state = Path.home() / ".local/state/swiftfabric/network-lab" / uuid.uuid4().hex
    if args.state is None:
        parser.error("--state is required for live lab actions")
    directory = args.state.resolve()
    if directory == ROOT or ROOT in directory.parents:
        parser.error("state and console credentials must be kept outside the repository")
    if args.action == "html-report":
        print(reporting.regenerate(directory, private_write))
        return
    if args.action in ("run", "create", "destroy") and not args.yes:
        parser.error("run/create/destroy require explicit --yes")
    if args.action in ("run", "create"):
        if not all((args.nodes, args.router, args.image_volume)) or (args.action == "create" and not args.segments):
            parser.error("run/create require --nodes, --router, and --image-volume; create also requires --segments")
        if len(set(args.nodes)) != 3 or not all(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]*", node) for node in args.nodes):
            parser.error("three distinct, valid Proxmox node names are required")
        if args.settle_seconds < 30:
            parser.error("allow at least 30 seconds for agent reconciliation")
        run_id = uuid.uuid4().hex
        segments = segment_plan(args.segments, run_id) if args.segments else []
        dns_address = str(ipaddress.IPv4Address(args.dns_address))
        directory.mkdir(mode=0o700, parents=True, exist_ok=False)
        private_write(directory / "state.json", {
            "run_id": run_id, "config": str(args.config.resolve()), "nodes": args.nodes,
            "tenancy": args.tenancy,
            "segments": segments, "vms": [], "router": args.router,
            "image_volume": args.image_volume, "storage": args.image_volume.split(":", 1)[0],
            "dns_address": dns_address, "console_password": secrets.token_urlsafe(32),
            "settle_seconds": args.settle_seconds, "results": [], "ready": False,
        })
        print(f"Integration state and reports: {directory}", flush=True)
    descriptor = os.open(directory / "run.lock", os.O_WRONLY | os.O_CREAT, 0o600)
    with os.fdopen(descriptor, "w"):
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as failure:
            raise RuntimeError("another command is already operating on this lab") from failure
        if json.loads((directory / "state.json").read_text()).get("tenancy"):
            from tenancy import TenantLab
            lab = TenantLab(directory)
        else:
            lab = LiveLab(directory)
        if args.action == "run":
            lab.run(args.first_segment_id, args.subnet_start, args.supernet)
        elif args.action == "capture":
            if not 1 <= args.capture_batches <= 10:
                parser.error("--capture-batches must be between 1 and 10")
            failures = []
            for batch in range(args.capture_batches):
                try:
                    lab.capture(args.plane, args.expected, args.capture_seconds)
                except RuntimeError as failure:
                    failures.append(f"batch {batch + 1}: {failure}")
            if failures:
                raise RuntimeError("; ".join(failures))
        elif args.action == "continuity":
            if not args.continuity_target or not args.expected_nat_address:
                parser.error("continuity requires --continuity-target and --expected-nat-address")
            lab.continuity(
                args.continuity_target, args.expected_nat_address,
                args.duration_seconds, args.tcp_port, args.udp_port, args.continuity_protocol,
                args.echo_format,
            )
        elif args.action == "test":
            lab.acceptance_test()
        else:
            getattr(lab, args.action)()


if __name__ == "__main__":
    main()
