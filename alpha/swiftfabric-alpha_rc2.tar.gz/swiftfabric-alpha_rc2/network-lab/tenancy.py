"""Opt-in overlapping-tenant acceptance using one sequentially shared NSR."""

import base64
import copy
import gzip
import ipaddress
import json
import math
from pathlib import Path
import shlex
import time
import uuid

from lab import (
    LiveLab, POLICY_KEYS, TCP_PORT, UDP_PORT, acl_rule,
    private_write, validate_held_results,
)
from deployment.api_retry import request_with_retry


EMPTY_POLICY = {key: [] for key in POLICY_KEYS}
HELD_TCP_PORT = TCP_PORT + 2
HELD_UDP_PORT = UDP_PORT + 2
MIGRATION_FLOW_SECONDS = 120
MIGRATION_TIMEOUT = 180
TENANT_SCOPES = [{
    "path": "/api/v1/**", "methods": ["GET", "POST", "PUT", "PATCH", "DELETE"],
}]
READ_ONLY_SCOPES = [{"path": "/api/v1/**", "methods": ["GET"]}]


def tenant_acl(segments, current, egress, ingress):
    policy = {"egress": [], "ingress": []}
    for network in sorted({segment["network"] for segment in segments} - {current["network"]}):
        for protocol, port in (
            ("tcp", str(TCP_PORT)), ("udp", str(UDP_PORT)),
            ("tcp", str(HELD_TCP_PORT)), ("udp", str(HELD_UDP_PORT)),
        ):
            if egress:
                policy["egress"].append(acl_rule(current["network"], network, protocol, port))
            if ingress:
                policy["ingress"].append(acl_rule(network, current["network"], protocol, port))
    return policy


class TenantLab(LiveLab):
    def checked(self, method, path, body=None, status=200, token=None, label=None):
        started_epoch = time.time()
        started = time.monotonic()
        headers = {"Authorization": f"Bearer {token}"} if token else {}
        response = request_with_retry(
            self.api,
            method, self.base_url + path, json=body, headers=headers, timeout=(5, 120),
        )
        result = {
            "case": label or f"{method} {path}", "status": response.status_code,
            "expected_status": status, "passed": response.status_code == status,
            "credential_kind": "scoped-key" if token else "global",
            "method": method, "path": path, "started_epoch": started_epoch,
            "elapsed_ms": round((time.monotonic() - started) * 1000, 2),
        }
        self.state.setdefault("api_results", []).append(result)
        self.save()
        private_write(self.directory / "api-results.json", self.state["api_results"])
        if not result["passed"]:
            raise RuntimeError(f"{result['case']}: expected HTTP {status}, got {response.status_code}")
        if status >= 400 and response.headers.get("Content-Type", "").split(";")[0] != "application/json":
            return None
        return response.json() if response.content else None

    def router(self):
        router = self.request("GET", f"/north-south-routers/{self.state['router']}")
        if (router["status"] != "active" or router.get("ha_state_sync_enabled")
                or router.get("deployment_mode") != "standalone"):
            raise RuntimeError("tenancy tests require an active standalone disposable NSR")
        original = self.state.get("router_identity")
        if original:
            if any(router.get(key) != original.get(key) for key in ("id", "name", "vmid")):
                raise RuntimeError("NSR identity changed outside the lab; refusing mutation")
            allowed = {self.state["wan_tenant"], self.state.get("pending_wan_tenant")}
            if router["tenant_id"] not in allowed:
                raise RuntimeError("NSR tenant changed outside the lab; refusing mutation")
        return router

    def preflight(self):
        for segment in self.state["segments"]:
            gateway = ipaddress.ip_interface(segment["gateway_cidr"])
            offset = int(gateway.ip) - int(gateway.network.network_address)
            if offset in (10, 11, 12):
                raise RuntimeError("tenant lab gateways cannot use tenant VM addresses .10 through .12")
        router = self.router()
        if any(router[key] for key in POLICY_KEYS):
            raise RuntimeError("shared test NSR must start with empty WAN ACL/NAT policy")
        existing = self.request("GET", "/segments")
        if any((segment.get("north_south_router") or {}).get("id") == self.state["router"]
               for segment in existing):
            raise RuntimeError("shared test NSR must start unattached")
        if len(self.state["segments"]) == 3:
            tenants = self.request("GET", "/tenants")
            if not any(tenant["id"] == "default" for tenant in tenants):
                raise RuntimeError("controller did not bootstrap the protected default tenant")
            first = router["tenant_id"]
            second = f"tenant-{uuid.uuid4()}"
            self.state.update({
                "tenant_ids": [first, second], "wan_tenant": first,
                "router_identity": {key: router.get(key) for key in ("id", "name", "vmid")},
                "new_tenant": {"id": second, "name": f"sf-lab-{self.state['run_id'][:16]}"},
            })
            used = {segment["id"] for segment in existing + self.state["segments"]}
            free = [identifier for identifier in range(49100, 50001) if identifier not in used]
            free += [identifier for identifier in range(5000, 49100) if identifier not in used]
            if len(free) < 3:
                raise RuntimeError("three additional unused segment IDs required for overlapping tenants")
            mirrors = []
            for segment, identifier in zip(self.state["segments"], free):
                segment["tenant_id"] = first
                mirrors.append({
                    **segment, "id": identifier, "name": segment["name"] + "-t2",
                    "tenant_id": second,
                })
            self.state["segments"].extend(mirrors)
            self.save()
        super().preflight()
        for node in self.state["nodes"]:
            memory = self.proxmox.get(f"/nodes/{node}/status")["data"]["memory"]
            if memory["total"] - memory["used"] < 7 * 1024**3:
                raise RuntimeError(f"{node} needs 7 GiB free before deploying six test VMs")

    def create_segment(self, segment):
        body = {key: segment[key] for key in ("id", "name", "gateway_cidr", "tenant_id")}
        if segment["tenant_id"] == self.state["tenant_ids"][1] and not self.state.get("tenant_created"):
            overlap = {**body, "tenant_id": self.state["tenant_ids"][0]}
            if not self.state.get("tenant_create_requested"):
                before_tenants = self.request("GET", "/tenants")
                before_segments = self.request("GET", "/segments")
                conflict = self.checked("POST", "/segments", overlap, status=409, label="overlap requires confirmation")
                if not isinstance(conflict, dict):
                    raise RuntimeError("overlap response lacks a structured JSON tenant confirmation")
                suggestion = conflict.get("suggested_tenant", {})
                identifier = suggestion.get("id", "")
                try:
                    canonical_id = "tenant-" + str(uuid.UUID(identifier.removeprefix("tenant-")))
                except ValueError as failure:
                    raise RuntimeError("overlap response lacks a canonical tenant UUID") from failure
                if (conflict.get("code") != "tenant_overlap"
                        or not conflict.get("conflicting_segments")
                        or identifier != canonical_id or suggestion.get("name") != identifier):
                    raise RuntimeError("overlap response lacks structured tenant confirmation")
                if (self.request("GET", "/tenants") != before_tenants
                        or self.request("GET", "/segments") != before_segments):
                    raise RuntimeError("unconfirmed overlap changed controller resources")
                self.state["tenant_create_requested"] = True
                self.save()
            body = {**overlap, "new_tenant": self.state["new_tenant"]}
        result = self.request("POST", "/segments", body)
        if result.get("tenant_id") != segment["tenant_id"]:
            raise RuntimeError("created segment has incorrect tenant ownership")
        if segment["tenant_id"] == self.state["tenant_ids"][1]:
            self.state["tenant_created"] = True
            self.save()
        return result

    def prepare_vm(self, vm, segment, index):
        network = ipaddress.ip_network(segment["network"])
        vm.update({
            "tenant_id": segment["tenant_id"], "endpoint_identity": vm["name"],
            "address": str(network.network_address + 10 + index),
        })

    def endpoint_command(self, vm):
        return ("/usr/bin/python3 /opt/swiftfabric-network-lab.py serve "
                + vm["address"] + " --identity "
                + shlex.quote(vm["endpoint_identity"]))

    def set_wan(self, allowed, restore=False):
        self.router()
        snapshot = self.request(
            "GET", f"/north-south-routers/{self.state['router']}/wan-policy",
        )
        self.verify_wan_policy(snapshot)
        policy = copy.deepcopy(EMPTY_POLICY)
        if not restore:
            for segment in self.state["segments"]:
                if segment["tenant_id"] != self.state["wan_tenant"]:
                    continue
                policy["masquerade_source_cidrs"].append(segment["network"])
                if allowed:
                    for protocol in ("tcp", "udp"):
                        policy["wan_egress_rules"].append(acl_rule(
                            segment["network"], f"{self.state['dns_address']}/32", protocol, "53",
                        ))
        self.state["pending_wan_policy"] = policy
        self.save()
        policy_version = snapshot["_version"]
        request_policy = {**policy, "_version": policy_version}
        updated = self.request("PUT", f"/north-south-routers/{self.state['router']}/wan-policy", request_policy)
        if any(updated[key] != policy[key] for key in POLICY_KEYS):
            raise RuntimeError("NSR did not retain requested lab policy")
        self.state["last_wan_policy"] = policy
        self.state.pop("pending_wan_policy", None)
        self.save()

    def router_policy(self):
        router = self.router()
        self.verify_wan_policy(router)
        return {key: router[key] for key in POLICY_KEYS}

    def verify_wan_policy(self, router):
        current = {key: router[key] for key in POLICY_KEYS}
        expected = self.state.get("last_wan_policy", EMPTY_POLICY)
        pending = self.state.get("pending_wan_policy")
        if current != expected and current != pending:
            raise RuntimeError("WAN policy changed outside the lab; refusing overwrite")

    def switch_tenant(self, tenant_id, attach=True):
        router = self.router()
        self.verify_wan_policy(router)
        owned = {segment["id"]: segment for segment in self.state["segments"]}
        attached = []
        for current in self.request("GET", "/segments"):
            if (current.get("north_south_router") or {}).get("id") != self.state["router"]:
                continue
            if current["id"] not in owned:
                raise RuntimeError("unowned segment attached to shared NSR; refusing handoff")
            self.owned_segment(owned[current["id"]])
            attached.append(current)
        for current in attached:
            self.request("PUT", f"/segments/{current['id']}/north-south-router", {
                "router_id": None, "_version": current["_version"],
            })
        if router["tenant_id"] != tenant_id and any(router[key] for key in POLICY_KEYS):
            self.checked("PUT", f"/north-south-routers/{self.state['router']}/tenant",
                         {"tenant_id": tenant_id, "_version": router["_version"]}, status=409,
                         label="unattached NSR with WAN policy cannot change tenant")
        self.set_wan(False, restore=True)
        self.state["pending_wan_tenant"] = tenant_id
        self.save()
        updated = self.request("PUT", f"/north-south-routers/{self.state['router']}/tenant", {
            "tenant_id": tenant_id, "_version": router["_version"],
        })
        if updated["tenant_id"] != tenant_id:
            raise RuntimeError("NSR tenant handoff did not take effect")
        self.state["wan_tenant"] = tenant_id
        self.state.pop("pending_wan_tenant", None)
        self.save()
        if attach:
            for segment in self.state["segments"]:
                if segment["tenant_id"] == tenant_id:
                    current = self.owned_segment(segment)
                    self.request("PUT", f"/segments/{segment['id']}/north-south-router",
                                 {"router_id": self.state["router"], "_version": current["_version"]})
            self.set_wan(True)
        time.sleep(self.state["settle_seconds"])

    def set_acls(self, egress, ingress):
        for segment in self.state["segments"]:
            self.owned_segment(segment)
            current = self.request("GET", f"/segments/{segment['id']}/acl")
            policy = tenant_acl(self.state["segments"], segment, egress, ingress)
            policy["_version"] = current["_version"]
            self.request("PUT", f"/segments/{segment['id']}/acl", policy)
        time.sleep(self.state["settle_seconds"])

    def configure(self):
        if len(self.state["vms"]) != 18:
            raise RuntimeError("all 18 tenant VMs must exist before configuration")
        self.verify_tenant_metadata()
        for vm in self.state["vms"]:
            self.vm_config(vm)
            self.setup_serial(vm, "systemctl is-active --quiet swiftfabric-network-lab")
        self.switch_tenant(self.state["tenant_ids"][0])
        self.set_acls(True, True)
        self.state["ready"] = True
        self.save()

    def verify_tenant_metadata(self):
        catalog = {tenant["id"]: tenant for tenant in self.request("GET", "/tenants")}
        selected = [catalog[tenant_id] for tenant_id in self.state["tenant_ids"]]
        if (len({tenant["conntrack_zone"] for tenant in selected}) != 2
                or len({tenant["routing_table"] for tenant in selected}) != 2
                or any(not 30000 <= tenant["conntrack_zone"] <= 65534
                       or tenant["routing_table"] != 100000 + tenant["conntrack_zone"]
                       for tenant in selected)):
            raise RuntimeError("tenant routing tables/conntrack zones are not distinct reserved allocations")
        for segment in self.state["segments"]:
            self.owned_segment(segment)
            routing = self.request("GET", f"/segments/{segment['id']}/routing")
            if (routing["tenant_id"] != segment["tenant_id"]
                    or routing["tenant"] != catalog[segment["tenant_id"]]
                    or routing["gateway_cidr"] != segment["gateway_cidr"]):
                raise RuntimeError("segment routing metadata does not match its tenant allocation")
        self.state["tenant_metadata"] = selected
        self.save()

    def probes(self, plane, phase, expected):
        grouped = []
        networks = {segment["id"]: segment["network"] for segment in self.state["segments"]}
        gateways = {segment["id"]: segment["gateway_cidr"].split("/")[0] for segment in self.state["segments"]}
        for source in self.state["vms"]:
            cases = []
            if plane == "north-south":
                targets = [{"address": self.state["dns_address"], "node": "WAN",
                            "tenant_id": self.state["wan_tenant"]}]
            elif plane == "health":
                targets = [self.health_target(source)]
            elif plane == "l2":
                targets = [target for target in self.state["vms"] if target != source
                           and networks[target["segment_id"]] == networks[source["segment_id"]]]
            else:
                targets = [target for target in self.state["vms"]
                           if networks[target["segment_id"]] != networks[source["segment_id"]]]
            for target in targets:
                overlap_tenant_id = None
                overlap_segment_id = None
                if (plane in ("l2", "east-west")
                        and target.get("tenant_id") != source["tenant_id"]):
                    overlap_tenant_id = target["tenant_id"]
                    overlap_segment_id = target["segment_id"]
                    resolved = next((vm for vm in self.state["vms"]
                                     if vm["tenant_id"] == source["tenant_id"]
                                     and networks[vm["segment_id"]] == networks[overlap_segment_id]
                                     and vm["address"] == target["address"]), None)
                    if resolved is None:
                        raise RuntimeError("overlapping IP has no matching VM in the source tenant")
                    target = resolved
                    if plane == "l2" and target is source:
                        continue
                same = target.get("tenant_id") == source["tenant_id"]
                permitted = (source["tenant_id"] == self.state["wan_tenant"]
                             if plane == "north-south" else same)
                protocols = ("tcp", "udp", "icmp") if plane == "l2" and same else ("tcp", "udp")
                for protocol in protocols:
                    port = source.get("next_source_port", 20000)
                    if port > 65000:
                        raise RuntimeError("fresh source ports exhausted; create a new lab run")
                    source["next_source_port"] = port + 1
                    cases.append({
                        "plane": plane, "phase": phase,
                        "expected": expected if permitted else "drop",
                        "source": source["address"],
                        "destination": target["address"],
                        "source_address_role": "primary",
                        "destination_address_role": "dns" if plane == "north-south" else "primary",
                        "source_node": source["node"], "destination_node": target["node"],
                        "source_tenant": source["tenant_id"], "destination_tenant": target.get("tenant_id"),
                        "source_segment": source["segment_id"], "destination_segment": target.get("segment_id"),
                        "overlap_tenant_id": overlap_tenant_id,
                        "overlap_segment_id": overlap_segment_id,
                        "gateway": gateways[source["segment_id"]],
                        "isolation_probe": not same and plane in ("l2", "east-west"),
                        "protocol": protocol, "dns": plane == "north-south", "source_port": port,
                        "endpoint_identity": None if plane == "north-south" else target["endpoint_identity"],
                        "destination_port": 53 if plane == "north-south" else (TCP_PORT if protocol == "tcp" else UDP_PORT),
                    })
            grouped.append((source, cases))
        self.execute_probes(grouped, plane, phase)

    def migration_plan(self, tenant_id):
        nodes = self.state["nodes"]
        if len(nodes) != 3 or len(set(nodes)) != 3:
            raise RuntimeError("tenancy migration requires exactly three distinct enrolled hosts")
        tenant_index = self.state["tenant_ids"].index(tenant_id)
        if tenant_index not in (0, 1):
            raise RuntimeError("migration tenant is not part of this acceptance run")
        segments = [segment for segment in self.state["segments"]
                    if segment["tenant_id"] == tenant_id]
        if len(segments) != 3:
            raise RuntimeError("each migration tenant must own three segments")
        source_segment = segments[0]
        dns_address = str(ipaddress.IPv4Address(self.state["dns_address"]))
        if any(ipaddress.IPv4Address(dns_address) in ipaddress.ip_network(segment["network"])
               for segment in segments):
            raise RuntimeError("North/South migration DNS target must be outside tenant test segments")
        source = next((vm for vm in self.state["vms"]
                       if vm["tenant_id"] == tenant_id
                       and vm["segment_id"] == source_segment["id"]
                       and vm["address"] == str(
                           ipaddress.ip_network(source_segment["network"]).network_address + 10
                       )), None)
        if source is None:
            raise RuntimeError(f"tenant {tenant_id} has no migration source VM")
        if source["node"] not in nodes:
            raise RuntimeError("migration source VM is not on a configured lab host")
        source_index = nodes.index(source["node"])
        preferred_target = nodes[(source_index + 1 + tenant_index) % len(nodes)]
        target_nodes = [preferred_target, *(
            node for node in nodes if node not in (source["node"], preferred_target)
        )]
        east_west_segment = segments[1]
        for target_node in target_nodes:
            endpoint_node = next(node for node in nodes if node not in (source["node"], target_node))
            l2_target = next((vm for vm in self.state["vms"]
                              if vm["tenant_id"] == tenant_id
                              and vm["segment_id"] == source_segment["id"]
                              and vm["node"] == endpoint_node), None)
            east_west_target = next((vm for vm in self.state["vms"]
                                     if vm["tenant_id"] == tenant_id
                                     and vm["segment_id"] == east_west_segment["id"]
                                     and vm["node"] == endpoint_node), None)
            if l2_target is not None and east_west_target is not None:
                break
        else:
            raise RuntimeError("migration traffic endpoints must be on the third enrolled host")
        cases = []
        targets = (
            ("l2", l2_target["address"], l2_target, HELD_TCP_PORT, HELD_UDP_PORT),
            ("east-west", east_west_target["address"], east_west_target,
             HELD_TCP_PORT, HELD_UDP_PORT),
            ("north-south", self.state["dns_address"], None, 53, 53),
        )
        source_port = source.get("next_source_port", 20000)
        if source_port + 5 > 65000:
            raise RuntimeError("fresh source ports exhausted; create a new lab run")
        for plane, destination, endpoint, tcp_port, udp_port in targets:
            for protocol, port in (("tcp", tcp_port), ("udp", udp_port)):
                dns = plane == "north-south"
                cases.append({
                    "case_id": f"{plane}-{protocol}", "plane": plane, "tenant_id": tenant_id,
                    "source": source["address"], "source_port": source_port,
                    "destination": destination, "destination_port": port,
                    "protocol": protocol, "duration_seconds": MIGRATION_FLOW_SECONDS,
                    "expected_nat_address": dns_address if dns else source["address"],
                    "echo_format": "plain" if dns else "observed-peer",
                    "dns": dns,
                    "endpoint_identity": endpoint["endpoint_identity"] if endpoint else None,
                    "destination_vm": endpoint["name"] if endpoint else None,
                })
                source_port += 1
        source["next_source_port"] = source_port
        return {
            "tenant_id": tenant_id, "source": source, "source_node": source["node"],
            "target_node": target_node, "endpoint_node": endpoint_node,
            "endpoints": [l2_target, east_west_target], "cases": cases,
        }

    def migration_preflight(self, plan):
        nodes = self.state["nodes"]
        hosts = self.request("GET", "/hosts")
        enrolled = {node: [
            host for host in hosts
            if host.get("node") == node
            and host.get("cluster") == self.config["proxmox_cluster_name"]
            and host.get("status") == "enrolled"
        ] for node in nodes}
        online = {
            item["node"] for item in self.proxmox.get("/nodes")["data"]
            if item.get("status") == "online"
        }
        for node in nodes:
            if len(enrolled[node]) != 1 or node not in online:
                raise RuntimeError(f"migration host {node} must be online and uniquely enrolled")
        host_bindings = {
            node: {
                "host_id": enrolled[node][0]["host_id"],
                "vtep_ip": enrolled[node][0]["vtep_ip"],
            }
            for node in nodes
        }
        segment_ids = {
            plan["source"]["segment_id"],
            *(vm["segment_id"] for vm in plan["endpoints"]),
        }
        for node in nodes:
            interfaces = self.proxmox.get(f"/nodes/{node}/network")["data"]
            active = {item.get("iface") for item in interfaces if item.get("active") == 1}
            if any(f"sf-br{segment_id}" not in active for segment_id in segment_ids):
                raise RuntimeError(f"{node} lacks an active bridge required by migration traffic")
        for vm in [plan["source"], *plan["endpoints"]]:
            self.reconcile_vm_node(vm)
            self.vm_config(vm)
            status = self.proxmox.get(
                f"/nodes/{vm['node']}/qemu/{vm['vmid']}/status/current",
            )["data"]["status"]
            if status != "running":
                raise RuntimeError(f"migration traffic VM {vm['vmid']} must be running")
        if plan["source"]["node"] != plan["source_node"]:
            raise RuntimeError("migration source VM moved from its planned enrolled host")
        return host_bindings

    def reconcile_vm_node(self, vm):
        resources = self.proxmox.get("/cluster/resources", params={"type": "vm"})["data"]
        matches = [item for item in resources if item.get("vmid") == vm["vmid"]]
        if (len(matches) != 1 or matches[0].get("type") != "qemu"
                or matches[0].get("node") not in self.state["nodes"]):
            raise RuntimeError(f"VM {vm['vmid']} must exist on exactly one recorded host")
        node = matches[0]["node"]
        original = vm["node"]
        try:
            vm["node"] = node
            self.vm_config(vm)
        finally:
            vm["node"] = original
        vm["node"] = node
        self.save()
        return node

    def install_guest_tool(self, vm):
        source = base64.b64encode(gzip.compress(
            Path(__file__).with_name("guest.py").read_bytes(),
        )).decode("ascii")
        program = (
            "import base64,gzip,pathlib;"
            f"pathlib.Path('/opt/swiftfabric-network-lab.py').write_bytes("
            f"gzip.decompress(base64.b64decode('{source}')))"
        )
        self.setup_serial(vm, "sudo -n python3 -c " + shlex.quote(program), timeout=60)

    def start_held_endpoint(self, vm, tenant_index):
        unit = f"sf-lab-migration-{self.state['run_id'][:8]}-t{tenant_index}-ep-{vm['vmid']}"
        command = shlex.join([
            "sudo", "-n", "systemd-run", "--collect", f"--unit={unit}",
            "/usr/bin/python3", "/opt/swiftfabric-network-lab.py", "serve-held",
            vm["address"], "--tcp-port", str(HELD_TCP_PORT), "--udp-port", str(HELD_UDP_PORT),
            "--identity", vm["endpoint_identity"],
        ])
        self.setup_serial(vm, command, timeout=30)
        self.setup_serial(vm, shlex.join([
            "sudo", "-n", "systemctl", "is-active", "--quiet", f"{unit}.service",
        ]), timeout=30)
        return unit

    def start_migration_flows(self, source, plan, tenant_index):
        run_id = self.state["run_id"][:8]
        unit = f"sf-lab-migration-{run_id}-t{tenant_index}-vm-{source['vmid']}"
        directory = "/run/swiftfabric-network-lab-migration"
        stem = f"{run_id}-t{tenant_index}-vm-{source['vmid']}"
        progress_path = f"{directory}/{stem}-progress.json"
        output_path = f"{directory}/{stem}-results.json"
        encoded = base64.b64encode(gzip.compress(
            json.dumps(plan["cases"], separators=(",", ":")).encode("utf-8"),
        )).decode("ascii")
        command = " && ".join((
            shlex.join(["sudo", "-n", "install", "-d", "-m", "700", directory]),
            shlex.join(["sudo", "-n", "rm", "-f", progress_path, output_path]),
            shlex.join([
                "sudo", "-n", "systemd-run", "--collect",
                f"--unit={unit}", f"--property=RuntimeMaxSec={MIGRATION_FLOW_SECONDS + 60}",
                "/usr/bin/python3", "/opt/swiftfabric-network-lab.py", "hold", encoded,
                "--progress-file", progress_path, "--output-file", output_path,
            ]),
        ))
        self.setup_serial(source, command, timeout=30)
        expected = {case["case_id"] for case in plan["cases"]}
        progress = {}
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            read_progress = (
                f"if {shlex.join(['sudo', '-n', 'test', '-s', progress_path])}; then "
                f"{shlex.join(['sudo', '-n', 'cat', progress_path])}; else printf '{{}}'; fi"
            )
            raw = self.setup_serial(source, read_progress, timeout=30)
            progress = json.loads(raw)
            if isinstance(progress, dict) and expected.issubset(progress):
                return {
                    "unit": unit, "progress_path": progress_path,
                    "output_path": output_path, "started": progress,
                }
            time.sleep(1)
        missing = sorted(expected - progress.keys()) if isinstance(progress, dict) else sorted(expected)
        raise TimeoutError(
            "held L2/East-West/North-South flows did not all start; "
            "missing verified responses: " + ", ".join(missing)
        )

    def migration_clock_sample(self, vm):
        before_epoch = time.time()
        before_monotonic = time.monotonic()
        raw = self.serial(vm, "python3 -c 'import time; print(time.monotonic())'", timeout=30)
        after_monotonic = time.monotonic()
        after_epoch = time.time()
        guest_monotonic = float(raw)
        if (not math.isfinite(guest_monotonic) or guest_monotonic < 0
                or abs((after_epoch - before_epoch) - (after_monotonic - before_monotonic)) > 0.1):
            raise ValueError("invalid guest clock sample or operator wall clock stepped")
        return {
            "guest_monotonic": guest_monotonic,
            "operator_epoch_bounds": [before_epoch, after_epoch],
        }

    def migration_workload_view(self, vm):
        source = vm["address"]
        destination = self.state["dns_address"]
        program = f"""import json,pathlib,subprocess
source={source!r}
destination={destination!r}
route=json.loads(subprocess.check_output(["ip","-j","-4","route","get",destination,"from",source]))[0]
device=route["dev"]
addresses=json.loads(subprocess.check_output(["ip","-j","-4","addr","show","dev",device]))[0]
link=json.loads(subprocess.check_output(["ip","-j","link","show","dev",device]))[0]
if not any(address["local"]==source for address in addresses["addr_info"]):
    raise RuntimeError("migration source address missing from guest interface")
neighbors=json.loads(subprocess.check_output(["ip","-j","-4","neigh","show","dev",device]))
print(json.dumps({{"boot_id":pathlib.Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    "source":source,"device":device,"mac":link["address"],"gateway":route.get("gateway"),
    "neighbors":neighbors}}))
"""
        return json.loads(self.setup_serial(
            vm, "python3 -c " + shlex.quote(program), timeout=30,
        ))

    def require_migration_learning(self, plan, baseline, migration, report):
        vm = plan["source"]
        source_binding = migration["source_binding"]
        target_binding = self.wait_for_migration_binding(
            plan, baseline, migration["target"],
        )
        if (source_binding["host_id"] == target_binding["host_id"]
                or source_binding["vtep_ip"] == target_binding["vtep_ip"]):
            raise RuntimeError("live migration did not move the controller binding to a new VTEP")
        current = self.migration_workload_view(vm)
        for field in ("boot_id", "source", "device", "mac", "gateway"):
            if current[field] != baseline[field]:
                raise RuntimeError(f"live migration changed workload {field}")
        if not current["gateway"]:
            raise RuntimeError("workload has no routed gateway after migration")
        gateway_mac = (
            f"02:53:46:00:{vm['segment_id'] >> 8:02x}:"
            f"{vm['segment_id'] & 255:02x}"
        )
        if not any(
            entry.get("dst") == current["gateway"]
            and entry.get("lladdr") == gateway_mac
            and not {"FAILED", "INCOMPLETE"} & set(entry.get("state", []))
            for entry in current["neighbors"]
        ):
            raise RuntimeError("workload gateway ARP did not converge after migration")
        migration["controller_binding"] = {
            key: target_binding[key] for key in ("ip", "mac", "host_id", "vtep_ip")
        }
        migration["workload"] = current
        migration["learning_passed"] = True
        private_write(self.directory / "migration-acceptance.json", report)

    def wait_for_migration_binding(self, plan, baseline, node):
        vm = plan["source"]
        expected = {
            **plan["host_bindings"][node],
            "ip": vm["address"], "mac": baseline["mac"],
        }
        deadline = time.monotonic() + 60
        while time.monotonic() < deadline:
            listing = self.request("GET", f"/segments/{vm['segment_id']}/macs")
            records = [entry for entry in listing["entries"]
                       if entry.get("mac") == baseline["mac"]]
            if len(records) == 1 and all(records[0].get(key) == value
                                         for key, value in expected.items()):
                return records[0]
            time.sleep(2)
        raise TimeoutError(f"controller IP/MAC-to-VTEP binding did not converge on {node}")

    def migrate_vm(self, vm, target, report, tenant_id):
        source = self.reconcile_vm_node(vm)
        if source == target or target not in self.state["nodes"]:
            raise RuntimeError("migration target must be another enrolled lab host")
        path = f"/nodes/{source}/qemu/{vm['vmid']}"
        if self.proxmox.get(path + "/status/current")["data"]["status"] != "running":
            raise RuntimeError("workload must be running before live migration")
        precondition = self.proxmox.get(path + "/migrate", params={"target": target})["data"]
        allowed = precondition.get("allowed_nodes")
        if isinstance(allowed, list) and target not in allowed:
            raise RuntimeError(f"Proxmox rejects migration to {target}")
        if precondition.get("local_resources"):
            raise RuntimeError("workload has local resources blocking live migration")
        event = {
            "tenant_id": tenant_id, "vmid": vm["vmid"], "source": source, "target": target,
            "started_epoch": time.time(), "started_monotonic": time.monotonic(),
            "passed": False,
        }
        report["migrations"].append(event)
        self.state.setdefault("migration_events", []).append(event)
        self.save()
        private_write(self.directory / "migration-acceptance.json", report)
        task = None
        try:
            response = self.proxmox.post(path + "/migrate", {
                "target": target, "online": 1, "with-local-disks": 1,
            })
            task = response.get("data")
            if not isinstance(task, str) or not task.startswith(f"UPID:{source}:"):
                raise RuntimeError("migration did not return an owned source-node task")
            event["task"] = task
            self.save()
            self.proxmox.wait_for_task(task, timeout=MIGRATION_TIMEOUT)
            deadline = time.monotonic() + 30
            while time.monotonic() < deadline:
                if self.reconcile_vm_node(vm) != target:
                    time.sleep(2)
                    continue
                status = self.proxmox.get(
                    f"/nodes/{target}/qemu/{vm['vmid']}/status/current",
                )["data"]["status"]
                if status == "running":
                    event.update(
                        completed_epoch=time.time(), completed_monotonic=time.monotonic(),
                        migration_completed=True,
                    )
                    return event
                time.sleep(2)
            raise TimeoutError(f"VM {vm['vmid']} did not become running on {target}")
        finally:
            actual_node = self.reconcile_vm_node(vm)
            event["actual_node"] = actual_node
            if actual_node != target:
                event["migration_completed"] = False
            self.save()
            private_write(self.directory / "migration-acceptance.json", report)

    def read_migration_results(self, source, worker):
        command = (
            f"while ! {shlex.join(['sudo', '-n', 'test', '-s', worker['output_path']])}; do "
            f"if ! {shlex.join(['sudo', '-n', 'systemctl', 'is-active', '--quiet', worker['unit'] + '.service'])}; then "
            f"{shlex.join(['sudo', '-n', 'systemctl', 'status', worker['unit'] + '.service', '--no-pager'])}; exit 1; fi; "
            "sleep 1; done; "
            + shlex.join(["sudo", "-n", "cat", worker["output_path"]])
        )
        raw = self.setup_serial(source, command, timeout=MIGRATION_FLOW_SECONDS + 60)
        return json.loads(raw)

    @staticmethod
    def verify_migration_overlap(cases, results, migration, before, after):
        validate_held_results(cases, results)
        offsets = [
            epoch - clock["guest_monotonic"]
            for clock in (before, after) for epoch in clock["operator_epoch_bounds"]
        ]
        lower_offset, upper_offset = min(offsets), max(offsets)
        failures = []
        for result in results:
            result["operator_clock_offset_seconds"] = [lower_offset, upper_offset]
            healthy_before = any(
                result["started_monotonic"] + sample["received_seconds"] + upper_offset
                < migration["started_epoch"] for sample in result["samples"]
            )
            healthy_after = any(
                result["started_monotonic"] + sample["received_seconds"] + lower_offset
                > migration["completed_epoch"] for sample in result["samples"]
            )
            result["migration_overlap"] = {
                "healthy_before": healthy_before, "healthy_after": healthy_after,
                "passed": result["passed"] and healthy_before and healthy_after,
            }
            if not healthy_before:
                result["failures"].append("no verified response before migration")
            if not healthy_after:
                result["failures"].append("no verified response after migration")
            result["passed"] = result["migration_overlap"]["passed"]
            if not result["passed"]:
                failures.append(result["case_id"])
        if failures:
            raise RuntimeError("held traffic failed or did not span migration: " + ", ".join(failures))
        return results

    def new_migration_report(self):
        return {
            "complete": False, "passed": False, "flow_duration_seconds": MIGRATION_FLOW_SECONDS,
            "scope": (
                "two overlapping tenants; held same-socket TCP/UDP L2, East/West, and WAN DNS "
                "flows bracket each live migration; DNS does not prove NAT tuple"
            ),
            "migrations": [], "flows": [], "errors": [],
        }

    def migration_acceptance(self, tenant_id, report):
        report_path = self.directory / "migration-acceptance.json"
        try:
            if self.state.get("wan_tenant") != tenant_id:
                raise RuntimeError("shared NSR must be attached to migration tenant")
            router = self.router()
            if router["tenant_id"] != tenant_id:
                raise RuntimeError("shared NSR tenant changed before migration acceptance")
            self.verify_wan_policy(router)
            segments = [segment for segment in self.state["segments"]
                        if segment["tenant_id"] == tenant_id]
            source_address = str(
                ipaddress.ip_network(segments[0]["network"]).network_address + 10,
            )
            source = next(vm for vm in self.state["vms"]
                          if vm["tenant_id"] == tenant_id and vm["address"] == source_address)
            self.reconcile_vm_node(source)
            tenant_index = self.state["tenant_ids"].index(tenant_id)
            plan = self.migration_plan(tenant_id)
            plan["host_bindings"] = self.migration_preflight(plan)
            self.save()
            for vm in [plan["source"], *plan["endpoints"]]:
                self.install_guest_tool(vm)
            endpoint_units = []
            worker = None
            try:
                for endpoint in plan["endpoints"]:
                    endpoint_units.append((
                        endpoint, self.start_held_endpoint(endpoint, tenant_index),
                    ))
                worker = self.start_migration_flows(plan["source"], plan, tenant_index)
                baseline = self.migration_workload_view(plan["source"])
                source_binding = self.wait_for_migration_binding(
                    plan, baseline, plan["source_node"],
                )
                before = self.migration_clock_sample(plan["source"])
                migration = self.migrate_vm(
                    plan["source"], plan["target_node"], report, tenant_id,
                )
                after = self.migration_clock_sample(plan["source"])
                migration["source_binding"] = {
                    key: source_binding[key] for key in ("ip", "mac", "host_id", "vtep_ip")
                }
                self.require_migration_learning(plan, baseline, migration, report)
                results = self.read_migration_results(plan["source"], worker)
                report["flows"].extend(results)
                private_write(report_path, report)
                self.verify_migration_overlap(plan["cases"], results, migration, before, after)
                migration["passed"] = True
                private_write(report_path, report)
            finally:
                for endpoint, unit in reversed(endpoint_units):
                    cleanup = (
                        f"if {shlex.join(['sudo', '-n', 'systemctl', 'is-active', '--quiet', unit + '.service'])}; "
                        f"then {shlex.join(['sudo', '-n', 'systemctl', 'stop', unit + '.service'])}; fi"
                    )
                    self.setup_serial(endpoint, cleanup, timeout=30)
                if worker:
                    cleanup = (
                        f"if {shlex.join(['sudo', '-n', 'systemctl', 'is-active', '--quiet', worker['unit'] + '.service'])}; "
                        f"then {shlex.join(['sudo', '-n', 'systemctl', 'stop', worker['unit'] + '.service'])}; fi"
                    )
                    self.setup_serial(plan["source"], cleanup, timeout=30)
            private_write(report_path, report)
        except Exception as failure:
            report["errors"].append({"error": f"{type(failure).__name__}: {failure}"})
            private_write(report_path, report)
            raise

    def setup_rbac(self):
        for index, tenant in enumerate(self.state["tenant_ids"]):
            for role, scopes in (("writer", TENANT_SCOPES), ("reader", READ_ONLY_SCOPES)):
                name = f"sf-lab-{self.state['run_id']}-t{index}-{role}"
                record = {"name": name, "group_id": f"group-{name}", "tenant_id": tenant, "role": role}
                self.state.setdefault("rbac", []).append(record)
                self.save()
                group = self.request("POST", "/system/groups", {
                    "name": name, "tenant_id": tenant, "scopes": scopes,
                })
                if group["id"] != record["group_id"]:
                    raise RuntimeError("unexpected disposable group identity")
                record["group_created"] = True
                record["user_requested"] = True
                self.save()
                user = self.request("POST", "/system/users", {"username": name, "group_id": group["id"]})
                record["token"] = user["api_key"]
                self.save()

    def rbac_tests(self):
        for record in self.state["rbac"]:
            token = record["token"]
            tenant = record["tenant_id"]
            read_only = record["role"] == "reader"
            write_status = 403 if read_only else 200
            other = next(value for value in self.state["tenant_ids"] if value != tenant)
            foreign = next(segment for segment in self.state["segments"] if segment["tenant_id"] == other)
            own = next(segment for segment in self.state["segments"] if segment["tenant_id"] == tenant)
            visible_segments = None
            me = self.checked("GET", "/system/me", token=token)
            if me["tenant_id"] != tenant or me["is_admin"]:
                raise RuntimeError("tenant key acquired incorrect identity")
            for path in ("/tenants", "/segments", "/north-south-routers"):
                resources = self.checked("GET", path, token=token)
                if path == "/segments":
                    visible_segments = resources
                if not resources or any(value.get("tenant_id", value.get("id")) != tenant for value in resources):
                    # The inactive tenant legitimately has no router.
                    if path != "/north-south-routers" or resources:
                        raise RuntimeError(f"{path} leaked tenant inventory or omitted owned resources")
                if path == "/north-south-routers" and any(
                        set(value) - {
                            "id", "tenant_id", "name", "status", "wan_address_cidr", "static_routes", "updated_at",
                            "_version", *POLICY_KEYS,
                        } for value in resources):
                    raise RuntimeError("tenant NSR view disclosed infrastructure fields")
            visible_own = next(segment for segment in visible_segments if segment["id"] == own["id"])
            self.checked("GET", f"/segments/{visible_own['id']}/routing", token=token)
            self.checked("GET", f"/ip-sets?tenant_id={tenant}", token=token)
            current_acl = self.checked("GET", f"/segments/{own['id']}/acl", token=token)
            own_acl = tenant_acl(self.state["segments"], own, True, True)
            own_acl["_version"] = current_acl["_version"]
            updated_acl = self.checked(
                "PUT", f"/segments/{own['id']}/acl", own_acl,
                status=write_status, token=token,
            )
            own_version = updated_acl["_version"] if write_status == 200 else current_acl["_version"]
            router_path = f"/north-south-routers/{self.state['router']}"
            if tenant == self.state["wan_tenant"]:
                self.checked("GET", router_path, token=token)
                current_segment = self.owned_segment(own)
                self.checked("PUT", f"/segments/{own['id']}/north-south-router",
                             {"router_id": self.state["router"], "_version": current_segment["_version"]},
                             status=write_status, token=token)
            else:
                self.checked("GET", router_path, status=403, token=token)
                self.checked("PUT", router_path + "/wan-policy", EMPTY_POLICY, status=403, token=token)
                current_segment = self.owned_segment(own)
                self.checked("PUT", f"/segments/{own['id']}/north-south-router",
                             {"router_id": self.state["router"], "_version": current_segment["_version"]},
                             status=403 if read_only else 404, token=token)
            for method, path, body in (
                ("GET", f"/segments/{foreign['id']}/routing", None),
                ("GET", f"/tenants/{other}", None),
                ("GET", f"/segments?tenant_id={other}", None),
                ("GET", f"/segments/{foreign['id']}/macs", None),
                ("GET", f"/segments/{foreign['id']}/macs/events", None),
                ("PUT", f"/segments/{foreign['id']}/acl",
                 {"egress": [], "ingress": []}),
                ("GET", f"/ip-sets?tenant_id={other}", None),
                ("PUT", f"/ip-sets?tenant_id={other}", {"sets": []}),
                ("GET", "/hosts", None),
                ("POST", "/tenants", {"name": record["name"] + "-denied"}),
                ("POST", "/system/groups", {"name": record["name"] + "-denied", "tenant_id": other, "scopes": TENANT_SCOPES}),
                ("PUT", f"/north-south-routers/{self.state['router']}/tenant", {"tenant_id": other}),
            ):
                self.checked(method, path, body, status=403, token=token)
            user = self.request("GET", f"/system/users/{record['name']}")
            child = self.checked(
                "POST", "/system/me/keys",
                {"name": "tenant-lab-child", "_version": user["_version"]}, token=token,
            )
            if child["key"]["scopes"] != (READ_ONLY_SCOPES if read_only else TENANT_SCOPES):
                raise RuntimeError("replacement key did not inherit its group's permissions")
            child_token = child["api_key"]
            self.checked("GET", f"/segments/{own['id']}/routing", token=child_token)
            self.checked("GET", f"/segments/{foreign['id']}/routing", status=403, token=child_token)
            self.checked("PUT", f"/segments/{own['id']}/acl",
                         {"egress": [], "ingress": [], "_version": own_version},
                         status=write_status, token=child_token)
            self.checked("POST", "/system/users",
                         {"username": record["name"] + "-admin", "group_id": "administrators"},
                         status=403, token=child_token)
            self.checked("PUT", f"/system/users/{record['name']}/group",
                         {"group_id": "administrators"}, status=403, token=child_token)
            self.checked("POST", "/system/me/keys",
                         {"name": "third-key", "_version": child["_version"]},
                         status=409, token=child_token)
            self.checked(
                "DELETE", f"/system/me/keys/{child['key']['id']}?_version={child['_version']}",
                status=204, token=token,
            )
            self.checked("GET", "/system/me", status=401, token=child_token)

    def test(self):
        if not self.state.get("ready") or len(self.state["vms"]) != 18:
            raise RuntimeError("tenant lab provisioning incomplete")
        if any("witness" in vm for vm in self.state["vms"]):
            raise RuntimeError(
                "saved lab uses secondary witness addresses; recreate it with the primary-IP-only kit"
            )
        tenant_vms = [
            [vm for vm in self.state["vms"] if vm["tenant_id"] == tenant]
            for tenant in self.state["tenant_ids"]
        ]
        if any(len(vms) != 9 or len({vm["address"] for vm in vms}) != 9 for vms in tenant_vms):
            raise RuntimeError("each tenant must have nine VMs with unique primary addresses")
        tenant_addresses = [{vm["address"] for vm in vms} for vms in tenant_vms]
        if tenant_addresses[0] != tenant_addresses[1]:
            raise RuntimeError("tenant acceptance requires identical primary IP spaces")
        self.state["results"] = []
        self.state["test_complete"] = False
        self.state.pop("migration_acceptance", None)
        self.save()
        private_write(self.directory / "acceptance.json", {"complete": False})
        migration_report = self.new_migration_report()
        private_write(self.directory / "migration-acceptance.json", migration_report)
        self.verify_tenant_metadata()
        if not self.state.get("rbac"):
            self.setup_rbac()
        expected = {(tenant, role) for tenant in self.state["tenant_ids"] for role in ("writer", "reader")}
        records = self.state["rbac"]
        if (len(records) != 4 or {(record.get("tenant_id"), record.get("role")) for record in records} != expected
                or any(not record.get("token") for record in records)):
            raise RuntimeError("RBAC provisioning incomplete; clean up this run before retrying")
        self.rbac_tests()
        self.probes("health", 0, "allow")
        self.probes("l2", 1, "allow")
        for phase, (egress, ingress) in enumerate(
                ((False, False), (True, False), (False, True), (True, True), (False, False)), 2):
            self.set_acls(egress, ingress)
            self.probes("health", phase + 10, "allow")
            self.probes("east-west", phase, "allow" if egress and ingress else "drop")
        self.probes("l2", 7, "allow")
        for tenant in self.state["tenant_ids"]:
            self.switch_tenant(tenant)
            router = self.router()
            self.rbac_tests()
            self.set_acls(False, False)
            foreign = next(segment for segment in self.state["segments"] if segment["tenant_id"] != tenant)
            current_foreign = self.owned_segment(foreign)
            self.checked("PUT", f"/segments/{foreign['id']}/north-south-router",
                         {"router_id": self.state["router"], "_version": current_foreign["_version"]}, status=409,
                         label="cross-tenant NSR attachment rejected")
            self.checked("PUT", f"/north-south-routers/{self.state['router']}/tenant",
                         {"tenant_id": foreign["tenant_id"], "_version": router["_version"]}, status=409,
                         label="attached NSR cannot change tenant")
            for segment in self.state["segments"]:
                routing = self.request("GET", f"/segments/{segment['id']}/routing")
                if routing["acl"] != {"egress": [], "ingress": []}:
                    raise RuntimeError("tenant WAN acceptance requires empty segment ACLs")
            self.probes("north-south", f"{tenant}-allow", "allow")
            self.set_wan(False)
            time.sleep(self.state["settle_seconds"])
            self.probes("north-south", f"{tenant}-deny", "drop")
            self.set_wan(True)
            time.sleep(self.state["settle_seconds"])
            self.probes("north-south", f"{tenant}-restore", "allow")
            self.set_acls(True, True)
            self.migration_acceptance(tenant, migration_report)
        migration_report["complete"] = True
        migration_report["passed"] = (
            len(migration_report["flows"]) == 12
            and len(migration_report["migrations"]) == 2
            and all(flow["passed"] for flow in migration_report["flows"])
            and all(migration.get("passed") for migration in migration_report["migrations"])
        )
        private_write(self.directory / "migration-acceptance.json", migration_report)
        if not migration_report["passed"]:
            raise RuntimeError("live migration acceptance did not pass every held-flow assertion")
        self.state["migration_acceptance"] = {
            "complete": True, "passed": True, "flow_assertions": len(migration_report["flows"]),
            "migration_assertions": len(migration_report["migrations"]),
            "report": "migration-acceptance.json",
        }
        self.save()
        self.switch_tenant(self.state["tenant_ids"][0])
        self.set_acls(True, True)
        self.state["test_complete"] = True
        self.save()
        private_write(self.directory / "acceptance.json", {
            "complete": True, "traffic_assertions": len(self.state["results"]),
            "api_assertions": len(self.state.get("api_results", [])),
            "scope": "two overlapping tenants; sequential shared standalone NSR",
            "simultaneous_dual_tenant_nat": False,
            "migration_assertions": self.state["migration_acceptance"]["flow_assertions"],
            "migration_report": self.state["migration_acceptance"]["report"],
        })

    def cleanup_rbac(self):
        for record in self.state.get("rbac", []):
            users = self.request("GET", "/system/users")
            user = next((user for user in users if user["username"] == record["name"]), None)
            if user:
                if (user["group_id"] not in (record["group_id"], "auditors")
                        or (user["group_id"] == "auditors" and user["active"])):
                    raise RuntimeError("disposable user group changed; refusing cleanup")
                if user["active"]:
                    self.request("DELETE", f"/system/users/{record['name']}?_version={user['_version']}")
                    user = self.request("GET", f"/system/users/{record['name']}")
                    if (user["username"] != record["name"] or user["active"]
                            or user["group_id"] not in (record["group_id"], "auditors")):
                        raise RuntimeError("disposable user changed after deactivation; refusing cleanup")
                # Controller retains deactivated users; release their group reference.
                if user["group_id"] != "auditors":
                    self.request("PUT", f"/system/users/{record['name']}/group", {
                        "group_id": "auditors", "_version": user["_version"],
                    })
            groups = self.request("GET", "/system/groups")
            group = next((group for group in groups if group["id"] == record["group_id"]), None)
            if group:
                if group["name"] != record["name"] or group["tenant_id"] != record["tenant_id"]:
                    raise RuntimeError("disposable group ownership changed; refusing cleanup")
                if group.get("active", True):
                    self.request("DELETE", f"/system/groups/{record['group_id']}?_version={group['_version']}")
            record.pop("token", None)
            self.save()

    def destroy(self, *, router_retired=False):
        if "original_wan_policy" in self.state or router_retired:
            routers = self.request("GET", "/north-south-routers")
            if (not isinstance(routers, list) or any(
                    not isinstance(router, dict) or not isinstance(router.get("id"), str)
                    for router in routers)):
                raise RuntimeError("Invalid router inventory; refusing cleanup")
            matches = [router for router in routers if router["id"] == self.state["router"]]
            if len(matches) > 1 or (router_retired and matches):
                raise RuntimeError("Retired router ownership is ambiguous; refusing cleanup")
            router_retired = not matches
        if "original_wan_policy" in self.state and not router_retired:
            self.switch_tenant(self.state["tenant_ids"][0], attach=False)
        self.cleanup_rbac()
        super().destroy(router_retired=router_retired)
        if self.state.get("tenant_create_requested"):
            tenants = self.request("GET", "/tenants")
            tenant = next((tenant for tenant in tenants if tenant["id"] == self.state["new_tenant"]["id"]), None)
            if tenant:
                if tenant["name"] != self.state["new_tenant"]["name"]:
                    raise RuntimeError("lab tenant ownership changed; refusing deletion")
                self.request(
                    "DELETE",
                    f"/tenants/{tenant['id']}?_version={tenant['_version']}",
                )
            self.state["tenant_create_requested"] = False
            self.save()

    def continuity(self, *args, **kwargs):
        raise RuntimeError("continuity requires a single-tenant run; shared-NSR tenancy mode is sequential")

    def capture(self, *args, **kwargs):
        raise RuntimeError("capture requires a single-tenant run; use retained tenant traffic/API matrices")
