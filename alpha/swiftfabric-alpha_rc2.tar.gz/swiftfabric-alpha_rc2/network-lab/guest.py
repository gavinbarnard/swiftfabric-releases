"""Standard-library-only traffic endpoint and probes for disposable lab VMs."""

import argparse
import base64
import concurrent.futures
import errno
import gzip
import hashlib
import ipaddress
import json
import math
import os
import secrets
import select
import socket
import socketserver
import struct
import subprocess
import threading
import time

TCP_PORT = 18080
UDP_PORT = 18081
HELD_FRAME_LIMIT = 4096
HELD_ECHO_FORMATS = ("observed-peer", "plain")
ECHO_LOG_LOCK = threading.Lock()


def echo_event(protocol, stage, data, peer, address):
    event = {
        "event": "echo", "protocol": protocol, "stage": stage,
        "source": peer[0], "source_port": peer[1],
        "destination": address[0], "destination_port": address[1],
        "probe_id": hashlib.sha256(data).hexdigest(), "bytes": len(data),
        "epoch": time.time(),
    }
    with ECHO_LOG_LOCK:
        print(json.dumps(event), flush=True)


class TCPHandler(socketserver.BaseRequestHandler):
    def handle(self):
        self.request.settimeout(5)
        data = self.request.recv(1024)
        echo_event("tcp", "received", data, self.client_address, self.request.getsockname())
        self.request.sendall(echo_response(data, self.server))
        echo_event("tcp", "sent", data, self.client_address, self.request.getsockname())


class UDPHandler(socketserver.BaseRequestHandler):
    def handle(self):
        data, connection = self.request
        echo_event("udp", "received", data, self.client_address, connection.getsockname())
        connection.sendto(echo_response(data, self.server), self.client_address)
        echo_event("udp", "sent", data, self.client_address, connection.getsockname())


class TCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def echo_response(data, server):
    identity = getattr(server, "endpoint_identity", None)
    return data if identity is None else data + b"|" + identity.encode("ascii")


def serve(address, identity=None):
    with TCPServer((address, TCP_PORT), TCPHandler) as tcp, \
            socketserver.ThreadingUDPServer((address, UDP_PORT), UDPHandler) as udp:
        tcp.endpoint_identity = udp.endpoint_identity = identity
        threading.Thread(target=tcp.serve_forever, daemon=True).start()
        udp.serve_forever()


def read_exact(connection, count):
    result = b""
    while len(result) < count:
        chunk = connection.recv(count - len(result))
        if not chunk:
            raise RuntimeError("unexpected TCP EOF")
        result += chunk
    return result


def held_response(data, peer, endpoint_identity=None):
    request = json.loads(data)
    if (not isinstance(request, dict) or set(request) != {"nonce", "sequence"}
            or not isinstance(request["nonce"], str)
            or len(request["nonce"]) != 32
            or type(request["sequence"]) is not int or request["sequence"] < 0):
        raise ValueError("invalid held-flow request")
    response = {**request, "peer": list(peer)}
    if endpoint_identity is not None:
        response["endpoint_identity"] = endpoint_identity
    return json.dumps(response).encode("ascii") + b"\n"


class HeldTCPHandler(socketserver.StreamRequestHandler):
    def handle(self):
        self.request.settimeout(45)
        while data := self.rfile.readline(HELD_FRAME_LIMIT + 1):
            if len(data) > HELD_FRAME_LIMIT or not data.endswith(b"\n"):
                raise ValueError("invalid held-flow TCP framing")
            self.wfile.write(held_response(
                data, self.client_address, getattr(self.server, "endpoint_identity", None),
            ))
            self.wfile.flush()


class HeldUDPHandler(socketserver.BaseRequestHandler):
    def handle(self):
        data, connection = self.request
        if len(data) > HELD_FRAME_LIMIT:
            raise ValueError("oversized held-flow UDP request")
        connection.sendto(held_response(
            data, self.client_address, getattr(self.server, "endpoint_identity", None),
        ), self.client_address)


def serve_held(address, tcp_port=TCP_PORT, udp_port=UDP_PORT, identity=None):
    with TCPServer((address, tcp_port), HeldTCPHandler) as tcp, \
            socketserver.ThreadingUDPServer((address, udp_port), HeldUDPHandler) as udp:
        tcp.endpoint_identity = udp.endpoint_identity = identity
        threading.Thread(target=tcp.serve_forever, daemon=True).start()
        udp.serve_forever()


def held_summary(case, samples, elapsed, error):
    echo_format = case.get("echo_format", "observed-peer")
    if echo_format not in HELD_ECHO_FORMATS:
        raise ValueError("unknown held-flow echo format")
    times = [sample["received_seconds"] for sample in samples]
    boundaries = [0.0, *times, elapsed]
    gap = max(right - left for left, right in zip(boundaries, boundaries[1:]))
    peers = {tuple(sample["peer"]) for sample in samples if sample["peer"] is not None}
    failures = []
    if error:
        failures.append(error)
    if elapsed < case["duration_seconds"]:
        failures.append("observation ended early")
    if len(samples) < 2:
        failures.append("fewer than two verified responses")
    if echo_format == "observed-peer":
        if len(peers) != 1:
            failures.append("observed NAT tuple missing or changed")
        elif next(iter(peers))[0] != case["expected_nat_address"]:
            failures.append("observed source does not match expected WAN NAT address")
    if gap > 30.0:
        failures.append("response gap exceeds thirty seconds")
    return {
        **case, "elapsed_seconds": elapsed, "samples": samples, "error": error,
        "max_response_gap_seconds": gap, "observed_peers": [list(peer) for peer in sorted(peers)],
        "failures": failures, "passed": not failures,
    }


def hold_flow(case, *, progress=None):
    if (case["protocol"] not in ("tcp", "udp")
            or case.get("echo_format", "observed-peer") not in HELD_ECHO_FORMATS
            or type(case["duration_seconds"]) not in (int, float)
            or not math.isfinite(case["duration_seconds"])
            or not 1 <= case["duration_seconds"] <= 1800):
        raise ValueError("held flow requires TCP/UDP and a duration of 1-1800 seconds")
    nonce = secrets.token_hex(16)
    samples = []
    sent = {}
    received = set()
    error = ""
    started = time.monotonic()
    epoch = time.time()
    connected = False
    sequence = 0
    bytes_sent = 0
    bytes_received = 0
    try:
        kind = socket.SOCK_STREAM if case["protocol"] == "tcp" else socket.SOCK_DGRAM
        with socket.socket(socket.AF_INET, kind) as connection:
            connection.settimeout(min(30.0, case["duration_seconds"]))
            connection.bind((case["source"], case["source_port"]))
            connection.connect((case["destination"], case["destination_port"]))
            connected = True
            connection.setblocking(False)
            outgoing = b""
            incoming = b""
            next_send = started
            deadline = started + case["duration_seconds"]
            while (now := time.monotonic()) < deadline:
                if now >= next_send:
                    request = json.dumps({"nonce": nonce, "sequence": sequence}).encode("ascii") + b"\n"
                    sent[sequence] = now - started
                    sequence += 1
                    if kind == socket.SOCK_STREAM:
                        outgoing += request
                    else:
                        try:
                            count = connection.send(request)
                        except BlockingIOError:
                            count = 0
                        if count not in (0, len(request)):
                            raise RuntimeError("partial UDP request")
                        bytes_sent += count
                    next_send = now + 0.25
                readable, writable, _ = select.select(
                    [connection], [connection] if outgoing else [], [],
                    max(0, min(next_send, deadline) - time.monotonic()),
                )
                if writable:
                    try:
                        count = connection.send(outgoing)
                    except BlockingIOError:
                        count = 0
                    outgoing = outgoing[count:]
                    bytes_sent += count
                if not readable:
                    continue
                try:
                    data = connection.recv(65536)
                except BlockingIOError:
                    continue
                if not data:
                    if kind == socket.SOCK_STREAM:
                        raise RuntimeError("held TCP connection closed; reconnection is forbidden")
                    raise RuntimeError("empty held-flow UDP response")
                bytes_received += len(data)
                incoming += data
                if len(incoming) > 65536:
                    raise RuntimeError("held-flow response buffer exceeded limit")
                if kind == socket.SOCK_DGRAM and (not data.endswith(b"\n") or data.count(b"\n") != 1):
                    raise RuntimeError("invalid held-flow UDP framing")
                while b"\n" in incoming:
                    line, incoming = incoming.split(b"\n", 1)
                    if len(line) > HELD_FRAME_LIMIT:
                        raise RuntimeError("oversized held-flow response")
                    reply = json.loads(line)
                    if not isinstance(reply, dict):
                        raise RuntimeError("held-flow response must be an object")
                    number = reply.get("sequence")
                    peer = reply.get("peer")
                    if reply.get("nonce") != nonce or type(number) is not int or number not in sent:
                        raise RuntimeError("held-flow reply does not match this socket's nonce/sequence")
                    expected_identity = case.get("endpoint_identity")
                    if reply.get("endpoint_identity") != expected_identity:
                        raise RuntimeError("held-flow reply has incorrect endpoint identity")
                    if case.get("echo_format", "observed-peer") == "plain":
                        if "peer" in reply:
                            raise RuntimeError("plain echo unexpectedly included a peer observation")
                    else:
                        if (not isinstance(peer, list) or len(peer) != 2
                                or not isinstance(peer[0], str) or type(peer[1]) is not int
                                or not 1 <= peer[1] <= 65535):
                            raise RuntimeError("held-flow reply has no valid observed peer")
                        ipaddress.IPv4Address(peer[0])
                    if number in received:
                        continue
                    received.add(number)
                    samples.append({
                        "sequence": number, "sent_seconds": sent[number],
                        "received_seconds": time.monotonic() - started, "peer": peer,
                    })
                    if progress is not None:
                        progress({
                            "protocol": case["protocol"], "started_monotonic": started,
                            "started_epoch": epoch,
                            "verified_responses": len(samples), "sample": dict(samples[-1]),
                        })
                if len(incoming) > HELD_FRAME_LIMIT:
                    raise RuntimeError("oversized held-flow response")
    except (OSError, RuntimeError, ValueError) as failure:
        error = f"{type(failure).__name__}: {failure}"
    elapsed = time.monotonic() - started
    return {
        **held_summary(case, samples, elapsed, error),
        "started_epoch": epoch, "started_monotonic": started, "connected": connected,
        "requests": sequence, "application_bytes_sent": bytes_sent,
        "application_bytes_received": bytes_received,
    }


def dns_query(transaction):
    return (
        struct.pack("!HHHHHH", transaction, 256, 1, 0, 0, 0)
        + b"\x07example\x03com\x00" + struct.pack("!HH", 1, 1)
    )


def verify_dns_answer(answer, transaction):
    if len(answer) < 12:
        raise RuntimeError("truncated DNS response")
    txid, flags, _, answers, _, _ = struct.unpack("!HHHHHH", answer[:12])
    if txid != transaction or not flags & 0x8000 or flags & 15 or answers == 0:
        raise RuntimeError("invalid DNS response")


def hold_dns_flow(case, *, progress=None):
    if (case["protocol"] not in ("tcp", "udp")
            or case.get("echo_format") != "plain"
            or type(case["duration_seconds"]) not in (int, float)
            or not math.isfinite(case["duration_seconds"])
            or not 1 <= case["duration_seconds"] <= 1800
            or type(case["destination_port"]) is not int
            or not 1 <= case["destination_port"] <= 65535):
        raise ValueError("held DNS flow requires TCP/UDP and a duration of 1-1800 seconds")
    samples = []
    error = ""
    started = time.monotonic()
    epoch = time.time()
    connected = False
    sequence = 0
    bytes_sent = 0
    bytes_received = 0
    pending = {}
    received_transactions = set()
    try:
        kind = socket.SOCK_STREAM if case["protocol"] == "tcp" else socket.SOCK_DGRAM
        with socket.socket(socket.AF_INET, kind) as connection:
            connection.settimeout(3)
            connection.bind((case["source"], case["source_port"]))
            connection.connect((case["destination"], case["destination_port"]))
            connected = True
            deadline = started + case["duration_seconds"]
            next_send = started
            while (now := time.monotonic()) < deadline:
                if now < next_send and kind == socket.SOCK_STREAM:
                    time.sleep(min(next_send - now, deadline - now))
                    continue
                if now >= next_send:
                    transaction = secrets.randbelow(65536)
                    while transaction in pending:
                        transaction = (transaction + 1) % 65536
                    payload = dns_query(transaction)
                    sent = time.monotonic() - started
                    pending[transaction] = (sequence, sent)
                    sequence += 1
                    next_send = max(next_send + 0.25, time.monotonic())
                    if kind == socket.SOCK_DGRAM:
                        count = connection.send(payload)
                        if count != len(payload):
                            raise RuntimeError("partial held DNS UDP request")
                        bytes_sent += count
                if kind == socket.SOCK_STREAM:
                    frame = struct.pack("!H", len(payload)) + payload
                    connection.sendall(frame)
                    bytes_sent += len(frame)
                    answer_length = struct.unpack("!H", read_exact(connection, 2))[0]
                    if not 12 <= answer_length <= 4096:
                        raise RuntimeError("invalid held DNS TCP frame length")
                    answer = read_exact(connection, answer_length)
                    bytes_received += answer_length + 2
                else:
                    connection.settimeout(max(0.001, min(next_send, deadline) - time.monotonic()))
                    try:
                        answer = connection.recv(4096)
                    except socket.timeout:
                        continue
                    bytes_received += len(answer)
                reply_transaction = struct.unpack("!H", answer[:2])[0]
                if reply_transaction not in pending:
                    raise RuntimeError("invalid DNS response: unknown transaction")
                verify_dns_answer(answer, reply_transaction)
                if reply_transaction in received_transactions:
                    continue
                received_transactions.add(reply_transaction)
                number, sent = pending[reply_transaction]
                received = time.monotonic() - started
                sample = {
                    "sequence": number, "sent_seconds": sent,
                    "received_seconds": received, "peer": None,
                }
                samples.append(sample)
                if progress is not None:
                    progress({
                        "protocol": case["protocol"], "started_monotonic": started,
                        "started_epoch": epoch, "verified_responses": len(samples),
                        "sample": dict(sample),
                    })
    except (OSError, RuntimeError, ValueError, struct.error) as failure:
        error = f"{type(failure).__name__}: {failure}"
    elapsed = time.monotonic() - started
    return {
        **held_summary(case, samples, elapsed, error),
        "started_epoch": epoch, "started_monotonic": started, "connected": connected,
        "requests": sequence, "application_bytes_sent": bytes_sent,
        "application_bytes_received": bytes_received,
    }


def write_json_file(path, value):
    temporary = path + ".tmp"
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(value, stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def held_matrix(cases, runner, progress_path=None):
    progress = {}
    lock = threading.Lock()

    def execute(indexed):
        index, case = indexed
        def record(event):
            if progress_path is None:
                return
            case_id = case.get("case_id", str(index))
            with lock:
                if case_id in progress:
                    return
                progress[case_id] = event
                write_json_file(progress_path, progress)
        return runner(case, progress=record if progress_path else None)

    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
        return list(executor.map(execute, enumerate(cases)))


def verify_isolation_route(case):
    if case["expected"] != "drop":
        raise RuntimeError("isolation route checks require a cross-tenant negative probe")
    devices = subprocess.run(["ip", "-j", "-4", "addr"], capture_output=True, text=True, timeout=5)
    routes = subprocess.run(
        ["ip", "-j", "route", "get", case["destination"], "from", case["source"]],
        capture_output=True, text=True, timeout=5,
    )
    if devices.returncode or routes.returncode:
        raise RuntimeError("guest route inspection failed; not evidence of tenant isolation")
    interfaces = [device["ifname"] for device in json.loads(devices.stdout)
                  if any(address.get("local") == case["source"] for address in device["addr_info"])]
    selected = json.loads(routes.stdout)
    source_network = ipaddress.ip_network(case["source"] + "/24", strict=False)
    gateway = None if ipaddress.ip_address(case["destination"]) in source_network else case["gateway"]
    if (len(interfaces) != 1 or interfaces[0] == "lo" or len(selected) != 1
            or selected[0].get("dev") != interfaces[0] or selected[0].get("gateway") != gateway):
        raise RuntimeError("guest route does not match the lab NIC/gateway; not tenant isolation")


def probe(case):
    start = time.monotonic()
    started_epoch = time.time()
    outcome = "error"
    detail = ""
    stage = "start"
    probe_id = None
    try:
        protocol = case["protocol"]
        if protocol == "icmp":
            result = subprocess.run(
                ["ping", "-n", "-c", "1", "-W", "3", "-I", case["source"], case["destination"]],
                capture_output=True, text=True, timeout=5, check=False,
            )
            outcome = "allow" if result.returncode == 0 else "error"
            detail = result.stdout + result.stderr
            stage = "complete" if result.returncode == 0 else "icmp"
        else:
            if case.get("isolation_probe"):
                stage = "route-check"
                verify_isolation_route(case)
            kind = socket.SOCK_STREAM if protocol == "tcp" else socket.SOCK_DGRAM
            with socket.socket(socket.AF_INET, kind) as connection:
                connection.settimeout(3)
                stage = "bind"
                connection.bind((case["source"], case["source_port"]))
                stage = "connect"
                connection.connect((case["destination"], case["destination_port"]))
                if protocol == "tcp" and case["expected"] == "drop":
                    raise RuntimeError("TCP handshake succeeded despite the deny policy")
                if case.get("dns"):
                    transaction = secrets.randbelow(65536)
                    payload = (
                        struct.pack("!HHHHHH", transaction, 256, 1, 0, 0, 0)
                        + b"\x07example\x03com\x00" + struct.pack("!HH", 1, 1)
                    )
                    probe_id = hashlib.sha256(payload).hexdigest()
                    if protocol == "tcp":
                        connection.sendall(struct.pack("!H", len(payload)) + payload)
                        answer = read_exact(connection, struct.unpack("!H", read_exact(connection, 2))[0])
                    else:
                        connection.send(payload)
                        answer = connection.recv(4096)
                    txid, flags, _, answers, _, _ = struct.unpack("!HHHHHH", answer[:12])
                    if txid != transaction or not flags & 0x8000 or flags & 15 or answers == 0:
                        raise RuntimeError("invalid DNS answer")
                    detail = "Verified DNS transaction, response flag, success code and nonempty answer."
                else:
                    payload = secrets.token_bytes(32)
                    probe_id = hashlib.sha256(payload).hexdigest()
                    stage = "send"
                    connection.sendall(payload)
                    stage = "receive"
                    expected = payload
                    if case.get("endpoint_identity") is not None:
                        expected += b"|" + case["endpoint_identity"].encode("ascii")
                    answer = read_exact(connection, len(expected)) if protocol == "tcp" else connection.recv(1024)
                    if answer != expected:
                        raise RuntimeError("echo response did not match this probe's nonce and endpoint identity")
                    detail = ("Verified echo nonce and endpoint identity."
                              if case.get("endpoint_identity") else "Verified echo nonce.")
                outcome = "allow"
                stage = "complete"
    except TimeoutError:
        if stage == "route-check":
            detail = "guest route inspection timed out; not evidence of tenant isolation"
        else:
            outcome = "drop"
            detail = "no response within 3 seconds"
    except OSError as failure:
        detail = f"{type(failure).__name__}: {failure}"
        if (case.get("isolation_probe") and stage in ("connect", "send", "receive")
                and failure.errno in (errno.EHOSTUNREACH, errno.ENETUNREACH)):
            outcome = "drop"
            detail = f"verified cross-tenant route denial: {detail}"
        elif failure.errno == errno.ECONNREFUSED:
            detail = "connection refused: reachable closed port is NOT a policy drop"
    except (RuntimeError, ValueError, struct.error, subprocess.SubprocessError) as failure:
        detail = str(failure)
    purpose = case.get("purpose")
    if purpose:
        detail = f"{purpose} Observation: {detail}"
    return {
        **case, "outcome": outcome, "detail": detail,
        "passed": outcome == case["expected"],
        "elapsed_ms": round((time.monotonic() - start) * 1000, 2),
        "started_epoch": started_epoch, "stage": stage, "probe_id": probe_id,
    }


def endpoint_status(address):
    address = str(ipaddress.IPv4Address(address))
    results = []
    for protocol, port in (("tcp", TCP_PORT), ("udp", UDP_PORT)):
        results.append(probe({
            "source": address, "destination": address, "source_port": 0,
            "destination_port": port, "protocol": protocol, "expected": "allow",
        }))
    return {"address": address, "epoch": time.time(), "ready": all(result["passed"] for result in results),
            "checks": results}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "action", choices=("serve", "probe", "serve-held", "hold", "hold-dns", "endpoint-status"),
    )
    parser.add_argument("value")
    parser.add_argument("--tcp-port", type=int, default=TCP_PORT)
    parser.add_argument("--udp-port", type=int, default=UDP_PORT)
    parser.add_argument("--identity", help="tenant lab endpoint identity included in nonce replies")
    parser.add_argument("--progress-file")
    parser.add_argument("--output-file")
    args = parser.parse_args()
    if args.action == "serve":
        serve(args.value, args.identity)
    elif args.action == "serve-held":
        serve_held(args.value, args.tcp_port, args.udp_port, args.identity)
    elif args.action == "endpoint-status":
        print(json.dumps(endpoint_status(args.value)))
    else:
        cases = json.loads(gzip.decompress(base64.b64decode(args.value)))
        if args.action in ("hold", "hold-dns"):
            runner = hold_dns_flow if args.action == "hold-dns" else None
            if runner is None:
                def runner(case, *, progress=None):
                    flow = hold_dns_flow if case.get("dns") else hold_flow
                    return flow(case, progress=progress)
            results = held_matrix(
                cases, runner, args.progress_file,
            )
        else:
            with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
                results = list(executor.map(probe, cases))
        if args.output_file:
            write_json_file(args.output_file, results)
        print(json.dumps(results))


if __name__ == "__main__":
    main()
