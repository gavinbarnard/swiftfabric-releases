# Live three-plane network acceptance lab

## Short automation command: fresh deployment

For **install -> enroll -> create tenancy lab -> L2/L3 East/West/L3 North/South
and isolation/RBAC tests -> full cleanup**, configure the local
`integration-test.json` once using the
[automation setup](../BUILDING.md#automation-two-short-commands), then run:

```sh
python python_installer/tests_integration/network_tenancy.py
```

For the same suite before and after controller loss and backup restore:

```sh
python python_installer/tests_integration/recovery.py
```

**Both require an empty disposable target and explicit destructive authorization
in the test config.** They automatically provision the NSR and deployment,
return nonzero on failure, and retain private evidence and lab state. On failure,
each prints an exact `recovery.py --cleanup --state ...` or
`network_tenancy.py --cleanup --state ...` command for cleanup after review.
That command loads the saved run and removes lab resources, the disposable NSR,
host enrollment, cluster registration, and controllers, in that order.
NSR and cluster deletion use current inventory `_version` values; missing
versions or stale-version conflicts stop cleanup without deleting controllers.
Successful runs still perform full ordered cleanup automatically. Explicit
cleanup requires reachable controllers and the unchanged deployment config.
It stops nonzero if safe teardown is blocked; it does not restore controllers.
Do not destroy controllers first: `lab.py destroy` alone leaves the NSR VM.
Run from the supervisor checkout with its Python environment activated.

Both runners use the same tenant NSR response checks, including before and
after restore in recovery runs. Tenant-owned `static_routes` are allowed alongside
WAN ACL/NAT policy; unexpected fields, including infrastructure and credentials,
still fail acceptance.

Recovered-forwarding preflight has a thirty-minute deadline and requires two
consecutive ready observations. It checks authoritative guest ownership,
active host agents, attached/unfenced local ports, the on-demand resolution
sink, and consistency of cached remote tunnel/FDB entries. Authenticated peer
bindings populate on demand, so an absent remote cache is not itself a failure.
The subsequent mandatory L2/East-West/North-South traffic tests remain the
connectivity proof. Pending checks print their individual reasons and remain
in private `forwarding-readiness.json` evidence.

### Dual-tenancy live VM migration

The acceptance now live-migrates one source VM in each overlapping tenant
between enrolled hosts while one TCP and one UDP socket per plane stay open.
These are tenant guest VMs attached to `sf-br<segment-id>` bridges; controller
VMs are not migration targets and remain on the real physical L2 network.
Same-segment held echoes cover L2; held echoes to another tenant-owned segment
cover East/West; repeated DNS queries on the same TCP connection and UDP socket
cover North/South through the shared router. Each response is nonce/sequence
verified for L2/East/West, and DNS transaction IDs, response flags and answers
are checked. Every flow must return verified traffic both before and after the
migration, with no response gap over the existing 30-second limit. The
controller's learned IP/MAC-to-host/VTEP entry for each source guest must move
to the target, while the guest MAC, IP, boot ID and gateway ARP remain
unchanged/converged.

VM location checks use Proxmox cluster VM inventory, then verify the lab name,
ownership marker and segment bridge on the current enrolled host before saving
its location. They do not probe configuration paths on other hosts: Proxmox can
return HTTP 500, rather than 404, for a VM that is absent from a node. Migration
completion and failure reconciliation both use this current-host lookup.

The two source VMs have the same overlapping IP in different tenants. One
migration initially targets the second enrolled host and the other targets the
third. Repeated acceptance (including after restore) selects a target from the
source's current placement while keeping both held endpoints on the remaining
third host. With the original stationary endpoints, this reverses the prior
migration; no unmeasured placement reset is required. All three hosts must be
online, enrolled and have the needed segment bridges.
The source VM's boot and TCP/UDP sockets remain live; migration task identity,
actual host, controller binding, response samples, clock bounds and overlap
assertions are retained in the private `migration-acceptance.json` report. DNS
checks prove routed application continuity, not an observed NAT tuple. The existing stationary
matrices still verify cross-tenant isolation; migration checks do not claim
simultaneous dual-tenant WAN access.

Held endpoints and flow workers use `systemd-run --collect` with run-, tenant-
and VM-specific unit names, not the unsupported `systemd-run --replace` option.
Endpoint activation and worker progress are checked before migration begins;
service launch failures stop acceptance and retain the failed run for review.
Permissive tenant segment ACLs allow both stationary probe ports (TCP 18080,
UDP 18081) and held migration ports (TCP 18082, UDP 18083) between the lab
subnets. Denial phases omit those rules; tenant isolation is unchanged.
Startup timeouts name the cases missing verified responses.
Held UDP DNS probes continue sending on the original socket after packet loss,
matching delayed replies to their original transaction and send time. A missing
datagram is not a fatal three-second socket timeout: the unchanged thirty-second
verified-response gap limit determines acceptance. Invalid replies still fail.
Flow observations are retained even when migration overlap validation fails.

## NSR HA pair-local acceptance test

The separate [NSR HA runner](../python_installer/tests_integration/nsr_ha.py)
targets **pair-local active/standby NSR HA**: the two NSR guests' installed
`swiftfabric-router` owns failover (mTLS liveness on TCP 4244, session
replication on TCP 4243, terms with higher-term-wins). The controller is not in
the failover path; it only observes both members through
`GET /api/v1/north-south-routers/:id/ha-status` and requests planned handoffs
through `POST .../ha-failover/planned`. There are no controller leases, arming
endpoints or replica databases. Everything the runner executes on NSR guests is
shell plus `swiftfabric-router --ha-status` and system tools (`nft`,
`systemd-run`); no Python is shipped to or run on NSR guests. (The workload VM
still runs the Python held-flow probe.) The runner requires
`deployment_mode: active-standby`, `ha_replication_mode: asynchronous`, a shared
VTEP and, once deployed, `ha_state_sync_enabled`. This is not production
certification.

After a passing retained run, the optional full-cluster outage gate is:

```sh
venv/bin/python python_installer/tests_integration/nsr_ha.py \
  --test-controller-loss --state /private/integration/nsr-ha-RUN
```

This stops all three owned controllers for twenty minutes, then crashes and
rejoins the active NSR while controllers remain stopped. Gateway reachability,
expired witness observations, cached policy, unchanged ownership before the
crash, ten-second takeover, new sessions and controller-return adoption are
checked through an independent pinned SSH transport. Original TCP/UDP sockets
run for thirty minutes (the held-flow worker accepts durations up to 1800
seconds; ordinary runner limits are unchanged). Controllers are restored even
on failure; the lab remains retained. See [diagnostic helpers](../diag/README.md).

Once buildbox packages and disposable deployment prerequisites are ready:

```sh
python3 python_installer/tests_integration/nsr_ha.py
```

**Destructive, empty disposable target only.** Uses the existing
`integration-test.json` authorization (`allow_destructive: true`), deployment
config, router config, image, three selected nodes and external private state
root. Build committed sources on the buildbox first; exactly one verified
prebuilt API package is required. This command does not build packages.

Topology: three controllers with normal initial host enrollment, **one new
segment and one workload VM**, and **two NSR VMs** forming one HA logical router.
The first selected node hosts the workload and first NSR; the second hosts the
standby. The third selected host is enrolled by the shared installer workflow,
but receives no workload VM. `router_config.node` must equal the first node.
Optional `standby_management_address_cidr` in the router request supplies the
second guest's management address; controller validation remains authoritative.
The test segment defaults to `49100`, `10.253.244.1/24`; occupied IDs/subnets
are rejected, never adopted. Override with `--segment-id` and `--segment`.

WAN endpoint and ports come from local `nsr.json` (`remote_endpoint`, `tcp_port`,
`udp_port`). Its `wan_ip` must agree with the primary router configuration.
Integrated release acceptance uses separate `router2.json` and `nsr2.json`
configurations for the HA router and its second WAN endpoint. The endpoint
must already run the **observed-peer held echo protocol**, not arbitrary/plain
echo or DNS. On that controlled WAN machine, run a copy of `guest.py`, for example:

```sh
python3 guest.py serve-held 203.0.113.3 --tcp-port 2000 --udp-port 2001
```

Use your real endpoint address/ports. The runner does not alter that machine.
It configures only outbound TCP/UDP permission to that endpoint and source NAT
for its owned segment. Segment East/West ACLs remain empty.

The guest opens one TCP socket and one UDP socket, sends nonce/sequence-verified
requests every 250 ms, and records progress privately. **No TCP reconnect or
packet replay.** Both flows must produce eight verified replies through the
expected NAT address before each HA event. Scenarios, in order:

1. **Pair status** – both members fresh and converged on one owner and term,
   peer heard.
2. **Planned handoff** – `POST .../ha-failover/planned` to the standby must
   return `planned_handoff_completed: true`; ownership moves and the term
   increases while held sessions survive.
3. **Replication-link cut** – a self-healing, owned `nft` table on the standby
   drops TCP 4243 for 60 seconds. Forwarding owner, roles and term must not
   change; replication must reconnect after the cut heals and held traffic
   must stay uninterrupted. Dropped-packet counters prove the cut.
4. **Controller-path cut** – owned `nft` tables on both members drop the three
   controller addresses and the API VIP for 60 seconds. The controller must
   lose both members at least once, nobody may change role or term, and held
   traffic must stay uninterrupted.
5. **Active-member crash** – after rechecking physical VM name/management
   identity, Proxmox `status/stop` (not guest shutdown or host power off)
   abruptly stops only the active NSR VM. The standby must promote itself with a
   higher term within 10 seconds. The stopped member is then started again and
   must rejoin as standby without preempting (same owner and term for 30
   seconds), followed by another held-flow check.

Cut tables (`sf_ha_<kind>_<hex>`) are applied and removed by `systemd-run`
timers on the guest, so a lost controller path still heals; nft counter
evidence is saved under `/run` before removal.

Default observation is 120 seconds (`--duration`, 60–600). Reports retain:

- Per-flow survival/loss and unchanged externally observed NAT address/port.
- Last pre-fault to first post-fault-request response gap, maximum response gap,
  and recovery delay bounds incorporating serial clock-sampling uncertainty.
- Event timestamps, successor member and term, pair observations and
  `--ha-status` evidence, unchanged WAN/shared-VTEP/member identities.
- Raw verified samples and application byte counts. These are **not**
  replicated kernel/logical counters or throughput measurements.

The existing held-flow validator uses a 30-second maximum response-gap check.
Initial connection establishment uses the same budget (capped by the requested
flow duration), not a separate three-second timeout. Startup time remains part
of the measured response gap and duration; each flow still uses one socket
without reconnecting. HA events begin only after both protocols have exchanged
verified replies. Preflight progress and terminal errors are retained privately
in the HA run directory as `*-preflight.json`.
That is a test assertion, not a measured product SLA; reports retain measured
gaps even on failure. A new term alone, a VM restart, ping, or a fresh
TCP connection cannot pass session continuity. This scenario does not
certify L2/East/West scope isolation, policy revocation, flow churn or every
failure mode.

Private `ha-report.json` (passes only when every scenario passed), per-scenario
reports, held-probe evidence, lifecycle logs and `recovery.json` remain under
the generated run directory. Each run also writes credential-free `report.html`
and `report-data.json` summaries; raw evidence stays private. `--retain` keeps a passing lab for saved-state
actions (each needs `--state /path/to/run`):

- `--test-partitions` repeats the replication-link and controller-path cuts;
  the lab stays retained.
- `--test-vip` abruptly stops and restores the API-VIP controller VM while
  original WAN sessions are held; NSR ownership and term must not change.
- `--test-rolling-upgrade` upgrades the controllers to a newer prebuilt
  package, then runs the pair rolling upgrade (standby, planned handoff, former
  active; **no failback**) under held sessions, requires both members at the
  target versions with the successor still active, then cleans up.

Without `--retain`, success performs ordered cleanup:
workload VM, attachment/segment, both NSRs, enrollment, cluster registration,
then controllers. Failure/blocked capability retains resources for review and
prints:

```sh
python3 python_installer/tests_integration/nsr_ha.py --cleanup --state /path/to/run
```

Cleanup validates saved ownership/configuration and current mutation versions.
HA lifecycle fences are not bypassed: unsupported or incomplete coordinated
teardown stops cleanup rather than deleting controllers beneath remaining NSRs.
Partial controller installation without saved inventory requires the installer's
printed partial-deployment cleanup command.

The commands documented below instead test **already-deployed controllers,
enrolled hosts, and an existing disposable router**.

By default this opt-in kit creates **nine disposable Ubuntu VMs**: one VM per segment on
each of three already-enrolled Proxmox hosts. It uses three new RFC1918 /24
segments, an existing disposable North/South router, and an existing Ubuntu
cloud-image import volume. No extra management NIC or public WAN address is
needed. VM control uses `serial0`, including when network policy denies traffic.

Live commands bootstrap Proxmox API trust using the deployment config's
`proxmox_ssh_user` and `proxmox_ssh_key`: they read the public Proxmox root CA
over pinned SSH and verify that every online node reports the same CA.
First-use SSH pins require approval. API certificate-chain and hostname
verification remain enabled; the CA copy is temporary and no private CA key
is retrieved.

## Coverage

### Versioned controller API compatibility

Lab mutations use current resource `_version` values: segment attachments and
deletion use segment metadata versions; ACL writes use their independent ACL
snapshot; WAN writes compare the saved lab policy against the same WAN-policy
snapshot that supplies its independent version. Cleanup reloads segment
metadata after detachment and user metadata after deactivation, then versions
group reassignment/deactivation and tenant deletion. Inactive RBAC tombstones
are not deactivated again on resumed cleanup. Stale-version 409 responses stop
the run rather than trigger an overwrite retry or guessed version.

The two-tenant lab persists its proposed tenant UUID before composite
tenant/segment creation and retains it for interrupted-run recovery. It uses
the confirmed `new_tenant` API, not unversioned name-only standalone creation.
After confirmed creation loses its response, retry replays the saved composite
request directly rather than repeat the already-confirmed overlap check.
Authorization-negative tests may deliberately omit versions where the expected
403 proves the caller cannot reach mutation preconditions; successful writes
and cross-tenant attachment validation tests submit the relevant version.
RBAC checks keep API segment metadata separate from the saved lab segment plan:
ACL generation uses the plan's derived `network` field, which is not part of
the API response. Ownership checks also use the saved plan. Plans do not supply
mutation versions: even the cross-tenant NSR attachment rejection test reloads
and ownership-checks current segment inventory before submitting `_version`.
`/system/me` supplies identity, not a mutation version. Before testing scoped
key creation, the supervisor reads the user's current `_version` from
`/system/users/{username}` with its global credential; key mutations still use
the tenant's credentials and the issued key response's updated user version.

| Plane | Checks |
| --- | --- |
| L2 | Same-segment ICMP and nonce-verified TCP/UDP echo between every pair of hosts, before and after routed ACL changes |
| L3 East/West | Every directed segment/host pair, including same-host and cross-host routing; TCP/UDP with neither ACL, only source egress, only destination ingress, both, then withdrawal |
| L3 North/South | With empty segment ACLs: TCP/UDP DNS through WAN NAT from all nine VMs; allowed, WAN ACL removed while NAT stays configured, then allowed again |

Negative probes use fresh, monotonically allocated source ports, including on
repeat runs. They cannot reuse an established flow that bypasses a changed ACL.
Only a response timeout counts as a drop: connection refusal, missing routes,
malformed responses, missing tools, and console failures are test failures.
A TCP handshake succeeding during a deny phase is an immediate failure,
even if the application would subsequently time out.
Remote same-segment endpoint-health probes run before East/West denial phases.
Each VM checks the next peer on another host, exercising the path between
host VTEPs instead of its own guest socket stack. Initial L2 and allowed
East/West traffic already verify primary endpoints, so those phases do not
repeat primary-health checks. Same-host VM-to-VM routing/ACL controls remain:
they test real fabric policy, but are not remote VTEP evidence. DNS success
before and after its denial phase guards against an unavailable WAN service
being mistaken for policy enforcement. Fresh echo nonces and DNS transaction
IDs validate actual responses, not just an open socket.

Segment ACLs contain **only cross-segment test-subnet rules** for TCP 18080 and
UDP 18081. DNS/WAN permissions and source NAT are configured only in the NS
router WAN policy. North/South acceptance explicitly verifies that all three
segment ACLs are empty; WAN access must not depend on East/West permissions.

The default matrix records the number of traffic assertions actually executed.
This is connectivity and policy acceptance, **not** HA failover/session-continuity,
throughput, or outage SLA certification.

E/W source routing hosts check **source egress + destination ingress** allowlists
before forwarding to the destination segment or its remote VTEP. Both default
to deny for new unmatched flows. The VTEP/physical fabric is trusted; receiving
hosts do not repeat routed ACL authorization for decapsulated L2 delivery.
Same-tenant, same-segment traffic remains allowed regardless of routed ACLs.
Cross-tenant isolation still applies even when subnet addresses overlap.
N/S WAN policy is enforced at the NSR, not at the compute host: outbound
traffic needs WAN egress authorization; unsolicited inbound traffic needs
a port mapping plus post-DNAT WAN ingress authorization. Segment ACLs neither
grant WAN access nor block WAN-authorized traffic.

## Overlapping-tenant acceptance

Add `--tenancy` to `run` or `create` for **18 disposable VMs**: two tenants,
three segments per tenant, one VM per segment on each of three enrolled hosts.
The existing nine-VM mode remains unchanged. This mode requires tenant-aware
controllers, compute agents, and the standalone NSR runtime.

The first tenant is the existing test NSR's tenant (normally `default`). The
kit creates a second `tenant-<uuid>` through the explicit overlap-confirmation
API. It first verifies that an unconfirmed overlap returns HTTP 409 without
changing the segment or tenant catalogs. Six globally unique segment IDs use
three /24s duplicated across tenants, with identical gateways and identical
primary VM addresses (`.10` through `.12`). Each VM has exactly one IPv4
address on its virtual adapter; the lab does not add secondary guest addresses.
TCP/UDP replies include the actual VM endpoint identity as well as a fresh nonce.

| Plane | Tenant assertions |
| --- | --- |
| L2 | Same-segment local/remote ICMP and identity-verified TCP/UDP; overlapping destination IPs must resolve to source-tenant VM identity; repeat after ACL changes |
| L3 East/West | Same-tenant local/remote routing across all ACL phases; overlapping destination IPs must resolve to source-tenant VM identity |
| L3 North/South | One shared NSR tested sequentially in each tenant; active tenant DNS/NAT allowed, denied with NAT retained, then allowed again; inactive tenant always denied |
| API/RBAC | Default bootstrap and distinct reserved routing-table/zone metadata; explicit overlap confirmation; rejected cross-tenant attachments; attached/policy-bearing NSR reassignment rejected; tenant-scoped inventory, policy and IP-set access; infrastructure denial; writer/read-only groups per tenant, replacement-key permission inheritance, escalation denial and revocation |

Remote endpoint-health checks use each VM's primary IP and precede overlap-address
tests. Every VM is checked over TCP/UDP from another host; no acceptance health
assertion connects a VM to itself. With identical tenant subnets and primary
addresses, an IPv4 packet carries no destination-tenant selector. Overlap
probes therefore verify that the source tenant's matching VM answers with its
own endpoint identity; they do not claim to send traffic directly into the
other tenant. Tenant boundaries are additionally checked through tenant-scoped
API/RBAC assertions and explicit overlap allocation checks. The acceptance
record stores the actual executed traffic-assertion count and report readers
verify that count matches recorded results. Missing or
misconfigured guest routes,
connection refusal, successful TCP handshakes, malformed responses, and wrong
endpoint identities fail. Ordinary ACL and WAN deny phases still require
timeouts. Acceptance records the number of traffic assertions actually run,
plus API assertions; it does not certify broadcast/multicast leakage or
simultaneous duplicate-tuple conntrack/NAT isolation.

**Use a dedicated, active standalone test NSR with no attachments and completely
empty WAN ACL/NAT policy.** No additional public WAN IP is needed. The kit
detaches its segments, explicitly clears its WAN policy, reassigns the NSR,
then attaches the next tenant's segments. It never silently carries policy
between tenants. HA routers and concurrent policy changes are rejected.
Sequential testing does **not** certify concurrent dual-tenant NAT, HA, or
session continuity through reassignment.

For a complete one-shot command, prerequisites, and cleanup instructions, see
[One-shot tenancy test](#one-shot-tenancy-test).

Allow at least 7 GiB free memory per host. `create --tenancy` accepts the same
three `--segments` specifications as ordinary creation; the kit allocates three
additional free IDs for their overlapping counterparts. Subsequent `configure`,
`test`, and `destroy` commands select tenancy mode from saved state; do not
repeat `--tenancy`. `capture` and `continuity` remain single-tenant-only and
reject tenancy state rather than silently testing half the topology.

`results.json` records traffic including source/destination tenant and segment,
primary/DNS address roles, path classification, and test purpose.
Details identify the exact destination IP role, protocol, expected result,
and isolation/ACL phase, followed by the observed nonce/identity, DNS, timeout,
or error evidence. Reports distinguish cross-host VTEP paths from same-host
policy controls and historical guest-local checks; endpoint replies alone
do not prove packet encapsulation. Regenerating an older HTML report labels
its original paths honestly without changing the historical observations.
`api-results.json` records expected/actual HTTP status without API key contents.
`acceptance.json` is marked incomplete before a test starts and becomes complete
only after every phase and final configuration succeeds. Failed/incomplete runs
must not be treated as acceptance.

### Human-readable evidence

Every `run` or `test` writes a self-contained **`report.html`** in the private run
directory, for both nine-VM and 18-VM modes. It contains phase summaries and one
row per traffic/API assertion: validation purpose, pass/fail, expected/observed
outcome, host, VM name/ID, tenant/segment, endpoints, timestamp, duration and
captured observations. Evidence includes ICMP output, echo nonce hashes and
endpoint-identity verification, DNS validation, and expected/actual API statuses.
It is not a packet capture.

The report snapshots the supervisor/submodule commits, dirty-checkout flags,
executed kit-file SHA-256 fingerprints, enrolled host agent versions, NSR/runtime
versions and topology before cleanup. Source commits and deployed versions are
separate; an uncommitted kit change is never presented as committed/deployed code.
All displayed timestamps are UTC. Guest traffic wall clocks are labelled as
such; they are not certified against the operator clock. Durations use monotonic
clocks. API rows cover the current run (including provisioning assertions), or
only the current test attempt when invoking `test`; prior retries are excluded.
Failed/incomplete test attempts also produce a report; only a complete passing
matrix is labelled PASS.

`evidence.json` retains metadata; `report-data.json` contains the allowlisted
metadata and observations used for rendering. Neither embeds credentials,
private state, API bodies or console transcripts. HTML escapes all displayed
values, loads no external resources, and remains readable after VM deletion.
Treat host names, addresses and topology as operationally sensitive even though
credentials are excluded. Report files remain owner-only.

Regenerate HTML offline from retained report data (no deployment/API access):

```sh
python3 network-lab/lab.py html-report --state /path/to/private/run
```

Cleanup restores the NSR's original tenant, empty policy and unattached state,
then removes owned VMs, segments, test groups and the new tenant. Disposable user
keys are revoked through user deactivation. The controller retains deactivated
user records, so cleanup moves those inactive tombstones to the built-in
non-admin `auditors` group before deleting their tenant groups. It does not claim
to erase user audit history. Run-specific credentials stay in owner-only state;
unknown ownership or external policy/attachment changes stop cleanup.

## One-shot tenancy test

This tests an **existing deployment**. It does not install controllers, enroll
hosts, create the NSR, take backups, or inject a disaster. For that separate
end-to-end flow, see the [disaster-recovery runbook](../BUILDING.md#full-disaster-recovery-one-shot).

Run from the supervisor checkout root. Initialize submodules as described in
[BUILDING.md](../BUILDING.md#supervisor-checkout-and-submodules). If the local
Python environment has not been prepared:

```sh
python3 -m venv venv
venv/bin/python -m pip install -r requirements.txt
```

Before running:

- Controllers and all three selected compute hosts must already be deployed,
  healthy, and running compatible tenant-aware agents. Select hosts permitted
  by `auto_enroll_host_list` in the local deployment `config.json`.
- Reserve at least **7 GiB free RAM per host** for six guests on each host.
  The Ubuntu import volume must already be available on all three hosts.
- Create a **dedicated, deployed, active standalone NSR** with no segment
  attachments and empty WAN ACL/NAT policy. Use its API ID, not its VM ID.
  Its WAN must reach the DNS target over both TCP and UDP port 53.
- Keep the deployment config and SSH keys local. Proxmox SSH uses the configured
  `proxmox_ssh_user`; controller SSH uses `ubuntu`, not `root`. Verify first-use
  SSH fingerprints when prompted. Do not disable HTTPS verification.
- Reserve the router and lab exclusively: no concurrent policy, tenant,
  attachment, or lifecycle edits.

Replace `nsr-test` with the disposable router's ID. Adjust hosts/storage as
needed. Use a new state directory for each run; do not create it beforehand.

```sh
LAB_STATE="$HOME/.local/state/swiftfabric/network-lab/tenancy-$(date -u +%Y%m%dT%H%M%SZ)"

venv/bin/python network-lab/lab.py run --tenancy --yes \
  --config config.json \
  --state "$LAB_STATE" \
  --nodes hunsn3 hunsn4 hunsn5 \
  --router nsr-test \
  --image-volume VMData:import/ubuntu-resolute-server-cloudimg-amd64.qcow2 \
  --dns-address 1.1.1.1
```

The command allocates six segment IDs and three /24s duplicated across two
tenants, creates 18 VMs, and runs all L2, L3 East/West, L3 North/South and tenant
isolation/RBAC phases. The shared NSR is tested **sequentially**, not as concurrent
dual-tenant NAT. It attempts ownership-checked cleanup even on test failure.
It preserves the existing controllers, enrolled hosts, and NSR, restoring the
router's original tenant, empty policy, and unattached state.

Success requires exit status zero, the message `Full integration suite passed
and cleanup completed`, and `acceptance.json` with `complete: true` and
`traffic_assertions` matching the report's traffic results. A fresh full run
currently records **372 API assertions**. Open `$LAB_STATE/report.html` for the
readable evidence; retain `acceptance.json`, `results.json`, `api-results.json`
and the private state.
The directory contains console credentials; do not publish it.

An API read can retry transient transport errors with capped backoff
(1, 3, 5, 10, 20, 40, then 60 seconds) until its thirty-minute deadline.
Guest bootstrap and pre-test service checks retry serial timeouts or closed
connections up to three attempts, with five seconds between attempts. Bootstrap
allows 300 seconds per attempt; service checks allow 120 seconds. Startup is
idempotent: if a lost serial reply follows a successful service start, the next
attempt checks the active service without uploading again or starting a duplicate.
Command failures and ownership mismatches fail immediately. Exhausted retries
report the failed serial stage; they do not automatically redeploy or delete VMs.
Standalone traffic assertions are **not** automatically replayed on failure.
The API retry window is not a deadline for the entire suite.

If cleanup fails, keep the state and resolve the reported ownership or
connectivity issue before retrying only the owned lab teardown:

```sh
venv/bin/python network-lab/lab.py destroy --state "$LAB_STATE" --yes
```

Do not pass `--tenancy` to `destroy` or `test`; saved state selects the topology.
Do not run `test` after a successful one-shot run: its guests were removed.
For a retained lab, use `create --tenancy`, then `test`, then `destroy` as
described under [Separate creation, testing, and cleanup](#separate-creation-testing-and-cleanup).

## Held TCP/UDP and NAT-tuple continuity

The separate `continuity` action holds one TCP connection and one UDP socket
from **each of the nine VMs** to a controlled WAN endpoint. It never reconnects
or replaces sockets. Unique per-flow nonces and monotonically numbered requests
are sent every 250 ms. Replies include the source IP/port observed by the WAN
endpoint, so a changed NAT tuple or an unexpected source address fails acceptance.
Duplicate replies do not count as fresh responses.

On an explicitly authorized, controlled WAN host, run this repository's
standard-library-only endpoint (not the existing one-request echo service):

```sh
python3 network-lab/guest.py serve-held 192.0.2.20 \
  --tcp-port 18080 --udp-port 18081
```

The held TCP endpoint allows 45 seconds of idle time so it does not close an
established socket during an otherwise acceptable 30-second recovery.

Bind only an appropriate interface and restrict endpoint access to the lab WAN
source. Provision that host and the required scoped WAN TCP/UDP permissions
separately, with explicit approval. The kit does not provision a WAN host,
change policy on a running synchronous pair, or assume a public DNS server will
keep a TCP session open. East/West segment ACLs are not WAN permissions.

Then run:

```sh
python3 network-lab/lab.py continuity \
  --state "$HOME/.local/state/swiftfabric/network-lab/run-001" \
  --continuity-target 192.0.2.20 --expected-nat-address 192.0.2.10 \
  --duration-seconds 120 --tcp-port 18080 --udp-port 18081
```

Use the deployed router's actual WAN IP for `--expected-nat-address`; the kit
cross-checks it against the controller before starting. The target must be
outside the three test segments. Duration is bounded to 30-600 seconds. VM
identity and attachment are verified before opening their serial consoles, and
two fresh source ports per VM are reserved durably. The current probe source
runs through the serial console without installing files or restarting services
in the guests. All nine VMs run concurrently, with independent TCP/UDP workers.

If only one protocol is available, explicitly select `--continuity-protocol tcp`
or `--continuity-protocol udp`. For example, a controlled TCP endpoint on port
2000 uses `--continuity-protocol tcp --tcp-port 2000`. This runs nine flows, one
per VM, and records the selected protocol in the manifest and offline event
report. It does not claim coverage of the untested protocol. The default remains
both protocols and 18 flows. Legacy manifests without a protocol declaration
still require all 18 flows; omitting UDP evidence cannot silently pass as TCP-only.

An existing ordinary TCP echo service can be used without replacing it:

```sh
python3 network-lab/lab.py continuity \
  --state "$HOME/.local/state/swiftfabric/network-lab/run-001" \
  --continuity-target 192.0.2.20 --expected-nat-address 192.0.2.10 \
  --continuity-protocol tcp --tcp-port 2000 --echo-format plain \
  --duration-seconds 120
```

It must echo every request on all nine concurrent connections, not close after
one request. Plain echo verifies nonce/sequence responses on the original
sockets but **does not observe or certify the WAN NAT tuple**. Its samples
explicitly record no peer; both live and offline reports identify this reduced
scope. The default `observed-peer` format never falls back to plain echo.
Replicated NAT/kernel state still requires independent evidence in either mode.

Private `continuity/<run-id>/` reports retain each VM's responses, clock
observations, and a manifest, including partial evidence when another VM's
console fails. Unparseable guest output is also retained for diagnosis. The
runner independently recomputes acceptance from validated guest samples.
Every flow must last for the requested duration, keep one observed WAN tuple,
and have a **maximum verified-response gap of at most 30 seconds**.
Initial and trailing silence count toward that bound; a reset, EOF, malformed
reply, wrong nonce, missing evidence, or early exit fails. The unrounded gap is
used for the decision, so exactly 30 seconds passes and anything greater fails.
Sub-five-second interruption is a later optimization goal, not a production
acceptance requirement. Application byte
counts are reported but are **not replicated kernel conntrack/NAT counters**.

This command performs no fault injection, upgrade, or configuration changes.
It can overlap a separately approved operation, but a passing no-fault run is
not failover certification. Use the per-flow start epoch and response times to
verify healthy responses before and after the actual operation, on the same
socket; elapsed seconds use the guest monotonic clock. Serial clock queries
before and after each VM's run conservatively bound its monotonic clock against
the operator machine's epoch clock, without assuming guest UTC synchronization.
Clock-query round-trip uncertainty is retained rather than silently removed.
Run long enough to cover both sides of the operation and that uncertainty.
A run lock prevents concurrent kit commands, not
separately initiated controller operations. No automatic retries or warmups hide
failed flows. Kernel state/counter continuity, exclusive ownership,
survivor/re-pair correctness, and the actual fault overlap still need independent
evidence. This action does not collect packet captures.

Analyze a retained run against a separately recorded operation window offline:

```sh
python3 network-lab/lab.py continuity-report \
  --report /private/run/continuity/RUN_ID/manifest.json \
  --event-start-epoch 1792940000 --event-end-epoch 1792940020
```

Use actual timestamps recorded on the **operator machine**, not guessed times
or a different host's unsynchronized clock. The report command needs no
deployment credentials or live connection. It independently checks all 18
flows, their measurements, and their NAT tuples. Each must have a verified
response unambiguously before the start and after the end, even after applying
the full measured clock uncertainty. Missing clock measurements, an incomplete
matrix, duplicate flow identities, or uncertain overlap cannot pass. A passing
result proves held-flow overlap and response-gap acceptance only; evidence of
which fault occurred, forwarding ownership, replicated kernel counters, and
survivor/re-pair semantics is still separate.

### Remaining HA production-readiness gates

- Established TCP and UDP sessions survive failover without replacing sockets.
- NAT mappings and replicated kernel conntrack counters remain continuous.
- Unexpected active-member loss recovers forwarding safely, with exclusive
  ownership and measured interruption no greater than 30 seconds.
- The historical intermittent L2 UDP failure is explained and its resolution
  verified; subsequent passing connectivity runs alone do not establish a cause.

The 30-second limit concerns traffic interruption, not the total duration of a
controller orchestration job. Sub-five-second interruption remains desirable
but does not block readiness. None of these gates is certified merely by
changing the acceptance threshold.

## Safety and requirements

- Explicitly select three hosts already enrolled in the configured cluster
  and permitted by `auto_enroll_host_list`. Each needs at least 4 GiB free RAM
  before provisioning. The nine VMs use 1 CPU and 1 GiB RAM each.
- Use a disposable deployed standalone router while setting up and
  changing policy. Existing synchronous-HA lifecycle fences are respected;
  this kit does not bypass them or silently skip blocked checks.
- Supply three unused segment IDs and nonoverlapping RFC1918 /24 networks.
  Existing segments, management networks, and the VTEP underlay are not adopted.
- Use the normal deployment configuration for authentication. Controller HTTPS
  validates the deployment CA. Secrets are never printed. The private run
  directory contains the console password and must remain outside this checkout.
- The kit only adds scoped test-subnet/DNS WAN policy; it preserves existing
  port mappings and policy. A concurrent administrator WAN edit stops the kit
  rather than being overwritten. Use a dedicated test router without broad
  existing WAN rules that would invalidate negative-policy assertions.
- NICs use normal Proxmox firewall-backed SwiftFabric bridges. The kit does not
  change host firewall rules, bridge netfilter, host routes, or agent versions.
- Ubuntu must provide Python 3, `ping`, password-based serial console login,
  and passwordless `sudo` for the cloud-init `ubuntu` user. The tested resolute
  cloud image already exposes serial0. No guest packages are downloaded.

## Run

### One-command full suite

Use an existing disposable standalone router and an uploaded cloud
image. Replace the example hosts, router ID, and storage with your lab values:

```sh
python3 network-lab/lab.py run \
  --config config.json \
  --nodes compute1 compute2 compute3 \
  --router nsr-test \
  --image-volume VMData:import/ubuntu-resolute-server-cloudimg-amd64.qcow2 \
  --yes
```

`run` selects three unused segment IDs and non-overlapping RFC1918 /24s,
creates nine test VMs, and runs the entire L2, L3 East/West, and L3 North/South
matrix. It then attempts ownership-checked cleanup even after provisioning or
test failures and Ctrl-C. It restores the original router WAN policy and never
deletes the existing router. Failed cleanup exits nonzero; saved state remains
available for retrying `destroy`. Process termination, power loss, or unavailable
APIs can prevent cleanup; do not delete the state before resolving leftovers.

The printed, unique run directory defaults to
`~/.local/state/swiftfabric/network-lab/<run-id>` and retains state and any
`results.json` evidence. Use `--state /private/new-run` to choose a new directory;
existing run directories are never overwritten.

Allocation starts at ID 49100 and subnet `10.253.244.0/24`, wrapping within IDs
5000–50000 and `10.0.0.0/8` as needed. Override preferences with
`--first-segment-id`, `--subnet-start`, and `--supernet`. The pool must be within
RFC1918 space. Allocation excludes existing segment networks, controller
management, configured/live VTEP pools, and Proxmox interface networks across
the cluster. Free IDs/subnets need not be consecutive. For exact allocations,
pass `--segments` as with `create`; conflicts fail instead of adopting resources.

Creation rechecks live conflicts immediately before provisioning. Inventory is
not a reservation: concurrent changes can still stop the run, and ownership
checks prevent cleanup from deleting unrelated resources. As with manual
testing, use a dedicated router and do not edit its policy during the run.

### Separate creation, testing, and cleanup

Choose values appropriate to the authorized lab. The example assumes the image
has already been uploaded to the indicated shared import storage.

```sh
python3 network-lab/lab.py create \
  --config config.json \
  --state "$HOME/.local/state/swiftfabric/network-lab/run-001" \
  --nodes compute1 compute2 compute3 \
  --segments 49100:10.253.244.1/24 49101:10.253.245.1/24 49102:10.253.246.1/24 \
  --router nsr-test \
  --image-volume VMData:import/ubuntu-resolute-server-cloudimg-amd64.qcow2 \
  --yes

python3 network-lab/lab.py test \
  --state "$HOME/.local/state/swiftfabric/network-lab/run-001"
```

Creation, one-command runs, and destruction require `--yes`. Testing explicitly mutates the test
segments' ACLs and the test router's scoped WAN additions. The default 35-second
settling interval allows compute and router reconciliation; it is not a measured
convergence bound. A failing phase exits nonzero with individual traffic
failures. The private run directory retains atomic state and machine-readable
`results.json`; incomplete provisioning is not reported as success.

If all nine VMs and their endpoint services were provisioned but a subsequent
attachment/policy operation failed, correct that error and resume only
configuration without recreating or adopting resources:

```sh
python3 network-lab/lab.py configure \
  --state "$HOME/.local/state/swiftfabric/network-lab/run-001"
```

Earlier provisioning failures retain the resource manifest for ownership-checked
cleanup; do not rerun `create` against an existing run directory.

When provisioned and after testing (including a failed test), the scoped
cross-segment TCP/UDP test rules remain installed and visible in the UI.
The test temporarily removes and reapplies them for its deny phases.
All other East/West traffic remains denied. Scoped WAN DNS/NAT is restored.
Keep the VMs for diagnosis or run ownership-checked cleanup:

```sh
python3 network-lab/lab.py destroy \
  --state "$HOME/.local/state/swiftfabric/network-lab/run-001" --yes
```

Cleanup verifies VM name, run-specific description, and segment bridge before
stopping/deleting each recorded VM. It verifies segment name and gateway before
detaching/deleting each test segment. It restores the original WAN policy only
if the router still has the last policy written by this run. Unknown or changed
resources stop cleanup rather than being deleted. The state directory is retained
for auditing; the kit never recursively deletes it.

## Unit and isolated kernel tests

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover \
  -s network-lab/tests -p 'test_*.py'
```

These tests validate ownership, ACL generation, scoped WAN updates and
restoration, HA fences, tenant topology/probe matrices, held-flow and DNS
continuity across migration, sequential NSR handoff, RBAC requests, endpoint
identities, and probe failure classification. They do not deploy VMs or replace
a successful live matrix run.

The policy-boundary regressions additionally execute the production compute-host
and NSR nftables generators in isolated user/network namespaces. Run only these:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover \
  -s network-lab/tests -p 'test_policy_boundaries.py'
```

They use real TCP/UDP nonce-and-identity echoes and count-only nftables observers
at input, individual ACL chains, and postrouting, without replacing ACL verdicts.
Fresh source ports prevent established flows from bypassing a denial phase.
They verify:

- E/W source egress denial stops before destination ingress; source allowance
  alone still fails at destination ingress on that same routing host.
- Both allowlists matching permits routing; empty/missing or source,
  destination, protocol, and port mismatches default-deny independently.
  Restoration allows new flows and withdrawal denies fresh flows again.
- Same-segment TCP/UDP/ICMP remains allowed in every E/W policy state.
- NSR outbound and unsolicited inbound authorization are independent; replies
  to authorized flows remain allowed through conntrack. NAT/mappings alone
  do not authorize a flow, and ingress allowance alone cannot replace a mapping.
- Empty segment ACLs permit WAN-authorized traffic; permissive segment ACLs
  cannot bypass empty or nonmatching WAN allowlists. Observers confirm
  outbound source NAT and inbound destination NAT on authorized traffic.

These are source-router/NSR kernel regressions, **not** live VTEP packet captures,
receiving-host enforcement, or additional live-matrix assertions.
They never change the operator's host-network rules or sysctls. They require
`unshare`, `nsenter`, `ip`, `nft`, `sysctl`, `ping`, and permission to create
isolated user/network namespaces. Unsupported environments report an explicit
skip, which is not evidence that kernel enforcement passed.

## Reproducible packet diagnostics

Packet capture is part of the kit, not a separate session helper. To reproduce
one plane's matrix under its **current** policy while recording all three
compute hosts:

```sh
python3 network-lab/lab.py capture \
  --state "$HOME/.local/state/swiftfabric/network-lab/run-001" \
  --plane l2 --expected allow --capture-seconds 60
```

Use `--plane east-west` or `--plane north-south` for routed checks.
`--expected drop` is supported for those two planes when their current ACLs
deny the test traffic. Capture does not change ACLs, attachments, NAT, services,
or host networking, and it does not add warmups or retries. It verifies VM
ownership, waits for every capture to report readiness, then runs fresh-port
probes using the same assertions as normal acceptance.

Each invocation creates a private `captures/<run-id>/` directory under the
external state directory, containing one PCAP and stderr log per compute host,
plus a `manifest.json` with the filter, requested expectation, probe results,
and completion status. Filters are derived from the recorded VM addresses and
plane-specific ports; ARP and ICMP are included for neighbor/error diagnosis.
These are compute-side captures, not captures inside the edge routing namespace.
Keep the artifacts private: they include test packet contents and DNS replies.

The three hosts must already provide `tcpdump` and `timeout`; the kit does not
install packages. Captures are bounded to 30-120 seconds and oversized captures
fail explicitly. The command waits for all bounded capture processes to exit,
including after a probe failure, and retains their artifacts. Missing tools,
readiness failures, premature capture termination, and failed traffic assertions
exit nonzero and never produce a completed manifest. A successful capture of one
plane does not replace the complete acceptance run.
