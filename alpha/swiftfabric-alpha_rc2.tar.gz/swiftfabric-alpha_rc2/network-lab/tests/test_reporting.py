import contextlib
from html.parser import HTMLParser
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import lab
import reporting
from test_tenancy import fixture


def observation(instance):
    source, destination = instance.state["vms"][:2]
    return {
        "plane": "l2", "phase": 1, "protocol": "tcp", "expected": "allow",
        "outcome": "allow", "passed": True, "source": source["address"],
        "destination": destination["address"], "source_node": source["node"],
        "destination_node": destination["node"], "source_vm": source["name"],
        "source_vmid": source["vmid"], "destination_vm": destination["name"],
        "destination_vmid": destination["vmid"], "source_tenant": source["tenant_id"],
        "destination_tenant": destination["tenant_id"], "source_segment": source["segment_id"],
        "destination_segment": destination["segment_id"], "started_epoch": 1793600000.125,
        "elapsed_ms": 1.5, "detail": "Verified nonce and endpoint identity.",
        "probe_id": "f" * 64, "stage": "complete", "console_password": "DO_NOT_EMBED",
    }


class TableParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags = []
        self.tables = 0
        self.rows = 0

    def handle_starttag(self, tag, attrs):
        self.tags.append(tag)
        if tag == "table":
            self.tables += 1
        if tag == "tr":
            self.rows += 1


class ReportingTests(unittest.TestCase):
    def test_source_revisions_record_demo_and_diagnostic_submodules(self):
        with mock.patch.object(reporting.subprocess, "run") as run:
            run.side_effect = lambda *args, **kwargs: mock.Mock(
                stdout="a" * 40 if "rev-parse" in args[0] else "")
            revisions = reporting.source_revisions(Path("/checkout"))
        self.assertEqual(
            {item["component"] for item in revisions},
            {"supervisor", "network-lab", "host-agent", "controller-api",
             "python_installer", "demos", "diag"},
        )
        self.assertTrue(all(item["commit"] == "a" * 40 and not item["dirty"]
                            for item in revisions))

    def test_probe_runner_counts_generated_cases(self):
        instance = fixture()
        instance.acceptance_assertion_count = 0
        instance._execute_probes_once = mock.Mock()
        with mock.patch.object(reporting, "traffic_path", return_value="cross-host"), \
                mock.patch.object(reporting, "purpose", return_value="probe"):
            instance.execute_probes([({}, [{}, {}, {}])], "l2", 1)
        self.assertEqual(instance.acceptance_assertion_count, 3)

    def test_purpose_identifies_primary_path_and_specific_policy(self):
        instance = fixture()
        source, destination = instance.state["vms"][:2]
        main = reporting.enrich_traffic(observation(instance), instance.state["vms"])
        self.assertIn(f'primary VM IP {destination["address"]}', main["purpose"])
        self.assertIn("Cross-host endpoints a -> b", main["purpose"])
        self.assertEqual(main["traffic_path"], "cross-host")
        local = reporting.enrich_traffic({
            **observation(instance), "plane": "health", "destination": source["address"],
            "destination_node": source["node"], "destination_vmid": source["vmid"],
        }, instance.state["vms"])
        self.assertEqual(local["traffic_path"], "guest-local")
        self.assertIn("no fabric or VTEP traversal", local["purpose"])
        same_host = reporting.enrich_traffic({
            **observation(instance), "plane": "east-west", "phase": 3,
            "destination_node": source["node"],
        }, instance.state["vms"])
        self.assertEqual(same_host["traffic_path"], "same-host")
        self.assertIn("Source egress alone", same_host["purpose"])
        self.assertIn("no remote VTEP traversal", same_host["purpose"])

    def test_overlap_primary_and_active_inactive_wan_have_distinct_purposes(self):
        instance = fixture()
        foreign = {
            **observation(instance), "plane": "east-west", "phase": 5, "expected": "allow",
            "destination_tenant": instance.state["tenant_ids"][0],
            "overlap_tenant_id": instance.state["tenant_ids"][1],
            "destination_address_role": "primary",
        }
        description = reporting.purpose(foreign)
        self.assertIn("IPv4 packet has no tenant selector", description)
        self.assertIn("not a direct cross-tenant delivery test", description)
        self.assertIn("Both source egress and destination ingress allow", description)
        for phase in ("allow", "deny", "restore"):
            result = {**foreign, "plane": "north-south", "phase": f"default-{phase}"}
            result.pop("destination_tenant")
            result.pop("overlap_tenant_id")
            self.assertNotIn("Inactive tenant", reporting.purpose(result))
            result["source_tenant"] = instance.state["tenant_ids"][1]
            self.assertIn("Inactive tenant", reporting.purpose(result))

    def test_historical_witness_rows_remain_explicit_when_reports_are_regenerated(self):
        instance = fixture()
        destination = instance.state["vms"][1]
        destination["witness"] = "10.253.244.31"
        result = {
            **observation(instance), "plane": "east-west", "expected": "drop",
            "destination": destination["witness"],
            "destination_tenant": instance.state["tenant_ids"][1],
            "destination_address_role": "witness",
        }
        rendered = reporting.enrich_traffic(result, instance.state["vms"])
        self.assertIn("historical tenant-unique witness IP", rendered["purpose"])
        self.assertIn("No current lab probes use secondary guest addresses", rendered["purpose"])

    def test_denial_describes_source_policy_without_claiming_remote_drop_location(self):
        instance = fixture()
        result = {**observation(instance), "plane": "east-west", "phase": 3, "expected": "drop"}
        description = reporting.purpose(result)
        self.assertIn("Source routing host checks source egress and destination ingress", description)
        self.assertIn("each defaults to deny", description)
        self.assertIn("guest result alone cannot locate the drop", description)
        self.assertNotIn("authorized delivery exercises remote VTEP", description)
        evidence = reporting.initial(instance.state)
        text = reporting.render(evidence, [result], [])
        self.assertIn("receiving-host re-enforcement is not asserted", text)
        self.assertIn("denied probes do not locate drops", text)

    def test_self_contained_html_escapes_values_and_excludes_private_state(self):
        instance = fixture()
        instance.state["console_password"] = "DO_NOT_EMBED"
        evidence = reporting.initial(instance.state)
        evidence["status"] = "PASS"
        evidence["assertion_output"] = [{"epoch": 1793600000, "line": "l2 phase 1: 216/216 passed"}]
        result = observation(instance)
        result["detail"] = '<script>alert("bad")</script>'
        api = {"case": "<unsafe>", "status": 403, "expected_status": 403, "passed": True,
               "credential_kind": "scoped-key", "api_key": "DO_NOT_EMBED",
               "started_epoch": 1793600000.5, "elapsed_ms": 4.25}
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)
            reporting.write_report(path, evidence, [result], [api], lab.private_write)
            text = (path / "report.html").read_text()
            self.assertIn("&lt;script&gt;", text)
            self.assertNotIn("<script>", text)
            self.assertIn("Content-Security-Policy", text)
            self.assertIn("l2 phase 1: 216/216 passed", text)
            self.assertIn("nonce and VM identity", text)
            self.assertIn(instance.state["vms"][0]["name"], text)
            self.assertIn(reporting.timestamp(result["started_epoch"]), text)
            self.assertNotIn("DO_NOT_EMBED", text)
            self.assertNotIn("DO_NOT_EMBED", (path / "report-data.json").read_text())
            self.assertEqual(os.stat(path / "report.html").st_mode & 0o777, 0o600)
            parser = TableParser()
            parser.feed(text)
            self.assertGreaterEqual(parser.tables, 10)
            self.assertNotIn("script", parser.tags)
            self.assertNotIn("img", parser.tags)
            instance.state["vms"].clear()
            reporting.regenerate(path, lab.private_write)
            self.assertEqual((path / "report.html").read_text(), text)

    def test_collect_allowlists_deployed_versions_and_actual_router_vm_name(self):
        instance = fixture()
        instance.request = mock.Mock(side_effect=[
            {"id": "test-router", "name": "NSR label", "vmid": 109, "node": "a",
             "runtime_version": "runtime-version", "agent_version": "agent-version",
             "cloud_init_password": "DO_NOT_EMBED"},
            [{"host_id": "host-a", "node": "a", "agent_version": "installed-version",
              "status": "active", "vtep_ip": "192.0.2.1", "token": "DO_NOT_EMBED"},
             {"node": "unrelated", "token": "DO_NOT_EMBED"}],
        ])
        instance.proxmox = mock.Mock()
        instance.proxmox.get.return_value = {"data": [
            {"vmid": 109, "name": "actual-router-vm", "password": "DO_NOT_EMBED"},
        ]}
        with mock.patch.object(reporting, "source_revisions", return_value=[
            {"component": "network-lab", "commit": "a" * 40, "dirty": True},
        ]):
            evidence = reporting.collect(instance, lab.ROOT)
        self.assertEqual(evidence["hosts"][0]["agent_version"], "installed-version")
        self.assertEqual(evidence["router"]["proxmox_vm_name"], "actual-router-vm")
        self.assertTrue(evidence["source_revisions"][0]["dirty"])
        self.assertNotIn("DO_NOT_EMBED", json.dumps(evidence))
        self.assertTrue(all(len(item["sha256"]) == 64 for item in evidence["kit_files"]))

    def test_failed_attempt_replaces_stale_pass_and_excludes_prior_api_assertions(self):
        instance = fixture()
        instance.state["api_results"] = [{"case": "old", "passed": True}]
        def fail():
            instance.state["results"].append(observation(instance))
            raise RuntimeError("traffic failure")
        instance.test = mock.Mock(side_effect=fail)
        with tempfile.TemporaryDirectory() as directory:
            instance.directory = Path(directory)
            (instance.directory / "report.html").write_text("STALE PASS")
            with mock.patch.object(reporting, "collect", return_value={}), \
                    contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaisesRegex(RuntimeError, "traffic failure"):
                    instance.acceptance_test()
            evidence = json.loads((instance.directory / "report-data.json").read_text())
            self.assertEqual(evidence["evidence"]["status"], "FAILED / INCOMPLETE")
            self.assertEqual(evidence["api"], [])
            self.assertEqual(len(evidence["traffic"]), 1)
            self.assertFalse(json.loads((instance.directory / "acceptance.json").read_text())["complete"])
            self.assertNotIn("STALE PASS", (instance.directory / "report.html").read_text())

    def test_metadata_failure_and_interrupt_produce_incomplete_report(self):
        for error in (RuntimeError("metadata failure"), KeyboardInterrupt()):
            instance = fixture()
            instance.test = mock.Mock()
            with tempfile.TemporaryDirectory() as directory:
                instance.directory = Path(directory)
                with mock.patch.object(reporting, "collect", side_effect=error), \
                        contextlib.redirect_stdout(io.StringIO()):
                    with self.assertRaises(type(error)):
                        instance.acceptance_test()
                self.assertIn("FAILED / INCOMPLETE", (instance.directory / "report.html").read_text())
                instance.test.assert_not_called()

    def test_planned_probe_count_must_match_report_results(self):
        for count in (2, 7):
            instance = fixture()
            instance.state["tenancy"] = True
            def finish():
                instance.state["results"] = [observation(instance) for _ in range(count)]
                instance.acceptance_assertion_count = count
            instance.test = mock.Mock(side_effect=finish)
            with tempfile.TemporaryDirectory() as directory:
                instance.directory = Path(directory)
                with mock.patch.object(reporting, "collect", return_value={}), \
                        contextlib.redirect_stdout(io.StringIO()):
                    instance.acceptance_test()
                data = json.loads((instance.directory / "report-data.json").read_text())
                self.assertEqual(data["evidence"]["status"], "PASS")
                self.assertEqual(len(data["traffic"]), count)
                acceptance = json.loads((instance.directory / "acceptance.json").read_text())
                self.assertEqual(acceptance["traffic_assertions"], len(data["traffic"]))

        instance = fixture()
        instance.state["tenancy"] = True
        instance.test = mock.Mock(side_effect=lambda: setattr(instance, "acceptance_assertion_count", 1))
        with tempfile.TemporaryDirectory() as directory:
            instance.directory = Path(directory)
            with mock.patch.object(reporting, "collect", return_value={}), \
                    contextlib.redirect_stdout(io.StringIO()), \
                    self.assertRaisesRegex(RuntimeError, "complete passing matrix"):
                instance.acceptance_test()

    def test_run_preserves_provisioning_assertions_and_start_time(self):
        instance = fixture()
        instance.state["api_results"] = [{
            "case": "overlap requires confirmation", "status": 409, "expected_status": 409,
            "passed": True, "credential_kind": "global", "started_epoch": 1793600000,
        }]
        instance.state.update(report_api_start_index=0, report_started_epoch=1793599999)
        instance.test = mock.Mock(side_effect=RuntimeError("stop after collection"))
        with tempfile.TemporaryDirectory() as directory:
            instance.directory = Path(directory)
            with mock.patch.object(reporting, "collect", return_value={}), \
                    contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaisesRegex(RuntimeError, "stop after collection"):
                    instance.acceptance_test()
            data = json.loads((instance.directory / "report-data.json").read_text())
            self.assertEqual(len(data["api"]), 1)
            self.assertEqual(data["evidence"]["started_epoch"], 1793599999)
            self.assertNotIn("report_api_start_index", instance.state)

    def test_vm_identity_join_disambiguates_overlapping_tenant_addresses(self):
        instance = fixture()
        instance.serial = mock.Mock(side_effect=lambda source, command: json.dumps([
            {**case, "outcome": case["expected"], "passed": True, "started_epoch": 1793600000}
            for case in json.loads(lab.gzip.decompress(lab.base64.b64decode(command.split()[-1])))
        ]))
        with tempfile.TemporaryDirectory() as directory, contextlib.redirect_stdout(io.StringIO()):
            instance.directory = Path(directory)
            instance.probes("l2", 1, "allow")
        vms = {vm["name"]: vm for vm in instance.state["vms"]}
        self.assertEqual(len(instance.state["results"]), 216)
        for result in instance.state["results"]:
            self.assertEqual(vms[result["destination_vm"]]["vmid"], result["destination_vmid"])
            self.assertEqual(vms[result["destination_vm"]]["tenant_id"], result["destination_tenant"])
            self.assertEqual(vms[result["source_vm"]]["vmid"], result["source_vmid"])

    def test_offline_cli_does_not_initialize_live_clients_or_read_private_state(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)
            instance = fixture()
            reporting.write_report(path, reporting.initial(instance.state), [], [], lab.private_write)
            with mock.patch.object(sys, "argv", ["lab.py", "html-report", "--state", directory]), \
                    mock.patch.object(lab, "LiveLab") as live, \
                    contextlib.redirect_stdout(io.StringIO()):
                lab.main()
            live.assert_not_called()
            self.assertTrue((path / "report.html").exists())
