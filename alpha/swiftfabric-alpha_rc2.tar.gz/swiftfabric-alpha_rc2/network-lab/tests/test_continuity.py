import copy
import contextlib
import importlib.util
import json
import io
from pathlib import Path
import socket
import subprocess
import sys
import struct
import tempfile
import threading
import unittest
from unittest import mock

DIRECTORY = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(DIRECTORY))
import guest

SPEC = importlib.util.spec_from_file_location("continuity_lab", DIRECTORY / "lab.py")
lab = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(lab)


def case(protocol="tcp", duration=30):
    return {
        "source": "127.0.0.1", "source_port": 0,
        "destination": "127.0.0.1", "destination_port": 18080,
        "protocol": protocol, "duration_seconds": duration,
        "expected_nat_address": "127.0.0.1",
    }


def sample(sequence, received, peer=None):
    return {
        "sequence": sequence, "sent_seconds": max(0, received - 0.01),
        "received_seconds": received, "peer": peer or ["127.0.0.1", 23456],
    }


def report(value, samples=None):
    if samples is None:
        samples = [
            sample(index, index + 0.1, [value["expected_nat_address"], 23456])
            for index in range(value["duration_seconds"])
        ]
        if value.get("echo_format") == "plain":
            for item in samples:
                item["peer"] = None
    return {
        **guest.held_summary(value, samples, value["duration_seconds"], ""),
        "started_epoch": 1000.0, "started_monotonic": 100.0,
        "connected": True, "requests": len(samples),
        "application_bytes_sent": 1000, "application_bytes_received": 2000,
    }


class ContinuityMeasurementsTests(unittest.TestCase):
    def test_held_connect_budget_matches_response_gap_and_never_retries(self):
        for duration, timeout in ((120, 30.0), (1, 1)):
            with self.subTest(duration=duration):
                connection = mock.MagicMock()
                connection.__enter__.return_value = connection
                connection.connect.side_effect = TimeoutError("connect timed out")
                with mock.patch.object(guest.socket, "socket", return_value=connection) as create:
                    result = guest.hold_flow(case(duration=duration))
                connection.settimeout.assert_called_once_with(timeout)
                connection.connect.assert_called_once_with(("127.0.0.1", 18080))
                create.assert_called_once_with(socket.AF_INET, socket.SOCK_STREAM)
                self.assertFalse(result["passed"])
                self.assertFalse(result["connected"])
                self.assertIn("connect timed out", result["error"])

    def test_plain_echo_holds_socket_without_fabricating_nat_tuple(self):
        class Echo(guest.socketserver.StreamRequestHandler):
            def handle(self):
                while data := self.rfile.readline():
                    self.wfile.write(data)
                    self.wfile.flush()

        with guest.TCPServer(("127.0.0.1", 0), Echo) as server:
            thread = threading.Thread(target=server.serve_forever)
            thread.start()
            try:
                value = {
                    **case(duration=1), "echo_format": "plain",
                    "destination_port": server.server_address[1],
                }
                result = guest.hold_flow(value)
                self.assertTrue(result["passed"], result)
                self.assertEqual(result["observed_peers"], [])
                self.assertTrue(all(item["peer"] is None for item in result["samples"]))
                lab.validate_held_results([value], [result])
                value["echo_format"] = "observed-peer"
                strict = guest.hold_flow(value)
                self.assertFalse(strict["passed"])
                self.assertIn("observed peer", strict["error"])
            finally:
                server.shutdown()
                thread.join(timeout=5)
                self.assertFalse(thread.is_alive())

    def test_endpoint_idle_timeout_exceeds_thirty_second_recovery_budget(self):
        handler = guest.HeldTCPHandler.__new__(guest.HeldTCPHandler)
        handler.request = mock.Mock()
        handler.rfile = io.BytesIO(b"")
        handler.handle()
        self.assertEqual(handler.request.settimeout.call_args.args, (45,))

    def test_thirty_second_gap_limit_includes_initial_and_trailing_silence(self):
        for times, passed in (
            ([0.0, 5.0, 30.0, 60.0], True),
            ([0.0, 30.0, 60.0], True),
            ([0.0, 30.000001, 60.0], False),
            ([30.0, 59.9], True),
            ([30.000001, 59.9], False),
            ([0.0, 30.0], True),
            ([0.0, 29.999999], False),
            ([], False),
        ):
            with self.subTest(times=times):
                result = guest.held_summary(
                    case(duration=60), [sample(index, value) for index, value in enumerate(times)], 60, "",
                )
                self.assertEqual(result["passed"], passed, result)

    def test_nat_tuple_change_wrong_wan_address_and_early_exit_fail(self):
        value = case(duration=2)
        for samples, elapsed, error, reason in (
            ([sample(0, 0.1), sample(1, 1, ["127.0.0.1", 23457])], 2, "", "tuple"),
            ([sample(0, 0.1, ["192.0.2.1", 20]), sample(1, 1, ["192.0.2.1", 20])], 2, "", "WAN"),
            ([sample(0, 0.1), sample(1, 1)], 1.1, "", "early"),
            ([sample(0, 0.1), sample(1, 1)], 2, "connection reset", "reset"),
        ):
            with self.subTest(reason=reason):
                result = guest.held_summary(value, samples, elapsed, error)
                self.assertFalse(result["passed"])
                self.assertIn(reason, " ".join(result["failures"]))

    def test_real_held_tcp_and_udp_use_one_socket_and_stable_observed_peer(self):
        for protocol, server_type, handler in (
            ("tcp", guest.TCPServer, guest.HeldTCPHandler),
            ("udp", guest.socketserver.ThreadingUDPServer, guest.HeldUDPHandler),
        ):
            with self.subTest(protocol=protocol), server_type(("127.0.0.1", 0), handler) as server:
                thread = threading.Thread(target=server.serve_forever)
                thread.start()
                try:
                    value = {**case(protocol, 1), "destination_port": server.server_address[1]}
                    factory = guest.socket.socket
                    with mock.patch.object(guest.socket, "socket", wraps=factory) as create:
                        result = guest.hold_flow(value)
                    self.assertTrue(result["passed"], result)
                    self.assertEqual(sum("fileno" not in call.kwargs for call in create.call_args_list), 1)
                    self.assertGreaterEqual(len(result["samples"]), 3)
                    self.assertEqual(len(result["observed_peers"]), 1)
                    self.assertGreater(result["application_bytes_received"], 0)
                    lab.validate_held_results([value], [result])
                finally:
                    server.shutdown()
                    thread.join(timeout=5)
                    self.assertFalse(thread.is_alive())

    def test_closed_tcp_never_reconnects(self):
        class Close(guest.socketserver.BaseRequestHandler):
            def handle(self):
                self.request.recv(1024)

        with guest.TCPServer(("127.0.0.1", 0), Close) as server:
            thread = threading.Thread(target=server.serve_forever)
            thread.start()
            try:
                factory = guest.socket.socket
                with mock.patch.object(guest.socket, "socket", wraps=factory) as create:
                    result = guest.hold_flow({**case(duration=1), "destination_port": server.server_address[1]})
                self.assertFalse(result["passed"])
                self.assertIn("reconnection is forbidden", result["error"])
                self.assertEqual(sum("fileno" not in call.kwargs for call in create.call_args_list), 1)
            finally:
                server.shutdown()
                thread.join(timeout=5)

    def test_progress_reports_only_verified_replies_on_same_held_socket(self):
        with guest.TCPServer(("127.0.0.1", 0), guest.HeldTCPHandler) as server:
            thread = threading.Thread(target=server.serve_forever)
            thread.start()
            progress = []
            try:
                value = {**case(duration=1), "destination_port": server.server_address[1]}
                result = guest.hold_flow(value, progress=progress.append)
                self.assertTrue(result["passed"], result)
                self.assertEqual(len(progress), len(result["samples"]))
                for index, update in enumerate(progress):
                    self.assertEqual(update["verified_responses"], index + 1)
                    self.assertEqual(update["sample"], result["samples"][index])
                    self.assertEqual(update["started_monotonic"], result["started_monotonic"])
            finally:
                server.shutdown()
                thread.join(timeout=5)
                self.assertFalse(thread.is_alive())

    def test_malformed_response_is_a_reported_failure_not_missing_evidence(self):
        class Malformed(guest.socketserver.BaseRequestHandler):
            def handle(self):
                _, connection = self.request
                connection.sendto(b"[]\n", self.client_address)

        with guest.socketserver.ThreadingUDPServer(("127.0.0.1", 0), Malformed) as server:
            thread = threading.Thread(target=server.serve_forever)
            thread.start()
            try:
                value = {**case("udp", 1), "destination_port": server.server_address[1]}
                result = guest.hold_flow(value)
                self.assertFalse(result["passed"])
                self.assertIn("response must be an object", result["error"])
                lab.validate_held_results([value], [result])
            finally:
                server.shutdown()
                thread.join(timeout=5)

    def test_wrong_nonce_response_cannot_count_as_continuity(self):
        class WrongNonce(guest.socketserver.BaseRequestHandler):
            def handle(self):
                data, connection = self.request
                response = json.loads(guest.held_response(data, self.client_address))
                response["nonce"] = "wrong"
                connection.sendto(json.dumps(response).encode() + b"\n", self.client_address)

        with guest.socketserver.ThreadingUDPServer(("127.0.0.1", 0), WrongNonce) as server:
            thread = threading.Thread(target=server.serve_forever)
            thread.start()
            try:
                result = guest.hold_flow({**case("udp", 1), "destination_port": server.server_address[1]})
                self.assertFalse(result["passed"])
                self.assertEqual(result["samples"], [])
                self.assertIn("nonce/sequence", result["error"])
            finally:
                server.shutdown()
                thread.join(timeout=5)

    def test_udp_loss_keeps_socket_and_duplicate_replies_do_not_hide_loss(self):
        class LossAndDuplicates(guest.socketserver.BaseRequestHandler):
            def handle(self):
                data, connection = self.request
                if json.loads(data)["sequence"] < 2:
                    return
                reply = guest.held_response(data, self.client_address)
                connection.sendto(reply, self.client_address)
                connection.sendto(reply, self.client_address)

        with guest.socketserver.ThreadingUDPServer(("127.0.0.1", 0), LossAndDuplicates) as server:
            thread = threading.Thread(target=server.serve_forever)
            thread.start()
            try:
                result = guest.hold_flow({**case("udp", 1), "destination_port": server.server_address[1]})
                self.assertTrue(result["passed"], result)
                self.assertGreaterEqual(result["samples"][0]["sequence"], 2)
                numbers = [sample["sequence"] for sample in result["samples"]]
                self.assertEqual(len(numbers), len(set(numbers)))
                self.assertLess(len(numbers), result["requests"])
            finally:
                server.shutdown()
                thread.join(timeout=5)

    def test_missing_malformed_or_inconsistent_guest_reports_are_rejected(self):
        value = case()
        good = report(value)
        lab.validate_held_results([value], [good])
        invalid = []
        for key, changed in (
            ("passed", False), ("source_port", 9999), ("samples", None),
            ("elapsed_seconds", float("nan")), ("connected", False),
            ("requests", -1), ("requests", 10000), ("application_bytes_sent", 0),
            ("observed_peers", []), ("started_epoch", float("inf")),
        ):
            invalid.append({**good, key: changed})
        for key, changed in (
            ("received_seconds", -1), ("received_seconds", float("nan")),
            ("sent_seconds", 40), ("peer", ["127.0.0.1", True]), ("sequence", True),
        ):
            bad = copy.deepcopy(good)
            bad["samples"][0][key] = changed
            invalid.append(bad)
        duplicate = copy.deepcopy(good)
        duplicate["samples"][1]["sequence"] = 0
        invalid.append(duplicate)
        for bad in invalid:
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                lab.validate_held_results([value], [bad])
        with self.assertRaises(ValueError):
            lab.validate_held_results([value], [])


class HeldEndpointIdentityTests(unittest.TestCase):
    def test_held_echo_checks_expected_endpoint_identity(self):
        for protocol, server_type, handler in (
            ("tcp", guest.TCPServer, guest.HeldTCPHandler),
            ("udp", guest.socketserver.ThreadingUDPServer, guest.HeldUDPHandler),
        ):
            with self.subTest(protocol=protocol), server_type(("127.0.0.1", 0), handler) as server:
                server.endpoint_identity = "tenant-a-vm"
                thread = threading.Thread(target=server.serve_forever)
                thread.start()
                try:
                    value = {
                        **case(protocol, 1), "destination_port": server.server_address[1],
                        "endpoint_identity": "tenant-a-vm",
                    }
                    self.assertTrue(guest.hold_flow(value)["passed"])
                    wrong = guest.hold_flow({**value, "endpoint_identity": "tenant-b-vm"})
                    self.assertFalse(wrong["passed"])
                    self.assertIn("endpoint identity", " ".join(wrong["failures"]))
                finally:
                    server.shutdown()
                    thread.join(timeout=5)
                    self.assertFalse(thread.is_alive())


class HeldDNSFlowTests(unittest.TestCase):
    def test_udp_loss_and_delayed_replies_keep_socket_and_thirty_second_gap_limit(self):
        for loss_end, delayed, expected_pass in (
            (5, False, True), (5, True, True), (35, False, False), (40, False, False),
        ):
            with self.subTest(loss_end=loss_end, delayed=delayed):
                clock = [0.0]
                queries = []
                connection = mock.MagicMock()
                connection.__enter__.return_value = connection

                def send(payload):
                    queries.append(payload)
                    return len(payload)

                def receive(size):
                    clock[0] += connection.settimeout.call_args.args[0]
                    if 1 <= clock[0] <= loss_end:
                        raise TimeoutError("simulated packet loss")
                    query = queries[-2] if delayed and len(queries) > 1 else queries[-1]
                    return self.answer(query)

                connection.send.side_effect = send
                connection.recv.side_effect = receive
                value = {**case("udp", 40), "destination_port": 53,
                         "echo_format": "plain", "dns": True}
                with mock.patch.object(guest.time, "monotonic", side_effect=lambda: clock[0]), \
                        mock.patch.object(guest.socket, "socket", return_value=connection) as create:
                    result = guest.hold_dns_flow(value)
                self.assertEqual(result["passed"], expected_pass, result["failures"])
                self.assertEqual(result["error"], "")
                self.assertGreaterEqual(result["elapsed_seconds"], 40)
                self.assertEqual(result["requests"], len(queries))
                create.assert_called_once()
                connection.connect.assert_called_once()
                connection.bind.assert_called_once()
                if expected_pass:
                    self.assertLessEqual(result["max_response_gap_seconds"], 30)
                else:
                    self.assertIn("response gap exceeds thirty seconds", result["failures"])
                lab.validate_held_results([value], [result])

    @staticmethod
    def answer(query):
        txid = struct.unpack("!H", query[:2])[0]
        return struct.pack("!HHHHHH", txid, 0x8180, 1, 1, 0, 0) + query[12:]

    def test_tcp_and_udp_dns_queries_keep_one_socket_and_validate_replies(self):
        class TCPDNS(guest.socketserver.StreamRequestHandler):
            connections = 0

            def handle(self):
                TCPDNS.connections += 1
                while header := self.rfile.read(2):
                    size = struct.unpack("!H", header)[0]
                    query = self.rfile.read(size)
                    reply = HeldDNSFlowTests.answer(query)
                    self.wfile.write(struct.pack("!H", len(reply)) + reply)
                    self.wfile.flush()

        class UDPDNS(guest.socketserver.BaseRequestHandler):
            def handle(self):
                query, connection = self.request
                connection.sendto(HeldDNSFlowTests.answer(query), self.client_address)

        for protocol, server_type, handler in (
            ("tcp", guest.TCPServer, TCPDNS),
            ("udp", guest.socketserver.ThreadingUDPServer, UDPDNS),
        ):
            with self.subTest(protocol=protocol), server_type(("127.0.0.1", 0), handler) as server:
                thread = threading.Thread(target=server.serve_forever)
                thread.start()
                try:
                    value = {
                        **case(protocol, 1), "destination_port": server.server_address[1],
                        "echo_format": "plain", "dns": True,
                    }
                    factory = guest.socket.socket
                    with mock.patch.object(guest.socket, "socket", wraps=factory) as create:
                        result = guest.hold_dns_flow(value)
                    self.assertTrue(result["passed"], result)
                    self.assertGreaterEqual(len(result["samples"]), 2)
                    self.assertTrue(all(sample["peer"] is None for sample in result["samples"]))
                    if protocol == "tcp":
                        self.assertEqual(TCPDNS.connections, 1)
                    else:
                        self.assertEqual(create.call_count, 1)
                    lab.validate_held_results([value], [result])
                finally:
                    server.shutdown()
                    thread.join(timeout=5)
                    self.assertFalse(thread.is_alive())

    def test_wrong_transaction_and_empty_answer_are_rejected(self):
        for response in (
            struct.pack("!HHHHHH", 101, 0x8180, 1, 1, 0, 0),
            struct.pack("!HHHHHH", 100, 0x8180, 1, 0, 0, 0),
            struct.pack("!HHHHHH", 100, 0x8183, 1, 1, 0, 0),
        ):
            with self.subTest(response=response), self.assertRaisesRegex(RuntimeError, "invalid DNS"):
                guest.verify_dns_answer(response, 100)

    def test_held_matrix_persists_first_verified_response_per_flow(self):
        cases = [{"case_id": "tcp", "protocol": "tcp"}, {"case_id": "udp", "protocol": "udp"}]

        def runner(value, *, progress):
            progress({"protocol": value["protocol"], "verified_responses": 1})
            progress({"protocol": value["protocol"], "verified_responses": 2})
            return {"case_id": value["case_id"]}

        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "progress.json")
            results = guest.held_matrix(cases, runner, path)
            saved = json.loads(Path(path).read_text())
            self.assertEqual(Path(path).stat().st_mode & 0o777, 0o600)
        self.assertEqual(results, [{"case_id": "tcp"}, {"case_id": "udp"}])
        self.assertEqual(
            {key: value["verified_responses"] for key, value in saved.items()},
            {"tcp": 1, "udp": 1},
        )


class ContinuityOrchestrationTests(unittest.TestCase):
    def setUp(self):
        self.instance = lab.LiveLab.__new__(lab.LiveLab)
        self.instance.state = {
            "router": "lab-router", "ready": True,
            "nodes": ["host0", "host1", "host2"],
            "segments": [
                {"id": 49100 + index, "network": f"10.253.{244 + index}.0/24"}
                for index in range(3)
            ],
            "vms": [
                {"vmid": index, "address": f"10.253.{244 + index // 3}.{10 + index % 3}",
                 "node": f"host{index % 3}", "segment_id": 49100 + index // 3}
                for index in range(9)
            ],
        }
        self.instance.vm_config = mock.Mock()
        self.instance.request = mock.Mock(return_value={"wan_address_cidr": "192.0.2.10/24"})
        self.instance.save = mock.Mock()
        self.clock_calls = {}

    def serial(self, vm, command, timeout):
        if timeout == 30:
            self.clock_calls[vm["vmid"]] = self.clock_calls.get(vm["vmid"], 0) + 1
            return "90" if self.clock_calls[vm["vmid"]] == 1 else "1000"
        shim = (
            "import sys;from unittest.mock import patch;"
            f"sys.path.insert(0,{str(DIRECTORY)!r});"
            f"sys.path.insert(0,{str(DIRECTORY / 'tests')!r});"
            "from test_continuity import report;"
            "import concurrent.futures;"
            "\n"
            "def mapped(self, function, values):\n"
            " return map(lambda item: report(item[1]),values)\n"
            "with patch.object(concurrent.futures.ThreadPoolExecutor,'map',mapped):\n"
            " exec(sys.argv[1])\n"
        )
        self.assertEqual(timeout, 120)
        self.assertLess(max(map(len, command.splitlines())), 2000)
        wrapped = "sh -c " + lab.shlex.quote(command)
        self.assertLess(max(map(len, wrapped.splitlines())), 4096)
        rewritten = command.replace("python3 -c ", "python3 -c " + lab.shlex.quote(shim) + " ", 1)
        return subprocess.check_output(["sh", "-c", rewritten], text=True, timeout=10)

    def test_owned_matrix_retains_private_reports_and_reserves_fresh_ports(self):
        self.instance.serial = mock.Mock(side_effect=self.serial)
        with tempfile.TemporaryDirectory() as directory:
            self.instance.directory = Path(directory)
            self.instance.continuity("192.0.2.20", "192.0.2.10", 30, 18080, 18081)
            manifest = next(Path(directory).glob("continuity/*/manifest.json"))
            result = json.loads(manifest.read_text())
            self.assertTrue(result["completed"])
            self.assertTrue(result["passed"])
            self.assertEqual(len(result["results"]), 18)
            self.assertEqual(len(list(manifest.parent.glob("vm-*.json"))), 9)
            self.assertEqual(manifest.stat().st_mode & 0o777, 0o600)
            self.assertEqual(manifest.parent.stat().st_mode & 0o777, 0o700)
        self.assertEqual(self.instance.vm_config.call_count, 9)
        self.assertTrue(all(vm["next_source_port"] == 20002 for vm in self.instance.state["vms"]))
        self.assertEqual(self.instance.serial.call_count, 27)
        self.assertEqual(self.instance.request.call_count, 1)
        self.assertEqual(self.instance.request.call_args.args[0], "GET")

    def test_console_failure_preserves_other_vm_evidence_and_fails_closed(self):
        def execute(vm, command, timeout):
            if vm["vmid"] == 0:
                raise TimeoutError("console unavailable")
            return self.serial(vm, command, timeout)

        self.instance.serial = mock.Mock(side_effect=execute)
        with tempfile.TemporaryDirectory() as directory:
            self.instance.directory = Path(directory)
            with self.assertRaisesRegex(RuntimeError, "continuity failed"):
                self.instance.continuity("192.0.2.20", "192.0.2.10", 30, 18080, 18081)
            result = json.loads(next(Path(directory).glob("continuity/*/manifest.json")).read_text())
            self.assertFalse(result["completed"])
            self.assertFalse(result["passed"])
            self.assertEqual(len(result["results"]), 16)
            self.assertEqual(result["errors"], [{"vmid": 0, "error": "console unavailable"}])

    def test_explicit_tcp_only_matrix_does_not_claim_udp_coverage(self):
        self.instance.serial = mock.Mock(side_effect=self.serial)
        with tempfile.TemporaryDirectory() as directory:
            self.instance.directory = Path(directory)
            self.instance.continuity("192.0.2.20", "192.0.2.10", 30, 2000, 2001, "tcp")
            result = json.loads(next(Path(directory).glob("continuity/*/manifest.json")).read_text())
            self.assertTrue(result["completed"])
            self.assertTrue(result["passed"])
            self.assertEqual(result["protocols"], ["tcp"])
            self.assertEqual(len(result["results"]), 9)
            self.assertEqual({flow["protocol"] for flow in result["results"]}, {"tcp"})
            self.assertEqual({flow["destination_port"] for flow in result["results"]}, {2000})
        self.assertTrue(all(vm["next_source_port"] == 20001 for vm in self.instance.state["vms"]))

    def test_plain_echo_matrix_explicitly_disclaims_nat_observation(self):
        self.instance.serial = mock.Mock(side_effect=self.serial)
        with tempfile.TemporaryDirectory() as directory:
            self.instance.directory = Path(directory)
            self.instance.continuity("192.0.2.20", "192.0.2.10", 30, 2000, 2001, "tcp", "plain")
            result = json.loads(next(Path(directory).glob("continuity/*/manifest.json")).read_text())
            self.assertTrue(result["passed"])
            self.assertEqual(result["echo_format"], "plain")
            self.assertFalse(result["nat_tuple_verified"])
            self.assertTrue(all(flow["observed_peers"] == [] for flow in result["results"]))

    def test_bad_scope_and_wrong_nat_fail_before_console_or_policy_changes(self):
        self.instance.serial = mock.Mock()
        for target, nat, duration, tcp, udp in (
            ("10.253.244.20", "192.0.2.10", 30, 18080, 18081),
            ("192.0.2.20", "192.0.2.10", 29, 18080, 18081),
            ("192.0.2.20", "192.0.2.10", 30, 0, 18081),
            ("192.0.2.20", "192.0.2.20", 30, 18080, 18081),
            ("192.0.2.20", "192.0.2.11", 30, 18080, 18081),
        ):
            with self.subTest(target=target, nat=nat), self.assertRaises((ValueError, RuntimeError)):
                self.instance.continuity(target, nat, duration, tcp, udp)
        self.instance.serial.assert_not_called()
        self.instance.save.assert_not_called()

    def test_duplicate_topology_and_exhausted_ports_do_not_start_guests(self):
        self.instance.serial = mock.Mock()
        original = copy.deepcopy(self.instance.state)
        for change in ("duplicate", "exhausted"):
            self.instance.state = copy.deepcopy(original)
            if change == "duplicate":
                self.instance.state["vms"][1]["node"] = "host0"
            else:
                self.instance.state["vms"][-1]["next_source_port"] = 65000
            with self.subTest(change=change), self.assertRaises(RuntimeError):
                self.instance.continuity("192.0.2.20", "192.0.2.10", 30, 18080, 18081)
            self.instance.save.assert_not_called()
            self.instance.serial.assert_not_called()
            self.assertNotIn("next_source_port", self.instance.state["vms"][0])

    def test_flow_failure_is_completed_but_never_passed(self):
        def execute(vm, command, timeout):
            if timeout == 30:
                return self.serial(vm, command, timeout)
            results = json.loads(self.serial(vm, command, timeout))
            if vm["vmid"] == 0:
                failed = results[0]
                results[0] = {
                    **failed, **guest.held_summary(failed, failed["samples"], 30, "TCP reset"),
                }
            return json.dumps(results)

        self.instance.serial = mock.Mock(side_effect=execute)
        with tempfile.TemporaryDirectory() as directory:
            self.instance.directory = Path(directory)
            with self.assertRaisesRegex(RuntimeError, "continuity failed"):
                self.instance.continuity("192.0.2.20", "192.0.2.10", 30, 18080, 18081)
            manifest = next(Path(directory).glob("continuity/*/manifest.json"))
            result = json.loads(manifest.read_text())
            self.assertTrue(result["completed"])
            self.assertFalse(result["passed"])
            self.assertEqual(len(result["results"]), 18)
            self.assertEqual(result["errors"], [])
            self.assertEqual(sum(flow["passed"] for flow in result["results"]), 17)
            self.assertIn("TCP reset", (manifest.parent / "vm-0.json").read_text())


class ContinuityEventTests(unittest.TestCase):
    def test_plain_echo_requires_explicit_matching_declaration_and_no_peer(self):
        manifest = self.manifest()
        manifest["echo_format"] = "plain"
        for index, result in enumerate(manifest["results"]):
            value = {**result, "echo_format": "plain"}
            manifest["results"][index] = {
                **report(value), "operator_clock_offset_seconds": [1000.0, 1000.1],
            }
        result = lab.continuity_event_report(manifest, 1110, 1115)
        self.assertTrue(result["passed"])
        self.assertFalse(result["nat_tuple_verified"])
        bad = copy.deepcopy(manifest)
        bad["results"][0]["samples"][0]["peer"] = ["127.0.0.1", 23456]
        with self.assertRaisesRegex(ValueError, "cannot claim"):
            lab.continuity_event_report(bad, 1110, 1115)
        del manifest["echo_format"]
        with self.assertRaisesRegex(ValueError, "does not match"):
            lab.continuity_event_report(manifest, 1110, 1115)

    def manifest(self):
        results = []
        for source in range(9):
            for protocol in ("tcp", "udp"):
                value = {
                    **case(protocol), "source": f"10.253.244.{10 + source}",
                    "source_port": 20000 if protocol == "tcp" else 20001,
                }
                results.append({**report(value), "operator_clock_offset_seconds": [1000.0, 1000.1]})
        return {"completed": True, "errors": [], "results": results}

    def test_all_same_socket_flows_must_span_actual_operation(self):
        result = lab.continuity_event_report(self.manifest(), 1110, 1115)
        self.assertTrue(result["passed"])
        self.assertEqual(len(result["flows"]), 18)
        for start, end in ((1100, 1115), (1110, 1131)):
            with self.subTest(start=start, end=end):
                result = lab.continuity_event_report(self.manifest(), start, end)
                self.assertFalse(result["passed"])

    def test_uncertain_clock_does_not_claim_operation_overlap(self):
        manifest = self.manifest()
        manifest["results"][0]["operator_clock_offset_seconds"] = [950, 1050]
        result = lab.continuity_event_report(manifest, 1110, 1115)
        self.assertFalse(result["passed"])
        self.assertFalse(result["flows"][0]["healthy_before"])
        self.assertFalse(result["flows"][0]["healthy_after"])

    def test_single_protocol_requires_explicit_complete_coverage(self):
        for protocol in ("tcp", "udp"):
            manifest = self.manifest()
            manifest["results"] = [flow for flow in manifest["results"] if flow["protocol"] == protocol]
            with self.assertRaises(ValueError):
                lab.continuity_event_report(manifest, 1110, 1115)
            manifest["protocols"] = [protocol]
            result = lab.continuity_event_report(manifest, 1110, 1115)
            self.assertTrue(result["passed"])
            self.assertEqual(result["protocols"], [protocol])
            self.assertEqual(len(result["flows"]), 9)
            manifest["results"][0]["protocol"] = "udp" if protocol == "tcp" else "tcp"
            with self.assertRaises(ValueError):
                lab.continuity_event_report(manifest, 1110, 1115)

    def test_invalid_protocol_declarations_cannot_reduce_evidence_requirements(self):
        for protocols in ([], ["icmp"], ["tcp", "tcp"], "tcp", None, ["udp", "tcp"]):
            manifest = self.manifest()
            manifest["protocols"] = protocols
            with self.subTest(protocols=protocols), self.assertRaises(ValueError):
                lab.continuity_event_report(manifest, 1110, 1115)

    def test_incomplete_unmeasured_duplicate_and_invalid_windows_are_rejected(self):
        for start, end in ((0, 1115), (1115, 1110), (float("nan"), 1115)):
            with self.subTest(start=start), self.assertRaises(ValueError):
                lab.continuity_event_report(self.manifest(), start, end)
        for kind in ("incomplete", "clock", "duplicate", "missing", "protocol"):
            manifest = self.manifest()
            if kind == "incomplete":
                manifest["completed"] = False
            elif kind == "clock":
                del manifest["results"][0]["operator_clock_offset_seconds"]
            elif kind == "duplicate":
                manifest["results"][1] = manifest["results"][0]
            elif kind == "missing":
                del manifest["results"][0]["source"]
            else:
                manifest["results"][0]["protocol"] = "icmp"
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                lab.continuity_event_report(manifest, 1110, 1115)

    def test_offline_report_needs_no_credentials_private_state_or_live_client(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "manifest.json"
            path.write_text(json.dumps(self.manifest()))
            arguments = [
                "lab.py", "continuity-report", "--report", str(path),
                "--event-start-epoch", "1110", "--event-end-epoch", "1115",
            ]
            with mock.patch.object(sys, "argv", arguments), mock.patch.object(
                lab, "LiveLab",
            ) as client, contextlib.redirect_stdout(io.StringIO()) as output:
                lab.main()
            client.assert_not_called()
            self.assertTrue(json.loads(output.getvalue())["passed"])


if __name__ == "__main__":
    unittest.main()
