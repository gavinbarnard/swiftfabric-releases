import base64
import contextlib
import copy
import errno
import gzip
import io
import ipaddress
import json
from pathlib import Path
import shlex
import sys
import tempfile
import threading
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import guest
import lab
import tenancy


SPECS = ["49100:10.253.244.1/24", "49101:10.253.245.1/24", "49102:10.253.246.1/24"]
SECOND = "tenant-11111111-1111-4111-8111-111111111111"


def rbac_records():
    return [
        {"name": f"user-{index}-{role}", "tenant_id": tenant, "role": role,
         "token": f"token-{index}-{role}"}
        for index, tenant in enumerate(("default", SECOND)) for role in ("writer", "reader")
    ]


def fixture():
    instance = tenancy.TenantLab.__new__(tenancy.TenantLab)
    segments = lab.segment_plan(SPECS, "a" * 32)
    for segment in segments:
        segment["tenant_id"] = "default"
        segment["_version"] = 1
    segments += [{**segment, "id": segment["id"] + 3, "name": segment["name"] + "-t2",
                  "tenant_id": SECOND} for segment in segments]
    instance.state = {
        "run_id": "a" * 32, "segments": segments, "vms": [], "nodes": ["a", "b", "c"],
        "tenant_ids": ["default", SECOND], "wan_tenant": "default",
        "router": "test-router", "settle_seconds": 35, "dns_address": "1.1.1.1",
        "new_tenant": {"id": SECOND, "name": "sf-lab-owned", "_version": 1}, "results": [],
    }
    instance.save = mock.Mock()
    instance.directory = Path("/private/lab")
    instance.owned_segment = mock.Mock(side_effect=lambda segment: copy.deepcopy(segment))
    for segment in segments:
        for index, node in enumerate(instance.state["nodes"]):
            vm = {"vmid": 100 + len(instance.state["vms"]), "segment_id": segment["id"],
                  "node": node, "name": segment["name"] + "-h" + str(index),
                  "address": str(ipaddress.ip_network(segment["network"]).network_address + 10 + index)}
            instance.prepare_vm(vm, segment, index)
            instance.state["vms"].append(vm)
    return instance


class TopologyTests(unittest.TestCase):
    def test_confirmed_composite_creation_retries_exact_request_without_rechecking_overlap(self):
        instance = fixture()
        instance.state["new_tenant"].pop("_version")
        instance.state["tenant_create_requested"] = True
        segment = instance.state["segments"][3]
        instance.request = mock.Mock(return_value={**segment, "_version": 8})
        instance.checked = mock.Mock(side_effect=AssertionError("confirmed overlap must not repeat"))
        result = instance.create_segment(segment)
        instance.request.assert_called_once_with("POST", "/segments", {
            "id": segment["id"], "name": segment["name"],
            "gateway_cidr": segment["gateway_cidr"], "tenant_id": "default",
            "new_tenant": instance.state["new_tenant"],
        })
        self.assertEqual(result["tenant_id"], SECOND)
        self.assertTrue(instance.state["tenant_created"])

    def test_create_hooks_provision_all_18_vms_with_exactly_overlapping_primary_addresses(self):
        instance = fixture()
        instance.state["vms"] = []
        instance.state.update(storage="VMData", image_volume="VMData:import/image.qcow2",
                              console_password="test")
        instance.preflight = mock.Mock()
        instance.router_policy = mock.Mock(return_value=copy.deepcopy(tenancy.EMPTY_POLICY))
        instance.create_segment = mock.Mock()
        instance.task = mock.Mock()
        instance.proxmox = mock.Mock()
        instance.proxmox.get.side_effect = lambda path: {"data": 100 + len(instance.state["vms"])}
        instance.bootstrap = mock.Mock()
        instance.configure = mock.Mock()
        with mock.patch.object(lab.time, "sleep"), contextlib.redirect_stdout(io.StringIO()):
            instance.create()
        self.assertEqual(len(instance.state["vms"]), 18)
        self.assertEqual(instance.create_segment.call_count, 6)
        self.assertEqual(instance.bootstrap.call_count, 18)
        self.assertEqual(sum(vm["tenant_id"] == SECOND for vm in instance.state["vms"]), 9)
        self.assertEqual(
            [vm["address"] for vm in instance.state["vms"][:9]],
            [vm["address"] for vm in instance.state["vms"][9:]],
        )
        self.assertTrue(all("witness" not in vm and vm["endpoint_identity"]
                            for vm in instance.state["vms"]))
        instance.configure.assert_called_once()

    def test_endpoint_service_binds_only_primary_address_for_udp_reply_identity(self):
        instance = fixture()
        vm = instance.state["vms"][0]
        command = instance.endpoint_command(vm)
        self.assertIn(f"serve {vm['address']} --identity {vm['endpoint_identity']}", command)
        self.assertNotIn("0.0.0.0", command)

    def test_bootstrap_does_not_add_secondary_addresses_or_start_extra_endpoint(self):
        instance = fixture()
        vm = instance.state["vms"][0]
        instance.serial = mock.Mock()
        instance.bootstrap(vm)
        self.assertEqual(instance.serial.call_count, 1)
        command = instance.serial.call_args.args[1]
        self.assertIn(f"systemd-run --collect --unit swiftfabric-network-lab {instance.endpoint_command(vm)}",
                      command)
        self.assertNotIn("swiftfabric-network-lab-witness", command)
        self.assertNotIn("ip addr replace", command)
        self.assertNotIn("witness", vm)

    def test_metadata_requires_distinct_reserved_zones_and_correct_segment_ownership(self):
        for corrupt in ("zone", "owner", None):
            instance = fixture()
            catalog = [
                {"id": tenant, "name": tenant, "conntrack_zone": 30000 + index,
                 "routing_table": 130000 + index}
                for index, tenant in enumerate(instance.state["tenant_ids"])
            ]
            if corrupt == "zone":
                catalog[1].update(conntrack_zone=30000, routing_table=130000)
            def request(method, path):
                if path == "/tenants":
                    return catalog
                segment = next(segment for segment in instance.state["segments"]
                               if path == f"/segments/{segment['id']}/routing")
                return {"tenant_id": "wrong" if corrupt == "owner" else segment["tenant_id"],
                        "tenant": next(tenant for tenant in catalog if tenant["id"] == segment["tenant_id"]),
                        "gateway_cidr": segment["gateway_cidr"]}
            instance.request = mock.Mock(side_effect=request)
            if corrupt:
                with self.assertRaises(RuntimeError):
                    instance.verify_tenant_metadata()
            else:
                instance.verify_tenant_metadata()
                self.assertEqual(instance.state["tenant_metadata"], catalog)

    def test_cli_tenancy_selects_subclass_and_persists_topology_choice(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "new"
            args = ["lab.py", "run", "--tenancy", "--state", str(path),
                    "--nodes", "hunsn3", "hunsn4", "hunsn5", "--router", "test-router",
                    "--image-volume", "VMData:import/image.qcow2", "--yes"]
            with mock.patch.object(sys, "argv", args), \
                    mock.patch.object(tenancy, "TenantLab") as constructor, \
                    contextlib.redirect_stdout(io.StringIO()):
                lab.main()
            constructor.assert_called_once_with(path)
            self.assertTrue(json.loads((path / "state.json").read_text())["tenancy"])
            constructor.return_value.run.assert_called_once()

    def test_tenancy_flag_cannot_silently_change_existing_test_state(self):
        with mock.patch.object(sys, "argv", ["lab.py", "test", "--tenancy"]), \
                contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                lab.main()

    def test_overlap_plan_reuses_identical_primary_ip_spaces_across_tenants(self):
        instance = fixture()
        self.assertEqual(len(instance.state["vms"]), 18)
        first, second = instance.state["segments"][:3], instance.state["segments"][3:]
        self.assertEqual([value["network"] for value in first], [value["network"] for value in second])
        self.assertEqual(len({value["id"] for value in first + second}), 6)
        vms = instance.state["vms"]
        first_addresses = [vm["address"] for vm in vms[:9]]
        second_addresses = [vm["address"] for vm in vms[9:]]
        self.assertEqual(first_addresses, second_addresses)
        self.assertEqual(len(set(first_addresses)), 9)
        self.assertTrue(all("witness" not in vm for vm in vms))
        self.assertEqual(len({vm["endpoint_identity"] for vm in vms}), 18)

    def test_preflight_expands_plan_without_creating_resources(self):
        instance = fixture()
        instance.state["segments"] = instance.state["segments"][:3]
        instance.router = mock.Mock(return_value={
            "id": "test-router", "tenant_id": "default", **copy.deepcopy(tenancy.EMPTY_POLICY),
        })
        instance.request = mock.Mock(side_effect=[[], [{"id": "default"}]])
        instance.proxmox = mock.Mock()
        instance.proxmox.get.return_value = {"data": {"memory": {"total": 10 * 1024**3, "used": 0}}}
        with mock.patch.object(lab.LiveLab, "preflight"):
            instance.preflight()
        self.assertEqual(len(instance.state["segments"]), 6)
        self.assertEqual(len({value["id"] for value in instance.state["segments"]}), 6)
        self.assertTrue(all(call.args[0] == "GET" for call in instance.request.call_args_list))

    def test_segment_cleanup_checks_tenant_as_well_as_name_and_gateway(self):
        segment = fixture().state["segments"][0]
        with self.assertRaisesRegex(RuntimeError, "ownership mismatch"):
            lab.assert_segment_owner({**segment, "tenant_id": SECOND}, segment)

    def test_permissive_acls_cover_both_tenants_without_duplicate_rules(self):
        instance = fixture()
        for segment in instance.state["segments"]:
            policy = tenancy.tenant_acl(instance.state["segments"], segment, True, True)
            self.assertEqual(len(policy["egress"]), 8)
            self.assertEqual(len(policy["ingress"]), 8)
            for direction in policy:
                self.assertEqual(len({json.dumps(rule, sort_keys=True) for rule in policy[direction]}), 8)

    def test_overlap_requires_no_write_conflict_then_explicit_confirmation(self):
        instance = fixture()
        segment = instance.state["segments"][3]
        instance.request = mock.Mock(side_effect=[
            [{"id": "default"}], [{"id": 49100}],
            [{"id": "default"}], [{"id": 49100}], {"tenant_id": SECOND},
        ])
        instance.checked = mock.Mock(return_value={
            "code": "tenant_overlap", "conflicting_segments": [49100],
            "suggested_tenant": {"id": SECOND, "name": SECOND},
        })
        instance.create_segment(segment)
        conflict = instance.checked.call_args
        self.assertEqual(conflict.args[2]["tenant_id"], "default")
        self.assertEqual(conflict.kwargs["status"], 409)
        confirmed = instance.request.call_args.args[2]
        self.assertEqual(confirmed["tenant_id"], "default")
        self.assertEqual(confirmed["new_tenant"], instance.state["new_tenant"])
        self.assertTrue(instance.state["tenant_created"])

    def test_overlap_side_effects_or_malformed_contract_fail_before_confirmation(self):
        for conflict, after in (
            ({"code": "wrong"}, [{"id": "default"}]),
            ({"code": "tenant_overlap", "conflicting_segments": [49100],
              "suggested_tenant": {"id": SECOND, "name": SECOND}}, [{"id": "default"}, {"id": SECOND}]),
        ):
            instance = fixture()
            instance.request = mock.Mock(side_effect=[
                [{"id": "default"}], [{"id": 49100}], after,
            ])
            instance.checked = mock.Mock(return_value=conflict)
            with self.assertRaises(RuntimeError):
                instance.create_segment(instance.state["segments"][3])
            self.assertFalse(any(call.args[0] == "POST" for call in instance.request.call_args_list))


class MatrixTests(unittest.TestCase):
    def cases(self, plane, expected):
        instance = fixture()
        instance.execute_probes = mock.Mock()
        instance.probes(plane, 1, expected)
        grouped, _, _ = instance.execute_probes.call_args.args
        return instance, [case for _, cases in grouped for case in cases]

    def test_l2_matrix_checks_primary_identity_for_overlapping_tenant_addresses(self):
        instance, cases = self.cases("l2", "allow")
        self.assertEqual(len(cases), 216)
        for case in cases:
            self.assertEqual(case["source_tenant"], case["destination_tenant"])
            self.assertEqual(case["expected"], "allow")
            self.assertTrue(case["endpoint_identity"])
            targets = [vm for vm in instance.state["vms"]
                       if vm["endpoint_identity"] == case["endpoint_identity"]]
            self.assertEqual(case["destination"], targets[0]["address"])
            self.assertEqual(targets[0]["tenant_id"], case["source_tenant"])
            self.assertEqual(case["destination_address_role"], "primary")
        overlap_cases = [case for case in cases if case["overlap_tenant_id"]]
        self.assertEqual(len(overlap_cases), 108)
        for case in overlap_cases:
            foreign = next(vm for vm in instance.state["vms"]
                           if vm["tenant_id"] == case["overlap_tenant_id"]
                           and vm["segment_id"] == case["overlap_segment_id"]
                           and vm["address"] == case["destination"])
            self.assertNotEqual(foreign["tenant_id"], case["destination_tenant"])
            self.assertNotEqual(foreign["segment_id"], case["destination_segment"])

    def test_east_west_overlapping_addresses_resolve_to_source_tenant_identity(self):
        instance, cases = self.cases("east-west", "allow")
        self.assertEqual(len(cases), 432)
        for case in cases:
            self.assertEqual(case["expected"], "allow")
            self.assertEqual(case["source_tenant"], case["destination_tenant"])
            self.assertNotEqual(case["source_segment"], case["destination_segment"])
        overlap_cases = [case for case in cases if case["overlap_tenant_id"]]
        self.assertEqual(len(overlap_cases), 216)
        for case in overlap_cases:
            foreign = next(vm for vm in instance.state["vms"]
                           if vm["tenant_id"] == case["overlap_tenant_id"]
                           and vm["segment_id"] == case["overlap_segment_id"]
                           and vm["address"] == case["destination"])
            self.assertNotEqual(foreign["tenant_id"], case["destination_tenant"])
            self.assertNotEqual(foreign["segment_id"], case["destination_segment"])
        _, denied = self.cases("east-west", "drop")
        self.assertTrue(all(case["expected"] == "drop" for case in denied))
        self.assertTrue(all(case["source_tenant"] == case["destination_tenant"] for case in denied))
        self.assertTrue(any(case["source_node"] == case["destination_node"] for case in cases))
        self.assertTrue(any(case["source_node"] != case["destination_node"] for case in cases))

    def test_wan_only_active_tenant_can_pass_and_deny_phase_denies_everyone(self):
        _, cases = self.cases("north-south", "allow")
        self.assertEqual(len(cases), 36)
        self.assertEqual(sum(case["expected"] == "allow" for case in cases), 18)
        self.assertTrue(all(case["dns"] and case["destination_port"] == 53 for case in cases))
        _, denied = self.cases("north-south", "drop")
        self.assertTrue(all(case["expected"] == "drop" for case in denied))

    def test_health_checks_remote_primary_and_ports_do_not_repeat(self):
        instance = fixture()
        instance.execute_probes = mock.Mock()
        instance.probes("health", 12, "allow")
        instance.probes("l2", 1, "allow")
        grouped = [call.args[0] for call in instance.execute_probes.call_args_list]
        cases = [case for batch in grouped for _, group in batch for case in group]
        keys = [(case["source_segment"], case["source"], case["source_port"]) for case in cases]
        self.assertEqual(len(keys), len(set(keys)))
        self.assertEqual(sum(case["plane"] == "health" for case in cases), 36)
        self.assertTrue(all(case["destination"] == next(
            vm["address"] for vm in instance.state["vms"]
            if vm["endpoint_identity"] == case["endpoint_identity"]
        ) for case in cases if case["plane"] == "health"))
        for vm in instance.state["vms"]:
            vm["next_source_port"] = 65000
        with self.assertRaisesRegex(RuntimeError, "exhausted"):
            instance.probes("health", 2, "allow")

    def test_health_never_falls_back_to_guest_local_when_remote_peer_is_missing(self):
        instance = fixture()
        for vm in instance.state["vms"]:
            vm["node"] = "a"
        with self.assertRaisesRegex(RuntimeError, "another host"):
            instance.probes("health", 0, "allow")

    def test_health_uses_remote_primary_ring(self):
        instance = fixture()
        instance.execute_probes = mock.Mock()
        for phase in (0, 12, 13, 14, 15, 16):
            instance.probes("health", phase, "allow")
            grouped = instance.execute_probes.call_args.args[0]
            cases = [case for _, batch in grouped for case in batch]
            self.assertEqual(len(cases), 36)
            for case in cases:
                self.assertNotEqual(case["source_node"], case["destination_node"])
                self.assertEqual(case["source_segment"], case["destination_segment"])
                self.assertEqual(case["source_tenant"], case["destination_tenant"])
            for vm in instance.state["vms"]:
                for protocol in ("tcp", "udp"):
                    self.assertEqual(sum(
                        case["destination"] == vm["address"] and case["protocol"] == protocol
                        and case["endpoint_identity"] == vm["endpoint_identity"]
                        for case in cases
                    ), 1)

    def test_old_witness_address_state_is_rejected_before_probing(self):
        instance = fixture()
        instance.state["ready"] = True
        instance.state["vms"][0]["witness"] = "10.253.244.20"
        with self.assertRaisesRegex(RuntimeError, "secondary witness addresses"):
            instance.test()

    def test_order_covers_rbac_acl_phases_and_both_sequential_wan_tenants(self):
        instance = fixture()
        for segment in instance.state["segments"]:
            segment.pop("_version")
        metadata = [
            {key: segment[key] for key in ("id", "name", "gateway_cidr", "tenant_id")}
            | {"_version": 17 + index}
            for index, segment in enumerate(instance.state["segments"])
        ]
        instance.owned_segment = tenancy.LiveLab.owned_segment.__get__(instance)
        instance.state["ready"] = True
        instance.state["rbac"] = rbac_records()
        instance.rbac_tests = mock.Mock()
        instance.verify_tenant_metadata = mock.Mock()
        instance.probes = mock.Mock(wraps=instance.probes)
        instance.execute_probes = mock.Mock()
        instance.set_acls = mock.Mock()
        instance.set_wan = mock.Mock()
        def migration(tenant_id, report):
            report["flows"].extend({"passed": True} for _ in range(6))
            report["migrations"].append({"passed": True})

        instance.migration_acceptance = mock.Mock(side_effect=migration)
        def checked(method, path, body=None, **kwargs):
            if path.startswith("/segments/") and path.endswith("/north-south-router"):
                current = next(item for item in metadata if item["id"] == int(path.split("/")[2]))
                self.assertEqual(body["_version"], current["_version"])

        instance.checked = mock.Mock(side_effect=checked)
        instance.request = mock.Mock(side_effect=lambda method, path, body=None: (
            copy.deepcopy(metadata) if (method, path) == ("GET", "/segments") else
            {
                "status": "active", "deployment_mode": "standalone",
                "tenant_id": instance.state["wan_tenant"], "_version": 1,
                **copy.deepcopy(tenancy.EMPTY_POLICY),
            } if method == "GET" and "/north-south-routers/" in path else
            {"acl": {"ingress": [], "egress": []}}
        ))
        instance.switch_tenant = mock.Mock(side_effect=lambda tenant: instance.state.update(wan_tenant=tenant))
        with mock.patch.object(tenancy.time, "sleep"), mock.patch.object(tenancy, "private_write"):
            instance.test()
        self.assertEqual(instance.switch_tenant.call_args_list,
                         [mock.call("default"), mock.call(SECOND), mock.call("default")])
        self.assertEqual(instance.set_acls.call_args_list, [
            mock.call(False, False), mock.call(True, False), mock.call(False, True),
            mock.call(True, True), mock.call(False, False),
            mock.call(False, False), mock.call(True, True),
            mock.call(False, False), mock.call(True, True), mock.call(True, True),
        ])
        self.assertEqual(
            [call.args[0] for call in instance.migration_acceptance.call_args_list],
            ["default", SECOND],
        )
        self.assertEqual(sum(call.args[0] == "north-south" for call in instance.probes.call_args_list), 6)
        self.assertEqual(sum(call.kwargs.get("status") == 409 for call in instance.checked.call_args_list), 4)
        cases = [case for call in instance.execute_probes.call_args_list
                 for _, batch in call.args[0] for case in batch]
        self.assertTrue(cases)
        self.assertTrue({"l2", "east-west", "north-south"}.issubset(
            {case["plane"] for case in cases}))
        self.assertTrue(instance.state["test_complete"])
        self.assertTrue(instance.state["migration_acceptance"]["passed"])
        self.assertTrue(all("_version" not in segment for segment in instance.state["segments"]))

    def test_cross_tenant_attachment_reloads_stale_plan_version(self):
        instance = fixture()
        instance.state.update(ready=True, rbac=rbac_records())
        instance.verify_tenant_metadata = mock.Mock()
        instance.rbac_tests = mock.Mock()
        instance.probes = mock.Mock()
        instance.set_acls = mock.Mock()
        instance.set_wan = mock.Mock()
        instance.switch_tenant = mock.Mock(side_effect=lambda tenant: instance.state.update(wan_tenant=tenant))
        def migration(tenant_id, report):
            report["flows"].extend({"passed": True} for _ in range(6))
            report["migrations"].append({"passed": True})

        instance.migration_acceptance = mock.Mock(side_effect=migration)
        metadata = [
            {key: segment[key] for key in ("id", "name", "gateway_cidr", "tenant_id")}
            | {"_version": 37 + index}
            for index, segment in enumerate(instance.state["segments"])
        ]
        instance.owned_segment = tenancy.LiveLab.owned_segment.__get__(instance)

        def request(method, path, body=None):
            if path == "/segments":
                return copy.deepcopy(metadata)
            if path == "/north-south-routers/test-router":
                return {
                    "status": "active", "deployment_mode": "standalone", "_version": 9,
                    "tenant_id": instance.state["wan_tenant"], **tenancy.EMPTY_POLICY,
                }
            if path.endswith("/routing"):
                return {"acl": {"ingress": [], "egress": []}}
            self.fail(f"unexpected API call: {method} {path}")

        def checked(method, path, body=None, **kwargs):
            if path.startswith("/segments/"):
                current = next(item for item in metadata if item["id"] == int(path.split("/")[2]))
                self.assertEqual(body, {"router_id": "test-router", "_version": current["_version"]})
                self.assertNotEqual(current["tenant_id"], instance.state["wan_tenant"])

        instance.request = mock.Mock(side_effect=request)
        instance.checked = mock.Mock(side_effect=checked)
        with mock.patch.object(tenancy.time, "sleep"), mock.patch.object(tenancy, "private_write"):
            instance.test()
        self.assertEqual(sum(call.args[1].startswith("/segments/")
                             for call in instance.checked.call_args_list), 2)
        self.assertTrue(all(segment["_version"] == 1 for segment in instance.state["segments"]))

    def test_single_tenant_matrix_keeps_same_host_controls_without_self_probes(self):
        instance = lab.LiveLab.__new__(lab.LiveLab)
        instance.state = fixture().state
        instance.state["vms"] = [vm for vm in instance.state["vms"] if vm["tenant_id"] == "default"]
        instance.state["segments"] = [
            segment for segment in instance.state["segments"] if segment["tenant_id"] == "default"
        ]
        instance.state["ready"] = True
        instance.save = mock.Mock()
        instance.execute_probes = mock.Mock()
        instance.set_acls = mock.Mock()
        instance.set_wan = mock.Mock()
        instance.request = mock.Mock(return_value={"acl": {"ingress": [], "egress": []}})
        with mock.patch.object(lab.time, "sleep"):
            instance.test()
        cases = [case for call in instance.execute_probes.call_args_list
                 for _, batch in call.args[0] for case in batch]
        self.assertTrue(cases)
        self.assertTrue({"l2", "east-west", "north-south"}.issubset(
            {case["plane"] for case in cases}))
        health = [case for case in cases if case["plane"] == "health"]
        self.assertEqual({case["phase"] for case in health}, {12, 13, 14, 16})
        self.assertTrue(all(case["source_node"] != case["destination_node"] for case in health))

    def test_failure_retains_incomplete_acceptance_even_after_previous_success(self):
        instance = fixture()
        instance.state.update(ready=True, test_complete=True, rbac=rbac_records())
        instance.rbac_tests = mock.Mock(side_effect=RuntimeError("denial failed"))
        instance.verify_tenant_metadata = mock.Mock()
        with tempfile.TemporaryDirectory() as directory:
            instance.directory = Path(directory)
            (instance.directory / "acceptance.json").write_text('{"complete": true}')
            with self.assertRaisesRegex(RuntimeError, "denial failed"):
                instance.test()
            self.assertFalse(json.loads((instance.directory / "acceptance.json").read_text())["complete"])
            self.assertFalse(instance.state["test_complete"])


class MigrationAcceptanceTests(unittest.TestCase):
    def test_repeated_acceptance_plans_preserve_stationary_endpoints_after_migration(self):
        instance = fixture()
        original_nodes = {vm["vmid"]: vm["node"] for vm in instance.state["vms"]}
        for round_index in range(4):
            plans = [instance.migration_plan(tenant) for tenant in instance.state["tenant_ids"]]
            self.assertEqual(
                [plan["target_node"] for plan in plans],
                ["b", "c"] if round_index % 2 == 0 else ["a", "a"],
            )
            for plan in plans:
                self.assertEqual(
                    {plan["source_node"], plan["target_node"], plan["endpoint_node"]},
                    set(instance.state["nodes"]),
                )
                self.assertTrue(all(
                    endpoint["node"] == plan["endpoint_node"]
                    and endpoint["node"] == original_nodes[endpoint["vmid"]]
                    and endpoint is not plan["source"]
                    for endpoint in plan["endpoints"]
                ))
                self.assertEqual(len(plan["cases"]), 6)
                plan["source"]["node"] = plan["target_node"]

    def test_repeated_plan_rejects_missing_third_host_endpoints_without_spending_ports(self):
        instance = fixture()
        plan = instance.migration_plan("default")
        source = plan["source"]
        source["node"] = plan["target_node"]
        for endpoint in plan["endpoints"]:
            endpoint["node"] = source["node"]
        next_port = source["next_source_port"]
        with self.assertRaisesRegex(RuntimeError, "third enrolled host"):
            instance.migration_plan("default")
        self.assertEqual(source["next_source_port"], next_port)

    def test_failed_overlap_retains_guest_flow_observations(self):
        instance = fixture()
        instance.router = mock.Mock(return_value={"tenant_id": "default"})
        instance.verify_wan_policy = mock.Mock()
        instance.reconcile_vm_node = mock.Mock()
        instance.migration_preflight = mock.Mock(return_value={})
        instance.install_guest_tool = mock.Mock()
        instance.start_held_endpoint = mock.Mock(return_value="held-endpoint")
        instance.start_migration_flows = mock.Mock(return_value={"unit": "held-worker"})
        instance.migration_workload_view = mock.Mock(return_value={})
        instance.wait_for_migration_binding = mock.Mock(return_value={
            "ip": "10.253.244.10", "mac": "02:00:00:00:00:01",
            "host_id": "a", "vtep_ip": "192.0.2.1",
        })
        instance.migration_clock_sample = mock.Mock(return_value={})
        instance.migrate_vm = mock.Mock(return_value={})
        instance.require_migration_learning = mock.Mock()
        observations = [{"case_id": "north-south-udp", "passed": False,
                         "error": "TimeoutError: timed out", "samples": []}]
        instance.read_migration_results = mock.Mock(return_value=observations)
        instance.verify_migration_overlap = mock.Mock(side_effect=RuntimeError("held traffic failed"))
        instance.setup_serial = mock.Mock()
        with tempfile.TemporaryDirectory() as directory:
            instance.directory = Path(directory)
            report = instance.new_migration_report()
            with self.assertRaisesRegex(RuntimeError, "held traffic failed"):
                instance.migration_acceptance("default", report)
            saved = json.loads((instance.directory / "migration-acceptance.json").read_text())
        self.assertEqual(saved["flows"], observations)
        self.assertFalse(saved["passed"])
        self.assertIn("held traffic failed", saved["errors"][0]["error"])

    def test_permissive_acls_allow_every_planned_east_west_flow_in_both_directions(self):
        instance = fixture()
        for tenant_id in instance.state["tenant_ids"]:
            plan = instance.migration_plan(tenant_id)
            source_segment = next(segment for segment in instance.state["segments"]
                                  if segment["id"] == plan["source"]["segment_id"])
            destination_segment = next(segment for segment in instance.state["segments"]
                                       if segment["id"] == plan["endpoints"][1]["segment_id"])
            for egress, ingress in ((False, False), (True, False), (False, True), (True, True)):
                source_policy = tenancy.tenant_acl(
                    instance.state["segments"], source_segment, egress, ingress,
                )
                destination_policy = tenancy.tenant_acl(
                    instance.state["segments"], destination_segment, egress, ingress,
                )
                for case in plan["cases"]:
                    if case["plane"] != "east-west":
                        continue
                    rule = lab.acl_rule(
                        source_segment["network"], destination_segment["network"],
                        case["protocol"], str(case["destination_port"]),
                    )
                    with self.subTest(tenant=tenant_id, protocol=case["protocol"],
                                      egress=egress, ingress=ingress):
                        self.assertEqual(rule in source_policy["egress"], egress)
                        self.assertEqual(rule in destination_policy["ingress"], ingress)

    def test_held_endpoint_uses_supported_systemd_run_options_and_checks_readiness(self):
        instance = fixture()
        vm = instance.state["vms"][2]
        instance.setup_serial = mock.Mock()
        unit = instance.start_held_endpoint(vm, 0)
        self.assertEqual(unit, f"sf-lab-migration-aaaaaaaa-t0-ep-{vm['vmid']}")
        self.assertEqual(shlex.split(instance.setup_serial.call_args_list[0].args[1]), [
            "sudo", "-n", "systemd-run", "--collect", f"--unit={unit}",
            "/usr/bin/python3", "/opt/swiftfabric-network-lab.py", "serve-held",
            vm["address"], "--tcp-port", str(tenancy.HELD_TCP_PORT),
            "--udp-port", str(tenancy.HELD_UDP_PORT), "--identity", vm["endpoint_identity"],
        ])
        self.assertEqual(instance.setup_serial.call_args_list[1], mock.call(
            vm, f"sudo -n systemctl is-active --quiet {unit}.service", timeout=30,
        ))

    def test_migration_flows_use_supported_systemd_run_options_and_wait_for_progress(self):
        instance = fixture()
        plan = instance.migration_plan("default")
        source = plan["source"]
        progress = {case["case_id"]: {"started": True} for case in plan["cases"]}
        instance.setup_serial = mock.Mock(side_effect=["", json.dumps(progress)])
        worker = instance.start_migration_flows(source, plan, 0)
        unit = f"sf-lab-migration-aaaaaaaa-t0-vm-{source['vmid']}"
        stem = f"/run/swiftfabric-network-lab-migration/aaaaaaaa-t0-vm-{source['vmid']}"
        self.assertEqual(worker, {
            "unit": unit, "progress_path": stem + "-progress.json",
            "output_path": stem + "-results.json", "started": progress,
        })
        commands = instance.setup_serial.call_args_list[0].args[1].split(" && ")
        self.assertEqual(shlex.split(commands[0]), [
            "sudo", "-n", "install", "-d", "-m", "700",
            "/run/swiftfabric-network-lab-migration",
        ])
        self.assertEqual(shlex.split(commands[1]), [
            "sudo", "-n", "rm", "-f", worker["progress_path"], worker["output_path"],
        ])
        launch = shlex.split(commands[2])
        self.assertEqual(launch[:9], [
            "sudo", "-n", "systemd-run", "--collect", f"--unit={unit}",
            f"--property=RuntimeMaxSec={tenancy.MIGRATION_FLOW_SECONDS + 60}",
            "/usr/bin/python3", "/opt/swiftfabric-network-lab.py", "hold",
        ])
        self.assertEqual(json.loads(gzip.decompress(base64.b64decode(launch[9]))), plan["cases"])
        self.assertEqual(launch[10:], [
            "--progress-file", worker["progress_path"], "--output-file", worker["output_path"],
        ])
        self.assertEqual(instance.setup_serial.call_count, 2)
        self.assertIn(f"sudo -n cat {worker['progress_path']}",
                      instance.setup_serial.call_args_list[1].args[1])

    def test_migration_startup_timeout_names_only_cases_without_verified_responses(self):
        instance = fixture()
        plan = instance.migration_plan("default")
        progress = {case["case_id"]: {"verified_responses": 1}
                    for case in plan["cases"] if case["plane"] != "east-west"}
        instance.setup_serial = mock.Mock(side_effect=["", json.dumps(progress)])
        with mock.patch.object(tenancy.time, "monotonic", side_effect=[0, 0, 31]), \
                mock.patch.object(tenancy.time, "sleep"), \
                self.assertRaisesRegex(
                    TimeoutError, "missing verified responses: east-west-tcp, east-west-udp$",
                ):
            instance.start_migration_flows(plan["source"], plan, 0)

    def test_reconcile_uses_inventory_instead_of_wrong_host_config_probes(self):
        for recorded_node in ("a", "b"):
            with self.subTest(recorded_node=recorded_node):
                instance = fixture()
                vm = instance.state["vms"][0]
                vm["node"] = recorded_node
                configuration = {
                    "name": vm["name"],
                    "description": f"SwiftFabric live network lab {instance.state['run_id']}",
                    "net0": f"virtio=02:00:00:00:00:01,bridge=sf-br{vm['segment_id']}",
                }

                def get(path, params=None):
                    if path == "/cluster/resources":
                        self.assertEqual(params, {"type": "vm"})
                        return {"data": [{"vmid": vm["vmid"], "type": "qemu", "node": "a"}]}
                    if path == f"/nodes/a/qemu/{vm['vmid']}/config":
                        return {"data": configuration}
                    raise lab.ProxmoxAPIError("Configuration file does not exist", 500)

                instance.proxmox = mock.Mock()
                instance.proxmox.get.side_effect = get
                self.assertEqual(instance.reconcile_vm_node(vm), "a")
                self.assertEqual(vm["node"], "a")
                instance.save.assert_called_once()
                self.assertEqual(instance.proxmox.get.call_args_list, [
                    mock.call("/cluster/resources", params={"type": "vm"}),
                    mock.call(f"/nodes/a/qemu/{vm['vmid']}/config"),
                ])

    def test_reconcile_rejects_missing_ambiguous_non_qemu_and_unenrolled_vm(self):
        for resources in (
            [],
            [{"vmid": 100, "type": "qemu", "node": "a"}] * 2,
            [{"vmid": 100, "type": "lxc", "node": "a"}],
            [{"vmid": 100, "type": "qemu", "node": "outside"}],
        ):
            with self.subTest(resources=resources):
                instance = fixture()
                vm = instance.state["vms"][0]
                instance.proxmox = mock.Mock()
                instance.proxmox.get.return_value = {"data": resources}
                instance.vm_config = mock.Mock()
                with self.assertRaises(RuntimeError):
                    instance.reconcile_vm_node(vm)
                self.assertEqual(vm["node"], "a")
                instance.vm_config.assert_not_called()
                instance.save.assert_not_called()

    def test_reconcile_preserves_recorded_node_when_owner_or_api_check_fails(self):
        for failure in (
            RuntimeError("ownership mismatch"),
            lab.ProxmoxAPIError("permission denied", 403),
            lab.ProxmoxAPIError("backend unavailable", 500),
        ):
            with self.subTest(failure=failure):
                instance = fixture()
                vm = instance.state["vms"][0]
                instance.proxmox = mock.Mock()
                instance.proxmox.get.return_value = {
                    "data": [{"vmid": vm["vmid"], "type": "qemu", "node": "b"}],
                }
                instance.vm_config = mock.Mock(side_effect=failure)
                with self.assertRaises(type(failure)) as caught:
                    instance.reconcile_vm_node(vm)
                self.assertIs(caught.exception, failure)
                self.assertEqual(vm["node"], "a")
                instance.save.assert_not_called()

    def test_migration_reconciles_current_host_after_task_success_or_failure(self):
        for task_failed in (False, True):
            with self.subTest(task_failed=task_failed), tempfile.TemporaryDirectory() as directory:
                instance = fixture()
                instance.directory = Path(directory)
                vm = instance.state["vms"][0]
                locations = iter(["a", "a", "b", "b"] if not task_failed else ["a", "a"])
                current_node = "a"

                def get(path, params=None):
                    nonlocal current_node
                    if path == "/cluster/resources":
                        current_node = next(locations)
                        return {"data": [{
                            "vmid": vm["vmid"], "type": "qemu", "node": current_node,
                        }]}
                    if path == f"/nodes/{current_node}/qemu/{vm['vmid']}/config":
                        return {"data": {
                            "name": vm["name"],
                            "description": f"SwiftFabric live network lab {instance.state['run_id']}",
                            "net0": f"virtio=02:00:00:00:00:01,bridge=sf-br{vm['segment_id']}",
                        }}
                    if path == f"/nodes/{current_node}/qemu/{vm['vmid']}/status/current":
                        return {"data": {"status": "running"}}
                    if path == f"/nodes/a/qemu/{vm['vmid']}/migrate":
                        return {"data": {"allowed_nodes": ["b"]}}
                    raise lab.ProxmoxAPIError("Configuration file does not exist", 500)

                instance.proxmox = mock.Mock()
                instance.proxmox.get.side_effect = get
                instance.proxmox.post.return_value = {"data": "UPID:a:migration"}
                if task_failed:
                    instance.proxmox.wait_for_task.side_effect = RuntimeError("migration task failed")
                report = {"migrations": []}
                with mock.patch.object(tenancy.time, "sleep") as sleep:
                    if task_failed:
                        with self.assertRaisesRegex(RuntimeError, "migration task failed"):
                            instance.migrate_vm(vm, "b", report, "default")
                    else:
                        result = instance.migrate_vm(vm, "b", report, "default")
                        self.assertTrue(result["migration_completed"])
                        sleep.assert_called_once_with(2)
                expected_node = "a" if task_failed else "b"
                self.assertEqual(vm["node"], expected_node)
                saved = json.loads((instance.directory / "migration-acceptance.json").read_text())
                self.assertEqual(saved["migrations"][0]["actual_node"], expected_node)
                self.assertEqual(
                    saved["migrations"][0]["migration_completed"], not task_failed,
                )
                instance.proxmox.post.assert_called_once_with(
                    f"/nodes/a/qemu/{vm['vmid']}/migrate",
                    {"target": "b", "online": 1, "with-local-disks": 1},
                )

    def test_plan_holds_tcp_and_udp_for_all_planes_across_distinct_vteps(self):
        instance = fixture()
        plans = [instance.migration_plan(tenant) for tenant in instance.state["tenant_ids"]]
        self.assertEqual([plan["target_node"] for plan in plans], ["b", "c"])
        self.assertEqual([plan["endpoint_node"] for plan in plans], ["c", "b"])
        self.assertEqual(plans[0]["source"]["address"], plans[1]["source"]["address"])
        for plan in plans:
            cases = plan["cases"]
            self.assertEqual(len(cases), 6)
            self.assertEqual(
                {(case["plane"], case["protocol"]) for case in cases},
                {(plane, protocol) for plane in ("l2", "east-west", "north-south")
                 for protocol in ("tcp", "udp")},
            )
            l2 = [case for case in cases if case["plane"] == "l2"]
            east_west = [case for case in cases if case["plane"] == "east-west"]
            north_south = [case for case in cases if case["plane"] == "north-south"]
            self.assertTrue(all(case["destination_vm"] for case in l2 + east_west))
            self.assertTrue(all(case["destination_port"] == 53 for case in north_south))
            self.assertTrue(all(case["dns"] and case["echo_format"] == "plain"
                                for case in north_south))
            self.assertTrue(all(case["source_port"] != case2["source_port"]
                                for index, case in enumerate(cases)
                                for case2 in cases[index + 1:]))
            self.assertEqual(
                next(vm for vm in plan["endpoints"]
                     if vm["name"] == l2[0]["destination_vm"])["segment_id"],
                plan["source"]["segment_id"],
            )
            self.assertNotEqual(
                next(vm for vm in plan["endpoints"]
                     if vm["name"] == east_west[0]["destination_vm"])["segment_id"],
                plan["source"]["segment_id"],
            )

    def test_controller_binding_and_guest_identity_must_converge_on_target(self):
        instance = fixture()
        plan = instance.migration_plan("default")
        plan["host_bindings"] = {
            "b": {"host_id": "host-b", "vtep_ip": "172.16.0.2"},
        }
        source = plan["source"]
        gateway = "10.253.244.1"
        baseline = {
            "boot_id": "boot-id", "source": source["address"], "device": "ens18",
            "mac": "02:00:00:00:00:01", "gateway": gateway,
        }
        gateway_mac = f"02:53:46:00:{source['segment_id'] >> 8:02x}:{source['segment_id'] & 255:02x}"
        instance.request = mock.Mock(return_value={"entries": [{
            "ip": source["address"], "mac": baseline["mac"],
            "host_id": "host-b", "vtep_ip": "172.16.0.2",
        }]})
        instance.migration_workload_view = mock.Mock(return_value={
            **baseline, "neighbors": [{
                "dst": gateway, "lladdr": gateway_mac, "state": ["REACHABLE"],
            }],
        })
        migration = {
            "target": "b",
            "source_binding": {
                "ip": source["address"], "mac": baseline["mac"],
                "host_id": "host-a", "vtep_ip": "172.16.0.1",
            },
        }
        report = {"migrations": [migration]}
        with tempfile.TemporaryDirectory() as directory:
            instance.directory = Path(directory)
            instance.require_migration_learning(plan, baseline, migration, report)
            saved = json.loads((instance.directory / "migration-acceptance.json").read_text())
        self.assertTrue(migration["learning_passed"])
        self.assertEqual(saved["migrations"][0]["controller_binding"]["vtep_ip"], "172.16.0.2")
        self.assertEqual(migration["source_binding"]["vtep_ip"], "172.16.0.1")
        self.assertEqual(instance.request.call_args.args[1], f"/segments/{source['segment_id']}/macs")

    def test_migration_overlap_requires_verified_responses_before_and_after_event(self):
        value = {
            **lab_case(), "case_id": "l2-tcp", "plane": "l2", "tenant_id": "default",
            "echo_format": "observed-peer",
        }
        measured = continuity_report(value)
        migration = {"started_epoch": 1005.0, "completed_epoch": 1008.0}
        before = {"guest_monotonic": 99.0, "operator_epoch_bounds": [999.0, 1001.0]}
        after = {"guest_monotonic": 200.0, "operator_epoch_bounds": [1100.0, 1102.0]}
        verified = tenancy.TenantLab.verify_migration_overlap(
            [value], [measured], migration, before, after,
        )
        self.assertTrue(verified[0]["migration_overlap"]["passed"])
        self.assertEqual(verified[0]["operator_clock_offset_seconds"], [900.0, 902.0])
        migration["completed_epoch"] = 1100.0
        with self.assertRaisesRegex(RuntimeError, "did not span migration"):
            tenancy.TenantLab.verify_migration_overlap(
                [value], [continuity_report(value)], migration, before, after,
            )


def lab_case():
    return {
        "source": "127.0.0.1", "source_port": 20000,
        "destination": "127.0.0.1", "destination_port": 18082,
        "protocol": "tcp", "duration_seconds": 30,
        "expected_nat_address": "127.0.0.1",
    }


def continuity_report(value):
    samples = [{
        "sequence": index, "sent_seconds": index + 0.09,
        "received_seconds": index + 0.1,
        "peer": [value["expected_nat_address"], 23456],
    } for index in range(value["duration_seconds"])]
    return {
        **guest.held_summary(value, samples, value["duration_seconds"], ""),
        "started_epoch": 1000.0, "started_monotonic": 100.0,
        "connected": True, "requests": len(samples),
        "application_bytes_sent": 1000, "application_bytes_received": 2000,
    }


class HandoffTests(unittest.TestCase):
    def test_handoff_orders_detach_clear_reassign_attach_and_restores_original_owner(self):
        instance = fixture()
        for segment in instance.state["segments"]:
            segment["_version"] = 1
        instance.router = mock.Mock(return_value={
            "tenant_id": "default", "_version": 1, **copy.deepcopy(tenancy.EMPTY_POLICY),
        })
        instance.state["segments"][0].update(
            north_south_router={"id": "test-router"}, _version=1,
        )
        instance.owned_segment = mock.Mock(side_effect=lambda segment: segment)
        instance.request = mock.Mock(side_effect=lambda method, path, body=None:
                                     instance.state["segments"] if method == "GET" else {"tenant_id": SECOND})
        instance.set_wan = mock.Mock()
        calls = mock.Mock()
        calls.attach_mock(instance.request, "request")
        calls.attach_mock(instance.set_wan, "wan")
        with mock.patch.object(tenancy.time, "sleep"):
            instance.switch_tenant(SECOND)
        operations = calls.mock_calls
        clear = operations.index(mock.call.wan(False, restore=True))
        reassign = operations.index(mock.call.request(
            "PUT", "/north-south-routers/test-router/tenant",
            {"tenant_id": SECOND, "_version": 1}))
        detach = operations.index(mock.call.request(
            "PUT", "/segments/49100/north-south-router",
            {"router_id": None, "_version": 1}))
        self.assertLess(detach, clear)
        self.assertLess(clear, reassign)
        attachments = [call for call in operations if call[0] == "request"
                       and len(call.args) == 3
                       and call.args[2].get("router_id") == "test-router"]
        self.assertEqual(len(attachments), 3)
        self.assertTrue(all(operations.index(call) > reassign for call in attachments))
        self.assertEqual(instance.state["wan_tenant"], SECOND)

    def test_external_policy_or_attachment_fails_before_any_mutation(self):
        for external_policy in (True, False):
            instance = fixture()
            policy = copy.deepcopy(tenancy.EMPTY_POLICY)
            if external_policy:
                policy["masquerade_source_cidrs"] = ["10.99.0.0/24"]
            instance.router = mock.Mock(return_value={"tenant_id": "default", **policy})
            instance.request = mock.Mock(return_value=[{
                "id": 12345, "north_south_router": {"id": "test-router"},
            }])
            with self.assertRaisesRegex(RuntimeError, "outside|unowned"):
                instance.switch_tenant(SECOND)
            self.assertFalse(any(call.args[0] == "PUT" for call in instance.request.call_args_list))

    def test_wan_denial_preserves_nat_then_restore_is_empty(self):
        instance = fixture()
        instance.router = mock.Mock(side_effect=lambda: {
            "tenant_id": instance.state["wan_tenant"],
            "_version": 1,
            **copy.deepcopy(instance.state.get("last_wan_policy", tenancy.EMPTY_POLICY)),
        })
        instance.request = mock.Mock(side_effect=lambda method, path, body=None:
                                     {**copy.deepcopy(instance.state.get("last_wan_policy", tenancy.EMPTY_POLICY)),
                                      "_version": 1} if method == "GET" else body)
        instance.set_wan(True)
        allowed = copy.deepcopy(instance.state["last_wan_policy"])
        self.assertEqual(len(allowed["wan_egress_rules"]), 6)
        self.assertEqual(len(allowed["masquerade_source_cidrs"]), 3)
        instance.set_wan(False)
        self.assertEqual(instance.state["last_wan_policy"]["masquerade_source_cidrs"],
                         allowed["masquerade_source_cidrs"])
        self.assertEqual(instance.state["last_wan_policy"]["wan_egress_rules"], [])
        instance.set_wan(False, restore=True)
        self.assertEqual(instance.state["last_wan_policy"], tenancy.EMPTY_POLICY)

    def test_wan_snapshot_change_is_rejected_before_pending_intent_or_write(self):
        instance = fixture()
        instance.router = mock.Mock(return_value={"tenant_id": "default", **tenancy.EMPTY_POLICY})
        instance.request = mock.Mock(return_value={
            **tenancy.EMPTY_POLICY, "masquerade_source_cidrs": ["10.99.0.0/24"],
            "_version": 24,
        })
        with self.assertRaisesRegex(RuntimeError, "outside the lab"):
            instance.set_wan(True)
        self.assertNotIn("pending_wan_policy", instance.state)
        instance.request.assert_called_once_with("GET", "/north-south-routers/test-router/wan-policy")

    def test_wan_writer_uses_independent_policy_version(self):
        instance = fixture()
        instance.router = mock.Mock(return_value={
            "tenant_id": "default", "_version": 3, **tenancy.EMPTY_POLICY,
        })
        instance.request = mock.Mock(side_effect=lambda method, path, body=None:
                                     {**tenancy.EMPTY_POLICY, "_version": 24}
                                     if method == "GET" else body)
        instance.set_wan(True)
        self.assertEqual(instance.request.call_args.args[2]["_version"], 24)

    def test_cleanup_restores_router_before_resources_and_deletes_only_owned_tenant(self):
        instance = fixture()
        instance.state["original_wan_policy"] = copy.deepcopy(tenancy.EMPTY_POLICY)
        instance.state["tenant_create_requested"] = True
        instance.switch_tenant = mock.Mock()
        instance.cleanup_rbac = mock.Mock()
        instance.request = mock.Mock(side_effect=lambda method, path, body=None:
                                     [{"id": "test-router"}] if path == "/north-south-routers"
                                     else [instance.state["new_tenant"]])
        calls = mock.Mock()
        calls.attach_mock(instance.switch_tenant, "handoff")
        calls.attach_mock(instance.cleanup_rbac, "rbac")
        with mock.patch.object(lab.LiveLab, "destroy") as destroy:
            calls.attach_mock(destroy, "resources")
            instance.destroy()
        self.assertEqual(calls.mock_calls[:3], [
            mock.call.handoff("default", attach=False), mock.call.rbac(),
            mock.call.resources(router_retired=False),
        ])
        instance.request.assert_called_with("DELETE", f"/tenants/{SECOND}?_version=1")
        self.assertFalse(instance.state["tenant_create_requested"])

    def test_cleanup_resumes_after_router_deleted_without_restoring_wan(self):
        instance = fixture()
        instance.state["original_wan_policy"] = copy.deepcopy(tenancy.EMPTY_POLICY)
        instance.switch_tenant = mock.Mock(side_effect=AssertionError("router already deleted"))
        instance.cleanup_rbac = mock.Mock()
        instance.request = mock.Mock(return_value=[])
        with mock.patch.object(lab.LiveLab, "destroy") as destroy:
            instance.destroy()
        instance.request.assert_called_once_with("GET", "/north-south-routers")
        instance.switch_tenant.assert_not_called()
        instance.cleanup_rbac.assert_called_once_with()
        destroy.assert_called_once_with(router_retired=True)

    def test_cleanup_rejects_invalid_inventory_or_existing_retired_router(self):
        for inventory in (None, [{}], [{"id": "test-router"}]):
            instance = fixture()
            instance.state["original_wan_policy"] = copy.deepcopy(tenancy.EMPTY_POLICY)
            instance.request = mock.Mock(return_value=inventory)
            instance.cleanup_rbac = mock.Mock()
            with mock.patch.object(lab.LiveLab, "destroy") as destroy:
                with self.assertRaisesRegex(RuntimeError, "refusing cleanup"):
                    instance.destroy(router_retired=True)
                destroy.assert_not_called()
                instance.cleanup_rbac.assert_not_called()

    def test_cleanup_after_preflight_failure_does_not_touch_router(self):
        instance = fixture()
        instance.state["router_identity"] = {"id": "test-router"}
        instance.switch_tenant = mock.Mock()
        instance.cleanup_rbac = mock.Mock()
        with mock.patch.object(lab.LiveLab, "destroy"):
            instance.destroy()
        instance.switch_tenant.assert_not_called()


class IdentityTests(unittest.TestCase):
    def route_output(self, gateway="10.253.244.1", returncode=0):
        device = mock.Mock(returncode=0, stdout=json.dumps([{
            "ifname": "ens18", "addr_info": [{"local": "10.253.244.10"}],
        }]))
        route = {"dev": "ens18"}
        if gateway is not None:
            route["gateway"] = gateway
        return [device, mock.Mock(returncode=returncode, stdout=json.dumps([route]))]

    def test_only_cross_tenant_verified_routes_can_classify_unreachable_as_isolation(self):
        case = {
            "source": "10.253.244.10", "destination": "10.253.245.30", "source_port": 20000,
            "destination_port": 18080, "protocol": "tcp", "expected": "drop",
            "isolation_probe": True, "gateway": "10.253.244.1",
        }
        for error in (errno.EHOSTUNREACH, errno.ENETUNREACH):
            connection = mock.MagicMock()
            connection.__enter__.return_value = connection
            connection.connect.side_effect = OSError(error, "unreachable")
            with mock.patch.object(guest.subprocess, "run", side_effect=self.route_output()), \
                    mock.patch.object(guest.socket, "socket", return_value=connection):
                result = guest.probe(case)
            self.assertTrue(result["passed"])
            self.assertIn("verified cross-tenant", result["detail"])
            with mock.patch.object(guest.socket, "socket", return_value=connection):
                ordinary = guest.probe({**case, "isolation_probe": False})
            self.assertFalse(ordinary["passed"])
            self.assertEqual(ordinary["outcome"], "error")

    def test_missing_or_wrong_guest_route_is_not_isolation(self):
        case = {
            "source": "10.253.244.10", "destination": "10.253.245.30", "source_port": 20000,
            "destination_port": 18080, "protocol": "tcp", "expected": "drop",
            "isolation_probe": True, "gateway": "10.253.244.1",
        }
        for output in (self.route_output(returncode=2), self.route_output(gateway="10.253.244.254")):
            with mock.patch.object(guest.subprocess, "run", side_effect=output), \
                    mock.patch.object(guest.socket, "socket") as connection:
                result = guest.probe(case)
            self.assertFalse(result["passed"])
            connection.assert_not_called()
        with mock.patch.object(guest.subprocess, "run", side_effect=TimeoutError()):
            result = guest.probe(case)
        self.assertFalse(result["passed"])

    def test_cross_tenant_on_link_route_requires_no_gateway(self):
        case = {"source": "10.253.244.10", "destination": "10.253.244.30",
                "expected": "drop", "gateway": "10.253.244.1"}
        with mock.patch.object(guest.subprocess, "run", side_effect=self.route_output(gateway=None)):
            guest.verify_isolation_route(case)
        with mock.patch.object(guest.subprocess, "run", side_effect=self.route_output()):
            with self.assertRaisesRegex(RuntimeError, "guest route"):
                guest.verify_isolation_route(case)

    def test_real_tcp_udp_replies_require_correct_endpoint_identity(self):
        with guest.TCPServer(("127.0.0.1", 0), guest.TCPHandler) as tcp, \
                guest.socketserver.ThreadingUDPServer(("127.0.0.1", 0), guest.UDPHandler) as udp:
            tcp.endpoint_identity = udp.endpoint_identity = "tenant-a-vm"
            for server in (tcp, udp):
                threading.Thread(target=server.serve_forever, daemon=True).start()
                self.addCleanup(server.shutdown)
            for protocol, port in (("tcp", tcp.server_address[1]), ("udp", udp.server_address[1])):
                case = {"source": "127.0.0.1", "destination": "127.0.0.1", "source_port": 0,
                        "destination_port": port, "protocol": protocol, "expected": "allow",
                        "endpoint_identity": "tenant-a-vm"}
                with mock.patch.object(guest, "echo_event"):
                    self.assertTrue(guest.probe(case)["passed"])
                    wrong = guest.probe({**case, "endpoint_identity": "tenant-b-vm"})
                self.assertFalse(wrong["passed"])
                self.assertEqual(wrong["outcome"], "error")

    def test_timeout_is_only_negative_success_and_handshake_is_not_a_drop(self):
        with guest.TCPServer(("127.0.0.1", 0), guest.TCPHandler) as tcp:
            tcp.endpoint_identity = "foreign-vm"
            threading.Thread(target=tcp.serve_forever, daemon=True).start()
            self.addCleanup(tcp.shutdown)
            case = {"source": "127.0.0.1", "destination": "127.0.0.1", "source_port": 0,
                    "destination_port": tcp.server_address[1], "protocol": "tcp", "expected": "drop"}
            with mock.patch.object(guest, "echo_event"):
                result = guest.probe(case)
            self.assertFalse(result["passed"])
            self.assertIn("handshake succeeded", result["detail"])


class RBACTests(unittest.TestCase):
    def test_expected_plain_text_denial_is_valid_but_overlap_requires_json(self):
        instance = fixture()
        with tempfile.TemporaryDirectory() as directory:
            instance.directory = Path(directory)
            instance.api = mock.Mock()
            instance.base_url = "https://controller/api/v1"
            instance.api.request.return_value = mock.Mock(
                status_code=403, content=b"Forbidden", headers={"Content-Type": "text/plain"},
            )
            self.assertIsNone(instance.checked("GET", "/hosts", status=403, token="scoped"))
            instance.api.request.return_value.json.assert_not_called()
        instance.request = mock.Mock(side_effect=[[{"id": "default"}], [{"id": 49100}]])
        instance.checked = mock.Mock(return_value=None)
        with self.assertRaisesRegex(RuntimeError, "structured JSON"):
            instance.create_segment(instance.state["segments"][3])

    def test_setup_rbac_creates_writer_and_reader_groups_for_each_tenant(self):
        instance = fixture()

        def request(method, path, body):
            if path == "/system/groups":
                record = instance.state["rbac"][-1]
                self.assertEqual(record["name"], body["name"])
                self.assertNotIn("token", record)
                return {"id": "group-" + body["name"]}
            return {"api_key": "test-key"}

        instance.request = mock.Mock(side_effect=request)
        instance.setup_rbac()
        self.assertEqual(len(instance.state["rbac"]), 4)
        for record in instance.state["rbac"]:
            scopes = tenancy.READ_ONLY_SCOPES if record["role"] == "reader" else tenancy.TENANT_SCOPES
            instance.request.assert_any_call("POST", "/system/groups", {
                "name": record["name"], "tenant_id": record["tenant_id"], "scopes": scopes,
            })
            self.assertEqual(record["token"], "test-key")
            self.assertTrue(record["user_requested"])

    def test_rbac_matrix_checks_group_scopes_key_lifecycle_and_escalation_denial(self):
        for routes in (None, [], [{
            "destination_cidr": "10.40.0.0/16", "next_hop": "198.51.100.21",
            "interface": "wan", "metric": 100,
        }]):
            with self.subTest(static_routes=routes):
                self.check_rbac_matrix({} if routes is None else {"static_routes": routes})

    def test_rbac_rejects_infrastructure_fields_even_with_static_routes(self):
        for field, value in (
            ("cluster", "private-cluster"), ("node", "private-node"),
            ("management_address_cidr", "192.0.2.20/24"), ("vtep_ip", "10.200.0.20"),
            ("ssh_private_key", "synthetic-key"), ("unexpected_field", None),
        ):
            with self.subTest(field=field), self.assertRaisesRegex(
                    RuntimeError, "tenant NSR view disclosed infrastructure fields"):
                self.check_rbac_matrix({"static_routes": [], field: value})

    def check_rbac_matrix(self, router_fields):
        instance = fixture()
        instance.state["rbac"] = rbac_records()
        instance.request = mock.Mock(side_effect=lambda method, path: {
            "username": path.rsplit("/", 1)[1], "_version": 7,
        })

        def checked(method, path, body=None, status=200, token=None, **kwargs):
            record = next((record for record in instance.state["rbac"] if record["token"] == token), None)
            tenant = record["tenant_id"] if record else None
            if status != 200:
                return None
            if path == "/system/me":
                return {"tenant_id": tenant, "is_admin": False}
            if path == "/tenants":
                return [{"id": tenant}]
            if path == "/segments":
                return [
                    {key: segment[key] for key in (
                        "id", "name", "gateway_cidr", "tenant_id", "_version",
                    )}
                    for segment in instance.state["segments"]
                    if segment["tenant_id"] == tenant
                ]
            if path == "/north-south-routers":
                return [{"tenant_id": tenant, **router_fields}]
            if method == "GET" and path.endswith("/acl"):
                return {"_version": 1}
            if method == "PUT" and path.endswith("/acl") and status == 200:
                return {"_version": body["_version"] + 1}
            if path == "/system/me/keys":
                scopes = tenancy.READ_ONLY_SCOPES if record["role"] == "reader" else tenancy.TENANT_SCOPES
                return {
                    "api_key": token + "-child", "_version": 8,
                    "key": {"id": "child-id", "scopes": scopes},
                }
            return {}

        instance.checked = mock.Mock(side_effect=checked)
        instance.rbac_tests()
        attachments = [
            call for call in instance.checked.call_args_list
            if call.args[0] == "PUT" and call.args[1].endswith("/north-south-router")
        ]
        self.assertEqual(len(attachments), 4)
        self.assertTrue(all(call.args[2]["_version"] == 1 for call in attachments))
        denials = [call for call in instance.checked.call_args_list if call.kwargs.get("status") == 403]
        self.assertGreaterEqual(len(denials), 56)
        self.assertTrue(any("/macs/events" in call.args[1] for call in denials))
        creates = [call for call in instance.checked.call_args_list
                   if call.args[:2] == ("POST", "/system/me/keys") and call.kwargs.get("status", 200) == 200]
        self.assertEqual(len(creates), 4)
        self.assertTrue(all(
            call.args[2] == {"name": "tenant-lab-child", "_version": 7}
            for call in creates
        ))
        for record in instance.state["rbac"]:
            instance.request.assert_any_call("GET", f"/system/users/{record['name']}")
            own = next(segment for segment in instance.state["segments"]
                       if segment["tenant_id"] == record["tenant_id"])
            instance.checked.assert_any_call(
                "PUT", f"/segments/{own['id']}/acl",
                {**tenancy.tenant_acl(instance.state["segments"], own, True, True), "_version": 1},
                status=403 if record["role"] == "reader" else 200, token=record["token"],
            )
            instance.owned_segment.assert_any_call(own)
            child = record["token"] + "-child"
            instance.checked.assert_any_call(
                "PUT", f"/segments/{own['id']}/acl",
                {"egress": [], "ingress": [],
                 "_version": 2 if record["role"] != "reader" else 1},
                status=403 if record["role"] == "reader" else 200, token=child,
            )
            instance.checked.assert_any_call(
                "POST", "/system/users",
                {"username": record["name"] + "-admin", "group_id": "administrators"},
                status=403, token=child,
            )
            instance.checked.assert_any_call(
                "PUT", f"/system/users/{record['name']}/group", {"group_id": "administrators"},
                status=403, token=child,
            )
            instance.checked.assert_any_call(
                "POST", "/system/me/keys", {"name": "third-key", "_version": 8},
                status=409, token=child,
            )
            instance.checked.assert_any_call(
                "DELETE", "/system/me/keys/child-id?_version=8",
                status=204, token=record["token"],
            )
            instance.checked.assert_any_call("GET", "/system/me", status=401, token=child)

    def test_rbac_rejects_replacement_key_with_wrong_group_permissions(self):
        instance = fixture()
        instance.state["rbac"] = [rbac_records()[1]]
        instance.request = mock.Mock(return_value={"_version": 7})
        instance.checked = mock.Mock(side_effect=lambda method, path, *args, **kwargs: (
            {"tenant_id": "default", "is_admin": False} if path == "/system/me" else
            [{"id": "default"}] if path == "/tenants" else
            [{key: segment[key] for key in (
                "id", "name", "gateway_cidr", "tenant_id", "_version",
            )} for segment in instance.state["segments"]
             if segment["tenant_id"] == "default"] if path == "/segments" else
            [{"tenant_id": "default"}] if path == "/north-south-routers" else
            {"_version": 1} if method == "GET" and path.endswith("/acl") else
            {"_version": 2, "key": {"scopes": tenancy.TENANT_SCOPES}}
            if path == "/system/me/keys" else {}
        ))
        with self.assertRaisesRegex(RuntimeError, "inherit its group's permissions"):
            instance.rbac_tests()

    def test_acceptance_rejects_old_incomplete_or_duplicate_role_records_before_rbac(self):
        for records in (
            rbac_records()[:2], rbac_records()[:-1] + [rbac_records()[0]],
            [{key: value for key, value in record.items() if key != "role"} for record in rbac_records()],
        ):
            instance = fixture()
            instance.state.update(ready=True, rbac=records)
            instance.verify_tenant_metadata = mock.Mock()
            instance.rbac_tests = mock.Mock()
            with mock.patch.object(tenancy, "private_write"), self.assertRaisesRegex(
                    RuntimeError, "RBAC provisioning incomplete"):
                instance.test()
            instance.rbac_tests.assert_not_called()

    def test_cleanup_deactivates_keys_and_moves_tombstone_before_group_delete(self):
        instance = fixture()
        record = {"name": "sf-lab-owned", "group_id": "group-sf-lab-owned",
                  "tenant_id": SECOND, "token": "sensitive"}
        instance.state["rbac"] = [record]
        instance.request = mock.Mock(side_effect=[
            [{"username": record["name"], "group_id": record["group_id"], "active": True, "_version": 6}],
            None,
            {"username": record["name"], "group_id": record["group_id"], "active": False, "_version": 7},
            None,
            [{"id": record["group_id"], "name": record["name"], "tenant_id": SECOND, "_version": 9}], None,
        ])
        instance.cleanup_rbac()
        self.assertEqual(instance.request.call_args_list[1:4], [
            mock.call("DELETE", "/system/users/sf-lab-owned?_version=6"),
            mock.call("GET", "/system/users/sf-lab-owned"),
            mock.call("PUT", "/system/users/sf-lab-owned/group", {"group_id": "auditors", "_version": 7}),
        ])
        instance.request.assert_called_with("DELETE", "/system/groups/group-sf-lab-owned?_version=9")
        self.assertNotIn("token", record)

    def test_api_status_assertions_persist_evidence_without_tokens_or_response_body(self):
        instance = fixture()
        with tempfile.TemporaryDirectory() as directory:
            instance.directory = Path(directory)
            instance.api = mock.Mock()
            instance.base_url = "https://controller/api/v1"
            instance.api.request.return_value = mock.Mock(status_code=200, content=b"body")
            with self.assertRaisesRegex(RuntimeError, "expected HTTP 403, got 200"):
                instance.checked("GET", "/hosts", status=403, token="sensitive")
            evidence = (instance.directory / "api-results.json").read_text()
            self.assertNotIn("sensitive", evidence)
            self.assertNotIn("body", evidence)
            self.assertFalse(json.loads(evidence)[0]["passed"])
            self.assertEqual((instance.directory / "api-results.json").stat().st_mode & 0o777, 0o600)

    def test_cleanup_resumes_inactive_user_and_group_without_repeating_deactivation(self):
        instance = fixture()
        record = {"name": "sf-lab-owned", "group_id": "group-owned",
                  "tenant_id": SECOND, "token": "sensitive"}
        instance.state["rbac"] = [record]
        instance.request = mock.Mock(side_effect=[
            [{"username": record["name"], "group_id": "auditors", "active": False, "_version": 11}],
            [{"id": record["group_id"], "name": record["name"], "tenant_id": SECOND,
              "active": False, "_version": 13}],
        ])
        instance.cleanup_rbac()
        self.assertTrue(all(call.args[0] == "GET" for call in instance.request.call_args_list))
        self.assertNotIn("token", record)

    def test_user_change_after_cleanup_deactivation_aborts_group_removal(self):
        instance = fixture()
        record = {"name": "sf-lab-owned", "group_id": "group-owned",
                  "tenant_id": SECOND, "token": "sensitive"}
        instance.state["rbac"] = [record]
        instance.request = mock.Mock(side_effect=[
            [{"username": record["name"], "group_id": record["group_id"], "active": True, "_version": 11}],
            None,
            {"username": record["name"], "group_id": "administrators", "active": True, "_version": 13},
        ])
        with self.assertRaisesRegex(RuntimeError, "changed after deactivation"):
            instance.cleanup_rbac()
        self.assertFalse(any(call.args[0] == "PUT" for call in instance.request.call_args_list))
        self.assertIn("token", record)


if __name__ == "__main__":
    unittest.main()
