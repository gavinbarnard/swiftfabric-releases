"""Real kernel ACL verdicts in disposable user/network namespaces, not live hosts."""

import contextlib
import json
import os
from pathlib import Path
import select
import shutil
import signal
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [
    str(ROOT / "network-lab"),
    str(ROOT / "host-agent"),
]
import guest
from swiftfabric_host import netdev
from swiftfabric_host.tenant import DEFAULT_TENANT


LAN = "198.18.1.2"
PEER = "198.18.1.3"
DESTINATION = "198.18.2.2"
WAN = "198.19.0.2"
WAN_GATEWAY = "198.19.0.1"
PUBLIC_PORT = 28080


def command(*argv, input=None):
    result = subprocess.run(argv, input=input, text=True, capture_output=True, timeout=10)
    if result.returncode:
        raise RuntimeError(f"{argv}: {result.stdout}{result.stderr}")
    return result


def rule(source, destination, protocol="any", port="any"):
    return {
        "source": source, "destination": destination, "protocol": protocol,
        "source_port": "any", "destination_port": port,
    }


def echo_rules(source, destination, *, wrong_port=False):
    return [rule(source, destination, protocol, str(port + int(wrong_port)))
            for protocol, port in (("tcp", guest.TCP_PORT), ("udp", guest.UDP_PORT))]


def segments():
    return [
        {"id": identifier, "tenant_id": "default", "tenant": DEFAULT_TENANT,
         "gateway_cidr": gateway, "acl": {"egress": [], "ingress": []}}
        for identifier, gateway in ((5000, "198.18.1.1/24"), (5001, "198.18.2.1/24"))
    ]


# NSR rulesets come from the Rust `swiftfabric-router` binary built on the
# buildbox; set SWIFTFABRIC_ROUTER_BINARY to run the NSR cases.
ROUTER_BINARY = os.environ.get("SWIFTFABRIC_ROUTER_BINARY", "")


def router_binary_available():
    return bool(ROUTER_BINARY) and os.access(ROUTER_BINARY, os.X_OK)


def router_config():
    return {
        "router_id": "boundary-test", "api_url": "https://192.0.2.10", "api_token": "test-token",
        "wan_interface": "wan", "wan_address_cidr": WAN_GATEWAY + "/24", "wan_gateway": WAN,
        "management_interface": "mgmt", "management_address_cidr": "192.0.2.2/24",
        "management_gateway": "192.0.2.1", "management_dns": ["192.0.2.1"],
        "vtep_interface": "vtep", "vtep_ip": "192.0.3.130", "vtep_prefix_len": 24,
        "vtep_cidr": "192.0.3.0/24", "vtep_mtu": 9000,
        "controller_ips": ["192.0.2.10"], "management_allowlist": ["192.0.2.0/24"],
    }


class RouterRenderError(RuntimeError):
    pass


def render_router(config, payload):
    with tempfile.TemporaryDirectory(prefix="sf-router-render-") as directory:
        path = Path(directory) / "router.json"
        path.write_text(json.dumps(config))
        result = subprocess.run(
            [ROUTER_BINARY, "--config", str(path), "--render-ruleset"],
            input=json.dumps(payload), text=True, capture_output=True, timeout=30,
        )
    if result.returncode:
        raise RouterRenderError(result.stderr.strip())
    return result.stdout


def wan_payload(segment_acl, egress, ingress, mappings=True):
    segment = segments()[0]
    segment["acl"] = segment_acl
    segment["north_south_router"] = {
        "id": "boundary-test", "router_mac": netdev.gateway_mac(5000), "vtep_ip": "192.0.3.130",
    }
    return {
        "tenant_id": "default", "tenant": DEFAULT_TENANT, "segments": [segment],
        "wan_egress_rules": egress, "wan_ingress_rules": ingress,
        "masquerade_source_cidrs": ["198.18.1.0/24"],
        "inbound_port_mappings": [
            {"protocol": protocol, "external_port": PUBLIC_PORT,
             "destination_ip": LAN, "destination_port": port}
            for protocol, port in (("tcp", guest.TCP_PORT), ("udp", guest.UDP_PORT))
        ] if mappings else [],
    }


class Topology:
    def __init__(self):
        self.children = []
        self.port = 20000

    def close(self):
        for process in reversed(self.children):
            if process.poll() is None:
                process.terminate()
            try:
                process.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.communicate(timeout=5)

    def namespace(self):
        process = subprocess.Popen(
            ["unshare", "--net", sys.executable, "-u", "-c",
             "import time;print('ready',flush=True);time.sleep(180)"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        self.children.append(process)
        self.ready(process)
        assert os.readlink(f"/proc/{process.pid}/ns/net") != os.readlink("/proc/self/ns/net")
        return process.pid

    @staticmethod
    def ready(process):
        if not select.select([process.stdout], [], [], 5)[0]:
            raise RuntimeError("isolated endpoint did not become ready")
        line = process.stdout.readline()
        if line != b"ready\n":
            raise RuntimeError(f"isolated endpoint startup failed: {process.communicate(timeout=5)}")

    @staticmethod
    def inside(pid, *argv):
        return command("nsenter", "-t", str(pid), "-n", *argv)

    def bridge(self, name, address=None, vrf=False):
        command("ip", "link", "add", name, "type", "bridge")
        if vrf:
            command("ip", "link", "set", name, "master", "sf-vrf30000")
        if address:
            command("ip", "addr", "add", address, "dev", name)
        command("ip", "link", "set", name, "up")

    def endpoint(self, name, address, gateway, bridge=None):
        pid = self.namespace()
        command("ip", "link", "add", name, "type", "veth", "peer", "name", "peer-" + name)
        command("ip", "link", "set", "peer-" + name, "netns", str(pid))
        if bridge:
            command("ip", "link", "set", name, "master", bridge)
        command("ip", "link", "set", name, "up")
        self.inside(pid, "ip", "link", "set", "lo", "up")
        self.inside(pid, "ip", "addr", "add", address, "dev", "peer-" + name)
        self.inside(pid, "ip", "link", "set", "peer-" + name, "up")
        self.inside(pid, "ip", "route", "add", "default", "via", gateway)
        ip = address.split("/")[0]
        code = (
            "import sys,threading;sys.path.insert(0,sys.argv[1]);import guest;"
            "tcp=guest.TCPServer((sys.argv[2],guest.TCP_PORT),guest.TCPHandler);"
            "udp=guest.socketserver.ThreadingUDPServer((sys.argv[2],guest.UDP_PORT),guest.UDPHandler);"
            "tcp.endpoint_identity=udp.endpoint_identity=sys.argv[2];"
            "threading.Thread(target=tcp.serve_forever,daemon=True).start();"
            "print('ready',flush=True);sys.stdout=open('/dev/null','w');udp.serve_forever()"
        )
        process = subprocess.Popen(
            ["nsenter", "-t", str(pid), "-n", sys.executable, "-u", "-c", code,
             str(ROOT / "network-lab"), ip],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        self.children.append(process)
        self.ready(process)
        return pid

    def install(self, table, rules):
        tables = command("nft", "list", "tables").stdout
        if f"table inet {table}\n" in tables:
            rules = f"delete table inet {table}\n" + rules
        command("nft", "-f", "-", input=rules)

    def probe(self, pid, source, destination, protocol, expected, *, port=None, identity=None):
        self.port += 1
        port = port or (guest.TCP_PORT if protocol == "tcp" else guest.UDP_PORT)
        case = {
            "source": source, "destination": destination, "protocol": protocol,
            "source_port": self.port, "destination_port": port, "expected": expected,
            "endpoint_identity": identity or destination,
        }
        code = (
            "import json,sys;sys.path.insert(0,sys.argv[1]);import guest;"
            "print(json.dumps(guest.probe(json.loads(sys.argv[2]))))"
        )
        result = json.loads(self.inside(
            pid, sys.executable, "-c", code, str(ROOT / "network-lab"), json.dumps(case),
        ).stdout)
        assert result["passed"], result
        if expected == "drop":
            assert result["outcome"] == "drop" and result["stage"] in ("connect", "receive"), result
        return result

    def watch(self, source, destination, translated_source, translated_destination,
              protocol, destination_port, forwarded_port, table, chains):
        port = self.port + 1
        match = f"ip saddr {source} ip daddr {destination} {protocol} sport {port}"
        after = (
            f"ip saddr {translated_source} ip daddr {translated_destination} "
            f"{protocol} dport {forwarded_port} ct original proto-src {port}"
        )
        self.install("sf_test_observe", (
            "table inet sf_test_observe {\n"
            " chain before { type filter hook prerouting priority -301; policy accept;\n"
            f'  {match} {protocol} dport {destination_port} counter comment "observed"\n'
            " }\n"
            " chain after { type filter hook postrouting priority 110; policy accept;\n"
            f'  {after} counter comment "observed"\n'
            " }\n}\n"
        ))
        for chain in chains:
            command("nft", "insert", "rule", "inet", table, chain,
                    "ip", "saddr", source, "ip", "daddr", translated_destination,
                    protocol, "sport", str(port), "counter", "comment", f"probe-{port}")
        return f"probe-{port}"

    @staticmethod
    def count(table, chain, comment="observed"):
        entries = json.loads(command("nft", "-j", "list", "chain", "inet", table, chain).stdout)
        counters = [
            expression["counter"]["packets"]
            for entry in entries["nftables"] if "rule" in entry
            and entry["rule"].get("comment") == comment
            for expression in entry["rule"]["expr"] if "counter" in expression
        ]
        assert len(counters) == 1, (table, chain, entries)
        return counters[0]


@contextlib.contextmanager
def topology():
    command("ip", "link", "set", "lo", "up")
    command("sysctl", "-w", "net.ipv4.ip_forward=1")
    fixture = Topology()
    try:
        yield fixture
    finally:
        fixture.close()


def east_west_case():
    with topology() as fixture:
        command("ip", "link", "add", "sf-vrf30000", "type", "vrf", "table", "130000")
        command("ip", "link", "set", "sf-vrf30000", "up")
        for identifier, network in ((5000, "198.18.1.1/24"), (5001, "198.18.2.1/24")):
            fixture.bridge(f"sf-br{identifier}", network, vrf=True)
        source = fixture.endpoint("src", LAN + "/24", "198.18.1.1", "sf-br5000")
        fixture.endpoint("peer", PEER + "/24", "198.18.1.1", "sf-br5000")
        fixture.endpoint("dst", DESTINATION + "/24", "198.18.2.1", "sf-br5001")
        allow = echo_rules("198.18.1.0/24", "198.18.2.0/24")
        miss = echo_rules("198.18.1.99/32", "198.18.2.0/24")
        wrong_destination = echo_rules("198.18.1.0/24", "198.18.2.99/32")
        wrong_protocol = [rule("198.18.1.0/24", "198.18.2.0/24", "icmp")]
        wrong_port = echo_rules("198.18.1.0/24", "198.18.2.0/24", wrong_port=True)
        cases = (
            ("authorized", allow, allow, True, True),
            ("neither-authorized", [], [], False, False),
            ("egress-only", allow, [], False, True),
            ("ingress-only", [], allow, False, False),
            ("egress-nonmatching", miss, allow, False, False),
            ("ingress-nonmatching", allow, miss, False, True),
            ("egress-destination-nonmatching", wrong_destination, allow, False, False),
            ("ingress-destination-nonmatching", allow, wrong_destination, False, True),
            ("egress-protocol-nonmatching", wrong_protocol, allow, False, False),
            ("ingress-protocol-nonmatching", allow, wrong_protocol, False, True),
            ("egress-port-nonmatching", wrong_port, allow, False, False),
            ("ingress-port-nonmatching", allow, wrong_port, False, True),
            ("missing-egress-policy", None, allow, False, False),
            ("missing-ingress-policy", allow, None, False, True),
            ("restored", allow, allow, True, True),
            ("withdrawn", [], [], False, False),
        )
        for name, egress, ingress, allowed, reached_ingress in cases:
            records = segments()
            for record, direction, policy in ((records[0], "egress", egress),
                                              (records[1], "ingress", ingress)):
                if policy is None:
                    record.pop("acl")
                else:
                    record["acl"][direction] = policy
            fixture.install("swiftfabric_routing", (
                "table inet swiftfabric_routing {\n" + netdev.routing_rules(records) + "\n}\n"
            ))
            for protocol in ("tcp", "udp"):
                port = guest.TCP_PORT if protocol == "tcp" else guest.UDP_PORT
                chains = ("sf_5000_egress", "sf_5001_ingress")
                comment = fixture.watch(
                    LAN, DESTINATION, LAN, DESTINATION, protocol, port, port,
                    "swiftfabric_routing", chains,
                )
                fixture.probe(source, LAN, DESTINATION, protocol, "allow" if allowed else "drop")
                assert fixture.count("sf_test_observe", "before") > 0, (name, protocol, "no input")
                assert fixture.count("swiftfabric_routing", chains[0], comment) > 0, (name, protocol)
                ingress_count = fixture.count("swiftfabric_routing", chains[1], comment)
                assert (ingress_count > 0) == reached_ingress, (name, protocol, ingress_count)
                forwarded = fixture.count("sf_test_observe", "after")
                assert (forwarded > 0) == allowed, (name, protocol, forwarded)
                fixture.probe(source, LAN, PEER, protocol, "allow")
            fixture.probe(source, LAN, PEER, "icmp", "allow")
            print(f"east-west {name}: ACL chain entry, source forwarding verdict, TCP/UDP and L2 verified")


def north_south_case():
    with topology() as fixture:
        fixture.bridge("sf-br5000", "198.18.1.1/24")
        source = fixture.endpoint("src", LAN + "/24", "198.18.1.1", "sf-br5000")
        wan = fixture.endpoint("wan", WAN + "/24", WAN_GATEWAY)
        command("ip", "addr", "add", WAN_GATEWAY + "/24", "dev", "wan")
        config = router_config()
        allow_out = echo_rules("198.18.1.0/24", WAN + "/32")
        allow_in = echo_rules(WAN + "/32", LAN + "/32")
        mismatch_out = echo_rules("198.18.1.99/32", WAN + "/32")
        mismatch_in = echo_rules("198.19.0.99/32", LAN + "/32")
        segment_allow = {"egress": [rule("0.0.0.0/0", "0.0.0.0/0")],
                         "ingress": [rule("0.0.0.0/0", "0.0.0.0/0")]}
        segment_deny = {"egress": [], "ingress": []}
        cases = (
            ("authorized-with-empty-segment-acls", allow_out, allow_in, segment_deny, True, True, True),
            ("wan-empty-despite-segment-allow", [], [], segment_allow, True, False, False),
            ("egress-only", allow_out, [], segment_deny, True, True, False),
            ("ingress-only", [], allow_in, segment_deny, True, False, True),
            ("nonmatching-wan-rules", mismatch_out, mismatch_in, segment_allow, True, False, False),
            ("nonmatching-wan-destination", echo_rules("198.18.1.0/24", "198.19.0.99/32"),
             echo_rules(WAN + "/32", "198.18.1.99/32"), segment_allow, True, False, False),
            ("nonmatching-wan-protocol", [rule("198.18.1.0/24", WAN + "/32", "icmp")],
             [rule(WAN + "/32", LAN + "/32", "icmp")], segment_allow, True, False, False),
            ("nonmatching-wan-port", echo_rules("198.18.1.0/24", WAN + "/32", wrong_port=True),
             echo_rules(WAN + "/32", LAN + "/32", wrong_port=True), segment_allow, True, False, False),
            ("mapping-without-ingress-allow", allow_out, [], segment_allow, True, True, False),
            ("ingress-allow-without-mapping", allow_out, allow_in, segment_allow, False, True, False),
            ("restored", allow_out, allow_in, segment_deny, True, True, True),
            ("withdrawn-with-nat-retained", [], [], segment_allow, True, False, False),
        )
        for name, egress, ingress, acl, mappings, out_allowed, in_allowed in cases:
            fixture.install(
                "swiftfabric_router", render_router(config, wan_payload(acl, egress, ingress, mappings)),
            )
            for protocol in ("tcp", "udp"):
                port = guest.TCP_PORT if protocol == "tcp" else guest.UDP_PORT
                for outbound, allowed in ((True, out_allowed), (False, in_allowed)):
                    address = WAN if outbound else WAN_GATEWAY
                    origin = LAN if outbound else WAN
                    target = WAN if outbound else LAN
                    public_port = port if outbound else PUBLIC_PORT
                    chain = "sf_egress_5000" if outbound else "sf_ingress_5000"
                    comment = fixture.watch(
                        origin, address, WAN_GATEWAY if outbound else WAN, target,
                        protocol, public_port, port, "swiftfabric_router", (chain,),
                    )
                    fixture.probe(
                        source if outbound else wan, origin, address, protocol,
                        "allow" if allowed else "drop", port=public_port, identity=target,
                    )
                    assert fixture.count("sf_test_observe", "before") > 0, (name, chain, "no input")
                    count = fixture.count("swiftfabric_router", chain, comment)
                    assert (count > 0) == (outbound or mappings), (name, chain, count)
                    forwarded = fixture.count("sf_test_observe", "after")
                    assert (forwarded > 0) == allowed, (name, chain, protocol, forwarded)
            print(f"north-south {name}: WAN chain entry, forwarding verdict and NAT/echo verified")


class PolicyDefinitionTests(unittest.TestCase):
    def test_missing_and_empty_segment_acls_each_render_terminal_default_deny(self):
        for missing in (False, True):
            records = segments()
            if missing:
                for record in records:
                    record.pop("acl")
            script = netdev.routing_rules(records)
            for identifier in (5000, 5001):
                for direction in ("egress", "ingress"):
                    self.assertIn(f"chain sf_{identifier}_{direction} {{\n    drop\n  }}", script)

    @unittest.skipUnless(router_binary_available(), "SWIFTFABRIC_ROUTER_BINARY not set")
    def test_wan_policy_not_segment_policy_controls_router_rules(self):
        config = router_config()
        allow = {"egress": [rule("0.0.0.0/0", "0.0.0.0/0")],
                 "ingress": [rule("0.0.0.0/0", "0.0.0.0/0")]}
        deny = {"egress": [], "ingress": []}
        scripts = [render_router(config, wan_payload(acl, [], [])) for acl in (allow, deny)]
        self.assertEqual(*scripts)
        for direction in ("egress", "ingress"):
            self.assertIn(f"chain sf_{direction}_5000", scripts[0])

    @unittest.skipUnless(router_binary_available(), "SWIFTFABRIC_ROUTER_BINARY not set")
    def test_missing_wan_egress_is_rejected(self):
        payload = wan_payload({"egress": [], "ingress": []}, [], [])
        payload.pop("wan_ingress_rules")
        render_router(router_config(), payload)
        payload.pop("wan_egress_rules")
        with self.assertRaisesRegex(RouterRenderError, "wan_egress_rules"):
            render_router(router_config(), payload)


class KernelPolicyBoundaryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        missing = [tool for tool in ("unshare", "nsenter", "ip", "nft", "sysctl", "ping")
                   if not shutil.which(tool)]
        if missing:
            raise unittest.SkipTest("kernel policy tools unavailable: " + ", ".join(missing))
        result = subprocess.run(
            ["unshare", "--user", "--map-root-user", "--net", "true"],
            text=True, capture_output=True,
        )
        if result.returncode:
            raise unittest.SkipTest("isolated network namespaces unavailable: " + result.stderr.strip())

    def run_case(self, name):
        process = subprocess.Popen(
            ["unshare", "--user", "--map-root-user", "--net", sys.executable,
             str(Path(__file__).resolve()), "--kernel-case", name],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        )
        try:
            output, error = process.communicate(timeout=180)
            self.assertEqual(process.returncode, 0, output + error)
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.communicate(timeout=30)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.communicate(timeout=5)

    def test_source_router_checks_both_acls_and_default_denies_without_blocking_l2(self):
        self.run_case("east-west")

    @unittest.skipUnless(router_binary_available(), "SWIFTFABRIC_ROUTER_BINARY not set")
    def test_nsr_wan_acls_default_deny_independently_of_segment_acls_and_nat(self):
        self.run_case("north-south")


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--kernel-case":
        def terminate(signum, _frame):
            raise SystemExit(128 + signum)
        signal.signal(signal.SIGTERM, terminate)
        {"east-west": east_west_case, "north-south": north_south_case}[sys.argv[2]]()
    else:
        unittest.main()
