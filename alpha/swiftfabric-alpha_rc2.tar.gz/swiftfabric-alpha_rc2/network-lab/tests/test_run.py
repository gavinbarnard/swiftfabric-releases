import contextlib
import io
import ipaddress
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import lab


class BootstrapTests(unittest.TestCase):
    def setUp(self):
        self.lab = lab.LiveLab.__new__(lab.LiveLab)
        self.vm = {"vmid": 151, "address": "10.253.245.11", "node": "hunsn4"}
        self.lab.serial = mock.Mock()

    def test_bootstrap_retries_serial_timeout_then_succeeds(self):
        self.lab.serial.side_effect = [TimeoutError("serial deadline exceeded"), ""]
        with mock.patch.object(lab.time, "sleep") as sleep, \
                contextlib.redirect_stdout(io.StringIO()) as output:
            self.lab.bootstrap(self.vm)
        self.assertEqual(self.lab.serial.call_count, 2)
        self.assertEqual(self.lab.serial.call_args.kwargs["timeout"], 300)
        sleep.assert_called_once_with(5)
        self.assertIn("VM 151", output.getvalue())
        self.assertIn("retry", output.getvalue())

    def test_bootstrap_persistent_timeout_is_bounded_and_preserves_cause(self):
        error = TimeoutError("serial deadline exceeded")
        self.lab.serial.side_effect = error
        with mock.patch.object(lab.time, "sleep") as sleep, \
                contextlib.redirect_stdout(io.StringIO()), \
                self.assertRaisesRegex(TimeoutError, "after 3 attempts") as failure:
            self.lab.bootstrap(self.vm)
        self.assertEqual(self.lab.serial.call_count, 3)
        self.assertEqual(sleep.call_count, 2)
        self.assertIs(failure.exception.__cause__, error)

    def test_bootstrap_does_not_retry_command_or_ownership_failure(self):
        for message in ("command failed", "ownership mismatch"):
            with self.subTest(message=message):
                self.lab.serial.reset_mock()
                self.lab.serial.side_effect = RuntimeError(message)
                with mock.patch.object(lab.time, "sleep") as sleep, \
                        self.assertRaisesRegex(RuntimeError, message):
                    self.lab.bootstrap(self.vm)
                self.lab.serial.assert_called_once()
                sleep.assert_not_called()

    def test_service_check_retries_closed_connection_without_changing_command(self):
        self.lab.serial.side_effect = [lab.SerialConnectionError("connection closed"), ""]
        command = "systemctl is-active --quiet swiftfabric-network-lab"
        with mock.patch.object(lab.time, "sleep"), contextlib.redirect_stdout(io.StringIO()):
            self.lab.setup_serial(self.vm, command)
        self.assertEqual(self.lab.serial.call_args_list, [
            mock.call(self.vm, command, timeout=120),
            mock.call(self.vm, command, timeout=120),
        ])

    def test_closed_connection_retries_are_bounded(self):
        self.lab.serial.side_effect = lab.SerialConnectionError("connection closed")
        with mock.patch.object(lab.time, "sleep"), contextlib.redirect_stdout(io.StringIO()), \
                self.assertRaisesRegex(lab.SerialConnectionError, "after 3 attempts"):
            self.lab.bootstrap(self.vm)
        self.assertEqual(self.lab.serial.call_count, 3)

    def test_bootstrap_command_is_idempotent_after_lost_serial_reply(self):
        self.lab.bootstrap(self.vm)
        command = self.lab.serial.call_args.args[1]
        script = """
active=1
uploads=0
starts=0
systemctl() { test "$active" = 1; }
sudo() { shift; "$@"; }
python3() { uploads=$((uploads + 1)); }
systemd-run() { starts=$((starts + 1)); active=1; }
set -e
""" + command + """
echo "$uploads $starts"
active=0
""" + command + "\n" + command + """
echo "$uploads $starts"
"""
        result = subprocess.run(["bash", "-c", script], capture_output=True, text=True, check=True)
        self.assertEqual(result.stdout.splitlines(), ["0 0", "1 1"])


class SerialProtocolTests(unittest.TestCase):
    def setUp(self):
        self.lab = lab.LiveLab.__new__(lab.LiveLab)
        self.lab.config = {
            "proxmox_ssh_key": "/synthetic/key", "proxmox_ssh_user": "root",
            "proxmox_cluster_ip": "192.0.2.1",
        }
        self.lab.vm_config = mock.Mock()
        self.vm = {"vmid": 151, "node": "hunsn4"}
        self.process = mock.Mock()

    def test_timeout_names_stage_and_terminates_serial_process(self):
        with mock.patch.object(lab.subprocess, "Popen", return_value=self.process), \
                mock.patch.object(lab.time, "monotonic", side_effect=[0, 1]), \
                self.assertRaisesRegex(TimeoutError, "during login prompt"):
            self.lab.serial(self.vm, "true", timeout=1)
        self.process.terminate.assert_called_once()
        self.process.wait.assert_called_once_with(timeout=5)

    def test_eof_is_retryable_connection_failure_and_terminates_process(self):
        with mock.patch.object(lab.subprocess, "Popen", return_value=self.process), \
                mock.patch.object(lab.select, "select", return_value=([self.process.stdout], [], [])), \
                mock.patch.object(lab.os, "read", return_value=b""), \
                self.assertRaisesRegex(lab.SerialConnectionError, "during login prompt"):
            self.lab.serial(self.vm, "true")
        self.process.terminate.assert_called_once()

    def test_broken_pipe_is_retryable_connection_failure(self):
        self.process.stdin.write.side_effect = BrokenPipeError("closed")
        with mock.patch.object(lab.subprocess, "Popen", return_value=self.process), \
                self.assertRaises(lab.SerialConnectionError) as failure:
            self.lab.serial(self.vm, "true")
        self.assertIsInstance(failure.exception.__cause__, BrokenPipeError)
        self.process.terminate.assert_called_once()

    def test_ownership_failure_prevents_opening_serial_connection(self):
        self.lab.vm_config.side_effect = RuntimeError("ownership mismatch")
        with mock.patch.object(lab.subprocess, "Popen") as popen, \
                self.assertRaisesRegex(RuntimeError, "ownership mismatch"):
            self.lab.serial(self.vm, "true")
        popen.assert_not_called()


class RunTests(unittest.TestCase):
    def setUp(self):
        self.lab = lab.LiveLab.__new__(lab.LiveLab)
        self.lab.state = {"segments": [], "run_id": "test", "vms": []}
        self.lab.directory = Path("/private/lab")
        self.lab.save = mock.Mock()
        self.lab.network_inventory = mock.Mock(return_value=([], []))
        self.output = contextlib.redirect_stdout(io.StringIO())
        self.output.__enter__()
        self.addCleanup(self.output.__exit__, None, None, None)

    def select(self, first_id=49100, subnet="10.253.244.0/24", pool="10.0.0.0/8"):
        self.lab.select_segments(first_id, subnet, pool)
        return self.lab.state["segments"]

    def test_auto_allocation_skips_existing_ids_and_overlapping_networks(self):
        self.lab.network_inventory.return_value = (
            [{"id": 49100}, {"id": 49102}],
            [ipaddress.ip_network("10.253.244.0/23"), ipaddress.ip_network("10.253.247.0/24")],
        )
        segments = self.select()
        self.assertEqual([segment["id"] for segment in segments], [49101, 49103, 49104])
        self.assertEqual([segment["network"] for segment in segments],
                         ["10.253.246.0/24", "10.253.248.0/24", "10.253.249.0/24"])
        self.lab.save.assert_called_once_with()

    def test_wraps_at_id_and_pool_bounds(self):
        segments = self.select(50000, "192.168.0.0/24", "192.168.0.0/22")
        self.assertEqual([segment["id"] for segment in segments], [50000, 5000, 5001])
        segments = self.select(50000, "192.168.3.0/24", "192.168.0.0/22")
        self.assertEqual([segment["network"] for segment in segments],
                         ["192.168.3.0/24", "192.168.0.0/24", "192.168.1.0/24"])

    def test_exhaustion_and_invalid_inputs_preserve_empty_plan(self):
        for inventory, args, message in (
            (([{"id": number} for number in range(5000, 50001)], []),
             (49100, "10.0.0.0/24", "10.0.0.0/8"), "unused segment IDs"),
            (([], [ipaddress.ip_network("10.0.0.0/8")]),
             (49100, "10.0.0.0/24", "10.0.0.0/8"), "non-overlapping"),
            (([], []), (49100, "203.0.113.0/24", "203.0.113.0/24"), "RFC1918"),
        ):
            with self.subTest(message=message):
                self.lab.network_inventory.return_value = inventory
                with self.assertRaisesRegex((ValueError, RuntimeError), message):
                    self.select(*args)
                self.assertEqual(self.lab.state["segments"], [])
        self.lab.save.assert_not_called()

    def test_cleanup_runs_on_success_provisioning_test_and_interrupt_failures(self):
        for failure_stage in (None, "select_segments", "create", "acceptance_test"):
            for error in (RuntimeError("failed"), KeyboardInterrupt()):
                with self.subTest(stage=failure_stage, error=type(error)):
                    calls = mock.Mock()
                    self.lab.state["segments"] = []
                    for method in ("select_segments", "create", "acceptance_test", "destroy"):
                        setattr(self.lab, method, getattr(calls, method))
                    if failure_stage:
                        getattr(calls, failure_stage).side_effect = error
                        with self.assertRaises(type(error)):
                            self.lab.run(49100, "10.253.244.0/24", "10.0.0.0/8")
                    else:
                        self.lab.run(49100, "10.253.244.0/24", "10.0.0.0/8")
                        self.assertEqual([call[0] for call in calls.mock_calls],
                                         ["select_segments", "create", "acceptance_test", "destroy"])
                    calls.destroy.assert_called_once_with()

    def test_cleanup_failure_does_not_hide_original_exception_context(self):
        self.lab.select_segments = mock.Mock()
        self.lab.create = mock.Mock(side_effect=RuntimeError("provision failed"))
        self.lab.destroy = mock.Mock(side_effect=RuntimeError("cleanup failed"))
        with self.assertRaisesRegex(RuntimeError, "cleanup failed") as failure:
            self.lab.run(49100, "10.253.244.0/24", "10.0.0.0/8")
        self.assertEqual(str(failure.exception.__context__), "provision failed")

    def test_explicit_segments_are_not_reallocated(self):
        self.lab.state["segments"] = [{"id": 5100}]
        self.lab.select_segments = mock.Mock()
        self.lab.create = mock.Mock()
        self.lab.acceptance_test = mock.Mock()
        self.lab.destroy = mock.Mock()
        self.lab.run(49100, "10.253.244.0/24", "10.0.0.0/8")
        self.lab.select_segments.assert_not_called()

    def test_cli_run_dispatches_with_unique_default_state(self):
        with tempfile.TemporaryDirectory() as temporary:
            home = Path(temporary)
            instance = mock.Mock()
            args = ["lab.py", "run", "--nodes", "a", "b", "c", "--router", "test-router",
                    "--image-volume", "VMData:import/image.qcow2", "--yes"]
            with mock.patch.object(sys, "argv", args), mock.patch.object(lab.Path, "home", return_value=home), \
                    mock.patch.object(lab, "LiveLab", return_value=instance) as constructor:
                lab.main()
            directory = constructor.call_args.args[0]
            state = json.loads((directory / "state.json").read_text())
            self.assertEqual(state["segments"], [])
            self.assertEqual(state["router"], "test-router")
            self.assertEqual(state["nodes"], ["a", "b", "c"])
            self.assertEqual((directory / "state.json").stat().st_mode & 0o777, 0o600)
            instance.run.assert_called_once_with(49100, "10.253.244.0/24", "10.0.0.0/8")
            with mock.patch.object(sys, "argv", [*args, "--state", str(directory)]), \
                    mock.patch.object(lab, "LiveLab") as constructor:
                with self.assertRaises(FileExistsError):
                    lab.main()
            constructor.assert_not_called()

    def test_cli_requires_explicit_approval_before_creating_state(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary) / "new-run"
            args = ["lab.py", "run", "--state", str(directory), "--nodes", "a", "b", "c",
                    "--router", "test-router", "--image-volume", "VMData:import/image.qcow2"]
            with mock.patch.object(sys, "argv", args), contextlib.redirect_stderr(io.StringIO()), \
                    mock.patch.object(lab, "LiveLab") as constructor:
                with self.assertRaises(SystemExit) as failure:
                    lab.main()
            self.assertEqual(failure.exception.code, 2)
            self.assertFalse(directory.exists())
            constructor.assert_not_called()

    def test_inventory_accounts_for_all_live_network_sources(self):
        del self.lab.network_inventory
        self.lab.config = {
            "ip_range_start": "10.1.0.5", "cidr": 24, "vtep_ip_range_cidr": "10.2.0.0/24",
        }
        self.lab.request = mock.Mock(side_effect=[
            [{"id": 5000, "gateway_cidr": "10.3.0.1/24"}], {"cidr": "10.4.0.0/24"},
        ])
        self.lab.proxmox = mock.Mock()
        self.lab.proxmox.get.side_effect = [
            {"data": [{"node": "unselected-host"}]},
            {"data": [{"cidr": "10.5.0.1/24", "cidr6": "fd00::1/64"}]},
        ]
        _, reserved = self.lab.network_inventory()
        self.assertEqual({str(network) for network in reserved},
                         {"10.1.0.0/24", "10.2.0.0/24", "10.3.0.0/24", "10.4.0.0/24",
                          "10.5.0.0/24", "fd00::/64"})

    def test_preflight_rechecks_conflicts_before_any_creation(self):
        self.lab.state.update({"nodes": ["a", "b", "c"],
                               "segments": lab.segment_plan(
                                   ["49100:10.10.0.1/24", "49101:10.11.0.1/24", "49102:10.12.0.1/24"],
                                   "test")})
        self.lab.config = {"proxmox_cluster_name": "cluster"}
        self.lab.router_policy = mock.Mock()
        self.lab.request = mock.Mock(return_value=[
            {"node": node, "cluster": "cluster", "status": "enrolled"} for node in ("a", "b", "c")
        ])
        for inventory, message in (
            (([{"id": 49100}], []), "refusing to adopt"),
            (([], [ipaddress.ip_network("10.10.0.0/24")]), "overlaps"),
        ):
            self.lab.network_inventory.return_value = inventory
            with self.assertRaisesRegex(RuntimeError, message):
                self.lab.create()
        self.assertTrue(all(call.args[0] == "GET" for call in self.lab.request.call_args_list))


if __name__ == "__main__":
    unittest.main()
