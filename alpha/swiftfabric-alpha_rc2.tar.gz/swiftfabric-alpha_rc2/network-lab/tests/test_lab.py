import copy
import base64
import errno
import gzip
import importlib.util
import json
import os
from pathlib import Path
import socket
import struct
import sys
import tempfile
import threading
import unittest
from unittest import mock

DIRECTORY = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(DIRECTORY))


def load(name, filename):
    specification = importlib.util.spec_from_file_location(name, DIRECTORY / filename)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


lab = load("network_lab", "lab.py")
guest = load("network_lab_guest", "guest.py")
SPECS = ["49100:10.253.244.1/24", "49101:10.253.245.1/24", "49102:10.253.246.1/24"]


class InterruptedPhaseTests(unittest.TestCase):
    def test_confirmed_outage_replays_whole_phase_and_retains_exact_matrix_size(self):
        instance = lab.LiveLab.__new__(lab.LiveLab)
        original = {"passed": True, "source_port": 20000}
        failed = {"passed": False}
        instance.state = {"results": [original]}
        instance.directory = Path("/synthetic")
        instance.save = mock.Mock()
        instance.phase_recovery = mock.Mock(return_value=True)
        source = {"next_source_port": 20001}
        case = {"source_port": 20000, "plane": "l2", "phase": 1, "source": "10.0.0.1",
                "destination": "10.0.0.2", "protocol": "tcp", "expected": "allow"}
        def execute(grouped, plane, phase):
            if not instance.phase_recovery.called:
                instance.state["results"].append(failed)
                raise lab.TrafficPhaseFailure("outage")
            instance.state["results"].append({"passed": True, "source_port": case["source_port"]})
        instance._execute_probes_once = mock.Mock(side_effect=execute)
        with mock.patch.object(lab, "private_write"):
            instance.execute_probes([(source, [case])], "l2", 1)
        self.assertEqual(len(instance.state["results"]), 2)
        self.assertTrue(all(result["passed"] for result in instance.state["results"]))
        self.assertEqual(case["source_port"], 20001)
        self.assertEqual(instance.phase_recovery.call_args.args[2], [failed])

    def test_unconfirmed_traffic_failure_never_replays(self):
        instance = lab.LiveLab.__new__(lab.LiveLab)
        instance.state = {"results": []}
        instance.phase_recovery = mock.Mock(return_value=False)
        instance._execute_probes_once = mock.Mock(side_effect=lab.TrafficPhaseFailure("real failure"))
        with self.assertRaises(lab.TrafficPhaseFailure):
            instance.execute_probes([], "l2", 1)
        self.assertEqual(instance._execute_probes_once.call_count, 1)


class ProxmoxTrustTests(unittest.TestCase):
    def test_lab_bootstraps_proxmox_ca_before_using_api(self):
        config = {
            "proxmox_cluster_ip": "192.0.2.1", "proxmox_port": 8006,
            "proxmox_user": "root@pam", "proxmox_tokenname": "lab",
            "proxmox_apikey": "test-key", "proxmox_ssh_user": "root",
            "proxmox_ssh_key": "/keys/proxmox", "controller_priv_key": "/keys/controller",
            "ip_range_start": "192.0.2.10",
        }
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)
            (path / "state.json").write_text(json.dumps({"config": "/config.json"}))
            with mock.patch.object(lab, "load_deployment_config", return_value=config), \
                    mock.patch.object(lab, "ProxmoxCATrust") as trust_type, \
                    mock.patch.object(lab, "ProxmoxClient") as client_type, \
                    mock.patch.object(lab, "SSHCommandRunner"), \
                    mock.patch.object(lab, "private_write"), \
                    mock.patch.object(lab, "_controller_vip", return_value="192.0.2.12"):
                trust_type.return_value.ca_path = "/temporary/proxmox-ca.pem"
                instance = lab.LiveLab(path)

            trust_type.assert_called_once_with("192.0.2.1", "root", "/keys/proxmox")
            client_type.assert_called_once_with(
                "192.0.2.1", port=8006, user="root@pam", token_name="lab",
                api_key="test-key", verify_ssl="/temporary/proxmox-ca.pem",
            )
            self.assertIs(instance.proxmox_ca, trust_type.return_value)
            trust_type.return_value.verify_cluster_nodes.assert_called_once_with(instance.proxmox)


class PlanTests(unittest.TestCase):
    def test_real_endpoint_readiness_and_nonce_receive_send_diagnostics(self):
        done = threading.Event()
        observed = []
        lock = threading.Lock()
        def observe(*args):
            with lock:
                observed.append(args)
                if len(observed) == 4:
                    done.set()
        with guest.TCPServer(("127.0.0.1", 0), guest.TCPHandler) as tcp, \
                guest.socketserver.ThreadingUDPServer(("127.0.0.1", 0), guest.UDPHandler) as udp:
            for server in (tcp, udp):
                thread = threading.Thread(target=server.serve_forever, daemon=True)
                thread.start()
                self.addCleanup(server.shutdown)
            with mock.patch.object(guest, "TCP_PORT", tcp.server_address[1]), \
                    mock.patch.object(guest, "UDP_PORT", udp.server_address[1]), \
                    mock.patch.object(guest, "echo_event", side_effect=observe) as events:
                status = guest.endpoint_status("127.0.0.1")
                self.assertTrue(done.wait(1))
            self.assertTrue(status["ready"])
            self.assertEqual([check["stage"] for check in status["checks"]], ["complete", "complete"])
            self.assertTrue(all(len(check["probe_id"]) == 64 for check in status["checks"]))
            self.assertEqual(events.call_count, 4)
            self.assertEqual({call.args[1] for call in events.call_args_list}, {"received", "sent"})

    def test_exactly_three_distinct_rfc1918_segments(self):
        segments = lab.segment_plan(SPECS, "a" * 32)
        self.assertEqual([item["id"] for item in segments], [49100, 49101, 49102])
        self.assertEqual(segments[0]["network"], "10.253.244.0/24")
        for specifications in (
            SPECS[:2], [SPECS[0], SPECS[0], SPECS[2]],
            ["49100:203.0.113.1/24", *SPECS[1:]],
            ["49100:10.253.244.1/25", *SPECS[1:]],
            ["49100:10.253.244.10/24", *SPECS[1:]],
            ["49100:10.253.244.0/24", *SPECS[1:]],
            ["50001:10.253.244.1/24", *SPECS[1:]],
        ):
            with self.subTest(specifications=specifications), self.assertRaises(ValueError):
                lab.segment_plan(specifications, "a" * 32)

    def test_acl_phases_require_both_sides_and_stay_scoped(self):
        segments = lab.segment_plan(SPECS, "a" * 32)
        for egress, ingress in ((False, False), (True, False), (False, True), (True, True)):
            with self.subTest(egress=egress, ingress=ingress):
                acl = lab.segment_acl(segments, segments[0], egress, ingress)
                self.assertEqual(len(acl["egress"]), 4 if egress else 0)
                self.assertEqual(len(acl["ingress"]), 4 if ingress else 0)
                for rule in acl["egress"]:
                    self.assertEqual(rule["source"], segments[0]["network"])
                    self.assertIn(rule["destination"], [segments[1]["network"], segments[2]["network"]])
                    self.assertIn(rule["destination_port"], ("18080", "18081"))
                for rule in acl["ingress"]:
                    self.assertEqual(rule["destination"], segments[0]["network"])
                    self.assertIn(rule["source"], [segments[1]["network"], segments[2]["network"]])
                    self.assertIn(rule["destination_port"], ("18080", "18081"))

    def test_vm_and_segment_ownership_are_verified(self):
        vm = {"vmid": 123, "name": "sf-lab-test", "segment_id": 49100}
        configuration = {
            "name": vm["name"], "description": "SwiftFabric live network lab run",
            "net0": "virtio=AA:BB:CC:DD:EE:FF,bridge=sf-br49100,firewall=1",
        }
        lab.assert_vm_owner(configuration, vm, "run")
        for changed in ({"name": "unrelated"}, {"description": "not ours"}, {"net0": "virtio,bridge=vmbr0"}):
            with self.subTest(changed=changed), self.assertRaisesRegex(RuntimeError, "refusing"):
                lab.assert_vm_owner({**configuration, **changed}, vm, "run")
        segment = lab.segment_plan(SPECS, "a" * 32)[0]
        lab.assert_segment_owner(segment, segment)
        with self.assertRaisesRegex(RuntimeError, "ownership"):
            lab.assert_segment_owner({**segment, "name": "someone-else"}, segment)

    def test_state_is_private_atomic_and_ca_is_not_json_encoded(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "state.json"
            lab.private_write(path, {"test": 1})
            lab.private_write(path, {"test": 2})
            self.assertEqual(json.loads(path.read_text()), {"test": 2})
            self.assertEqual(os.stat(path).st_mode & 0o777, 0o600)
            self.assertFalse(path.with_suffix(".tmp").exists())
            lab.private_write(path, "public PEM certificate\n")
            self.assertEqual(path.read_text(), "public PEM certificate\n")


class VersionedSegmentLifecycleTests(unittest.TestCase):
    def fixture(self):
        instance = lab.LiveLab.__new__(lab.LiveLab)
        segment = lab.segment_plan(SPECS, "a" * 32)[0]
        segment["create_requested"] = True
        instance.state = {"router": "test-router", "segments": [segment], "vms": []}
        instance.save = mock.Mock()
        instance.set_wan = mock.Mock()
        instance.set_acls = mock.Mock()
        return instance, segment

    def test_configure_attaches_using_current_segment_metadata_version(self):
        instance, segment = self.fixture()
        instance.state["vms"] = [{} for _ in range(9)]
        instance.setup_serial = mock.Mock()
        instance.owned_segment = mock.Mock(return_value={**segment, "_version": 17})
        instance.request = mock.Mock()
        instance.configure()
        instance.request.assert_called_once_with(
            "PUT", f"/segments/{segment['id']}/north-south-router",
            {"router_id": "test-router", "_version": 17},
        )

    def test_destroy_reloads_metadata_version_after_detach_before_delete(self):
        instance, segment = self.fixture()
        instance.owned_segment = mock.Mock(side_effect=[
            {**segment, "_version": 17}, {**segment, "_version": 18},
        ])
        instance.request = mock.Mock()
        instance.destroy()
        self.assertEqual(instance.request.call_args_list, [
            mock.call("PUT", f"/segments/{segment['id']}/north-south-router",
                      {"router_id": None, "_version": 17}),
            mock.call("DELETE", f"/segments/{segment['id']}?_version=18"),
        ])
        self.assertFalse(segment["create_requested"])

    def test_stale_detach_aborts_cleanup_without_delete_or_overwrite_retry(self):
        instance, segment = self.fixture()
        instance.owned_segment = mock.Mock(return_value={**segment, "_version": 17})
        instance.request = mock.Mock(side_effect=lab.LabAPIError(409, "stale segment version"))
        with self.assertRaisesRegex(lab.LabAPIError, "stale"):
            instance.destroy()
        self.assertEqual(instance.request.call_count, 1)
        self.assertTrue(segment["create_requested"])

    def test_retired_router_cleanup_requires_detached_inventory(self):
        instance, segment = self.fixture()
        instance.state["original_wan_policy"] = {}
        instance.owned_segment = mock.Mock(return_value={**segment, "_version": 18})
        instance.request = mock.Mock()
        instance.destroy(router_retired=True)
        instance.set_wan.assert_not_called()
        instance.request.assert_called_once_with(
            "DELETE", f"/segments/{segment['id']}?_version=18",
        )

    def test_retirement_does_not_allow_deleting_attached_segment(self):
        instance, segment = self.fixture()
        instance.owned_segment = mock.Mock(return_value={
            **segment, "_version": 18, "north_south_router": {"id": "test-router"},
        })
        instance.request = mock.Mock()
        with self.assertRaisesRegex(RuntimeError, "still has a segment attachment"):
            instance.destroy(router_retired=True)
        instance.request.assert_not_called()
        self.assertTrue(segment["create_requested"])


class PolicyTests(unittest.TestCase):
    def setUp(self):
        self.instance = lab.LiveLab.__new__(lab.LiveLab)
        self.original = {
            "wan_ingress_rules": [], "wan_egress_rules": [],
            "inbound_port_mappings": [], "outbound_port_mappings": [],
            "masquerade_source_cidrs": ["10.9.0.0/24"],
        }
        self.instance.state = {
            "router": "test-router", "segments": lab.segment_plan(SPECS, "a" * 32),
            "dns_address": "1.1.1.1", "original_wan_policy": copy.deepcopy(self.original),
        }
        self.instance.save = mock.Mock()
        self.instance.router_policy = mock.Mock(return_value=copy.deepcopy(self.original))
        self.router_record = {
            **copy.deepcopy(self.original), "status": "active",
            "ha_state_sync_enabled": False, "deployment_mode": "standalone", "_version": 1,
        }

        def request(method, path, body=None):
            if method == "GET":
                return copy.deepcopy(self.router_record)
            self.router_record.update({
                key: value for key, value in body.items()
                if key != "_version"
            })
            self.router_record["_version"] += 1
            return copy.deepcopy(self.router_record)

        self.instance.request = mock.Mock(side_effect=request)

    def test_wan_negative_phase_keeps_nat_and_existing_policy(self):
        self.instance.set_wan(False)
        policy = self.instance.request.call_args.args[2]
        self.assertEqual(policy["wan_egress_rules"], [])
        self.assertEqual(len(policy["masquerade_source_cidrs"]), 4)
        self.assertEqual(self.instance.state["original_wan_policy"], self.original)

    def test_allow_is_only_dns_and_restore_removes_only_test_additions(self):
        self.instance.set_wan(True)
        policy = self.instance.request.call_args.args[2]
        self.assertEqual(len(policy["wan_egress_rules"]), 6)
        self.assertTrue(all(rule["destination"] == "1.1.1.1/32" and rule["destination_port"] == "53"
                            for rule in policy["wan_egress_rules"]))
        self.instance.router_policy.return_value = copy.deepcopy(policy)
        self.instance.set_wan(False, restore=True)
        self.assertEqual(
            {key: value for key, value in self.instance.request.call_args.args[2].items()
             if key != "_version"},
            self.original,
        )

    def test_concurrent_administrator_policy_changes_are_not_overwritten(self):
        self.router_record["wan_egress_rules"] = ["administrator change"]
        with self.assertRaisesRegex(RuntimeError, "outside the lab"):
            self.instance.set_wan(True)
        self.assertFalse(any(call.args[0] == "PUT" for call in self.instance.request.call_args_list))

    def test_policy_change_between_router_and_policy_reads_is_not_overwritten(self):
        original = self.instance.request.side_effect

        def request(method, path, body=None):
            snapshot = original(method, path, body)
            if method == "GET" and path.endswith("/wan-policy"):
                snapshot["wan_egress_rules"] = ["concurrent administrator change"]
                snapshot["_version"] = 23
            return snapshot

        self.instance.request.side_effect = request
        with self.assertRaisesRegex(RuntimeError, "outside the lab"):
            self.instance.set_wan(True)
        self.assertFalse(any(call.args[0] == "PUT" for call in self.instance.request.call_args_list))

    def test_wan_write_uses_policy_version_not_router_configuration_version(self):
        original = self.instance.request.side_effect

        def request(method, path, body=None):
            snapshot = original(method, path, body)
            if method == "GET":
                snapshot["_version"] = 31 if path.endswith("/wan-policy") else 4
            return snapshot

        self.instance.request.side_effect = request
        self.instance.set_wan(True)
        self.assertEqual(self.instance.request.call_args.args[2]["_version"], 31)

    def test_ha_lifecycle_fence_is_not_bypassed(self):
        self.instance.request.return_value = {"status": "active", "ha_state_sync_enabled": True}
        self.instance.request.side_effect = None
        with self.assertRaisesRegex(RuntimeError, "not bypassed"):
            lab.LiveLab.router_policy(self.instance)

    def test_segment_ownership_uses_the_public_list_endpoint(self):
        segment = self.instance.state["segments"][0]
        self.instance.request.side_effect = None
        self.instance.request.return_value = [segment]
        self.assertEqual(self.instance.owned_segment(segment), segment)
        self.instance.request.assert_called_with("GET", "/segments")
        self.instance.request.return_value = []
        with self.assertRaises(lab.LabAPIError) as failure:
            self.instance.owned_segment(segment)
        self.assertEqual(failure.exception.status, 404)


class ProbeTests(unittest.TestCase):
    def case(self, expected="allow", protocol="tcp"):
        return {
            "source": "127.0.0.1", "destination": "127.0.0.1",
            "source_port": 0, "destination_port": 12345,
            "protocol": protocol, "expected": expected,
        }

    def test_refused_connection_is_not_a_drop(self):
        with mock.patch.object(guest.socket, "socket") as socket_factory:
            socket_factory.return_value.__enter__.return_value.connect.side_effect = ConnectionRefusedError(
                errno.ECONNREFUSED, "refused",
            )
            result = guest.probe(self.case(expected="drop"))
        self.assertFalse(result["passed"])
        self.assertEqual(result["outcome"], "error")
        self.assertIn("NOT a policy drop", result["detail"])

    def test_details_preserve_test_purpose_for_success_and_failure(self):
        for error in (None, TimeoutError(), ConnectionRefusedError(errno.ECONNREFUSED, "refused")):
            with self.subTest(error=error), mock.patch.object(guest.socket, "socket") as socket_factory:
                connection = socket_factory.return_value.__enter__.return_value
                connection.connect.side_effect = error
                connection.recv.return_value = b"x" * 32
                with mock.patch.object(guest.secrets, "token_bytes", return_value=b"x" * 32):
                    result = guest.probe({**self.case(), "purpose": "Validate remote primary VM IP."})
                self.assertIn("Validate remote primary VM IP. Observation:", result["detail"])
                self.assertEqual(result["passed"], error is None)

    def test_only_timeout_satisfies_denial(self):
        with mock.patch.object(guest.socket, "socket") as socket_factory:
            socket_factory.return_value.__enter__.return_value.connect.side_effect = TimeoutError()
            result = guest.probe(self.case(expected="drop"))
        self.assertTrue(result["passed"])
        self.assertEqual(result["outcome"], "drop")

    def test_tcp_handshake_cannot_be_mistaken_for_a_policy_drop(self):
        with mock.patch.object(guest.socket, "socket") as socket_factory:
            connection = socket_factory.return_value.__enter__.return_value
            connection.recv.side_effect = TimeoutError()
            result = guest.probe(self.case(expected="drop"))
        self.assertFalse(result["passed"])
        self.assertEqual(result["outcome"], "error")
        self.assertIn("handshake succeeded", result["detail"])
        connection.sendall.assert_not_called()

    def test_unreachable_network_is_an_error_not_a_drop(self):
        with mock.patch.object(guest.socket, "socket") as socket_factory:
            socket_factory.return_value.__enter__.return_value.connect.side_effect = OSError(
                errno.ENETUNREACH, "no route",
            )
            result = guest.probe(self.case(expected="drop"))
        self.assertFalse(result["passed"])
        self.assertEqual(result["outcome"], "error")

    def test_wrong_echo_is_not_success(self):
        with mock.patch.object(guest.socket, "socket") as socket_factory:
            socket_factory.return_value.__enter__.return_value.recv.return_value = b"x" * 32
            with mock.patch.object(guest.secrets, "token_bytes", return_value=b"y" * 32):
                result = guest.probe(self.case())
        self.assertFalse(result["passed"])
        self.assertIn("nonce", result["detail"])

    def test_real_tcp_echo(self):
        with socket.socket() as server:
            server.bind(("127.0.0.1", 0))
            server.listen()

            def answer():
                connection, _ = server.accept()
                with connection:
                    connection.sendall(connection.recv(1024))

            thread = threading.Thread(target=answer)
            thread.start()
            try:
                result = guest.probe({**self.case(), "destination_port": server.getsockname()[1]})
                self.assertTrue(result["passed"], result)
            finally:
                thread.join(timeout=5)
                self.assertFalse(thread.is_alive())

    def test_truncated_tcp_response_is_not_success(self):
        left, right = socket.socketpair()
        with left, right:
            right.sendall(b"short")
            right.shutdown(socket.SHUT_WR)
            with self.assertRaisesRegex(RuntimeError, "EOF"):
                guest.read_exact(left, 32)


class MatrixTests(unittest.TestCase):
    def setUp(self):
        self.instance = lab.LiveLab.__new__(lab.LiveLab)
        self.instance.state = {
            "vms": [
                {"address": f"10.253.{244 + segment}.{10 + host}",
                 "segment_id": 49100 + segment, "node": f"host{host}",
                 "name": f"test-s{segment}-h{host}", "vmid": 100 + 3 * segment + host}
                for segment in range(3) for host in range(3)
            ],
            "dns_address": "1.1.1.1", "results": [], "ready": True,
        }
        self.instance.save = mock.Mock()

        def serial(vm, command):
            cases = json.loads(gzip.decompress(base64.b64decode(command.split()[-1])))
            return json.dumps([
                {**case, "outcome": case["expected"], "passed": True}
                for case in cases
            ])

        self.instance.serial = mock.Mock(side_effect=serial)

    def test_complete_matrix_includes_same_host_routing_and_fresh_ports(self):
        with tempfile.TemporaryDirectory() as directory:
            self.instance.directory = Path(directory)
            self.instance.probes("l2", 1, "allow")
            self.assertEqual(len(self.instance.state["results"]), 54)
            self.assertTrue(all(
                result["source_node"] != result["destination_node"]
                for result in self.instance.state["results"]
            ))
            self.instance.probes("east-west", 2, "drop")
            routed = self.instance.state["results"][54:]
            self.assertEqual(len(routed), 108)
            self.assertTrue(any(r["source_node"] == r["destination_node"] for r in routed))
            self.assertTrue(any(r["source_node"] != r["destination_node"] for r in routed))
            self.instance.probes("east-west", 2, "drop")
            for vm in self.instance.state["vms"]:
                ports = [r["source_port"] for r in self.instance.state["results"] if r["source"] == vm["address"]]
                self.assertEqual(len(ports), len(set(ports)))

    def test_inconsistent_guest_result_is_rejected(self):
        self.instance.serial.side_effect = lambda vm, command: "[]"
        with self.assertRaisesRegex(RuntimeError, "do not match"):
            self.instance.probes("east-west", 1, "drop")

    def test_test_sequence_restores_policy_after_a_failure(self):
        self.instance.set_wan = mock.Mock()
        self.instance.set_acls = mock.Mock()
        self.instance.probes = mock.Mock(side_effect=RuntimeError("probe failure"))
        with self.assertRaisesRegex(RuntimeError, "probe failure"):
            self.instance.test()
        self.instance.set_acls.assert_called_with(True, True)
        self.instance.set_wan.assert_called_with(True)


    def test_north_south_uses_empty_segment_acls_and_restores_visible_mesh(self):
        self.instance.state["segments"] = lab.segment_plan(SPECS, "a" * 32)
        self.instance.state["settle_seconds"] = 0
        self.instance.set_wan = mock.Mock()
        self.instance.set_acls = mock.Mock()
        self.instance.request = mock.Mock(return_value={"acl": {"ingress": [], "egress": []}})
        wan = []

        def probes(plane, phase, expected):
            if plane == "north-south":
                self.instance.set_acls.assert_called_with(False, False)
                wan.append((phase, expected))

        self.instance.probes = mock.Mock(side_effect=probes)
        self.instance.test()
        self.assertEqual(wan, [(8, "allow"), (9, "drop"), (10, "allow")])
        self.assertEqual(self.instance.request.call_count, 3)
        self.instance.set_acls.assert_called_with(True, True)

    def test_north_south_refuses_nonempty_segment_acls(self):
        self.instance.state["segments"] = lab.segment_plan(SPECS, "a" * 32)
        self.instance.set_wan = mock.Mock()
        self.instance.set_acls = mock.Mock()
        self.instance.probes = mock.Mock()
        self.instance.request = mock.Mock(return_value={
            "acl": {"ingress": [{}], "egress": []},
        })

        with self.assertRaisesRegex(RuntimeError, "requires empty East/West segment ACLs"):
            self.instance.test()

        self.assertTrue(all(call.args[0] != "north-south"
                            for call in self.instance.probes.call_args_list))
        self.instance.set_acls.assert_called_with(True, True)
        self.instance.set_wan.assert_called_with(True)


class CaptureTests(unittest.TestCase):
    def setUp(self):
        self.instance = lab.LiveLab.__new__(lab.LiveLab)
        self.instance.state = {
            "nodes": ["host0", "host1", "host2"],
            "vms": [
                {"address": f"10.253.{244 + segment}.{10 + host}", "node": f"host{host}"}
                for segment in range(3) for host in range(3)
            ],
            "results": [], "ready": True,
        }
        self.instance.vm_config = mock.Mock()
        self.instance.probes = mock.Mock()
        self.instance.config = {
            "proxmox_ssh_key": "/unused/key", "proxmox_ssh_user": "root",
            "proxmox_cluster_ip": "192.0.2.10",
        }
        self.instance.endpoint_snapshots = mock.Mock(return_value={"10.253.244.10": {"ready": True}})
        self.instance.endpoint_logs = mock.Mock(return_value={})

    def executor(self, finished=False, error=None):
        executor = mock.MagicMock()
        executor.__enter__.return_value = executor
        futures = []

        def submit(function, node, directory, packet_filter, seconds, ready):
            ready.set()
            future = mock.Mock()
            future.done.return_value = finished
            future.result.return_value = {"packets": 1, "bytes": 100}
            if error is not None:
                future.result.side_effect = error
            futures.append(future)
            return future

        executor.submit.side_effect = submit
        return executor, futures

    def test_filters_include_only_lab_endpoints_and_selected_plane_ports(self):
        for plane in ("l2", "east-west", "north-south"):
            packet_filter = lab.capture_filter(self.instance.state["vms"], plane)
            for vm in self.instance.state["vms"]:
                self.assertIn(f"host {vm['address']}", packet_filter)
            self.assertIn("arp or icmp", packet_filter)
            self.assertIn("tcp port 53" if plane == "north-south" else "tcp port 18080", packet_filter)
            self.assertNotIn("tcp port 18080" if plane == "north-south" else "tcp port 53", packet_filter)
        with self.assertRaises(ValueError):
            lab.capture_filter([], "l2")
        with self.assertRaises(ValueError):
            lab.capture_filter([{"address": "192.0.2.1; unsafe"}], "l2")

    def test_capture_validates_ownership_and_waits_for_all_hosts(self):
        executor, futures = self.executor()
        with tempfile.TemporaryDirectory() as directory:
            self.instance.directory = Path(directory)
            with mock.patch.object(lab.concurrent.futures, "ThreadPoolExecutor", return_value=executor):
                self.instance.capture("east-west", "drop", 60)
            manifest = json.loads(next(Path(directory).glob("captures/*/manifest.json")).read_text())
            self.assertTrue(manifest["completed"])
            self.assertTrue(manifest["traffic_passed"])
            self.assertEqual(executor.submit.call_count, 3)
            self.assertEqual(self.instance.vm_config.call_count, 9)
            self.instance.probes.assert_called_once_with("east-west", 0, "drop")
            self.assertTrue(all(future.result.call_count == 1 for future in futures))

    def test_probe_failure_retains_diagnostics_and_is_not_success(self):
        executor, futures = self.executor()
        self.instance.probes.side_effect = RuntimeError("traffic failed")
        with tempfile.TemporaryDirectory() as directory:
            self.instance.directory = Path(directory)
            with mock.patch.object(lab.concurrent.futures, "ThreadPoolExecutor", return_value=executor):
                with self.assertRaisesRegex(RuntimeError, "traffic failed"):
                    self.instance.capture("l2", "allow", 60)
            manifest_path = next(Path(directory).glob("captures/*/manifest.json"))
            manifest = json.loads(manifest_path.read_text())
            self.assertFalse(manifest["completed"])
            self.assertFalse(manifest["traffic_passed"])
            self.assertEqual(manifest_path.stat().st_mode & 0o777, 0o600)
            self.assertEqual(manifest_path.parent.stat().st_mode & 0o777, 0o700)
            self.assertTrue(all(future.result.call_count == 1 for future in futures))

    def test_endpoint_not_ready_is_not_misreported_as_packet_loss(self):
        executor, _ = self.executor()
        self.instance.endpoint_snapshots.return_value = {"10.253.244.10": {"ready": False}}
        with tempfile.TemporaryDirectory() as directory:
            self.instance.directory = Path(directory)
            with mock.patch.object(lab.concurrent.futures, "ThreadPoolExecutor", return_value=executor):
                with self.assertRaisesRegex(RuntimeError, "readiness"):
                    self.instance.capture("l2", "allow", 60)
            manifest = json.loads(next(Path(directory).glob("captures/*/manifest.json")).read_text())
            self.assertFalse(manifest["traffic_passed"])
            self.assertFalse(manifest["endpoints_before"]["10.253.244.10"]["ready"])
            self.instance.probes.assert_not_called()

    def test_failure_binds_exact_flow_to_host_pcaps_and_nonce_events(self):
        executor, _ = self.executor()
        result = {
            "passed": False, "source_node": "host0", "destination_node": "host1",
            "source": "10.253.244.10", "destination": "10.253.244.11",
            "protocol": "udp", "probe_id": "nonce-digest",
        }
        def fail(*_args):
            self.instance.state["results"].append(result)
            raise RuntimeError("traffic failed")
        self.instance.probes.side_effect = fail
        self.instance.endpoint_logs.return_value = {
            "10.253.244.11": [{"probe_id": "nonce-digest", "stage": "received"}, {"probe_id": "unrelated"}],
        }
        with tempfile.TemporaryDirectory() as directory:
            self.instance.directory = Path(directory)
            with mock.patch.object(lab.concurrent.futures, "ThreadPoolExecutor", return_value=executor):
                with self.assertRaisesRegex(RuntimeError, "traffic failed"):
                    self.instance.capture("l2", "allow", 60)
            manifest = json.loads(next(Path(directory).glob("captures/*/manifest.json")).read_text())
            diagnostic = manifest["failure_diagnostics"][0]
            self.assertEqual(diagnostic["flow"], result)
            self.assertEqual(diagnostic["pcaps"], ["host0.pcap", "host1.pcap"])
            self.assertEqual(diagnostic["endpoint_events"], [{"probe_id": "nonce-digest", "stage": "received"}])
            self.assertFalse(manifest["traffic_passed"])

    def test_capture_failure_is_not_reported_as_a_passed_probe(self):
        executor, _ = self.executor(finished=True, error=RuntimeError("tcpdump missing"))
        with tempfile.TemporaryDirectory() as directory:
            self.instance.directory = Path(directory)
            with mock.patch.object(lab.concurrent.futures, "ThreadPoolExecutor", return_value=executor):
                with self.assertRaisesRegex(RuntimeError, "tcpdump missing"):
                    self.instance.capture("l2", "allow", 60)
            manifest = json.loads(next(Path(directory).glob("captures/*/manifest.json")).read_text())
            self.assertFalse(manifest["completed"])
            self.instance.probes.assert_not_called()

    def test_capture_ending_during_probes_is_incomplete(self):
        executor, futures = self.executor()

        def finish_capture(*args):
            futures[0].done.return_value = True

        self.instance.probes.side_effect = finish_capture
        with tempfile.TemporaryDirectory() as directory:
            self.instance.directory = Path(directory)
            with mock.patch.object(lab.concurrent.futures, "ThreadPoolExecutor", return_value=executor):
                with self.assertRaisesRegex(RuntimeError, "ended before probes finished"):
                    self.instance.capture("l2", "allow", 30)
            manifest = json.loads(next(Path(directory).glob("captures/*/manifest.json")).read_text())
            self.assertTrue(manifest["traffic_passed"])
            self.assertFalse(manifest["completed"])

    def test_invalid_capture_arguments_fail_before_starting_processes(self):
        for plane, expected, seconds in (
            ("l2", "drop", 60), ("unknown", "allow", 60),
            ("l2", "allow", 29), ("l2", "allow", 121),
        ):
            with self.subTest(plane=plane, expected=expected, seconds=seconds):
                with self.assertRaises(ValueError):
                    self.instance.capture(plane, expected, seconds)
        self.instance.vm_config.assert_not_called()

    def test_capture_worker_retains_private_pcap_and_stderr(self):
        original_popen = lab.subprocess.Popen
        payload = (b"\xd4\xc3\xb2\xa1" + struct.pack("<HHIIII", 2, 4, 0, 0, 65535, 276)
                   + struct.pack("<IIII", 1, 0, 60, 60) + bytes(60))
        program = (
            f"import sys;sys.stdout.buffer.write({payload!r});sys.stdout.flush();"
            "sys.stderr.write('tcpdump: listening on any\\n');sys.stderr.flush();sys.exit(124)"
        )

        def popen(command, **kwargs):
            self.assertIn("timeout", command[-1])
            self.assertIn("tcpdump", command[-1])
            return original_popen([sys.executable, "-c", program], **kwargs)

        ready = threading.Event()
        with tempfile.TemporaryDirectory() as directory:
            with mock.patch.object(lab.subprocess, "Popen", side_effect=popen):
                self.instance._capture_host("host0", Path(directory), "host 192.0.2.1", 30, ready)
            self.assertTrue(ready.is_set())
            self.assertEqual((Path(directory) / "host0.pcap").stat().st_mode & 0o777, 0o600)
            self.assertIn("listening on", (Path(directory) / "host0.log").read_text())

    def test_missing_tcpdump_fails_worker_without_readiness(self):
        original_popen = lab.subprocess.Popen
        program = "import sys;sys.stderr.write('tcpdump: not found\\n');sys.exit(127)"

        def popen(command, **kwargs):
            return original_popen([sys.executable, "-c", program], **kwargs)

        ready = threading.Event()
        with tempfile.TemporaryDirectory() as directory:
            with mock.patch.object(lab.subprocess, "Popen", side_effect=popen):
                with self.assertRaisesRegex(RuntimeError, "capture failed"):
                    self.instance._capture_host("host0", Path(directory), "host 192.0.2.1", 30, ready)
            self.assertFalse(ready.is_set())
            self.assertIn("not found", (Path(directory) / "host0.log").read_text())

    def test_pcap_validation_rejects_invalid_empty_and_truncated_artifacts(self):
        header = b"\xd4\xc3\xb2\xa1" + struct.pack("<HHIIII", 2, 4, 0, 0, 65535, 276)
        packet = struct.pack("<IIII", 1, 0, 60, 60) + bytes(60)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "capture.pcap"
            for payload in (b"not a capture" * 3, header, header + packet[:-1], header + b"partial"):
                with self.subTest(size=len(payload)):
                    path.write_bytes(payload)
                    with self.assertRaises(RuntimeError):
                        lab.pcap_packet_count(path)
            path.write_bytes(header + packet * 2)
            self.assertEqual(lab.pcap_packet_count(path), 2)

if __name__ == "__main__":
    unittest.main()
