"""Credential-free, self-contained acceptance evidence and HTML rendering."""

from collections import Counter
from datetime import datetime, timezone
import hashlib
import html
import json
import subprocess
import time


VM_FIELDS = ("vmid", "name", "node", "segment_id", "tenant_id", "address")
TRAFFIC_FIELDS = (
    "plane", "phase", "protocol", "expected", "outcome", "passed", "source",
    "destination", "source_port", "destination_port", "source_node", "destination_node",
    "source_tenant", "destination_tenant", "source_segment", "destination_segment",
    "source_vm", "source_vmid", "destination_vm", "destination_vmid",
    "started_epoch", "elapsed_ms", "stage", "probe_id", "endpoint_identity", "detail",
    "source_address_role", "destination_address_role", "traffic_path", "purpose",
    "overlap_tenant_id", "overlap_segment_id",
)
API_FIELDS = (
    "case", "method", "path", "status", "expected_status", "passed", "credential_kind",
    "started_epoch", "elapsed_ms",
)


def select(record, fields):
    return {key: record[key] for key in fields if key in record}


def timestamp(epoch):
    if epoch is None:
        return "Not captured"
    return datetime.fromtimestamp(epoch, timezone.utc).isoformat(timespec="milliseconds")


def source_revisions(root):
    revisions = []
    for name in (".", "network-lab", "host-agent", "controller-api", "python_installer",
                 "demos", "diag"):
        directory = root / name
        commit = subprocess.run(
            ["git", "-C", str(directory), "rev-parse", "HEAD"],
            check=True, text=True, capture_output=True,
        ).stdout.strip()
        dirty = subprocess.run(
            ["git", "-C", str(directory), "status", "--porcelain"],
            check=True, text=True, capture_output=True,
        ).stdout
        revisions.append({"component": "supervisor" if name == "." else name,
                          "commit": commit, "dirty": bool(dirty)})
    return revisions


def initial(state):
    return {
        "schema_version": 1, "run_id": state["run_id"],
        "started_epoch": time.time(), "finished_epoch": None, "status": "RUNNING",
        "tenancy": bool(state.get("tenancy")),
        "source_revisions": [], "kit_files": [], "hosts": [], "router": {},
        "vms": [select(vm, VM_FIELDS) for vm in state["vms"]],
        "segments": [select(segment, ("id", "name", "tenant_id", "network", "gateway_cidr"))
                     for segment in state["segments"]],
        "tenant_metadata": [select(tenant, ("id", "name", "routing_table", "conntrack_zone"))
                            for tenant in state.get("tenant_metadata", [])],
        "api_start_index": len(state.get("api_results", [])),
    }


def collect(lab, root):
    router = lab.request("GET", f"/north-south-routers/{lab.state['router']}")
    hosts = lab.request("GET", "/hosts")
    resources = lab.proxmox.get("/cluster/resources", params={"type": "vm"})["data"]
    router_vm = next(vm for vm in resources if int(vm["vmid"]) == router["vmid"])
    nodes = set(lab.state["nodes"])
    return {
        "source_revisions": source_revisions(root),
        "kit_files": [
            {"file": str(path.relative_to(root)),
             "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
            for path in sorted((root / "network-lab").glob("*.py"))
        ],
        "hosts": [select(host, ("host_id", "node", "agent_version", "status", "vtep_ip"))
                  for host in hosts if host["node"] in nodes],
        "router": {**select(router, (
            "id", "name", "node", "vmid", "tenant_id", "deployment_mode",
            "runtime_version", "agent_version", "current_runtime_version",
        )), "proxmox_vm_name": router_vm["name"]},
    }


def traffic_path(result):
    if result["plane"] == "north-south":
        return "wan"
    if (result.get("source_node") is not None
            and result.get("source_node") != result.get("destination_node")):
        return "cross-host"
    if (result.get("source_vmid") is not None
            and result.get("source_vmid") == result.get("destination_vmid")):
        return "guest-local"
    if result["plane"] == "health":
        return "guest-local"
    return "same-host"


def policy_purpose(result):
    plane = result["plane"]
    if plane == "health":
        return "Endpoint availability control for isolation/ACL denial tests."
    overlap_tenant = result.get("overlap_tenant_id")
    if overlap_tenant:
        overlap_segment = result.get("overlap_segment_id")
        identity = (f"Destination primary IP also belongs to tenant {overlap_tenant}"
                    + (f", segment {overlap_segment}" if overlap_segment is not None else "")
                    + "; "
                    "IPv4 packet has no tenant selector, so endpoint identity must match "
                    "the source tenant's VM at that address. This is not a direct "
                    "cross-tenant delivery test. ")
        if plane == "l2":
            return identity + "Same-segment traffic remains allowed."
        phases = {
            "2": "Neither source egress nor destination ingress ACL allows routed traffic.",
            "3": "Source egress alone cannot permit routed traffic.",
            "4": "Destination ingress alone cannot permit routed traffic.",
            "5": "Both source egress and destination ingress allow same-tenant routing.",
            "6": "Withdrawing ACLs blocks fresh routed flows.",
        }
        return identity + phases.get(str(result["phase"]), "Same-tenant routed ACL enforcement.")
    foreign = (result.get("source_tenant") != result.get("destination_tenant")
               and plane != "north-south")
    if foreign:
        if result.get("destination_address_role") == "witness":
            return ("Historical report: cross-tenant witness was used to avoid an own-tenant VM "
                    "with the same primary IP. No current lab probes use secondary guest addresses.")
        return ("Historical direct cross-tenant probe row. Current tests use identical tenant IP "
                "spaces and verify source-tenant endpoint identity; an IPv4 packet cannot select "
                "a destination tenant.")
    if plane == "l2":
        return ("Same-tenant, same-segment traffic remains allowed independently of routed ACLs; "
                "TCP/UDP nonce and VM identity or ICMP reply.")
    if plane == "east-west":
        phases = {
            "2": "Neither source egress nor destination ingress ACL allows traffic.",
            "3": "Source egress alone cannot permit routed traffic.",
            "4": "Destination ingress alone cannot permit routed traffic.",
            "5": "Both source egress and destination ingress allow same-tenant routing.",
            "6": "Withdrawing ACLs blocks fresh routed flows.",
        }
        return ("Source routing host checks source egress and destination ingress allowlists; "
                "each defaults to deny for new unmatched flows. "
                + phases.get(str(result["phase"]), "Same-tenant routed ACL enforcement."))
    if plane == "north-south":
        phase = str(result["phase"])
        tenant = result.get("destination_tenant")
        if tenant is None and phase.endswith(("-allow", "-deny", "-restore")):
            tenant = phase.rsplit("-", 1)[0]
        if tenant is not None and result.get("source_tenant") != tenant:
            return "Inactive tenant must not reach WAN DNS through the other tenant's NSR/NAT."
        if phase == "9" or phase.endswith("-deny"):
            return "WAN ACL removed while NAT remains configured; fresh DNS flow must time out."
        if phase == "10" or phase.endswith("-restore"):
            return "Restored WAN ACL permits DNS through NSR source NAT with empty segment ACLs."
        return "Active tenant reaches WAN DNS through NSR source NAT with empty segment ACLs."
    raise ValueError(f"unknown traffic plane: {plane}")


def purpose(result):
    path = result.get("traffic_path") or traffic_path(result)
    paths = {
        "guest-local": "Guest-local socket check; no fabric or VTEP traversal.",
        "same-host": "Same-host VM-to-VM bridge/routing path; no remote VTEP traversal.",
        "cross-host": ("Cross-host endpoints "
                       f'{result.get("source_node")} -> {result.get("destination_node")}; '
                       + ("authorized delivery exercises remote VTEP forwarding."
                          if result["expected"] == "allow"
                          else "blocked reachability expected; guest result alone cannot locate the drop.")),
        "wan": "Guest-to-WAN path through NSR; not a host-to-host VTEP assertion.",
    }
    roles = {
        "primary": "primary VM IP", "dns": "WAN DNS IP",
        "witness": "historical tenant-unique witness IP",
    }
    source_role = roles.get(result.get("source_address_role"), "source IP")
    destination_role = roles.get(result.get("destination_address_role"), "endpoint IP")
    return (f'{paths[path]} Validate {source_role} {result["source"]} -> '
            f'{destination_role} {result["destination"]} using {result["protocol"].upper()}; '
            f'expected {result["expected"]}. {policy_purpose(result)}')


def enrich_traffic(result, vms):
    record = select(result, TRAFFIC_FIELDS)
    record.setdefault("source_address_role", "primary")
    if "destination_address_role" not in record:
        role = "dns" if record["plane"] == "north-south" else "endpoint"
        for vm in vms:
            if record.get("destination_vmid") is not None:
                matches = vm["vmid"] == record["destination_vmid"]
            else:
                matches = (vm.get("tenant_id") == record.get("destination_tenant")
                           and vm.get("node") == record.get("destination_node"))
            if matches:
                if record["destination"] == vm.get("witness"):
                    role = "witness"
                    break
                if record["destination"] == vm["address"]:
                    role = "primary"
                    break
        record["destination_address_role"] = role
    record["traffic_path"] = traffic_path(record)
    record["purpose"] = purpose(record)
    return record


def api_purpose(result):
    case = result["case"]
    if "overlap" in case:
        return "Overlapping CIDRs require confirmation and a separate tenant allocation."
    if "child" in case or "/keys" in case:
        return "Child key is read-only, tenant-scoped and revocable; cannot escalate."
    if "router" in case:
        return "NSR attachment, reassignment and policy access remain tenant-scoped."
    return "Expected API status enforces tenant inventory/access boundaries or scoped identity."


def table(headers, rows, identifier=""):
    head = "".join(f"<th>{html.escape(str(value))}</th>" for value in headers)
    body = []
    for row in rows:
        cells = "".join(f"<td>{html.escape(str(value))}</td>" for value in row)
        body.append(f"<tr>{cells}</tr>")
    return (f'<div class="scroll"><table id="{identifier}"><thead><tr>{head}</tr></thead>'
            f'<tbody>{"".join(body)}</tbody></table></div>')


def render(evidence, results, api_results):
    traffic = [enrich_traffic(result, evidence["vms"]) for result in results]
    apis = [select(result, API_FIELDS) for result in api_results]
    counts = Counter(result["plane"] for result in traffic)
    sections = [
        "<h1>SwiftFabric live network acceptance</h1>",
        f"<p><strong>{html.escape(evidence['status'])}</strong> &mdash; "
        f"run {html.escape(evidence['run_id'])}</p>",
        table(("Started (UTC)", "Finished (UTC)", "Mode"),
              [(timestamp(evidence["started_epoch"]), timestamp(evidence.get("finished_epoch")),
                "Two overlapping tenants / sequential shared NSR" if evidence["tenancy"]
                else "Single tenant / nine VMs")]),
        "<p>All times UTC. Run/API times use operator clock; traffic timestamps use guest "
        "wall clocks (not clock-offset certified). Durations use monotonic clocks. "
        "Each traffic row is one assertion; phase summary groups those rows. "
        "Topology and deployed versions were captured before cleanup. "
        "Commit IDs describe source checkout; deployed package versions are listed separately. "
        "Dirty source is explicitly marked; SHA-256 fingerprints identify executed kit files.</p>",
        "<h2>Scope and limitations</h2><p>Connectivity and tenant/ACL enforcement only. "
        "No throughput, HA/session-continuity, broadcast/multicast isolation, or simultaneous "
        "dual-tenant NAT certification. One dedicated standalone NSR is reassigned sequentially. "
        "Evidence includes guest observations, echo nonce hashes/identities, ICMP output, DNS "
        "validation results and API status assertions; no packet capture is implied. "
        "Successful cross-host delivery exercises remote VTEP forwarding; encapsulation itself "
        "is not captured. Denied probes assert blocked reachability, not VTEP traversal or drop location. "
        "E/W source routing host evaluates both source egress and destination ingress ACLs before "
        "forwarding. VTEP/physical fabric is trusted; receiving-host re-enforcement is not asserted. "
        "Same-host policy controls and guest-local checks are not remote VTEP evidence. "
        "No credentials, request/response bodies, console transcripts or private state are embedded.</p>",
        "<h2>Captured test assertion output</h2><pre>"
        + html.escape("\n".join(
            f'{timestamp(item["epoch"])}  {item["line"]}'
            for item in evidence.get("assertion_output", [])
        )) + "</pre>",
        "<h2>Summary</h2>",
        table(("Test family", "Assertions", "Passed", "Failed"),
              [(plane, count, sum(r["passed"] for r in traffic if r["plane"] == plane),
                sum(not r["passed"] for r in traffic if r["plane"] == plane))
               for plane, count in counts.items()]
              + [("API/RBAC (this run/attempt)", len(apis), sum(r["passed"] for r in apis),
                  sum(not r["passed"] for r in apis))]),
        table(("Traffic path", "Allowed assertions", "Denied assertions", "Remote host VTEP evidence"),
              [(path,
                sum(r["traffic_path"] == path and r["expected"] == "allow" for r in traffic),
                sum(r["traffic_path"] == path and r["expected"] == "drop" for r in traffic),
                "Successful delivery only; denied probes do not locate drops"
                if path == "cross-host" else "Not a host-to-host VTEP assertion")
               for path in dict.fromkeys(r["traffic_path"] for r in traffic)]),
        "<h2>Commits</h2>",
        table(("Component", "Full commit", "Uncommitted changes"),
              [(r["component"], r["commit"], r["dirty"]) for r in evidence["source_revisions"]]),
        "<h2>Executed kit fingerprints</h2>",
        table(("File", "SHA-256"), [(r["file"], r["sha256"]) for r in evidence["kit_files"]]),
        "<h2>Hosts and recorded deployed packages</h2>",
        table(("Host", "Host ID", "Agent version", "Status", "VTEP"),
              [(r["node"], r["host_id"], r.get("agent_version", "Not captured"),
                r["status"], r["vtep_ip"]) for r in evidence["hosts"]]),
        "<h2>Dedicated North/South router</h2>",
        table(("Field", "Captured value"), evidence["router"].items()),
        "<h2>VM inventory (retained after deletion)</h2>",
        table(VM_FIELDS, [[vm.get(key, "") for key in VM_FIELDS] for vm in evidence["vms"]]),
        "<h2>Segments and tenants</h2>",
        table(("Segment", "Name", "Tenant", "Network", "Gateway"),
              [(s["id"], s["name"], s.get("tenant_id", "default"), s["network"], s["gateway_cidr"])
               for s in evidence["segments"]]),
        table(("Tenant", "Routing table", "Conntrack zone"),
              [(t["id"], t["routing_table"], t["conntrack_zone"])
               for t in evidence["tenant_metadata"]]),
        "<h2>Test phases</h2>",
    ]
    groups = {}
    for result in traffic:
        groups.setdefault((result["plane"], str(result["phase"]), policy_purpose(result)), []).append(result)
    sections.append(table(
        ("Plane", "Phase", "What it validates", "Passed / total", "First observation (UTC)"),
        [(plane, phase, description, f'{sum(r["passed"] for r in rows)} / {len(rows)}',
          timestamp(min(r["started_epoch"] for r in rows))) for
         (plane, phase, description), rows in groups.items()],
    ))
    sections.append("<h2>Traffic assertions and captured observations</h2>"
                    "<p>Use browser Find to locate VM names, tenants, phases or failures.</p>")
    sections.append(table(
        ("#", "Result", "Plane / phase", "Validates", "Protocol", "Expected / observed",
         "Source host / VM / VMID", "Destination host / VM / VMID", "Tenant / segment",
         "Source -> destination", "Started (UTC)", "Duration ms", "Captured evidence"),
        [(index, "PASS" if r["passed"] else "FAIL", f'{r["plane"]} / {r["phase"]}', purpose(r),
          r["protocol"], f'{r["expected"]} / {r["outcome"]}',
          f'{r.get("source_node", "")} / {r.get("source_vm", "")} / {r.get("source_vmid", "")}',
          f'{r.get("destination_node", "")} / {r.get("destination_vm", "WAN")} / {r.get("destination_vmid", "")}',
          f'{r.get("source_tenant", "default")} / {r.get("source_segment", "")} -> '
          f'{r.get("destination_tenant", "")} / {r.get("destination_segment", "")}',
          f'{r["source"]}:{r.get("source_port", "")} -> {r["destination"]}:{r.get("destination_port", "")}',
          timestamp(r.get("started_epoch")), r.get("elapsed_ms", ""),
          f'stage={r.get("stage", "")}; nonce SHA-256={r.get("probe_id") or "n/a"}; '
          f'expected endpoint={r.get("endpoint_identity") or "n/a"}; {r.get("detail", "")}')
         for index, r in enumerate(traffic, 1)],
        "traffic",
    ))
    sections.append("<h2>API / RBAC assertions (this run/attempt)</h2>")
    sections.append(table(
        ("#", "Result", "Test", "Validates", "Expected / actual HTTP", "Credential scope",
         "Started (UTC)", "Duration ms"),
        [(index, "PASS" if r["passed"] else "FAIL", r["case"], api_purpose(r),
          f'{r["expected_status"]} / {r["status"]}', r["credential_kind"],
          timestamp(r.get("started_epoch")), r.get("elapsed_ms", ""))
         for index, r in enumerate(apis, 1)],
    ))
    style = """
body{font:15px system-ui,sans-serif;margin:2rem;color:#17212b;background:#f8fafc}
h1,h2{color:#143c57}table{border-collapse:collapse;background:white;width:100%}
th,td{border:1px solid #cbd5e1;padding:.5rem;text-align:left;vertical-align:top}
th{background:#e2e8f0;position:sticky;top:0}td{overflow-wrap:anywhere;white-space:pre-wrap}
.scroll{overflow:auto;max-height:70vh;margin-bottom:1.5rem}p{max-width:1100px}
@media print{.scroll{max-height:none;overflow:visible}th{position:static}body{margin:0}}
"""
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; '
            'style-src \'unsafe-inline\'">'
            f"<title>SwiftFabric acceptance {html.escape(evidence['run_id'])}</title>"
            f"<style>{style}</style></head><body>{''.join(sections)}</body></html>")


def write_report(directory, evidence, results, api_results, write):
    safe_results = [enrich_traffic(result, evidence["vms"]) for result in results]
    safe_api = [select(result, API_FIELDS)
                for result in api_results[evidence["api_start_index"]:]]
    write(directory / "evidence.json", evidence)
    write(directory / "report-data.json", {
        "evidence": evidence, "traffic": safe_results, "api": safe_api,
    })
    write(directory / "report.html", render(evidence, safe_results, safe_api))


def regenerate(directory, write):
    data = json.loads((directory / "report-data.json").read_text())
    write(directory / "report.html", render(data["evidence"], data["traffic"], data["api"]))
    return directory / "report.html"
