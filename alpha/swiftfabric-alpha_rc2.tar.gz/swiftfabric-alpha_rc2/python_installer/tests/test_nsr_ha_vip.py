import contextlib
import copy
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tests_integration"))
import nsr_ha_vip as vip
from test_nsr_ha import cases, guest, observation, router


class FakeGuard:
    def __init__(self):
        self.faults = []
        self.returning = None
        self.rejoin = True

    @contextlib.contextmanager
    def controller_fault(self, name):
        self.faults.append(name)
        try:
            yield self
        finally:
            self.returning = name

    def healthy(self):
        if self.rejoin:
            self.returning = None


class VipGateTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.current = {**router(), "upgrade_in_progress": False}
        self.observation = observation()
        self.controllers = [
            {"node": "n1", "vmid": 110 + index,
             "name": f"sf-dr-{'a' * 20}-swiftfabric-controller-{index}",
             "configuration": {"owned": index}}
            for index in range(3)
        ]
        self.power = {controller["vmid"]: "running" for controller in self.controllers}
        self.posts = []
        self.clock = 0
        self.foreign = False
        self.owner = 0
        self.run = SimpleNamespace(
            directory=self.root,
            config={"ip_range_start": "192.0.2.2"},
            state={"prefix": "sf-dr-" + "a" * 20, "pair": vip.ha.pair_identity(self.current),
                   "controllers": self.controllers, "held_flow_cases": cases(),
                   "router_requested": self.current["id"]},
            lab=SimpleNamespace(state={"vms": [{}]}),
            router=mock.Mock(side_effect=lambda: copy.deepcopy(self.current)),
            wait_converged=mock.Mock(return_value=("a", 3)),
            pair_status=mock.Mock(side_effect=lambda: copy.deepcopy(self.observation)),
            start_probes=mock.Mock(),
            stop_probes=mock.Mock(return_value={"stopped_or_collected": True}),
        )
        self.run.platform_health = FakeGuard()
        self.run.require_platform_healthy = mock.Mock(side_effect=self.run.platform_health.healthy)
        self.response = mock.Mock(ok=True, status_code=200)
        self.response.json.side_effect = lambda: copy.deepcopy(self.current)
        self.run.api = SimpleNamespace(
            base_url="https://192.0.2.5/api/v1",
            ssh=SimpleNamespace(run=mock.Mock(side_effect=lambda address, *_: json.dumps([
                {"addr_info": [{"local": "192.0.2.5" if address == f"192.0.2.{2 + self.owner}"
                               else address}]},
            ]))),
            session=SimpleNamespace(get=mock.Mock(return_value=self.response)),
        )

        def get(path):
            vmid = int(path.split("/")[4])
            controller = next(c for c in self.controllers if c["vmid"] == vmid)
            if path.endswith("/config"):
                return {"data": {"name": "foreign" if self.foreign else controller["name"],
                                 "owned": controller["configuration"]["owned"]}}
            return {"data": {"status": self.power[vmid]}}

        def post(path):
            self.posts.append(path)
            vmid = int(path.split("/")[4])
            self.power[vmid] = "stopped" if path.endswith("/stop") else "running"
            return {"data": "task"}

        self.run.proxmox = SimpleNamespace(get=mock.Mock(side_effect=get), post=mock.Mock(side_effect=post))

        def probe_status(*_):
            if not self.posts:
                return {"progress": {p: {"verified_responses": 8} for p in ("tcp", "udp")}}
            matrix = self.run.start_probes.call_args.args[1]
            results = []
            for case in matrix:
                samples = [
                    {"sequence": i - 1, "sent_seconds": i - 0.1, "received_seconds": i,
                     "peer": [case["expected_nat_address"], 44000]}
                    for i in range(1, 120)
                ]
                results.append({**guest.held_summary(case, samples, 120, ""),
                                "connected": True, "requests": len(samples),
                                "started_epoch": 1000, "started_monotonic": 100,
                                "application_bytes_sent": 1000, "application_bytes_received": 1000})
            return {"completed": True, "results": results}

        self.run.probe_status = mock.Mock(side_effect=probe_status)
        patches = [
            mock.patch.object(vip.ha.deployment, "controller_inventory", return_value=self.controllers),
            mock.patch.object(vip.ha.deployment, "controller_configuration",
                              side_effect=lambda configuration: {"owned": configuration["owned"]}),
            mock.patch.object(vip.ha.deployment, "wait_task"),
            mock.patch.object(vip.time, "monotonic", side_effect=lambda: self.clock),
            mock.patch.object(vip.time, "sleep", side_effect=self.sleep),
            mock.patch("builtins.print"),
        ]
        for patch in patches:
            patch.start()
            self.addCleanup(patch.stop)

    def sleep(self, seconds):
        self.clock += seconds

    def report(self):
        return json.loads(next(self.root.glob("vip-controller-*-report.json")).read_text())

    def assert_restored_and_cleaned(self):
        self.assertEqual(self.power[110], "running")
        self.assertEqual(len([p for p in self.posts if p.endswith("/stop")]), 1)
        self.assertEqual(len([p for p in self.posts if p.endswith("/start")]), 1)
        self.run.stop_probes.assert_called_once()

    def test_pass_requires_owned_controller_return_original_sessions_and_cleanup(self):
        report = vip.run_gate(self.run)
        self.assertTrue(report["passed"])
        self.assertEqual(len(report["api_samples"]), 45)
        self.assertTrue(report["stopped_controller_restored"])
        self.assertTrue(report["probe_cleanup"]["stopped_or_collected"])
        self.assert_restored_and_cleaned()
        self.assertTrue(self.report()["passed"])
        self.assertEqual(next(self.root.glob("*report.json")).stat().st_mode & 0o777, 0o600)
        self.assertTrue(all("/qemu/110/" in p for p in self.posts))
        self.assertEqual(self.response.close.call_count, 45)
        self.assertEqual(self.run.platform_health.faults, [self.controllers[0]["name"]])
        self.assertTrue(report["restored_controller_rejoined"])

    def test_restored_controller_that_never_rejoins_fails_gate(self):
        self.run.platform_health.rejoin = False
        with self.assertRaisesRegex(RuntimeError, "did not rejoin"):
            vip.run_gate(self.run)
        self.assert_restored_and_cleaned()
        self.assertTrue(self.report()["stopped_controller_restored"])
        self.assertNotIn("restored_controller_rejoined", self.report())
        self.assertFalse(self.report()["passed"])

    def test_platform_failure_immediately_restores_controller_and_stops_measurement(self):
        self.run.require_platform_healthy.side_effect = RuntimeError("platform unhealthy: controller offline")
        with self.assertRaisesRegex(RuntimeError, "platform unhealthy"):
            vip.run_gate(self.run)
        self.assert_restored_and_cleaned()
        self.run.api.session.get.assert_not_called()
        self.assertFalse(self.report()["passed"])
        self.assertTrue(self.report()["stopped_controller_restored"])

    def test_foreign_or_multiple_vip_owners_refuse_before_probes_and_power(self):
        self.foreign = True
        with self.assertRaisesRegex(RuntimeError, "ownership changed"):
            vip.run_gate(self.run)
        self.assertFalse(self.posts)
        self.run.start_probes.assert_not_called()
        self.foreign = False
        self.run.api.ssh.run.side_effect = lambda *_: '[{"addr_info":[{"local":"192.0.2.5"}]}]'
        with self.assertRaisesRegex(RuntimeError, "single owned"):
            vip.run_gate(self.run)
        self.assertFalse(self.posts)

    def test_unconverged_pair_cannot_authorize_fault(self):
        broken = []
        for field, value in (("healthy", False), ("split_brain", True), ("active_member", "b")):
            broken.append({**observation(), field: value})
        stale = observation()
        stale["b"]["status"]["peer_heard"] = False
        broken.append(stale)
        for value in broken:
            self.observation = value
            with self.subTest(value=value), self.assertRaises(RuntimeError):
                vip.run_gate(self.run)
            self.assertFalse(self.posts)
            self.run.start_probes.assert_not_called()

    def test_post_traffic_unconverged_pair_cannot_leave_successful_report(self):
        calls = 0

        def status():
            nonlocal calls
            calls += 1
            return observation(healthy=calls < 3)

        self.run.pair_status.side_effect = status
        with self.assertRaisesRegex(RuntimeError, "not converged"):
            vip.run_gate(self.run)
        self.assert_restored_and_cleaned()
        self.assertFalse(self.report()["passed"])

    def test_restored_controller_requires_same_owner_and_term(self):
        self.run.wait_converged.side_effect = [("a", 3), RuntimeError("pair converged on member b term 4")]
        with self.assertRaisesRegex(RuntimeError, "member b term 4"):
            vip.run_gate(self.run)
        self.assertEqual(self.run.wait_converged.call_args_list[-1], mock.call("a", term=3))
        self.assert_restored_and_cleaned()
        self.assertFalse(self.report()["passed"])

    def test_unknown_api_outage_restores_controller_and_keeps_failed_report(self):
        self.run.api.session.get.side_effect = vip.ha.deployment.requests.ConnectionError("test")
        with self.assertRaisesRegex(RuntimeError, "API VIP did not recover"):
            vip.run_gate(self.run)
        self.assert_restored_and_cleaned()
        self.assertFalse(self.report()["passed"])
        self.assertEqual(self.report()["api_samples"][0]["error"], "ConnectionError")

    def test_changed_router_identity_restores_controller_without_certification(self):
        self.response.json.side_effect = lambda: {**self.current, "active_member": "b"}
        with self.assertRaisesRegex(RuntimeError, "changed NSR ownership"):
            vip.run_gate(self.run)
        self.assert_restored_and_cleaned()
        self.assertFalse(self.report()["passed"])

    def test_ambiguous_stop_task_failure_still_restores_exact_controller(self):
        original = self.run.proxmox.post.side_effect

        def post(path):
            response = original(path)
            if path.endswith("/stop"):
                raise RuntimeError("ambiguous task response")
            return response

        self.run.proxmox.post.side_effect = post
        with self.assertRaisesRegex(RuntimeError, "ambiguous task response"):
            vip.run_gate(self.run)
        self.assert_restored_and_cleaned()
        self.assertFalse(self.report()["passed"])

    def test_cleanup_failure_cannot_leave_successful_report(self):
        self.run.stop_probes.side_effect = RuntimeError("probe cleanup failed")
        with self.assertRaisesRegex(RuntimeError, "probe cleanup failed"):
            vip.run_gate(self.run)
        self.assertTrue(self.report()["traffic_passed"])
        self.assertFalse(self.report()["passed"])
        self.assertEqual(self.power[110], "running")

    def test_stale_original_results_fail_exact_matrix_and_restore(self):
        original = self.run.probe_status.side_effect

        def status(*args):
            value = original(*args)
            if value.get("completed"):
                value["results"][0]["source_port"] += 1
            return value

        self.run.probe_status.side_effect = status
        with self.assertRaisesRegex(ValueError, "held-flow identity"):
            vip.run_gate(self.run)
        self.assert_restored_and_cleaned()
        self.assertFalse(self.report()["passed"])


if __name__ == "__main__":
    unittest.main()
