import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from deployment.api_service import ApiServiceDeployment
from deployment.ssh import SSHCommandRunner, SSHHostKeyError


class BuildboxCopyTests(unittest.TestCase):
    def test_remote_source_manifest_contains_every_rust_source(self):
        source = Path(__file__).resolve().parents[2] / "controller-api" / "segment-manager"
        destinations = {destination for _, destination in ApiServiceDeployment._source_files(source)}
        expected = {
            f"segment-manager/{path.relative_to(source)}" for path in (source / "src").rglob("*.rs")
        }
        self.assertTrue(expected)
        self.assertTrue(expected.issubset(destinations))

    def setUp(self):
        self.deployment = ApiServiceDeployment(private_key="")
        self.buildbox = {
            "buildbox_ip": "192.0.2.10",
            "buildbox_username": "builder",
            "buildbox_key": "/tmp/buildbox-key",
        }

    def test_scp_uses_build_runner_pin_for_each_package(self):
        for package in ("swiftfabric-api-service_1_amd64.deb",
                        "swiftfabric-host-agent_1_all.deb"):
            with self.subTest(package=package), tempfile.TemporaryDirectory() as directory:
                runner = SSHCommandRunner(
                    self.buildbox["buildbox_key"], "builder", "build",
                    known_hosts_file=str(Path(directory) / "known_hosts"),
                )
                remote = f"/tmp/artifacts/{package}"
                destination = Path(directory) / package
                with (
                    mock.patch.object(runner, "ensure_host_key") as ensure,
                    mock.patch("deployment.api_service.subprocess.run") as scp,
                ):
                    scp.return_value = mock.Mock(returncode=0)
                    self.deployment._copy_from_buildbox(
                        remote, destination, self.buildbox, runner,
                    )
                ensure.assert_called_once_with(self.buildbox["buildbox_ip"])
                command = scp.call_args.args[0]
                self.assertIn(f"UserKnownHostsFile={runner.known_hosts_file}", command)
                self.assertIn("StrictHostKeyChecking=yes", command)
                self.assertIn("BatchMode=yes", command)
                self.assertNotIn("GlobalKnownHostsFile=/dev/null", command)
                self.assertEqual(command[-2:], [f"builder@192.0.2.10:{remote}", str(destination)])

    def test_untrusted_key_stops_before_scp(self):
        runner = mock.Mock()
        runner.ensure_host_key.side_effect = SSHHostKeyError("no interactive terminal")
        with tempfile.TemporaryDirectory() as directory, mock.patch(
            "deployment.api_service.subprocess.run"
        ) as scp:
            destination = Path(directory) / "package.deb"
            with self.assertRaisesRegex(SSHHostKeyError, "no interactive terminal"):
                self.deployment._copy_from_buildbox(
                    "/tmp/package.deb", destination, self.buildbox, runner,
                )
            scp.assert_not_called()
            self.assertFalse(destination.exists())

    def test_first_use_approval_persists_key_before_scp(self):
        key = "192.0.2.10 ssh-ed25519 c3ludGhldGljLWhvc3Qta2V5"
        with tempfile.TemporaryDirectory() as directory:
            known_hosts = Path(directory) / "known_hosts"
            runner = SSHCommandRunner(
                self.buildbox["buildbox_key"], "builder", "build",
                known_hosts_file=str(known_hosts),
            )

            def copy_after_approval(command, **kwargs):
                self.assertEqual(known_hosts.read_text(), key + "\n")
                return mock.Mock(returncode=0)

            with (
                mock.patch.dict(os.environ, {"SWIFTFABRIC_INTEGRATION_TOFU": "0"}),
                mock.patch.object(runner, "_host_is_pinned", return_value=False),
                mock.patch.object(runner, "_scan_host_keys", return_value=[key]),
                mock.patch("deployment.ssh.sys.stdin.isatty", return_value=True),
                mock.patch("builtins.input", return_value="yes") as prompt,
                mock.patch("deployment.api_service.subprocess.run", side_effect=copy_after_approval),
            ):
                self.deployment._copy_from_buildbox(
                    "/tmp/package.deb", Path(directory) / "package.deb",
                    self.buildbox, runner,
                )
            prompt.assert_called_once()

    def test_integration_store_options_match_ssh_runner(self):
        runner = mock.Mock()
        runner.known_hosts_file = Path("/tmp/integration-known-hosts")
        with (
            tempfile.TemporaryDirectory() as directory,
            mock.patch.dict(os.environ, {
                "SWIFTFABRIC_INTEGRATION_TOFU": "1",
                "SWIFTFABRIC_INTEGRATION_KNOWN_HOSTS": str(runner.known_hosts_file),
            }),
            mock.patch("deployment.api_service.subprocess.run") as scp,
        ):
            scp.return_value = mock.Mock(returncode=0)
            self.deployment._copy_from_buildbox(
                "/tmp/package.deb", Path(directory) / "package.deb",
                self.buildbox, runner,
            )
            command = scp.call_args.args[0]
            self.assertIn(f"UserKnownHostsFile={runner.known_hosts_file}", command)
            self.assertIn("GlobalKnownHostsFile=/dev/null", command)
            self.assertIn("StrictHostKeyChecking=yes", command)

    def test_mismatched_host_key_surfaces_scp_error(self):
        runner = mock.Mock()
        runner.known_hosts_file = Path("/tmp/known_hosts")
        with tempfile.TemporaryDirectory() as directory, mock.patch(
            "deployment.api_service.subprocess.run",
            return_value=mock.Mock(
                returncode=255, stdout="", stderr="REMOTE HOST IDENTIFICATION HAS CHANGED",
            ),
        ):
            destination = Path(directory) / "package.deb"
            with self.assertRaisesRegex(RuntimeError, "IDENTIFICATION HAS CHANGED"):
                self.deployment._copy_from_buildbox(
                    "/tmp/package.deb", destination, self.buildbox, runner,
                )
            self.assertFalse(destination.exists())


if __name__ == "__main__":
    unittest.main()
