import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch
import xml.etree.ElementTree as ET

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tests_integration"))
import platform_health as health


NODES = {"controller-0", "controller-1", "controller-2"}


def snapshot():
    root = ET.Element("pacemaker-result")
    summary = ET.SubElement(root, "summary")
    ET.SubElement(summary, "current_dc", present="true", with_quorum="true")
    ET.SubElement(summary, "cluster_options", attrib={
        "maintenance-mode": "false", "stop-all-resources": "false",
    })
    nodes = ET.SubElement(root, "nodes")
    for name in sorted(NODES):
        ET.SubElement(nodes, "node", name=name, online="true", health="green",
                      standby="false", standby_onfail="false", maintenance="false",
                      pending="false", unclean="false", shutdown="false")
    resources = ET.SubElement(root, "resources")
    clone = ET.SubElement(resources, "clone", id="swiftfabric-valkey-4999-clone",
                          multi_state="true", managed="true")
    for index, name in enumerate(sorted(NODES)):
        resource = ET.SubElement(clone, "resource", id="swiftfabric-valkey-4999",
                                 resource_agent="ocf:swiftfabric:valkey-segment",
                                 role="Promoted" if index == 0 else "Unpromoted",
                                 active="true", nodes_running_on="1", managed="true")
        ET.SubElement(resource, "node", name=name)
    return {
        "node": "controller-0", "monitor": ET.tostring(root, encoding="unicode"),
        "clone_limits": {"swiftfabric-valkey-4999-clone": {"clone-max": "3", "promoted-max": "1"}},
        "resource_ids": ["swiftfabric-valkey-4999"],
        "corosync": "Nodes: 3\nQuorate: Yes\nTotal votes: 3\n",
        "replication": {"4999": {"role": "master", "connected_slaves": "2",
                               "slave0": "ip=192.0.2.2,port=4999,state=online,offset=1,lag=0,type=replica",
                               "slave1": "ip=192.0.2.3,port=4999,state=online,offset=1,lag=0,type=replica"}},
    }


def with_new_segment(value, sync="1", failed="false", fail_count=None):
    root = ET.fromstring(value["monitor"])
    clone = ET.SubElement(root.find("./resources"), "clone", id="swiftfabric-valkey-49100-clone",
                          multi_state="true", managed="true")
    for index, name in enumerate(sorted(NODES)):
        resource = ET.SubElement(clone, "resource", id="swiftfabric-valkey-49100",
                                 resource_agent="ocf:swiftfabric:valkey-segment",
                                 role="Unpromoted" if index else "Promoted",
                                 active="true", nodes_running_on="1", managed="true", failed=failed)
        ET.SubElement(resource, "node", name=name)
    if fail_count is not None:
        ET.SubElement(root, "resource_history", attrib={"fail-count": fail_count})
    value["monitor"] = ET.tostring(root, encoding="unicode")
    value["clone_limits"]["swiftfabric-valkey-49100-clone"] = {"clone-max": "3", "promoted-max": "1"}
    value["resource_ids"].append("swiftfabric-valkey-49100")
    value["replication"]["49100"] = {"role": "master", "connected_slaves": "2",
                                     "slave0": "ip=192.0.2.2,port=49100,state=online,offset=1,lag=0,type=replica",
                                     "slave1": "ip=192.0.2.3,port=49100,state=" +
                                     ("wait_bgsave" if sync == "1" else "online") + ",offset=0,lag=0,type=replica"}
    return value


class ConvergenceTests(unittest.TestCase):
    def guard(self, directory):
        run = Mock(directory=Path(directory))
        run.state = {"controllers": [{"name": name} for name in sorted(NODES)]}
        run.config = {"ip_range_start": "192.0.2.2"}
        return health.PlatformHealth(run)

    def snapshots(self, new=False, sync="1", **extra):
        receipts = []
        for name in sorted(NODES):
            value = snapshot()
            value["node"] = name
            if name != "controller-0":
                value["replication"]["4999"] = {"role": "slave", "master_link_status": "up",
                                                "master_sync_in_progress": "0"}
            if new:
                with_new_segment(value, sync, **extra)
                if name != "controller-0":
                    value["replication"]["49100"] = {"role": "slave", "master_link_status": "up",
                                                     "master_sync_in_progress": sync}
            receipts.append(value)
        return receipts

    def test_new_port_syncing_needs_explicit_grace(self):
        value = with_new_segment(snapshot())
        with self.assertRaisesRegex(RuntimeError, "lacks online replicas: 49100"):
            health.validate(value, NODES)
        receipt = health.validate(with_new_segment(snapshot()), NODES, frozenset({"49100"}))
        self.assertFalse(receipt["healthy"])
        self.assertEqual(receipt["converging"], ["49100"])
        settled = health.validate(with_new_segment(snapshot(), sync="0"), NODES, frozenset({"49100"}))
        self.assertTrue(settled["healthy"])
        self.assertEqual(settled["converging"], [])

    def test_grace_never_hides_failures_or_other_ports(self):
        for extra in ({"failed": "true"}, {"fail_count": "1"}):
            with self.subTest(extra=extra), self.assertRaisesRegex(RuntimeError, "platform unhealthy"):
                health.validate(with_new_segment(snapshot(), **extra), NODES, frozenset({"49100"}))
        value = with_new_segment(snapshot())
        value["replication"]["4999"]["connected_slaves"] = "1"
        with self.assertRaisesRegex(RuntimeError, "lacks online replicas: 4999"):
            health.validate(value, NODES, frozenset({"49100"}))
        value = with_new_segment(snapshot())
        root = ET.fromstring(value["monitor"])
        root.findall(".//clone")[1].findall("resource")[1].find("node").set("name", "controller-0")
        value["monitor"] = ET.tostring(root, encoding="unicode")
        with self.assertRaisesRegex(RuntimeError, "share a controller"):
            health.validate(value, NODES, frozenset({"49100"}))

    def test_cluster_restart_replica_sync_is_expected_until_settled(self):
        with tempfile.TemporaryDirectory() as directory:
            clock = [1000.0]
            run = Mock(directory=Path(directory))
            run.state = {"controllers": [{"name": name} for name in sorted(NODES)]}
            run.config = {"ip_range_start": "192.0.2.2"}
            with patch.object(health.time, "time", side_effect=lambda: clock[0]):
                guard = health.PlatformHealth(run, recovering_cluster=True)
                receipts = self.snapshots()
                receipts[0]["replication"]["4999"]["connected_slaves"] = "1"
                with patch.object(guard, "collect", return_value=receipts):
                    guard.capture()
                self.assertEqual(guard.converging, {"4999"})
                self.assertEqual(guard.report["expected_recovery"]["last_converging"], ["4999"])
                self.assertTrue(guard.report["latest"]["fault_window_relaxed"])
                with patch.object(guard, "collect", return_value=self.snapshots()):
                    guard.capture()
                self.assertIsNone(guard.cluster_recovery_deadline)
                self.assertEqual(guard.report["expected_recovery"]["settled_epoch"], clock[0])
                with patch.object(guard, "collect", return_value=receipts):
                    with self.assertRaisesRegex(RuntimeError, "lacks online replicas: 4999"):
                        guard.capture()

    def test_cluster_restart_grace_expires_and_never_hides_failed_operations(self):
        with tempfile.TemporaryDirectory() as directory:
            clock = [1000.0]
            run = Mock(directory=Path(directory))
            run.state = {"controllers": [{"name": name} for name in sorted(NODES)]}
            with patch.object(health.time, "time", side_effect=lambda: clock[0]):
                guard = health.PlatformHealth(run, recovering_cluster=True)
                receipts = self.snapshots()
                receipts[0]["replication"]["4999"]["connected_slaves"] = "1"
                clock[0] += health.RECOVERY_SECONDS + 1
                with patch.object(guard, "collect", return_value=receipts):
                    with self.assertRaisesRegex(RuntimeError, "lacks online replicas: 4999"):
                        guard.capture()
                clock[0] = 1000.0
                root = ET.fromstring(receipts[0]["monitor"])
                root.find(".//resource").set("failed", "true")
                receipts[0]["monitor"] = ET.tostring(root, encoding="unicode")
                with patch.object(guard, "collect", return_value=receipts):
                    with self.assertRaisesRegex(RuntimeError, "failed or unmanaged"):
                        guard.capture()

    def test_disabled_creation_phase_only_for_new_port(self):
        value = with_new_segment(snapshot())
        root = ET.fromstring(value["monitor"])
        clone = root.findall(".//clone")[1]
        clone.set("disabled", "true")
        for resource in clone.findall("resource"):
            resource.set("role", "Stopped")
            resource.set("active", "false")
            resource.set("nodes_running_on", "0")
            resource.remove(resource.find("node"))
        value["monitor"] = ET.tostring(root, encoding="unicode")
        del value["replication"]["49100"]
        with self.assertRaisesRegex(RuntimeError, "disabled: swiftfabric-valkey-49100-clone"):
            health.validate(value, NODES)
        self.assertEqual(health.validate(value, NODES, frozenset({"49100"}))["converging"], ["49100"])
        value = snapshot()
        root = ET.fromstring(value["monitor"])
        root.find(".//clone").set("disabled", "true")
        value["monitor"] = ET.tostring(root, encoding="unicode")
        with self.assertRaisesRegex(RuntimeError, "disabled: swiftfabric-valkey-4999-clone"):
            health.validate(value, NODES, frozenset({"49100"}))

    def test_admission_is_strict_for_already_present_ports(self):
        with tempfile.TemporaryDirectory() as directory:
            guard = self.guard(directory)
            with patch.object(guard, "collect", return_value=self.snapshots(new=True)), \
                    self.assertRaisesRegex(RuntimeError, "49100"):
                guard.capture()

    def test_port_created_after_admission_converges_once_within_bound(self):
        with tempfile.TemporaryDirectory() as directory:
            guard = self.guard(directory)
            clock = [1000.0]
            with patch.object(health.time, "time", side_effect=lambda: clock[0]), \
                    patch.object(guard, "collect") as collect:
                collect.return_value = self.snapshots()
                guard.capture()
                collect.return_value = self.snapshots(new=True)
                guard.capture()
                self.assertEqual(guard.converging, {"49100"})
                clock[0] += health.CONVERGENCE_SECONDS
                guard.capture()
                collect.return_value = self.snapshots(new=True, sync="0")
                guard.capture()
                self.assertEqual(guard.converging, set())
                self.assertIn("49100", guard.settled_ports)
                collect.return_value = self.snapshots(new=True)
                with self.assertRaisesRegex(RuntimeError, "49100"):
                    guard.capture()

    def stopping(self, orphaned=False):
        receipts = self.snapshots(new=True, sync="0")
        for value in receipts:
            root = ET.fromstring(value["monitor"])
            for resource in root.iter("resource"):
                if resource.get("id") == "swiftfabric-valkey-49100":
                    resource.set("active", "false")
                    resource.set("role", "Stopped")
                    resource.set("nodes_running_on", "0")
                    resource.set("orphaned", "true" if orphaned else "false")
                    for node in resource.findall("node"):
                        resource.remove(node)
            value["monitor"] = ET.tostring(root, encoding="unicode")
            value["replication"].pop("49100")
            if orphaned:
                value["resource_ids"].remove("swiftfabric-valkey-49100")
                del value["clone_limits"]["swiftfabric-valkey-49100-clone"]
        return receipts

    def test_declared_retiring_port_may_stop_orphan_and_be_recreated(self):
        with tempfile.TemporaryDirectory() as directory:
            guard = self.guard(directory)
            clock = [1000.0]
            with patch.object(health.time, "time", side_effect=lambda: clock[0]), \
                    patch.object(guard, "collect") as collect:
                collect.return_value = self.snapshots()
                guard.capture()
                collect.return_value = self.snapshots(new=True, sync="0")
                guard.capture()
                self.assertIn("49100", guard.settled_ports)
                collect.return_value = self.stopping()
                with self.assertRaisesRegex(RuntimeError, "49100"):
                    guard.capture()
                with guard.retiring({49100}):
                    guard.capture()
                    collect.return_value = self.stopping(orphaned=True)
                    guard.capture()
                    collect.return_value = self.snapshots()
                    guard.capture()
                self.assertNotIn("49100", guard.settled_ports)
                clock[0] += health.CONVERGENCE_SECONDS + 1
                collect.return_value = self.snapshots(new=True)
                guard.capture()
                self.assertEqual(guard.converging, {"49100"})

    def test_retiring_never_hides_failed_operations_or_other_ports(self):
        with tempfile.TemporaryDirectory() as directory:
            guard = self.guard(directory)
            with patch.object(guard, "collect") as collect:
                collect.return_value = self.snapshots()
                guard.capture()
                with guard.retiring({49100}):
                    collect.return_value = self.snapshots(new=True, sync="0", fail_count="1")
                    with self.assertRaisesRegex(RuntimeError, "failure counters"):
                        guard.capture()
                    value = self.snapshots()
                    value[0]["replication"]["4999"]["connected_slaves"] = "1"
                    collect.return_value = value
                    with self.assertRaises(RuntimeError):
                        guard.capture()

    def test_new_port_that_never_converges_fails_after_bound(self):
        with tempfile.TemporaryDirectory() as directory:
            guard = self.guard(directory)
            clock = [1000.0]
            with patch.object(health.time, "time", side_effect=lambda: clock[0]), \
                    patch.object(guard, "collect") as collect:
                collect.return_value = self.snapshots()
                guard.capture()
                collect.return_value = self.snapshots(new=True)
                guard.capture()
                clock[0] += health.CONVERGENCE_SECONDS + 1
                with self.assertRaisesRegex(RuntimeError, "49100"):
                    guard.capture()

    def test_exit_waits_for_convergence_before_pass(self):
        with tempfile.TemporaryDirectory() as directory:
            guard = self.guard(directory)
            guard.stop.wait = Mock(return_value=True)
            replies = [self.snapshots(), self.snapshots(new=True), self.snapshots(new=True, sync="0")]
            with patch.object(guard, "collect", side_effect=replies), \
                    patch.object(health.time, "sleep") as sleep:
                with guard:
                    pass
            sleep.assert_called_once_with(3)
            report = json.loads(guard.output.read_text())
            self.assertTrue(report["passed"])
            self.assertEqual(report["latest"]["converging"], [])


    def test_close_gives_final_verdict_once_and_stops_monitoring_before_teardown(self):
        with tempfile.TemporaryDirectory() as directory:
            guard = self.guard(directory)
            guard.stop.wait = Mock(return_value=True)
            with patch.object(guard, "collect", side_effect=[self.snapshots(), self.snapshots()]) as collect:
                with guard:
                    guard.close()
                    self.assertTrue(guard.stop.is_set())
                    self.assertTrue(json.loads(guard.output.read_text())["passed"])
                    collect.side_effect = OSError("controllers destroyed")
            self.assertEqual(collect.call_count, 2)
            self.assertTrue(json.loads(guard.output.read_text())["passed"])


class PlatformHealthTests(unittest.TestCase):
    def test_healthy_full_cluster_and_replica_are_accepted(self):
        value = snapshot()
        self.assertTrue(health.validate(value, NODES)["healthy"])
        value["node"] = "controller-1"
        value["replication"]["4999"] = {
            "role": "slave", "master_host": "192.0.2.1",
            "master_link_status": "up", "master_sync_in_progress": "0",
        }
        self.assertTrue(health.validate(value, NODES)["healthy"])

    def test_stopped_replica_rejected_even_when_failed_flag_is_false(self):
        value = snapshot()
        root = ET.fromstring(value["monitor"])
        resource = root.findall(".//resource")[1]
        resource.set("role", "Stopped")
        resource.set("active", "false")
        resource.set("failed", "false")
        resource.set("nodes_running_on", "0")
        resource.remove(resource.find("node"))
        value["monitor"] = ET.tostring(root, encoding="unicode")
        with self.assertRaisesRegex(RuntimeError, "resource stopped"):
            health.validate(value, NODES)

    def test_all_unhealthy_nodes_and_resource_flags_fail_closed(self):
        for path, key, bad in (
            ("./summary/current_dc", "with_quorum", "false"),
            ("./summary/cluster_options", "maintenance-mode", "true"),
            ("./nodes/node", "online", "false"),
            ("./nodes/node", "health", "red"),
            ("./nodes/node", "standby", "true"),
            ("./nodes/node", "unclean", "true"),
            (".//clone", "disabled", "true"),
            (".//resource", "failed", "true"),
            (".//resource", "failure_ignored", "true"),
            (".//resource", "blocked", "true"),
            (".//resource", "managed", "false"),
        ):
            with self.subTest(path=path, key=key):
                value = snapshot()
                root = ET.fromstring(value["monitor"])
                root.find(path).set(key, bad)
                value["monitor"] = ET.tostring(root, encoding="unicode")
                with self.assertRaisesRegex(RuntimeError, "platform unhealthy"):
                    health.validate(value, NODES)

    def test_failed_operations_counters_missing_clone_and_wrong_primary_fail(self):
        for failure in ("operation", "counter", "missing", "promotion", "duplicate-node"):
            with self.subTest(failure=failure):
                value = snapshot()
                root = ET.fromstring(value["monitor"])
                if failure == "operation":
                    ET.SubElement(root, "failure", op_key="swiftfabric-valkey-4999_start_0")
                elif failure == "counter":
                    ET.SubElement(root, "resource_history", attrib={"fail-count": "INFINITY"})
                elif failure == "missing":
                    root.find(".//clone").remove(root.findall(".//resource")[1])
                elif failure == "promotion":
                    root.findall(".//resource")[1].set("role", "Promoted")
                else:
                    root.findall(".//resource")[1].find("node").set("name", "controller-0")
                value["monitor"] = ET.tostring(root, encoding="unicode")
                with self.assertRaisesRegex(RuntimeError, "platform unhealthy"):
                    health.validate(value, NODES)

    def test_corosync_replication_and_missing_receipts_fail(self):
        for field, replacement in (
            ("corosync", "Nodes: 2\nQuorate: Yes\nTotal votes: 2"),
            ("clone_limits", {}),
            ("resource_ids", ["swiftfabric-valkey-4999", "missing-api-vip"]),
            ("replication", {}),
            ("replication", {"4999": {"role": "master", "connected_slaves": "1"}}),
            ("replication", {"4999": {"role": "slave", "master_link_status": "down",
                                     "master_sync_in_progress": "0"}}),
            ("replication", {"4999": {"role": "slave", "master_link_status": "up",
                                     "master_sync_in_progress": "1"}}),
            ("replication", {"4999": {"unavailable": "1"}}),
        ):
            with self.subTest(field=field, replacement=replacement):
                value = snapshot()
                value[field] = replacement
                with self.assertRaisesRegex(RuntimeError, "platform unhealthy"):
                    health.validate(value, NODES)
        with self.assertRaisesRegex(RuntimeError, "malformed"):
            health.validate({}, NODES)

    def test_monitor_latches_first_failure_and_records_it(self):
        with tempfile.TemporaryDirectory() as directory:
            guard = health.PlatformHealth(Mock(directory=Path(directory)))
            guard.stop.wait = Mock(return_value=False)
            with patch.object(guard, "capture", side_effect=RuntimeError("stopped replica")), \
                    patch("builtins.print"):
                guard.monitor()
            with self.assertRaisesRegex(RuntimeError, "stopped replica"):
                guard.check()
            with patch.object(guard, "capture"):
                with self.assertRaisesRegex(RuntimeError, "stopped replica"):
                    guard.check()
            report = json.loads(guard.output.read_text())
            self.assertFalse(report["passed"])
            self.assertIn("stopped replica", report["error"])
            self.assertEqual(guard.output.stat().st_mode & 0o777, 0o600)

    def test_initial_failure_never_starts_monitor_or_allows_body(self):
        with tempfile.TemporaryDirectory() as directory:
            guard = health.PlatformHealth(Mock(directory=Path(directory)))
            body = Mock()
            with patch.object(guard, "capture", side_effect=RuntimeError("not healthy")), \
                    self.assertRaisesRegex(RuntimeError, "not healthy"):
                with guard:
                    body()
            body.assert_not_called()
            self.assertIsNone(guard.thread)

    def test_final_health_failure_prevents_pass_and_thread_is_joined(self):
        with tempfile.TemporaryDirectory() as directory:
            guard = health.PlatformHealth(Mock(directory=Path(directory)))
            with patch.object(guard, "capture", side_effect=[None, RuntimeError("failed after action")]), \
                    self.assertRaisesRegex(RuntimeError, "failed after action"):
                with guard:
                    pass
            self.assertFalse(guard.thread.is_alive())
            report = json.loads(guard.output.read_text())
            self.assertFalse(report["passed"])
            self.assertIn("failed after action", report["error"])

    def test_remote_collector_never_exports_password_or_full_cib(self):
        self.assertNotIn('"cib":', health.COLLECT)
        self.assertNotIn('"password":', health.COLLECT)
        self.assertIn('env={**os.environ,"VALKEYCLI_AUTH":password}', health.COLLECT)

    def test_latched_failure_blocks_measurements_but_not_owned_probe_cleanup(self):
        import nsr_ha as ha
        run = ha.HARun.__new__(ha.HARun)
        run.platform_health = Mock()
        run.platform_health.check.side_effect = RuntimeError("platform unhealthy")
        run.api, run.lab = Mock(), Mock()
        run.lab.serial.return_value = '{"stopped_or_collected":true}'
        vm = {"vmid": 109}
        with self.assertRaisesRegex(RuntimeError, "platform unhealthy"):
            run.router()
        with self.assertRaisesRegex(RuntimeError, "platform unhealthy"):
            run.start_probes(vm, [], "/owned")
        with self.assertRaisesRegex(RuntimeError, "platform unhealthy"):
            run.probe_status(vm, "/owned")
        run.api.json.assert_not_called()
        run.lab.serial.assert_not_called()
        self.assertTrue(run.stop_probes(vm, "swiftfabric-ha-probes")["stopped_or_collected"])


    def test_owned_cleanup_stage_closes_active_guard_before_teardown(self):
        import nsr_ha as ha
        run = ha.HARun.__new__(ha.HARun)
        guard = Mock()
        run.platform_health = guard
        order = []
        guard.close.side_effect = lambda: order.append("close")
        with patch.object(ha.deployment.RecoveryRun, "stage",
                          side_effect=lambda name, operation: operation()):
            run.stage("cleanup", lambda: order.append("teardown"))
        self.assertEqual(order, ["close", "teardown"])

    def test_nested_stage_keeps_outer_guard_for_owned_cleanup(self):
        import nsr_ha as ha
        run = ha.HARun.__new__(ha.HARun)
        run.api = Mock()
        outer = Mock()
        run.platform_health = outer
        inner = Mock()
        inner.__enter__ = Mock(return_value=inner)
        inner.__exit__ = Mock(return_value=False)
        seen = []
        with patch.object(ha.deployment.RecoveryRun, "stage",
                          side_effect=lambda name, operation: operation()), \
                patch.object(ha, "PlatformHealth", return_value=inner):
            run.stage("rolling", lambda: seen.append(run.platform_health))
            self.assertIs(run.platform_health, outer)
            run.stage("cleanup", lambda: seen.append("teardown"))
        self.assertEqual(seen, [inner, "teardown"])
        outer.close.assert_called_once()

def survivor_snapshot(name, absent="controller-2", failed_start=False):
    """Receipt from a survivor while ``absent`` is down (or rejoining with a failed start)."""
    value = snapshot()
    value["node"] = name
    root = ET.fromstring(value["monitor"])
    if not failed_start:
        root.find("./nodes/node[@name='%s']" % absent).set("online", "false")
    for resource in root.findall(".//clone/resource"):
        if resource.find("node").get("name") == absent:
            resource.remove(resource.find("node"))
            resource.attrib.update(role="Stopped", active="false", nodes_running_on="0")
    if failed_start:
        ET.SubElement(root, "failures").append(ET.Element("failure", op_key="start_0", node=absent))
        ET.SubElement(root, "resource_history", attrib={"fail-count": "1000000"})
    value["monitor"] = ET.tostring(root, encoding="unicode")
    count = 3 if failed_start else 2
    value["corosync"] = f"Nodes: {count}\nQuorate: Yes\nTotal votes: {count}\n"
    if name == "controller-0":
        value["replication"]["4999"] = {
            "role": "master", "connected_slaves": "1",
            "slave0": "ip=192.0.2.3,port=4999,state=online,offset=1,lag=0,type=replica"}
    else:
        value["replication"]["4999"] = {"role": "slave", "master_link_status": "up",
                                        "master_sync_in_progress": "0"}
    return value


class DeclaredControllerFaultTests(unittest.TestCase):
    def guard(self, directory):
        return ConvergenceTests.guard(self, directory)

    def survivors(self, **extra):
        return [survivor_snapshot(name, **extra) for name in ("controller-0", "controller-1")]

    def test_absent_controller_accepted_only_when_declared(self):
        value = survivor_snapshot("controller-0")
        with self.assertRaisesRegex(RuntimeError, "platform unhealthy"):
            health.validate(value, NODES)
        self.assertTrue(health.validate(value, NODES, absent="controller-2")["healthy"])

    def test_survivor_degradation_fails_even_while_controller_absent(self):
        value = survivor_snapshot("controller-0")
        value["replication"]["4999"]["connected_slaves"] = "0"
        with self.assertRaisesRegex(RuntimeError, "lacks online replicas"):
            health.validate(value, NODES, absent="controller-2")
        value = survivor_snapshot("controller-0")
        root = ET.fromstring(value["monitor"])
        root.find("./nodes/node[@name='controller-1']").set("standby", "true")
        value["monitor"] = ET.tostring(root, encoding="unicode")
        with self.assertRaisesRegex(RuntimeError, "standby"):
            health.validate(value, NODES, absent="controller-2", relax_all=True)

    def test_undetected_absence_settles_only_in_relaxed_window(self):
        # Just after a hard stop, survivors still show the absent controller online with its replicas.
        value = snapshot()
        value["node"] = "controller-0"
        with self.assertRaisesRegex(RuntimeError, "platform unhealthy"):
            health.validate(value, NODES, absent="controller-2")
        receipt = health.validate(value, NODES, absent="controller-2", relax_all=True)
        self.assertIn("4999", receipt["converging"])

    def test_failed_start_on_rejoin_fails_even_in_relaxed_window(self):
        # A controller returning with an unloadable AOF leaves a failed start and INFINITY fail-count.
        with self.assertRaisesRegex(RuntimeError, "failed resource operations remain"):
            health.validate(survivor_snapshot("controller-0", failed_start=True), NODES, relax_all=True)

    def test_fault_scope_requires_strict_rejoin_within_bound(self):
        with tempfile.TemporaryDirectory() as directory:
            guard = self.guard(directory)
            clock = [1000.0]
            healthy = ConvergenceTests.snapshots(self)
            with patch.object(health.time, "time", side_effect=lambda: clock[0]), \
                    patch.object(guard, "collect", return_value=healthy):
                guard.capture()
            with patch.object(health.time, "time", side_effect=lambda: clock[0]), \
                    patch.object(guard, "collect") as collect:
                with guard.controller_fault("controller-2"):
                    collect.return_value = self.survivors()
                    guard.capture()
                    collect.assert_called_with(skip="controller-2")
                    self.assertEqual(guard.report["latest"]["declared_absent"], "controller-2")
                self.assertEqual(guard.returning, "controller-2")
                collect.return_value = [*self.survivors(), None]
                guard.capture()
                self.assertIn("controller:controller-2", guard.converging)
                self.assertEqual(guard.returning, "controller-2")
                clock[0] += health.RECOVERY_SECONDS + 1
                with self.assertRaisesRegex(RuntimeError, "platform unhealthy"):
                    guard.capture()

    def test_rejoined_controller_restores_strict_validation(self):
        with tempfile.TemporaryDirectory() as directory:
            guard = self.guard(directory)
            healthy = ConvergenceTests.snapshots(self)
            with patch.object(guard, "collect", return_value=healthy):
                guard.capture()
                with guard.controller_fault("controller-2"):
                    pass
                guard.capture()
                self.assertIsNone(guard.returning)
            with patch.object(guard, "collect", return_value=self.survivors()), \
                    self.assertRaisesRegex(RuntimeError, "platform unhealthy"):
                guard.capture()

    def test_fault_scope_rejects_unowned_and_nested_faults(self):
        with tempfile.TemporaryDirectory() as directory:
            guard = self.guard(directory)
            with self.assertRaises(ValueError):
                with guard.controller_fault("other-controller"):
                    pass
            with guard.controller_fault("controller-2"):
                with self.assertRaisesRegex(RuntimeError, "still active"):
                    with guard.controller_fault("controller-1"):
                        pass


if __name__ == "__main__":
    unittest.main()
