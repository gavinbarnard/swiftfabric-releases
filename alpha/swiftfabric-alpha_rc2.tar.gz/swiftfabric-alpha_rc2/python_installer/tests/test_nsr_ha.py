import argparse
import copy
import io
import ipaddress
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tests_integration"))
import nsr_ha as ha
import nsr_ha_guest as worker

guest = ha.importlib.import_module("guest")
ROUTER_ID = "sf-dr-" + "a" * 20 + "-nsr"


def router():
    return {
        "id": ROUTER_ID, "name": ROUTER_ID,
        "deployment_mode": "active-standby", "ha_replication_mode": "asynchronous",
        "ha_shared_vtep": True, "status": "active", "ha_state_sync_enabled": True,
        "active_member": "a", "ha_generation": 7,
        "node": "n1", "vmid": 100, "management_address_cidr": "192.0.2.10/24",
        "vtep_ip": "198.51.100.10", "wan_address_cidr": "203.0.113.2/29",
        "standby": {
            "node": "n2", "vmid": 101, "management_address_cidr": "192.0.2.11/24",
            "vtep_ip": "198.51.100.10",
        },
    }


def cases():
    return [
        {
            "source": "10.253.244.10", "source_port": 22000 + index,
            "destination": "203.0.113.3", "destination_port": 2000 + index,
            "protocol": protocol, "duration_seconds": 60,
            "expected_nat_address": "203.0.113.2", "echo_format": "observed-peer",
        } for index, protocol in enumerate(("tcp", "udp"))
    ]


def result(case, times=(1, 2, 9, 12, 13, 30, 59), error=""):
    samples = [
        {"sequence": index, "sent_seconds": value - 0.1, "received_seconds": value,
         "peer": ["203.0.113.2", 44000]} for index, value in enumerate(times)
    ]
    return {
        **guest.held_summary(case, samples, 60, error),
        "started_epoch": 1000, "started_monotonic": 100,
        "connected": True, "requests": len(samples),
        "application_bytes_sent": 200, "application_bytes_received": 300,
    }


def view(member, owner="a", term=3, **changes):
    return {"member": member, "role": "active" if member == owner else "standby", "fresh": True,
            "age_ms": 200, "term": term, "owner": owner, "peer_heard": True, "peer_silent_ms": 900,
            "generation": 7, "policy_digest": "digest", "last_error": None, **changes}


def observation(owner="a", term=3, **changes):
    return {"router_id": ROUTER_ID, "observed_at_ms": 1, "active_member": owner, "term": term,
            "healthy": True, "split_brain": False,
            "a": {"status": view("a", owner, term)}, "b": {"status": view("b", owner, term)}, **changes}


def guest_status(member, owner="a", term=3, **changes):
    return json.dumps({
        "router_id": ROUTER_ID, "member": member, "role": "active" if member == owner else "standby",
        "pair": {"term": term, "owner": owner, "peer_heard": True},
        "replication": {"sender": {"connected": True}, "receiver": {"connected": True}}, **changes,
    })


class IntegratedPhaseTests(unittest.TestCase):
    def test_integrated_cleanup_reuses_parent_ssh_trust_session(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            state = {
                "nsr_ha_directory": str(directory), "prefix": "sf-dr-" + "a" * 20,
                "config": "/synthetic/config", "config_sha256": "hash",
            }
            ha.deployment.private_write(directory / "recovery.json", {
                **state, "router_requested": state["prefix"] + "-ha-nsr",
            })
            parent = SimpleNamespace(state=state)
            run = mock.Mock()
            with mock.patch.object(
                ha, "automated_ssh_tofu",
                side_effect=AssertionError("parent already owns the trust session"),
            ), mock.patch.object(ha, "with_saved_run") as saved:
                saved.side_effect = lambda path, action, **kwargs: action(run)
                ha.cleanup_integrated(parent)
            self.assertEqual(saved.call_args.args[0], directory)
            self.assertEqual(saved.call_args.kwargs["action_name"], "release-ha-cleanup")
            run.cleanup_integrated_resources.assert_called_once_with()

    def test_failed_restore_cleanup_adopts_verified_controllers_not_member_identities(self):
        for changed_inventory, changed_history in ((False, False), (True, False), (False, True)):
            with self.subTest(inventory=changed_inventory, history=changed_history), \
                    tempfile.TemporaryDirectory() as temporary:
                directory = Path(temporary)
                state = {
                    "nsr_ha_directory": str(directory), "prefix": "sf-dr-" + "a" * 20,
                    "config": "/synthetic/config", "config_sha256": "hash",
                    "controllers": ["original"], "replacement_controllers": ["replacement"],
                }
                saved = {
                    **state, "router_requested": state["prefix"] + "-ha-nsr",
                    "controllers": ["unknown"] if changed_history else ["original"],
                    "pair": {"a": {"vmid": 157}, "b": {"vmid": 158}},
                }
                path = directory / "recovery.json"
                ha.deployment.private_write(path, saved)
                parent = SimpleNamespace(state=state, proxmox=mock.Mock())
                inventory = ["changed"] if changed_inventory else ["replacement"]
                with mock.patch.object(ha.deployment, "controller_inventory", return_value=inventory), \
                        mock.patch.object(ha, "with_saved_run") as action:
                    if changed_inventory or changed_history:
                        with self.assertRaisesRegex(RuntimeError, "ownership"):
                            ha.cleanup_integrated(parent)
                        self.assertEqual(json.loads(path.read_text()), saved)
                        action.assert_not_called()
                    else:
                        ha.cleanup_integrated(parent)
                        updated = json.loads(path.read_text())
                        self.assertEqual(updated["controllers"], ["replacement"])
                        self.assertEqual(updated["pair"], saved["pair"])
                        self.assertNotIn("controller_recovery", updated)
                        action.assert_called_once()

    def test_recovery_adopts_only_explicitly_replaced_physical_members(self):
        for replaced, change_member, valid in (
            ([], None, True), (["b"], "b", True), (["a", "b"], "a", True),
            ([], "b", False), (["a"], "b", False),
        ):
            with self.subTest(replaced=replaced, change_member=change_member), \
                    tempfile.TemporaryDirectory() as temporary:
                parent = mock.Mock()
                parent.state = {
                    "prefix": "sf-dr-" + "a" * 20,
                    "nsr_ha_directory": temporary, "replacement_controllers": ["new-controllers"],
                }
                current = router()
                current["id"] = current["name"] = parent.state["prefix"] + "-ha-nsr"
                previous = ha.pair_identity(current)
                if change_member:
                    physical = current if change_member == "a" else current["standby"]
                    physical["vmid"] += 500
                observed = observation()
                observed["router_id"] = current["id"]
                report = {"router": current, "replaced_members": replaced, "observation": observed}
                saved = {
                    "prefix": parent.state["prefix"], "router_requested": current["id"],
                    "pair": previous,
                }
                path = Path(temporary) / "recovery.json"
                ha.deployment.private_write(path, saved)
                with mock.patch.object(
                    ha, "automated_ssh_tofu",
                    side_effect=AssertionError("parent already owns the trust session"),
                ), \
                        mock.patch.object(ha, "with_saved_run") as trusted:
                    if valid:
                        ha.accept_integrated_recovery(parent, [report])
                        recovered = json.loads(path.read_text())
                        self.assertEqual(recovered["pair"], ha.pair_identity(current))
                        self.assertEqual(recovered["controllers"], ["new-controllers"])
                        self.assertEqual(path.stat().st_mode & 0o777, 0o600)
                        trusted.assert_called_once()
                    else:
                        with self.assertRaisesRegex(RuntimeError, "Surviving"):
                            ha.accept_integrated_recovery(parent, [report])
                        self.assertEqual(json.loads(path.read_text()), saved)
                        trusted.assert_not_called()

    def test_saved_integrated_phases_preserve_parent_ssh_pins(self):
        with tempfile.TemporaryDirectory() as temporary, \
                mock.patch.object(Path, "home", return_value=Path(temporary)):
            parent = mock.Mock()
            parent.directory = Path(temporary)
            parent.state = {"prefix": "sf-dr-" + "a" * 20}
            directory = parent.directory / "nsr-ha"
            directory.mkdir()
            (directory / "recovery.json").write_text("{}")
            run = mock.Mock()

            def saved_action(path, action, **kwargs):
                self.assertEqual(path, directory)
                action(run)

            with ha.automated_ssh_tofu():
                pins = Path(temporary) / ".ssh" / "swiftfabric-integration-known-hosts"
                pins.write_text("parent session pin\n")
                with mock.patch.object(ha, "with_saved_run", side_effect=saved_action) as saved, \
                        mock.patch.object(ha, "write_ha_report"), \
                        mock.patch.object(ha, "publish_integrated_report"), \
                        mock.patch.dict(sys.modules, {"nsr_controller_loss": mock.Mock()}) as modules:
                    result = ha.run_integrated_phase(
                        parent, "post-restore", Path("router.json"), Path("nsr.json"),
                    )
                    self.assertEqual(result, directory)
                    run.run_integrated_scenarios.assert_called_once_with()
                    self.assertEqual(saved.call_args.kwargs["action_name"], "release-post-restore")
                    self.assertEqual(pins.read_text(), "parent session pin\n")
                    ha.run_integrated_controller_loss(directory)
                    modules["nsr_controller_loss"].run_gate.assert_called_once_with(run)
                    self.assertEqual(saved.call_args.kwargs["action_name"], "release-controller-cluster-loss")
                    self.assertEqual(pins.read_text(), "parent session pin\n")
            self.assertFalse(pins.exists())

    def test_first_phase_copies_controller_ca_before_running_ha(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            certificate = b"test-controller-ca\n"
            (directory / "controller-ca.crt").write_bytes(certificate)
            parent = mock.Mock()
            parent.directory = directory
            parent.state = {"prefix": "sf-dr-owned", "config_sha256": "digest", "controllers": []}
            parent.args = argparse.Namespace(
                router_config=directory / "router.json", nodes=["n1", "n2", "n3"],
                config=directory / "config.json", image_volume="images:guest",
            )
            parent.api.json.return_value = []
            run = mock.Mock()
            run.state = {}
            run.lab = None
            run.lab_lock = None
            with mock.patch.object(ha, "validate_integrated_configuration", return_value=(
                {}, {"remote_endpoint": "198.51.100.3", "tcp_port": 2000, "udp_port": 2001},
                ipaddress.IPv4Interface("198.51.100.2/29"),
            )), mock.patch.object(ha, "allocate_integrated_segment", return_value=(
                50000, "10.254.0.1/24",
            )), mock.patch.object(ha, "HARun", return_value=run), \
                    mock.patch.object(ha, "write_ha_report"), \
                    mock.patch.object(ha, "publish_integrated_report"):
                result = ha.run_integrated_phase(
                    parent, "post-deploy", directory / "router2.json", directory / "nsr2.json",
                )
            self.assertEqual((result / "controller-ca.crt").read_bytes(), certificate)
            self.assertEqual((result / "controller-ca.crt").stat().st_mode & 0o777, 0o600)
            run.run_integrated_scenarios.assert_called_once()
            self.assertEqual(run.state["status"], "passed")

    def test_publication_copies_reports_and_evidence_with_private_permissions(self):
        with tempfile.TemporaryDirectory() as temporary:
            parent = mock.Mock()
            parent.directory = Path(temporary)
            source = parent.directory / "nsr-ha"
            source.mkdir()
            (source / "report.html").write_text("test report")
            (source / "report-data.json").write_text('{"passed": true}')
            with mock.patch.object(ha, "write_ha_report"):
                ha.publish_integrated_report(parent, "post-deploy", source)
            destination = parent.directory / "nsr-ha-post-deploy"
            for name, original in (
                ("report.html", "report.html"), ("report-data.json", "report-data.json"),
                ("evidence.json", "report-data.json"),
            ):
                self.assertEqual((destination / name).read_bytes(), (source / original).read_bytes())
                self.assertEqual((destination / name).stat().st_mode & 0o777, 0o600)


class Clock:
    def __init__(self):
        self.now = 1000.0

    def monotonic(self):
        return self.now

    def sleep(self, seconds):
        self.now += seconds


def make_run(directory):
    run = ha.HARun.__new__(ha.HARun)
    run.directory = Path(directory)
    value = router()
    run.state = {"router_requested": ROUTER_ID, "pair": ha.pair_identity(value),
                 "held_flow_cases": cases(), "prefix": "sf-dr-" + "a" * 20,
                 "guest_ssh_fingerprints": {"a": "fa", "b": "fb"}}
    run.args = argparse.Namespace(duration=60, config=Path("/owned/config.json"))
    run.config = {"ip_range_start": "192.0.2.2", "ip_range_end": "192.0.2.9"}
    run.save, run.close = mock.Mock(), mock.Mock()
    run.api, run.proxmox = mock.Mock(), mock.Mock()
    run.api.base_url = "https://192.0.2.9/api/v1"
    run.platform_health = None
    run.lab = SimpleNamespace(state={"vms": [{"address": "10.253.244.10"}], "run_id": "owned"})
    return run


class ClockedTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.clock = Clock()
        for patch in (mock.patch.object(ha.time, "monotonic", side_effect=self.clock.monotonic),
                      mock.patch.object(ha.time, "sleep", side_effect=self.clock.sleep),
                      mock.patch("builtins.print")):
            patch.start()
            self.addCleanup(patch.stop)
        self.run = make_run(self.temporary.name)


class CapabilityTests(unittest.TestCase):
    def test_requires_explicit_pair_local_contract(self):
        ha.require_pair(router(), deployed=True)
        for field, value in (("deployment_mode", "standalone"), ("ha_replication_mode", "synchronous"),
                             ("ha_shared_vtep", False), ("synchronous_ha", True), ("ha_edge_pair_id", "x")):
            with self.subTest(field=field), self.assertRaises(ha.CapabilityBlocked):
                ha.require_pair({**router(), field: value})
        for field, value in (("status", "deploying"), ("ha_state_sync_enabled", False)):
            changed = {**router(), field: value}
            ha.require_pair(changed)
            with self.subTest(field=field), self.assertRaises(ha.CapabilityBlocked):
                ha.require_pair(changed, deployed=True)

    def test_removed_controller_ha_fields_are_not_required(self):
        value = router()
        for key in ("failover_enabled", "production_ha", "ha_async_lab_failover_available"):
            value.pop(key, None)
        ha.require_pair(value, deployed=True)

    def test_unique_members_and_stable_service_vtep_required(self):
        self.assertEqual(set(ha.pair_identity(router())), {"a", "b"})
        for field, value in (
            ("node", "n1"), ("vmid", 100), ("vmid", True), ("vtep_ip", "198.51.100.11"),
            ("management_address_cidr", "192.0.2.10/25"),
        ):
            changed = copy.deepcopy(router())
            changed["standby"][field] = value
            with self.subTest(field=field), self.assertRaises(RuntimeError):
                ha.pair_identity(changed)


class PairStatusTests(unittest.TestCase):
    def test_converged_requires_both_members_agreeing_on_connected_owner_and_term(self):
        self.assertEqual(ha.converged(observation("b", 4), ROUTER_ID), ("b", 4))
        broken = [
            observation(healthy=False), observation(split_brain=True), observation(term=0),
            observation(active_member=None),
        ]
        for member in ("a", "b"):
            for field, value in (("fresh", False), ("term", 2), ("owner", "b"), ("peer_heard", False),
                                 ("role", "fenced"), ("member", "x")):
                changed = observation()
                changed[member]["status"][field] = value
                broken.append(changed)
            changed = observation()
            changed[member] = {"error": "ssh timeout"}
            broken.append(changed)
        for value in broken:
            with self.subTest(value=value):
                self.assertIsNone(ha.converged(value, ROUTER_ID))
        with self.assertRaisesRegex(RuntimeError, "another router"):
            ha.converged({**observation(), "router_id": "foreign"}, ROUTER_ID)

    def test_ownership_conflict_ignores_unreachable_but_flags_contradictions(self):
        unreachable = observation(healthy=False, a={"error": "timeout"}, b={"error": "timeout"})
        self.assertIsNone(ha.ownership_conflict(unreachable, "a", 3))
        stale = observation()
        stale["b"]["status"].update(fresh=False, role="active", term=9)
        self.assertIsNone(ha.ownership_conflict(stale, "a", 3))
        self.assertIn("split brain", ha.ownership_conflict(observation(split_brain=True), "a", 3))
        promoted = observation()
        promoted["b"]["status"]["role"] = "active"
        self.assertIn("member b changed role", ha.ownership_conflict(promoted, "a", 3))
        bumped = observation()
        bumped["a"]["status"]["term"] = 4
        self.assertIn("term 4", ha.ownership_conflict(bumped, "a", 3))

    def test_member_status_must_name_exact_router_and_member(self):
        self.assertEqual(ha.member_status(guest_status("b"), ROUTER_ID, "b")["member"], "b")
        for raw in (guest_status("a"), guest_status("b", router_id="foreign"), guest_status("b", pair=None)):
            with self.assertRaises(RuntimeError):
                ha.member_status(raw, ROUTER_ID, "b")

    def test_dropped_packets_sums_nft_counters(self):
        listing = {"nftables": [{"metainfo": {}}, {"rule": {"expr": [{"counter": {"packets": 2}}]}},
                                {"rule": {"expr": [{"match": {}}, {"counter": {"packets": 3}}]}}]}
        self.assertEqual(ha.dropped_packets(json.dumps(listing)), 5)
        self.assertEqual(ha.dropped_packets({"nftables": []}), 0)


class CutScriptTests(unittest.TestCase):
    def test_cut_is_shell_scoped_self_healing_and_saves_evidence(self):
        rules = "tcp dport 4243 counter drop; tcp sport 4243 counter drop;"
        script = ha.cut_script("sf_ha_replication_0123abcd", rules, rules, delay=2, seconds=60)
        self.assertTrue(script.startswith("set -eu\n"))
        self.assertNotIn("python", script)
        self.assertIn("table inet sf_ha_replication_0123abcd", script)
        self.assertIn("hook input priority -300", script)
        self.assertIn("hook output priority -300", script)
        self.assertEqual(script.count("tcp dport 4243 counter drop"), 2)
        self.assertNotIn("4244", script)
        self.assertIn("--on-active=2 /usr/sbin/nft -f /run/sf_ha_replication_0123abcd.nft", script)
        self.assertIn("--on-active=62", script)
        self.assertIn("nft -j list table inet sf_ha_replication_0123abcd > /run/sf_ha_replication_0123abcd.json",
                      script)

    def test_cut_rejects_foreign_tables_and_unbounded_timing(self):
        for table, delay, seconds in (("swiftfabric_router", 2, 60), ("sf_ha_x_0123abcd; rm", 2, 60),
                                      ("sf_ha_x_0123abcd", 0, 60), ("sf_ha_x_0123abcd", 2, 601),
                                      ("sf_ha_x_0123abcd", True, 60)):
            with self.subTest(table=table, delay=delay, seconds=seconds), self.assertRaises(ValueError):
                ha.cut_script(table, "", "", delay=delay, seconds=seconds)
        with self.assertRaises(ValueError):
            ha.heal_script("swiftfabric_router")
        heal = ha.heal_script("sf_ha_controller_0123abcd")
        self.assertIn("nft delete table inet sf_ha_controller_0123abcd", heal)
        self.assertNotIn("python", heal)


class MeasurementTests(unittest.TestCase):
    def test_measures_event_gap_recovery_bounds_survival_and_nat(self):
        matrix = cases()
        report = ha.measurements(matrix, [result(case) for case in matrix], [110, 111])
        self.assertTrue(report["passed"])
        self.assertEqual(report["survival_percent"], 100)
        for flow in report["flows"]:
            self.assertEqual(flow["event_response_gap_seconds"], 3)
            self.assertEqual(flow["recovery_delay_seconds_bounds"], [1, 2])
            self.assertEqual(flow["nat_tuples"], [["203.0.113.2", 44000]])
        self.assertNotIn("replica_age", report)

    def test_missing_before_or_after_evidence_cannot_claim_survival(self):
        matrix = cases()
        for times in ((12, 13, 30, 59), (1, 2, 5, 9)):
            report = ha.measurements(matrix, [result(case, times) for case in matrix], [110, 111])
            self.assertFalse(report["passed"])
            self.assertEqual(report["survival_percent"], 0)

    def test_nat_tuple_change_and_tcp_reset_are_losses_not_reconnect_success(self):
        matrix = cases()
        results = [result(case) for case in matrix]
        results[0] = result(matrix[0], error="held TCP connection closed; reconnection is forbidden")
        udp = results[1]
        udp["samples"][-1]["peer"][1] += 1
        udp.update(guest.held_summary(matrix[1], udp["samples"], 60, ""))
        report = ha.measurements(matrix, results, [110, 111])
        self.assertFalse(report["passed"])

    def test_forged_summary_plain_echo_and_reversed_bounds_are_rejected(self):
        matrix = cases()
        results = [result(case) for case in matrix]
        with self.assertRaises(ValueError):
            ha.measurements(matrix, results, [111, 110])
        results[0]["max_response_gap_seconds"] = 0
        with self.assertRaises(ValueError):
            ha.measurements(matrix, results, [110, 111])
        matrix[0]["echo_format"] = "plain"
        with self.assertRaises(ValueError):
            ha.measurements(matrix, [result(case) for case in matrix], [110, 111])


class HeldTrafficTests(ClockedTest):
    def setUp(self):
        super().setUp()
        self.current = {}

        def start(vm, matrix, remote, *, unit):
            self.current.update(matrix=matrix, remote=remote, unit=unit)

        self.run.start_probes = mock.Mock(side_effect=start)
        self.run.probe_status = mock.Mock(side_effect=lambda *_: {
            "completed": True, "results": [result(case, times=range(1, 60)) for case in self.current["matrix"]],
        })
        self.run.stop_probes = mock.Mock(return_value={"stopped_or_collected": True})

    def test_establishment_failure_preserves_guest_status_and_reason(self):
        status = {"completed": False, "progress": {}, "results": [
            {"protocol": "tcp", "error": "TimeoutError: timed out", "connected": False},
        ]}
        self.run.probe_status = mock.Mock(return_value=status)
        with self.assertRaisesRegex(RuntimeError, "tcp: TimeoutError: timed out"):
            self.run.wait_established({}, "/var/lib/owned-probe")
        path = self.run.directory / "owned-probe-preflight.json"
        self.assertEqual(json.loads(path.read_text()), status)
        self.assertEqual(path.stat().st_mode & 0o777, 0o600)

    def test_establishment_waits_for_both_protocols_and_expected_nat(self):
        def progress(nat, count):
            return {protocol: {"verified_responses": count, "sample": {"peer": [nat, 40000]}}
                    for protocol in ("tcp", "udp")}

        ready = progress("203.0.113.2", 8)
        self.run.probe_status = mock.Mock(side_effect=[
            {}, {"progress": progress("203.0.113.2", 7)},
            {"progress": progress("203.0.113.3", 8)}, {"progress": ready},
        ])
        self.assertEqual(self.run.wait_established({}, "/var/lib/owned-probe", "203.0.113.2"), ready)
        self.assertEqual(self.run.probe_status.call_count, 4)

    def test_repeated_traffic_uses_unique_paths_units_and_always_cleans(self):
        with mock.patch.object(ha.secrets, "token_hex", side_effect=[c * 16 for c in "abc"]), \
                mock.patch.object(ha.secrets, "randbelow", side_effect=[1, 2, 3]):
            reports = [self.run.held_traffic("cut", 60) for _ in range(2)]
            self.run.stop_probes.side_effect = RuntimeError("injected cleanup failure")
            with self.assertRaisesRegex(RuntimeError, "injected cleanup failure"):
                self.run.held_traffic("cut", 60)
        self.assertTrue(all(report["passed"] for report in reports))
        self.assertNotEqual(reports[0]["probe_directory"], reports[1]["probe_directory"])
        self.assertNotEqual(reports[0]["probe_unit"], reports[1]["probe_unit"])
        self.assertEqual(self.run.stop_probes.call_count, 3)
        failed = json.loads((self.run.directory / f"cut-{'c' * 16}-probes.json").read_text())
        self.assertTrue(failed["traffic_passed"])
        self.assertFalse(failed["passed"])

    def test_interrupted_traffic_fails_and_during_runs_after_establishment(self):
        order = []
        self.run.wait_established = mock.Mock(side_effect=lambda *_: order.append("established"))
        report = self.run.held_traffic("cut", 60, lambda: order.append("during") or "evidence")
        self.assertEqual(order, ["established", "during"])
        self.assertEqual(report["during"], "evidence")
        self.run.probe_status.side_effect = lambda *_: {
            "completed": True, "results": [result(case) for case in self.current["matrix"]],
        }
        with self.assertRaisesRegex(RuntimeError, "interrupted"):
            self.run.held_traffic("cut", 60)
        self.assertEqual(self.run.stop_probes.call_count, 2)


class ConvergenceTests(ClockedTest):
    def test_wait_converged_requires_exact_owner_and_term_when_given(self):
        self.run.api.json.side_effect = [observation(healthy=False), observation("b", 4)]
        self.assertEqual(self.run.wait_converged("b", minimum_term=4), ("b", 4))
        self.assertTrue(self.run.api.json.call_args.args[1].endswith(f"/{ROUTER_ID}/ha-status"))
        self.run.api.json.side_effect = None
        self.run.api.json.return_value = observation("a", 5)
        with self.assertRaisesRegex(RuntimeError, "converged on member a term 5"):
            self.run.wait_converged("b", term=4)
        with self.assertRaises(TimeoutError):
            self.run.wait_converged("a", minimum_term=6, timeout=10)

    def test_observe_stable_fails_on_any_ownership_change(self):
        self.run.api.json.return_value = observation()
        samples = self.run.observe_stable("a", 3, 10)
        self.assertTrue(all(sample["converged"] for sample in samples))
        promoted = observation()
        promoted["b"]["status"]["role"] = "active"
        self.run.api.json.return_value = promoted
        with self.assertRaisesRegex(RuntimeError, "forwarding ownership changed"):
            self.run.observe_stable("a", 3, 10, reachable=False)
        self.run.api.json.return_value = observation(healthy=False)
        with self.assertRaisesRegex(RuntimeError, "lost owner/term convergence"):
            self.run.observe_stable("a", 3, 10)
        self.run.api.json.return_value = observation(healthy=False, a={"error": "x"}, b={"error": "y"})
        samples = self.run.observe_stable("a", 3, 4, reachable=False)
        self.assertEqual(samples[0]["errors"], {"a": "x", "b": "y"})

    def test_inspect_protected_guests_uses_controller_observation_only(self):
        self.run.api.json.return_value = observation()
        self.run.run_owned_guest = mock.Mock()
        self.assertEqual(ha.inspect_protected_guests(self.run, router())["term"], 3)
        self.run.run_owned_guest.assert_not_called()
        for value, current in ((router(), observation("b")), ({**router(), "upgrade_in_progress": True},
                                                                observation())):
            self.run.api.json.return_value = current
            with self.assertRaises(RuntimeError):
                ha.inspect_protected_guests(self.run, value)

    def test_member_status_reads_router_cli_with_shell_only(self):
        self.run.run_owned_guest = mock.Mock(return_value=guest_status("b"))
        self.assertEqual(self.run.member_status("b")["member"], "b")
        program = self.run.run_owned_guest.call_args.args[1]
        self.assertIn("swiftfabric-router --config /etc/swiftfabric/router.json --ha-status", program)
        self.assertNotIn("python", program)


class EventTests(ClockedTest):
    def test_planned_handoff_requires_completed_receipt_and_higher_term(self):
        self.run.api.json.return_value = {"planned_handoff_completed": True, "active_member": "b"}
        self.run.wait_converged = mock.Mock(return_value=("b", 4))
        fault = {}
        self.assertEqual(self.run.planned_handoff("a", 3, fault)["term"], 4)
        self.run.api.json.assert_called_once_with(
            "POST", f"/north-south-routers/{ROUTER_ID}/ha-failover/planned", {"target_member": "b"})
        self.run.wait_converged.assert_called_once_with("b", minimum_term=4, timeout=60)
        self.assertIn("completed_monotonic", fault)
        for receipt in ({"planned_handoff_started": True, "active_member": "b"},
                        {"planned_handoff_completed": True, "active_member": "a"}, None):
            self.run.api.json.return_value = receipt
            with self.subTest(receipt=receipt), self.assertRaisesRegex(RuntimeError, "completed planned"):
                self.run.planned_handoff("a", 3, {})

    def test_crash_stops_only_owned_active_vm_and_waits_for_self_promotion(self):
        self.run.owned_member_path = mock.Mock(return_value="/nodes/n1/qemu/100")
        self.run.proxmox.get.side_effect = [{"data": {"status": "running"}}, {"data": {"status": "stopped"}}]
        self.run.member_status = mock.Mock(side_effect=[
            ha.member_status(guest_status("b", "a", 3), ROUTER_ID, "b"),
            ha.member_status(guest_status("b", "b", 3), ROUTER_ID, "b"),
            ha.member_status(guest_status("b", "b", 4), ROUTER_ID, "b"),
        ])
        fault = {}
        with mock.patch.object(ha.deployment, "wait_task"):
            successor = self.run.crash_active("a", 3, fault)
        self.run.proxmox.post.assert_called_once_with("/nodes/n1/qemu/100/status/stop")
        self.assertEqual((successor["member"], successor["term"]), ("b", 4))
        self.assertEqual(successor["takeover_observed_seconds"], 1)
        self.run.owned_member_path.assert_called_once_with("a")

    def test_crash_without_promotion_times_out(self):
        self.run.owned_member_path = mock.Mock(return_value="/nodes/n1/qemu/100")
        self.run.proxmox.get.side_effect = [{"data": {"status": "running"}}, {"data": {"status": "stopped"}}]
        self.run.member_status = mock.Mock(
            return_value=ha.member_status(guest_status("b", "a", 3), ROUTER_ID, "b"))
        with mock.patch.object(ha.deployment, "wait_task"), self.assertRaisesRegex(TimeoutError, "promote"):
            self.run.crash_active("a", 3, {})

    def test_rejoining_member_must_not_preempt_new_owner(self):
        report = {"passed": True, "fault": {"member": "a"}, "successor": {"member": "b", "term": 4}}
        self.run.measure = mock.Mock(return_value=report)
        self.run.power_member = mock.Mock()
        self.run.wait_converged = mock.Mock(return_value=("b", 4))
        self.run.observe_stable = mock.Mock(return_value=[])
        self.run.held_traffic = mock.Mock(return_value={"passed": True})
        self.run.crash_scenario()
        self.run.power_member.assert_called_once_with("a", "start")
        self.run.wait_converged.assert_called_once_with("b", term=4)
        self.run.observe_stable.assert_called_once_with("b", 4, ha.REJOIN_OBSERVATION_SECONDS)
        saved = ha.read_config_object(self.run.directory / "ha-report.json")
        self.assertIn("active-crash", saved["scenarios"])
        self.run.wait_converged.side_effect = RuntimeError("pair converged on member a term 5")
        with self.assertRaisesRegex(RuntimeError, "member a"):
            self.run.crash_scenario()

    def test_crash_measurement_enforces_takeover_limit(self):
        vm = self.run.lab.state["vms"][0]
        self.run.router = mock.Mock(return_value=router())
        self.run.wait_converged = mock.Mock(return_value=("a", 3))
        self.run.guest_clock = mock.Mock(return_value=[0, 0])
        self.run.start_probes, self.run.wait_established = mock.Mock(), mock.Mock()
        self.run.stop_probes = mock.Mock(return_value={})
        self.run.probe_status = mock.Mock(side_effect=lambda *_: {
            "completed": True,
            "results": [result(case) for case in self.run.start_probes.call_args.args[1]],
        })
        self.run.proxmox.get.return_value = {"data": {"status": "stopped"}}

        def crash(source, term, fault):
            fault.update(started_monotonic=109.5, completed_monotonic=110)
            return {"member": "b", "term": 4, "takeover_observed_seconds": takeover}

        self.run.crash_active = crash
        takeover = 4
        self.assertTrue(self.run.measure("crash", "active-crash", 60)["passed"])
        self.run.stop_probes.assert_called_with(vm, mock.ANY)
        takeover = ha.TAKEOVER_LIMIT_SECONDS + 1
        with self.assertRaisesRegex(RuntimeError, "acceptance failed"):
            self.run.measure("crash", "active-crash", 60)
        self.assertNotIn("held_probe_unit", self.run.state)


class CutTests(ClockedTest):
    def setUp(self):
        super().setUp()
        self.run.wait_converged = mock.Mock(return_value=("a", 3))
        self.run.held_traffic = mock.Mock(side_effect=lambda label, duration, during: {
            "passed": True, "during": during()})
        counters = json.dumps({"nftables": [{"rule": {"expr": [{"counter": {"packets": 7}}]}}]})
        self.scripts = []

        def guest_run(member, program, **_):
            self.scripts.append((member, program))
            if program.startswith("set -eu\ncat /run/"):
                return counters
            if "--ha-status" in program:
                return guest_status(member)
            return "scheduled\n"

        self.run.run_owned_guest = mock.Mock(side_effect=guest_run)
        self.run.member_status = mock.Mock(side_effect=lambda member: ha.member_status(
            guest_status(member), ROUTER_ID, member))

    def test_replication_cut_blocks_only_sync_port_on_standby_and_requires_stable_owner(self):
        self.run.observe_stable = mock.Mock(return_value=[{"converged": True}])
        self.run.replication_cut()
        member, script = self.scripts[0]
        self.assertEqual(member, "b")
        self.assertIn("tcp dport 4243 counter drop", script)
        self.assertNotIn("4244", script)
        self.assertEqual({member for member, _ in self.scripts}, {"b"})
        self.run.observe_stable.assert_called_once_with("a", 3, ha.CUT_SECONDS - 10)
        self.run.wait_converged.assert_called_with("a", term=3, timeout=ha.CUT_SECONDS + 180)
        report = ha.read_config_object(self.run.directory / "ha-report.json")["scenarios"]["replication-cut"]
        self.assertTrue(report["passed"])
        self.assertEqual(report["dropped_packets"], {"b": 7})

    def test_replication_cut_heals_immediately_when_ownership_changes(self):
        self.run.observe_stable = mock.Mock(side_effect=RuntimeError("forwarding ownership changed"))
        with self.assertRaisesRegex(RuntimeError, "ownership changed"):
            self.run.replication_cut()
        self.assertIn("nft delete table inet sf_ha_replication_", self.scripts[-1][1])
        self.assertFalse((self.run.directory / "ha-report.json").exists())

    def test_controller_cut_blocks_controllers_and_vip_on_both_members(self):
        self.run.observe_stable = mock.Mock(return_value=[
            {"errors": {"a": None, "b": None}}, {"errors": {"a": "timeout", "b": "timeout"}}])
        self.run.controller_cut()
        scripts = [script for _, script in self.scripts if "nft -f" in script]
        self.assertEqual([member for member, script in self.scripts if "nft -f" in script], ["a", "b"])
        for address in ("192.0.2.2", "192.0.2.3", "192.0.2.4", "192.0.2.9"):
            self.assertIn(address, scripts[0])
        self.assertIn(f"--on-active={ha.CONTROLLER_CUT_DELAY} ", scripts[0])
        self.run.observe_stable.assert_called_once_with("a", 3, ha.CUT_SECONDS - 10, reachable=False)
        report = ha.read_config_object(self.run.directory / "ha-report.json")["scenarios"]["controller-path-cut"]
        self.assertEqual(report["dropped_packets"], {"a": 7, "b": 7})

    def test_controller_cut_must_prove_both_members_unreachable(self):
        self.run.observe_stable = mock.Mock(return_value=[{"errors": {"a": "timeout", "b": None}}])
        with self.assertRaisesRegex(RuntimeError, "still reached both"):
            self.run.controller_cut()

    def test_cut_without_dropped_packets_is_not_proof(self):
        self.run.observe_stable = mock.Mock(return_value=[{"converged": True}])
        self.run.run_owned_guest.side_effect = lambda member, program, **_: (
            '{"nftables": []}' if program.startswith("set -eu\ncat") else "scheduled\n")
        with self.assertRaisesRegex(RuntimeError, "dropped no packets"):
            self.run.replication_cut()


class GuestTransportTests(unittest.TestCase):
    def test_owned_guest_transport_runs_shell_with_exact_trust_and_controller_side_keys(self):
        with tempfile.TemporaryDirectory() as directory:
            run = make_run(directory)
        run.state["guest_ssh_fingerprints"] = {"a": "fingerprint", "b": "fingerprint"}
        run.owned_member_path = mock.Mock()
        run.api.json.return_value = {
            "changed": False,
            "trusted": {"endpoint": "[192.0.2.10]:22", "public_key": "ssh-ed25519 TEST",
                        "fingerprint": "fingerprint"},
        }
        run.api.ssh.run.return_value = "raw text\n"
        with mock.patch.object(ha.deployment.SSHCommandRunner, "_fingerprint", return_value="fingerprint"):
            self.assertEqual(run.run_owned_guest("a", "set -eu\ntrue\n"), "raw text\n")
            command = run.api.ssh.run.call_args.args[1]
            self.assertIn('"sudo -n /bin/sh -s"', command)
            self.assertNotIn("/usr/bin/python3 -\"", command)
            self.assertIn("StrictHostKeyChecking=yes", command)
            self.assertIn("key.chmod(0o600)", command)
            self.assertEqual(run.api.ssh.run.call_args.kwargs["timeout"], 110)
            for timeout in (0, 241, True):
                with self.subTest(timeout=timeout), self.assertRaises(ValueError):
                    run.run_owned_guest("a", "true", timeout=timeout)
            run.api.ssh.run.reset_mock()
            run.api.json.return_value["changed"] = True
            with self.assertRaises(RuntimeError):
                run.run_owned_guest("a", "true")
            run.api.ssh.run.assert_not_called()

    def test_root_only_workload_probe_evidence_is_read_with_sudo(self):
        run = ha.HARun.__new__(ha.HARun)
        run.lab = mock.Mock()
        run.lab.setup_serial.return_value = '{"completed": false}'
        self.assertEqual(run.probe_status({"vmid": 200}, "/var/lib/test"), {"completed": False})
        self.assertIn("sudo -n sh -c", run.lab.setup_serial.call_args.args[1])


class RollingTests(ClockedTest):
    def setUp(self):
        super().setUp()
        self.run.state["rolling_targets"] = {"runtime": "2:1", "agent": "2:2"}

    def receipt(self, **changes):
        journal = {"phase": "upgrade_standby", "source_member": "a", "successor_member": "b",
                   "target_runtime": "2:1", "target_agent": "2:2", **changes}
        return {"upgrade_started": True, "router": {"ha_rolling_upgrade": journal}}

    def test_rolling_upgrade_completes_on_successor_without_failback(self):
        self.run.api.json.return_value = self.receipt()
        self.run.router = mock.Mock(side_effect=[
            {"ha_rolling_upgrade": {"phase": "handoff"}, "upgrade_in_progress": True},
            {"ha_rolling_upgrade": {"phase": "completed"}, "upgrade_in_progress": False},
        ])
        self.run.wait_converged = mock.Mock(return_value=("b", 4))
        successor = self.run.rolling_upgrade("a", 3, {})
        self.assertEqual((successor["member"], successor["term"]), ("b", 4))
        self.run.wait_converged.assert_called_once_with("b", minimum_term=4, timeout=120)
        self.run.api.json.assert_called_once_with("POST", f"/north-south-routers/{ROUTER_ID}/upgrade")

    def test_rolling_upgrade_rejects_wrong_intent_and_paused_journal(self):
        for changes in ({"successor_member": "a"}, {"target_runtime": "1:0"}, {"source_member": "b"}):
            self.run.api.json.return_value = self.receipt(**changes)
            with self.subTest(changes=changes), self.assertRaises(ha.CapabilityBlocked):
                self.run.rolling_upgrade("a", 3, {})
        self.run.api.json.return_value = self.receipt()
        self.run.router = mock.Mock(return_value={"ha_rolling_upgrade": {"phase": "handoff", "failure": "x"}})
        with self.assertRaisesRegex(RuntimeError, "paused"):
            self.run.rolling_upgrade("a", 3, {})

    def test_rolling_scenario_requires_target_versions_on_successor(self):
        target = self.run.state["rolling_targets"]
        self.run.state["rolling_package_sha256"] = "sha"
        report = {"passed": True, "fault": {"member": "a"}, "successor": {"member": "b"}}
        final = {"active_member": "b", "runtime_version": "2:1", "agent_version": "2:2",
                 "member_runtime_versions": {"a": "2:1", "b": "2:1"},
                 "member_agent_versions": {"a": "2:2", "b": "2:2"}}
        self.run.measure = mock.Mock(return_value=dict(report))
        self.run.router = mock.Mock(return_value=final)
        self.run.held_traffic = mock.Mock(return_value={"passed": True})
        self.run.rolling_scenario()
        self.assertEqual(self.run.measure.call_args.args, ("rolling", "rolling-upgrade", ha.ROLLING_HELD_SECONDS))
        self.assertEqual(target["runtime"], "2:1")
        self.run.measure.return_value = dict(report)
        self.run.router.return_value = {**final, "active_member": "a"}
        with self.assertRaisesRegex(RuntimeError, "successor"):
            self.run.rolling_scenario()

    def test_rolling_admission_requires_retained_lab_flows_and_baseline_before_changes(self):
        self.run.router = mock.Mock()
        with self.assertRaisesRegex(RuntimeError, "retained"):
            self.run.test_rolling_upgrade()
        self.run.state["cleanup_status"] = "retained"
        self.run.state["held_flow_cases"] = [{"protocol": "tcp"}, None]
        with self.assertRaisesRegex(RuntimeError, "held-flow"):
            self.run.test_rolling_upgrade()
        self.run.state["held_flow_cases"] = cases()
        ha.deployment.private_write(self.run.directory / "ha-report.json", {"passed": False, "scenarios": {}})
        with self.assertRaisesRegex(RuntimeError, "baseline"):
            self.run.test_rolling_upgrade()
        self.run.router.assert_not_called()

    def test_version_scope_requires_both_members_older(self):
        ha.require_rolling_version_scope({"a": "1:1", "b": "1:1"}, "1:2")
        for versions in ({"a": "1:2", "b": "1:1"}, {"a": "1:1"}, {"a": "", "b": "1:1"}):
            with self.subTest(versions=versions), self.assertRaises(ha.CapabilityBlocked):
                ha.require_rolling_version_scope(versions, "1:2")


class LifecycleTests(unittest.TestCase):
    STAGES = ("install", "create_router", "create_lab", "deploy_pair", "baseline_status",
              "planned_scenario", "replication_cut", "controller_cut", "crash_scenario", "cleanup")

    def lifecycle_run(self, state):
        run = ha.HARun.__new__(ha.HARun)
        run.state, run.directory = state, Path("/owned/evidence")
        run.save, run.close = mock.Mock(), mock.Mock()
        actions = []
        for name in self.STAGES:
            setattr(run, name, mock.Mock(side_effect=lambda name=name: actions.append(name)))
        run.stage = lambda name, operation: operation()
        return run, actions

    def test_harness_orders_all_pair_local_scenarios_then_cleanup(self):
        run, actions = self.lifecycle_run({})
        run.run_test()
        self.assertEqual(actions, list(self.STAGES))
        self.assertEqual(run.state["status"], "passed")
        run.close.assert_called_once()

    def test_retain_keeps_only_passing_lab(self):
        run, actions = self.lifecycle_run({"retain": True})
        with mock.patch("builtins.print"):
            run.run_test()
        self.assertEqual(actions, list(self.STAGES[:-1]))
        self.assertEqual(run.state["cleanup_status"], "retained")

    def test_blocked_runtime_retains_state_and_never_injects_fault(self):
        run, actions = self.lifecycle_run({})
        run.create_router.side_effect = ha.CapabilityBlocked("not implemented")
        with mock.patch("builtins.print"), self.assertRaises(ha.CapabilityBlocked):
            run.run_test()
        self.assertEqual(actions, ["install"])
        self.assertEqual(run.state["status"], "blocked")

    def test_report_passes_only_with_every_required_scenario(self):
        with tempfile.TemporaryDirectory() as directory:
            run = make_run(directory)
            for index, name in enumerate(ha.REQUIRED_SCENARIOS):
                run.record(name, {"passed": True})
                report = ha.read_config_object(run.directory / "ha-report.json")
                self.assertEqual(report["passed"], index == len(ha.REQUIRED_SCENARIOS) - 1)
            run.record("replication-cut", {"passed": False})
            self.assertFalse(ha.read_config_object(run.directory / "ha-report.json")["passed"])
            self.assertEqual((run.directory / "ha-report.json").stat().st_mode & 0o777, 0o600)

    def test_cli_rejects_removed_and_conflicting_flags(self):
        for argv in (["--production"], ["--test-counters", "--state", "x"], ["--after-abort"],
                     ["--max-replica-age", "5"], ["--planned-round-trip"], ["--peer-outage-seconds", "1"],
                     ["--test-partitions"], ["--cleanup", "--test-vip", "--state", "x"],
                     ["--retain", "--cleanup", "--state", "x"]):
            with self.subTest(argv=argv), mock.patch("sys.stderr", io.StringIO()), \
                    self.assertRaises(SystemExit):
                ha.main(argv)

    def test_saved_partitions_action_dispatches_to_retained_lab(self):
        with mock.patch.object(ha, "with_saved_run") as saved, mock.patch.object(ha, "automated_ssh_tofu"):
            self.assertEqual(ha.main(["--test-partitions", "--state", "/owned/state"]), 0)
        self.assertEqual(saved.call_args.kwargs["action_name"], "partitions")

    def test_saved_action_results_preserve_baseline_and_prior_errors(self):
        with tempfile.TemporaryDirectory() as directory:
            state = {"prefix": "sf-dr-" + "a" * 20, "config": "/owned/config.json",
                     "config_sha256": "digest", "controllers": ["owned"], "status": "passed"}
            with mock.patch.object(ha, "read_config_object", return_value=state), \
                    mock.patch.object(ha.deployment, "fingerprint", return_value="digest"), \
                    mock.patch.object(ha.deployment, "controller_inventory", return_value=["owned"]), \
                    mock.patch.object(ha.deployment, "ControllerAPI"), \
                    mock.patch.object(ha, "PlatformHealth"), \
                    mock.patch.object(ha, "HARun", return_value=mock.Mock()):
                with self.assertRaisesRegex(RuntimeError, "cut failed"):
                    ha.with_saved_run(Path(directory), mock.Mock(side_effect=RuntimeError("cut failed")),
                                      action_name="partitions")
                ha.with_saved_run(Path(directory), mock.Mock(), action_name="partitions")
        self.assertEqual(state["status"], "passed")
        self.assertEqual([record["status"] for record in state["saved_actions"]], ["failed", "passed"])

    def test_cleanup_resume_requires_absent_api_router_and_both_absent_physical_vms(self):
        for allow_retired, inventory, accepted in (
            (True, [], True), (False, [], False),
            (True, [{"vmid": ha.pair_identity(router())["a"]["vmid"]}], False),
        ):
            with self.subTest(allow_retired=allow_retired, inventory=inventory), \
                    tempfile.TemporaryDirectory() as directory:
                prefix = "sf-dr-" + "a" * 20
                state = {"prefix": prefix, "config": "/owned/config.json", "config_sha256": "digest",
                         "router_requested": prefix + "-nsr", "pair": ha.pair_identity(router()),
                         "controllers": ["owned"]}
                run = mock.Mock()
                run.proxmox.get.return_value = {"data": inventory}
                api = mock.Mock()
                api.json.return_value = []
                action = mock.Mock()
                with mock.patch.object(ha, "read_config_object", return_value=state), \
                        mock.patch.object(ha.deployment, "fingerprint", return_value="digest"), \
                        mock.patch.object(ha.deployment, "controller_inventory", return_value=["owned"]), \
                        mock.patch.object(ha.deployment, "ControllerAPI", return_value=api), \
                        mock.patch.object(ha, "HARun", return_value=run):
                    if accepted:
                        ha.with_saved_run(Path(directory), action, allow_retired=allow_retired,
                                          action_name="cleanup")
                        action.assert_called_once_with(run)
                    else:
                        with self.assertRaises(RuntimeError):
                            ha.with_saved_run(Path(directory), action, allow_retired=allow_retired,
                                              action_name="cleanup")
                        action.assert_not_called()

    def test_member_power_operations_require_owned_vm_and_confirm_result(self):
        with tempfile.TemporaryDirectory() as directory:
            run = make_run(directory)
        run.proxmox.get.side_effect = [{"data": {"name": "foreign", "ipconfig0": "ip=192.0.2.10/24"}}]
        with self.assertRaises(RuntimeError):
            run.power_member("a", "start")
        run.proxmox.post.assert_not_called()
        run.proxmox.get.side_effect = [
            {"data": {"name": ROUTER_ID + "-a", "ipconfig0": "ip=192.0.2.10/24"}},
            {"data": {"status": "running"}},
        ]
        with mock.patch.object(ha.deployment, "wait_task"):
            run.power_member("a", "start")
        run.proxmox.post.assert_called_once_with("/nodes/n1/qemu/100/status/start")
        self.assertEqual(run.state["power_events"][0]["member"], "a")

    def test_single_segment_workload_configures_one_attachment_without_wan_mutation(self):
        lab = ha.SingleSegmentLab.__new__(ha.SingleSegmentLab)
        lab.state = {"vms": [{"vmid": 200}], "segments": [{"id": 49100}], "router": "test-nsr",
                     "original_wan_policy": {}}
        lab.setup_serial, lab.request, lab.save = mock.Mock(), mock.Mock(), mock.Mock()
        lab.owned_segment = mock.Mock(return_value={"_version": 5})
        lab.configure()
        lab.request.assert_called_once_with(
            "PUT", "/segments/49100/north-south-router", {"router_id": "test-nsr", "_version": 5})
        self.assertNotIn("original_wan_policy", lab.state)

    def test_migrated_workload_location_is_persisted_only_after_identity_validation(self):
        lab = ha.SingleSegmentLab.__new__(ha.SingleSegmentLab)
        vm = {"vmid": 200, "node": "hunsn3", "name": "owned", "segment_id": 49100}
        lab.state = {"migration_events": [{"task": "owned"}],
                     "migration_nodes": ["hunsn3", "hunsn4", "hunsn5"], "run_id": "owned-run"}
        lab.save = mock.Mock()
        lab.proxmox = mock.Mock()
        lab.proxmox.get.side_effect = [
            {"data": [{"vmid": 200, "type": "qemu", "node": "hunsn4"}]},
            {"data": {"name": "owned", "description": "SwiftFabric live network lab owned-run",
                      "net0": "virtio=bc:24:11:00:00:11,bridge=sf-br49100"}},
        ]
        lab.vm_config(vm)
        self.assertEqual(vm["node"], "hunsn4")
        lab.save.assert_called_once()
        lab.proxmox.get.side_effect = [
            {"data": [{"vmid": 200, "type": "qemu", "node": "hunsn5"}]},
            {"data": {"name": "foreign"}},
        ]
        with self.assertRaisesRegex(RuntimeError, "ownership mismatch"):
            lab.vm_config(vm)
        self.assertEqual(vm["node"], "hunsn4")
        lab.proxmox.get.side_effect = [
            {"data": [{"vmid": 200, "type": "qemu", "node": "foreign"}]},
        ]
        with self.assertRaisesRegex(RuntimeError, "authorized migration nodes"):
            lab.vm_config(vm)


class WorkerTests(unittest.TestCase):
    def test_progress_and_final_results_saved_privately_without_socket_restart(self):
        with tempfile.TemporaryDirectory() as root:
            directory = Path(root) / "flows"

            def hold(case, *, progress):
                progress({"protocol": case["protocol"], "verified_responses": 8})
                return result(case)

            with mock.patch.object(worker, "hold_flow", side_effect=hold) as hold_mock:
                worker.run(cases(), directory)
            saved = json.loads((directory / "status.json").read_text())
            self.assertTrue(saved["completed"])
            self.assertEqual(set(saved["progress"]), {"tcp", "udp"})
            self.assertEqual(hold_mock.call_count, 2)
            self.assertEqual((directory / "status.json").stat().st_mode & 0o777, 0o600)
            with self.assertRaises(FileExistsError):
                worker.run(cases(), directory)


class SSHTrustTests(unittest.TestCase):
    def make_run(self, *, trusted=False, changed=False):
        run = ha.HARun.__new__(ha.HARun)
        value = router()
        run.router = mock.Mock(return_value=value)
        run.state = {"router_requested": value["id"], "pair": ha.pair_identity(value)}
        run.save = mock.Mock()
        run.api = mock.Mock()
        key = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        fingerprint = ha.deployment.SSHCommandRunner._fingerprint(key.split()[1])

        def response(method, path, body=None):
            physical = run.state["pair"][path[-1]]
            endpoint = f"[{ha.ipaddress.IPv4Interface(physical['management_address_cidr']).ip}]:22"
            record = {"endpoint": endpoint, "public_key": key, "fingerprint": fingerprint}
            if method == "GET":
                return {"endpoint": endpoint, "changed": changed, "observed": [record],
                        "trusted": record if trusted else None}
            self.assertEqual(body, {"endpoint": endpoint, "public_key": key})
            return {"approved": True, "trusted": record}

        run.api.json.side_effect = response
        return run

    def test_explicit_first_use_accepts_exact_owned_member_candidates(self):
        run = self.make_run()
        with mock.patch.dict(ha.os.environ, {"SWIFTFABRIC_INTEGRATION_TOFU": "1"}), \
                mock.patch("builtins.print"):
            run.trust_pair()
        self.assertEqual(set(run.state["guest_ssh_fingerprints"]), {"a", "b"})
        self.assertEqual([call.args[0] for call in run.api.json.call_args_list], ["GET", "POST", "GET", "POST"])

    def test_changed_pin_never_replaced(self):
        run = self.make_run(trusted=True, changed=True)
        with mock.patch.dict(ha.os.environ, {"SWIFTFABRIC_INTEGRATION_TOFU": "1"}), \
                self.assertRaises(ha.CapabilityBlocked):
            run.trust_pair()
        self.assertNotIn("guest_ssh_fingerprints", run.state)

    def test_first_use_requires_explicit_integration_session(self):
        run = self.make_run()
        with mock.patch.dict(ha.os.environ, {}, clear=True), self.assertRaises(ha.CapabilityBlocked):
            run.trust_pair()
        run.api.json.assert_not_called()


if __name__ == "__main__":
    unittest.main()
