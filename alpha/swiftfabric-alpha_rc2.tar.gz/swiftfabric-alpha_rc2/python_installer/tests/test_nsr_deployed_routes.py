import copy
import ipaddress
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tests_integration"))
import nsr_deployed_routes as gate


def observations():
    cases, results, events = [], [], []
    for offset, (protocol, port) in enumerate((("tcp", 18080), ("udp", 18081))):
        case = {
            "source": "10.253.242.10", "source_port": 30000 + offset,
            "destination": "198.51.100.10", "destination_port": port,
            "protocol": protocol, "expected": "allow",
        }
        cases.append(case)
        results.append({**case, "outcome": "allow", "passed": True, "probe_id": str(offset) * 64})
        events.append({
            **{key: value for key, value in case.items() if key != "expected"},
            "probe_id": str(offset) * 64, "stage": "received",
        })
    return cases, results, events


class DeployedRoutesTests(unittest.TestCase):
    def test_compute_auth_preflight_keeps_credentials_on_owned_nodes(self):
        run = Mock(config={"proxmox_ssh_key": "/private/key", "proxmox_ssh_user": "root"})
        run.lab.state = {"segments": [{"id": 49100}]}
        first = {"node": "host-a", "standby": {"node": "host-b"}}
        ssh = Mock()
        ssh.run.side_effect = [
            json.dumps({"host_id": node, "segment": 49100, "authenticated": True, "entries": 1})
            for node in ("host-a", "host-b")
        ]
        with patch.object(gate.ha.deployment, "SSHCommandRunner", return_value=ssh):
            receipts = gate.compute_auth_preflight(run, first)
        self.assertEqual(set(receipts), {"host-a", "host-b"})
        self.assertEqual([call.args[0] for call in ssh.run.call_args_list], ["host-a", "host-b"])
        self.assertIn("load_config", ssh.run.call_args.args[1])
        self.assertIn("client.list_macs(SEGMENT)", ssh.run.call_args.args[1])
        run.api.json.assert_not_called()
        ssh.run.side_effect = RuntimeError("HTTP 401 invalid bearer token")
        with patch.object(gate.ha.deployment, "SSHCommandRunner", return_value=ssh), \
                self.assertRaisesRegex(RuntimeError, "HTTP 401"):
            gate.compute_auth_preflight(run, first)

    def test_exact_nonce_and_unnatted_source_receipts_required(self):
        cases, results, events = observations()
        gate.validate_observations(cases, results, events)
        for field, value in (
            ("source", "198.18.255.2"), ("source_port", 50000),
            ("destination", "198.51.100.11"), ("destination_port", 2000), ("protocol", "udp"),
        ):
            changed = copy.deepcopy(events)
            changed[0][field] = value
            with self.subTest(field=field), self.assertRaisesRegex(RuntimeError, "NATed|wrong destination"):
                gate.validate_observations(cases, results, changed)

    def test_missing_duplicate_or_unrelated_destination_receipt_rejected(self):
        cases, results, events = observations()
        for changed in (events[1:], [*events, events[0]], [{**events[0], "probe_id": "f" * 64}, events[1]]):
            with self.subTest(events=changed), self.assertRaisesRegex(RuntimeError, "unique destination receipt"):
                gate.validate_observations(cases, results, changed)

    def test_forged_or_partial_result_shapes_rejected(self):
        cases, results, events = observations()
        for field, value in (
            ("outcome", "drop"), ("passed", False), ("probe_id", ""),
            ("source", "10.253.242.11"), ("expected", "drop"),
        ):
            changed = copy.deepcopy(results)
            changed[0][field] = value
            with self.subTest(field=field), self.assertRaises(RuntimeError):
                gate.validate_observations(cases, changed, events)
        with self.assertRaisesRegex(RuntimeError, "exact distinct TCP/UDP"):
            gate.validate_observations(cases, results[:1], events)

    def test_deny_requires_actual_drop_not_closed_port_or_forged_success(self):
        cases, results, _ = observations()
        cases = [{**case, "expected": "drop"} for case in cases]
        results = [{**case, "outcome": "drop", "passed": True} for case in cases]
        gate.validate_observations(cases, results, [])
        for outcome in ("allow", "error"):
            with self.subTest(outcome=outcome), self.assertRaisesRegex(RuntimeError, "ACL decision"):
                gate.validate_observations(cases, [{**results[0], "outcome": outcome}, results[1]], [])

    def test_route_selects_explicit_peer_interface(self):
        peer = {"wan_address_cidr": "198.18.255.3/29", "vtep_ip": "172.20.0.4"}
        remote = ipaddress.IPv4Network("198.51.100.0/24")
        for transport, hop in (("wan", "198.18.255.3"), ("private", "172.20.0.4")):
            self.assertEqual(gate.route(peer, remote, transport), {
                "destination_cidr": str(remote), "next_hop": hop, "interface": transport, "metric": 100,
            })

    def test_policy_never_grants_nat_or_unrequested_direction(self):
        local, remote = "10.253.242.0/24", "198.51.100.0/24"
        for egress in (False, True):
            for ingress in (False, True):
                policy = gate.policy(local, remote, egress, ingress)
                self.assertEqual(set(policy), set(gate.ha.networking.POLICY_KEYS))
                self.assertEqual(len(policy["wan_egress_rules"]), 2 * egress)
                self.assertEqual(len(policy["wan_ingress_rules"]), 2 * ingress)
                for key in ("masquerade_source_cidrs", "inbound_port_mappings", "outbound_port_mappings"):
                    self.assertEqual(policy[key], [])

    def test_policy_update_checks_previous_policy_and_version_before_mutation(self):
        old = gate.policy("10.253.242.0/24", "198.51.100.0/24", False, False)
        desired = gate.policy("10.253.242.0/24", "198.51.100.0/24", True, True)
        lab = Mock(state={"router": "owned", "expected_wan_policy": old})
        lab.request.side_effect = [{**old, "_version": 7}, desired]
        gate.set_policy(lab, desired)
        self.assertEqual(lab.request.call_args.args,
                         ("PUT", "/north-south-routers/owned/wan-policy", {**desired, "_version": 7}))
        self.assertEqual(lab.state["expected_wan_policy"], desired)
        lab.save.assert_called_once()
        lab = Mock(state={"router": "owned", "expected_wan_policy": old})
        lab.request.return_value = {**desired, "_version": 8}
        with self.assertRaisesRegex(RuntimeError, "changed outside"):
            gate.set_policy(lab, desired)
        self.assertEqual(lab.request.call_count, 1)

    def test_allocation_rejects_reserved_benchmark_and_public_networks(self):
        run = Mock()
        run.api.json.return_value = [{"wan_address_cidr": "45.78.183.60/29"}]
        run.lab.network_inventory.return_value = ([], [ipaddress.ip_network("10.253.242.0/24")])
        wan, networks, ids = gate.allocation(run)
        self.assertEqual(str(wan), "198.18.255.0/29")
        self.assertEqual([str(item) for item in networks], ["10.253.241.0/24", "198.51.100.0/24"])
        self.assertEqual(ids, [49101, 49102])
        for network in ("198.18.255.0/24", "198.51.100.0/24"):
            run.lab.network_inventory.return_value = ([], [ipaddress.ip_network(network)])
            with self.subTest(network=network), self.assertRaisesRegex(RuntimeError, "already in use"):
                gate.allocation(run)

    def test_partial_creation_failure_journals_original_error_and_cleans_owned_records(self):
        run = Mock(directory=Path("/owned"), state={"prefix": "sf-dr-owned"})
        first = {
            "wan_bridge": "vmbr0", "wan_vlan_id": 4000, "node": "host-a",
            "standby": {"node": "host-b"},
        }
        run.router.return_value = first
        run.api.json.side_effect = RuntimeError("controller unavailable")
        report = {"transports": {}}
        with patch.object(gate, "allocation", return_value=(
            ipaddress.ip_network("198.18.255.0/29"),
            (ipaddress.ip_network("10.253.242.0/24"), ipaddress.ip_network("198.51.100.0/24")),
            [49101, 49102],
        )), patch.object(gate, "management_addresses", return_value=["172.16.255.254/24", "172.16.255.253/24"]), \
                patch.object(gate.endpoints, "cleanup") as cleanup, \
                self.assertRaisesRegex(RuntimeError, "controller unavailable"):
            gate.run_transport(run, "wan", report, Mock())
        scope = report["transports"]["wan"]
        self.assertFalse(scope["passed"])
        self.assertEqual(scope["error"], "RuntimeError: controller unavailable")
        self.assertEqual(scope["cleanup_errors"], [])
        record, = run.state["second_endpoint_runs"]
        cleanup.assert_called_once_with(run, record)
        self.assertEqual(record["purpose"], "static-routes")
        run.save.assert_called_once()

    def test_guest_diagnostics_reuse_exact_pinned_controller_side_transport(self):
        run = Mock()
        record = {"router_id": "owned", "network": "10.253.242.0/24",
                  "remote_network": "198.51.100.0/24", "segment_id": 49101}
        physical = {"node": "host-a", "vmid": 142, "management_address_cidr": "172.16.255.8/24",
                    "vtep_ip": "172.16.25.9"}
        trusted = {"endpoint": "[172.16.255.8]:22", "public_key": "ssh-ed25519 AAAA",
                   "fingerprint": "SHA256:test"}
        run.api.json.return_value = {"changed": False, "trusted": trusted, "observed": [trusted]}
        with patch.object(gate.endpoints, "owned_router", return_value={**physical, "status": "active"}), \
                patch.object(gate.ha.deployment.SSHCommandRunner, "_fingerprint", return_value="SHA256:test"), \
                patch.object(gate.ha, "execute_owned_guest", return_value="### routes\n[]\n") as execute:
            self.assertEqual(gate.guest_diagnostics(run, record), {"output": "### routes\n[]\n"})
        self.assertEqual(execute.call_args.args[:5], (run, "owned", "a", physical, "SHA256:test"))
        program = execute.call_args.args[5]
        self.assertNotIn("python", program)
        self.assertIn("ip -n sf-router -j -4 route show table all", program)
        self.assertIn("route get 198.51.100.10 from 10.253.242.10 iif sf-br49101", program)
        self.assertNotIn('"replace"', program)
        self.assertNotIn('"flush"', program)
        self.assertEqual([call.args[0] for call in run.api.json.call_args_list], ["GET"])

    def test_diagnostic_management_allocation_never_reuses_previous_guest_endpoints(self):
        run = Mock(state={"second_endpoint_runs": [
            {"management_address_cidr": "172.16.255.254/24", "cleanup_complete": True},
        ]})
        run.api.json.side_effect = [
            {"network": {"start_ip": "172.16.255.250", "end_ip": "172.16.255.254", "prefix_len": 24},
             "reserved": ["172.16.255.250"]},
            [{"management_address_cidr": "172.16.255.253/24",
              "standby": {"management_address_cidr": "172.16.255.252/24"}}],
        ]
        with self.assertRaisesRegex(RuntimeError, "existing SSH pins left intact"):
            gate.management_addresses(run)
        run.api.json.side_effect = [
            {"network": {"start_ip": "172.16.255.249", "end_ip": "172.16.255.254", "prefix_len": 24},
             "reserved": ["172.16.255.250"]},
            [{"management_address_cidr": "172.16.255.253/24",
              "standby": {"management_address_cidr": "172.16.255.252/24"}}],
        ]
        self.assertEqual(gate.management_addresses(run), ["172.16.255.251/24", "172.16.255.249/24"])
    def test_guest_diagnostics_refuse_changed_or_mismatched_host_key(self):
        physical = {"node": "host-a", "vmid": 142, "management_address_cidr": "172.16.255.8/24",
                    "vtep_ip": "172.16.25.9", "status": "active"}
        trusted = {"endpoint": "[172.16.255.8]:22", "public_key": "ssh-ed25519 AAAA",
                   "fingerprint": "SHA256:test"}
        for candidate in (
            {"changed": True, "trusted": trusted, "observed": [trusted]},
            {"changed": False, "trusted": {**trusted, "fingerprint": "wrong"}, "observed": [trusted]},
            {"changed": False, "trusted": {**trusted, "endpoint": "[172.16.255.9]:22"}, "observed": [trusted]},
        ):
            run = Mock()
            run.api.json.return_value = candidate
            with self.subTest(candidate=candidate), \
                    patch.object(gate.endpoints, "owned_router", return_value=physical), \
                    patch.object(gate.ha.deployment.SSHCommandRunner, "_fingerprint", return_value="SHA256:test"), \
                    patch.object(gate.ha, "execute_owned_guest") as execute:
                with self.assertRaisesRegex(RuntimeError, "host key"):
                    gate.guest_diagnostics(run, {"router_id": "owned"})
                execute.assert_not_called()
                self.assertEqual([call.args[0] for call in run.api.json.call_args_list], ["GET"])


if __name__ == "__main__":
    unittest.main()
