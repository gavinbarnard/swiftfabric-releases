import contextlib
import copy
import io
import ipaddress
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tests_integration"))
import nsr_two_endpoint as gate


PROFILE = {
    "remote_endpoint": "198.51.100.59", "tcp_port": 2000, "udp_port": 2001,
    "wan_bridge": "vmbr0", "wan_ip": "198.51.100.58/29",
    "wan_upstream_router": "198.51.100.57", "wan_vlan": "4000",
}


def observations(count=220):
    groups = {}
    for label, nat, port in (
        ("first-masquerade", "198.51.100.60", 30000),
        ("second-masquerade", "198.51.100.58", 42000),
        ("second-fixed-snat", "198.51.100.58", 43000),
    ):
        cases = gate.cases({"address": "10.253.243.10"}, PROFILE, nat, port)
        results = []
        for index, case in enumerate(cases):
            external = 53000 + index if label == "second-fixed-snat" else case["source_port"]
            samples = [
                {"sequence": number, "sent_seconds": (number + 1) * 90 / (count + 1) - 0.01,
                 "received_seconds": (number + 1) * 90 / (count + 1), "peer": [nat, external]}
                for number in range(count)
            ]
            results.append({
                **gate.ha.networking.held_summary(case, samples, 90, ""),
                "connected": True, "requests": count, "application_bytes_sent": count * 64,
                "application_bytes_received": count * 128, "started_epoch": 1, "started_monotonic": 1,
            })
        groups[label] = {"cases": cases, "results": results}
    return groups


class TwoEndpointGateTests(unittest.TestCase):
    def test_retained_upgrade_uses_supported_api_and_exact_versions(self):
        run = Mock()
        record = {"router_id": "owned"}
        first = {"current_runtime_version": "new", "current_agent_version": "agent"}
        old = {"status": "active", "runtime_version": "old", "agent_version": "agent"}
        current = {**old, "runtime_version": "new", "upgrade_in_progress": False}
        run.api.json.return_value = {"upgrade_started": True}
        with patch.object(gate, "owned_router", side_effect=[
                old, {**old, "upgrade_in_progress": True}, current]), patch.object(gate.time, "sleep"):
            self.assertEqual(gate.upgrade_retained(run, record, first), current)
        run.api.json.assert_called_once_with("POST", "/north-south-routers/owned/upgrade")
        run.api.json.reset_mock()
        with patch.object(gate, "owned_router", return_value=current):
            self.assertEqual(gate.upgrade_retained(run, record, first), current)
        run.api.json.assert_not_called()
        with patch.object(gate, "owned_router", side_effect=[old, old]), \
                self.assertRaisesRegex(RuntimeError, "exact target"):
            gate.upgrade_retained(run, record, first)

    def test_retained_reverification_preserves_resources_even_on_failure(self):
        for fails in (False, True):
            with self.subTest(fails=fails), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary)
                directory = root / "two-endpoint-1234567890abcdef"
                directory.mkdir()
                record = {
                    "router_id": "owned-nsr2-12345678", "tenant_id": "tenant-owned",
                    "tenant_name": "owned-tenant2-12345678", "endpoint": PROFILE,
                    "lab_directory": str(directory), "retained": True, "cleanup_complete": False,
                }
                run = Mock(directory=root, state={
                    "prefix": "owned", "config": "saved", "second_endpoint_runs": [record],
                })
                first = {"current_runtime_version": "new", "current_agent_version": "agent"}
                run.router.return_value = first
                router = {
                    "id": record["router_id"], "tenant_id": record["tenant_id"], "vmid": 133,
                    "status": "active", "runtime_version": "new", "agent_version": "agent",
                }
                second = Mock(state={
                    "router": record["router_id"], "config": "saved", "ready": True,
                    "vms": [{"vmid": 140}],
                })

                def measure(*args):
                    if fails:
                        raise RuntimeError("actual NAT proof failed")
                    args[4]["measurements_passed"] = True

                with patch.object(gate.ha, "require_pair"), \
                        patch.object(gate, "protected", return_value=True), \
                        patch.object(gate, "inspect_protected_guests", return_value={}), \
                        patch.object(gate, "SecondEndpointLab", return_value=second), \
                        patch.object(gate, "owned_router", return_value=router), \
                        patch.object(gate, "measure_nat", side_effect=measure) as measured, \
                        patch.object(gate, "cleanup") as cleanup, \
                        patch.object(gate, "upgrade_retained") as upgrade, \
                        contextlib.redirect_stdout(io.StringIO()):
                    if fails:
                        with self.assertRaisesRegex(RuntimeError, "actual NAT"):
                            gate.run_retained(run)
                    else:
                        gate.run_retained(run)
                cleanup.assert_not_called()
                upgrade.assert_not_called()
                second.destroy.assert_not_called()
                run.api.json.assert_not_called()
                measured.assert_called_once()
                second.api.close.assert_called_once()
                report = json.loads(next(root.glob("two-endpoint-retained-*-report.json")).read_text())
                self.assertEqual(report["passed"], not fails)
                self.assertTrue(report["resources_retained"])
                self.assertTrue(record["retained"])
                self.assertFalse(record["cleanup_complete"])

    def test_retained_reverification_rejects_pending_cleanup_and_unowned_directory(self):
        record = {"retained": True, "cleanup_complete": False, "lab_directory": "/foreign/two-endpoint-1234567890abcdef"}
        run = Mock(directory=Path("/owned"), state={"prefix": "owned", "second_endpoint_runs": [record]})
        with self.assertRaisesRegex(RuntimeError, "ownership changed"):
            gate.run_retained(run)
        run.state["second_endpoint_runs"].append({"cleanup_complete": False})
        with self.assertRaisesRegex(RuntimeError, "exactly one"):
            gate.run_retained(run)
        run.api.json.assert_not_called()
        run.router.assert_not_called()

    def test_cli_retained_reverification_uses_journal_not_changed_profile(self):
        with patch.object(gate.ha, "with_saved_run") as saved, \
                patch.object(gate.ha, "automated_ssh_tofu", return_value=contextlib.nullcontext()), \
                patch.object(gate.ha, "read_config_object") as read, \
                patch.object(gate, "run_retained") as retained:
            gate.main(["--state", "/owned", "--verify-retained", "--upgrade-retained"])
            run = Mock()
            saved.call_args.args[1](run)
            retained.assert_called_once_with(run, upgrade=True)
            read.assert_not_called()
        for flags in (
            ["--upgrade-retained"], ["--verify-retained", "--cleanup"],
            ["--verify-retained", "--retain-on-success"],
        ):
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                gate.main(["--state", "/owned", *flags])

    def test_shared_standalone_request_never_inherits_ha_member_state(self):
        first = {
            key: [] if key in ("management_dns", "management_allowlist") else key
            for key in ("cluster", "image_storage", "image_volume", "management_bridge",
                        "management_vlan_id", "management_gateway", "management_dns",
                        "management_allowlist", "vtep_bridge", "vtep_vlan_id")
        }
        first.update(deployment_mode="active-standby", standby={"node": "host-b"}, vmid=112)
        record = {"router_id": "owned", "tenant_id": "tenant-owned", "endpoint": PROFILE}
        policy = {key: [] for key in gate.ha.networking.POLICY_KEYS}
        request = gate.standalone_request(first, record, "host-b", policy)
        self.assertEqual(request["deployment_mode"], "standalone")
        self.assertEqual(request["ha_replication_mode"], "standalone")
        self.assertEqual(request["wan_address_cidr"], PROFILE["wan_ip"])
        self.assertEqual(request["management_address_cidr"], "")
        self.assertNotIn("standby", request)
        self.assertNotIn("vmid", request)
        request["management_dns"].append("192.0.2.1")
        self.assertEqual(first["management_dns"], [])

    def test_workload_state_snapshots_static_routes_without_changing_primary(self):
        run = Mock(state={"config": "/owned/config"}, lab=Mock(state={"image_volume": "local:cloud.qcow2"}))
        record = {"router_id": "owned", "tenant_id": "tenant-owned", "endpoint": PROFILE}
        routes = [{"destination_cidr": "198.51.100.0/24", "next_hop": "192.0.2.4",
                   "interface": "private", "metric": 100}]
        router = {"id": "owned", "name": "owned", "vmid": 133, "tenant_id": "tenant-owned",
                  "static_routes": routes}
        state = gate.workload_state(run, record, router, "host-b", ipaddress.ip_network("10.253.243.0/24"),
                                    49101, {key: [] for key in gate.ha.networking.POLICY_KEYS})
        self.assertEqual(state["expected_static_routes"], routes)
        self.assertIsNot(state["expected_static_routes"], routes)
        self.assertEqual(state["segments"][0]["gateway_cidr"], "10.253.243.1/24")
        self.assertEqual(state["nodes"], ["host-b"])
        self.assertEqual(state["router_identity"]["vmid"], 133)
        self.assertEqual(run.state, {"config": "/owned/config"})

    def test_profile_normalizes_vlan_and_validates_actual_network(self):
        self.assertEqual(gate.endpoint_configuration(PROFILE)["wan_vlan"], 4000)
        for key, value in (
            ("wan_ip", "198.51.100.56/29"), ("wan_ip", "198.51.100.59/29"),
            ("wan_upstream_router", "198.51.100.56"), ("wan_upstream_router", "198.51.100.63"),
            ("wan_upstream_router", "198.51.100.65"), ("remote_endpoint", "127.0.0.1"),
            ("remote_endpoint", 1), ("tcp_port", True), ("udp_port", 0), ("wan_vlan", True),
            ("wan_vlan", 4095), ("wan_bridge", "bridge;false"),
        ):
            with self.subTest(key=key, value=value), self.assertRaises((RuntimeError, ValueError)):
                gate.endpoint_configuration({**PROFILE, key: value})

    def test_exact_six_real_result_shapes_and_minimum_200_responses(self):
        gate.validate_results(observations(200))
        with self.assertRaisesRegex(RuntimeError, "held-flow acceptance"):
            gate.validate_results(observations(199))

    def test_missing_workload_or_duplicate_protocol_rejected(self):
        groups = observations()
        del groups["second-fixed-snat"]
        with self.assertRaisesRegex(RuntimeError, "all three"):
            gate.validate_results(groups)
        groups = observations()
        group = groups["second-masquerade"]
        group["cases"][1] = copy.deepcopy(group["cases"][0])
        group["results"][1] = copy.deepcopy(group["results"][0])
        with self.assertRaisesRegex(RuntimeError, "distinct TCP/UDP"):
            gate.validate_results(groups)

    def test_forged_summary_gap_nat_and_fixed_port_rejected(self):
        for change in ("summary", "gap", "nat", "port"):
            groups = observations()
            group = groups["second-fixed-snat"]
            result = group["results"][0]
            samples = copy.deepcopy(result["samples"])
            if change == "summary":
                result["observed_peers"] = [["198.51.100.58", 53001]]
            else:
                if change == "gap":
                    samples = samples[15:]
                elif change == "nat":
                    for sample in samples:
                        sample["peer"][0] = "198.51.100.60"
                else:
                    for sample in samples:
                        sample["peer"][1] = 54000
                group["results"][0] = {
                    **result, **gate.ha.networking.held_summary(group["cases"][0], samples, 90, ""),
                }
            with self.subTest(change=change), self.assertRaises((RuntimeError, ValueError)):
                gate.validate_results(groups)

    def test_cleanup_refuses_foreign_router_before_any_delete(self):
        run = Mock()
        run.api.json.return_value = [{
            "id": "owned", "name": "owned", "tenant_id": "foreign",
            "wan_address_cidr": PROFILE["wan_ip"], "deployment_mode": "standalone",
        }]
        with self.assertRaisesRegex(RuntimeError, "identity changed"):
            gate.owned_router(run, {
                "router_id": "owned", "tenant_id": "ours", "endpoint": PROFILE,
            })
        self.assertEqual([call.args[0] for call in run.api.json.call_args_list], ["GET"])

    def test_cleanup_only_deletes_owned_resources_and_journals_completion(self):
        with tempfile.TemporaryDirectory() as temporary:
            run = Mock(directory=Path(temporary), state={"prefix": "owned"})
            record = {
                "router_id": "owned-nsr2-12345678", "tenant_id": "tenant-owned",
                "tenant_name": "owned-tenant2-12345678", "endpoint": PROFILE,
                "lab_directory": str(Path(temporary) / "two-endpoint-1234567890abcdef"),
                "segment_id": 49101,
            }
            retired = []

            @contextlib.contextmanager
            def retiring(ports):
                retired.append(set(ports))
                yield
                self.assertTrue(record.get("cleanup_complete") is not True)

            run.platform_health.retiring = retiring
            router = {
                "id": record["router_id"], "name": record["router_id"], "tenant_id": record["tenant_id"],
                "wan_address_cidr": PROFILE["wan_ip"], "deployment_mode": "standalone", "_version": 2,
            }
            tenant = {"id": record["tenant_id"], "name": record["tenant_name"], "_version": 3}
            run.api.json.side_effect = [[router], {}, [], [tenant], {}, []]
            gate.cleanup(run, record)
            self.assertTrue(record["cleanup_complete"])
            deletes = [call.args[1] for call in run.api.json.call_args_list if call.args[0] == "DELETE"]
            self.assertEqual(deletes, [
                "/north-south-routers/owned-nsr2-12345678?_version=2", "/tenants/tenant-owned?_version=3",
            ])
            run.save.assert_called_once()
            self.assertEqual(retired, [{49101}])

    def test_failed_cleanup_stays_resumable(self):
        with tempfile.TemporaryDirectory() as temporary:
            run = Mock(directory=Path(temporary), state={"prefix": "owned"})
            record = {
                "router_id": "owned-nsr2-12345678", "tenant_id": "tenant-owned",
                "tenant_name": "owned-tenant2-12345678", "endpoint": PROFILE,
                "lab_directory": str(Path(temporary) / "two-endpoint-1234567890abcdef"),
                "cleanup_complete": False,
            }
            run.platform_health = None
            run.api.json.side_effect = RuntimeError("controller unavailable")
            with self.assertRaisesRegex(RuntimeError, "controller unavailable"):
                gate.cleanup(run, record)
            self.assertFalse(record["cleanup_complete"])
            run.save.assert_not_called()

    def test_whole_lab_cleanup_blocks_unfinished_secondary_resources(self):
        run = gate.ha.HARun.__new__(gate.ha.HARun)
        run.state = {"second_endpoint_runs": [{"cleanup_complete": False}]}
        with patch.object(gate.ha.deployment.RecoveryRun, "cleanup") as original:
            with self.assertRaisesRegex(RuntimeError, "nsr_two_endpoint.py --cleanup"):
                run.cleanup()
            original.assert_not_called()
            run.state["second_endpoint_runs"][0]["cleanup_complete"] = True
            run.cleanup()
            original.assert_called_once()

    def test_retention_requires_successful_measurements_and_probe_cleanup(self):
        for retain, passed, errors, expected_retention in (
            (False, True, [], False), (True, False, [], False),
            (True, True, ["probe stop failed"], False), (True, True, [], True),
        ):
            with self.subTest(retain=retain, passed=passed, errors=errors):
                run = Mock()
                record = {"cleanup_complete": False}
                report = {"measurements_passed": passed, "cleanup_errors": errors}
                with patch.object(gate, "cleanup") as cleanup, \
                        patch.object(gate, "owned_router", return_value={"id": "owned"}) as owned:
                    gate.finish_resources(run, record, report, retain=retain)
                self.assertEqual(report["resources_retained"], expected_retention)
                self.assertEqual(record.get("retained", False), expected_retention)
                self.assertFalse(record["cleanup_complete"])
                self.assertEqual(run.save.call_count, int(expected_retention))
                self.assertEqual(owned.call_count, int(expected_retention))
                self.assertEqual(cleanup.call_count, int(not expected_retention))

    def test_retention_refuses_missing_or_changed_router(self):
        for failure in (None, RuntimeError("identity changed")):
            with self.subTest(failure=failure):
                run = Mock()
                record = {"cleanup_complete": False}
                report = {"measurements_passed": True, "cleanup_errors": []}
                with patch.object(gate, "owned_router", return_value=None,
                                  side_effect=failure), patch.object(gate, "cleanup") as cleanup:
                    with self.assertRaisesRegex(RuntimeError, "disappeared|identity changed"):
                        gate.finish_resources(run, record, report, retain=True)
                run.save.assert_not_called()
                cleanup.assert_not_called()
                self.assertNotIn("retained", record)
                self.assertNotIn("resources_retained", report)

    def test_cli_retention_is_explicit_and_incompatible_with_cleanup(self):
        with patch.object(gate.ha, "with_saved_run") as saved, \
                patch.object(gate.ha, "automated_ssh_tofu", return_value=contextlib.nullcontext()), \
                patch.object(gate.ha, "read_config_object", return_value=PROFILE), \
                patch.object(gate, "run_gate") as run_gate:
            run = Mock()
            saved.side_effect = lambda state, action, **kwargs: action(run)
            for flag, retain in (([], False), (["--retain-on-success"], True)):
                self.assertEqual(gate.main(["--state", "/owned", *flag]), 0)
                run_gate.assert_called_with(run, gate.endpoint_configuration(PROFILE), retain=retain)
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as failure:
                gate.main(["--state", "/owned", "--cleanup", "--retain-on-success"])
            self.assertEqual(failure.exception.code, 2)

    def test_probe_status_uses_explicit_second_lab_without_changing_primary(self):
        run = gate.ha.HARun.__new__(gate.ha.HARun)
        run.lab = Mock()
        second = Mock()
        second.setup_serial.return_value = '{"completed": true}'
        self.assertEqual(run.probe_status({"vmid": 123}, "/owned", lab=second), {"completed": True})
        second.setup_serial.assert_called_once()
        run.lab.setup_serial.assert_not_called()

    def test_failed_gate_persists_original_error_and_cleanup_failure(self):
        for cleanup_failure in (False, True):
            with self.subTest(cleanup_failure=cleanup_failure), tempfile.TemporaryDirectory() as temporary:
                run = Mock(directory=Path(temporary), state={
                    "prefix": "owned", "held_flow_cases": gate.cases(
                        {"address": "10.253.244.10"}, PROFILE, "198.51.100.60", 30000,
                    ),
                })
                run.router.return_value = {"wan_address_cidr": "198.51.100.60/29"}
                run.api.json.return_value = [{"wan_address_cidr": "198.51.100.60/29"}]
                run.lab.network_inventory.side_effect = RuntimeError("subnet unavailable")
                with patch.object(gate.ha, "require_pair"), patch.object(gate, "protected", return_value=True), \
                        patch.object(gate, "inspect_protected_guests", return_value={}), \
                        patch.object(gate, "cleanup", side_effect=(
                            RuntimeError("cleanup unavailable") if cleanup_failure else None
                        )) as cleanup, contextlib.redirect_stdout(io.StringIO()), \
                        self.assertRaisesRegex(RuntimeError, (
                            "cleanup incomplete" if cleanup_failure else "subnet unavailable"
                        )):
                    gate.run_gate(run, gate.endpoint_configuration(PROFILE), retain=True)
                cleanup.assert_called_once()
                report_path, = Path(temporary).glob("two-endpoint-nat-*-report.json")
                report = json.loads(report_path.read_text())
                self.assertFalse(report["passed"])
                self.assertEqual(report["error"], "RuntimeError: subnet unavailable")
                self.assertEqual(bool(report["cleanup_errors"]), cleanup_failure)
                self.assertEqual(report_path.stat().st_mode & 0o777, 0o600)


class EgressReadinessTests(unittest.TestCase):
    def test_command_retries_tcp_connect_to_remote_endpoint(self):
        command = gate.egress_ready_command(PROFILE, seconds=7)
        self.assertTrue(command.startswith("python3 -c "))
        program = gate.shlex.split(command)[2]
        compile(program, "<ready>", "exec")
        self.assertIn("('198.51.100.59',2000)", program)
        self.assertIn("time.monotonic()+7", program)
        self.assertIn("raise", program)

    def test_wait_uses_bounded_serial_command(self):
        lab = Mock()
        elapsed = gate.wait_egress_ready(lab, {"vmid": 1}, PROFILE)
        lab.serial.assert_called_once_with(
            {"vmid": 1}, gate.egress_ready_command(PROFILE),
            timeout=gate.ATTACH_READY_SECONDS + 60,
        )
        self.assertGreaterEqual(elapsed, 0)


if __name__ == "__main__":
    unittest.main()
