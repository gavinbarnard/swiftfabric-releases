#!/usr/bin/env python3
"""Use a retained owned HA lab and nsr2.json for simultaneous two-tenant NAT proof.

Creates a standalone second NSR, tenant, segment and workload VM.
Leaves the first pair and its policy unchanged. By default all added resources
are cleaned after either result. --retain-on-success keeps a passing endpoint
for inspection; --cleanup removes retained resources or resumes failed cleanup.
--verify-retained repeats NAT proof without replacing retained resources;
--upgrade-retained first requests the supported standalone software upgrade.
Deployed public/private routes are covered by nsr_deployed_routes.py.
"""

import argparse
import contextlib
import copy
import fcntl
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import shlex
import time
import uuid

import nsr_ha as ha
from nsr_ha import inspect_protected_guests, protected


def require(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def endpoint_configuration(raw):
    fields = {"remote_endpoint", "tcp_port", "udp_port", "wan_bridge",
              "wan_ip", "wan_upstream_router", "wan_vlan"}
    require(isinstance(raw, dict) and set(raw) == fields, "invalid second endpoint configuration fields")
    require(all(isinstance(raw[key], str) for key in
                ("wan_ip", "wan_upstream_router", "remote_endpoint")), "invalid endpoint address fields")
    wan = ipaddress.IPv4Interface(raw["wan_ip"])
    gateway = ipaddress.IPv4Address(raw["wan_upstream_router"])
    endpoint = ipaddress.IPv4Address(raw["remote_endpoint"])
    require(wan.ip not in (wan.network.network_address, wan.network.broadcast_address)
            and gateway in wan.network and gateway != wan.ip
            and gateway not in (wan.network.network_address, wan.network.broadcast_address),
            "invalid second endpoint WAN/gateway")
    require(all(not (address.is_multicast or address.is_unspecified or address.is_loopback
                     or address.is_link_local or address.is_reserved)
                for address in (wan.ip, gateway, endpoint)) and endpoint != wan.ip,
            "second endpoint addresses must be unicast")
    require(isinstance(raw["wan_bridge"], str)
            and re.fullmatch(r"[A-Za-z0-9_.-]{1,15}", raw["wan_bridge"]), "invalid WAN bridge")
    require(all(type(raw[key]) is int and 1 <= raw[key] <= 65535
                for key in ("tcp_port", "udp_port")), "invalid endpoint TCP/UDP ports")
    vlan = raw["wan_vlan"]
    require(vlan is None or type(vlan) is int or (isinstance(vlan, str) and vlan.isdecimal()),
            "invalid WAN VLAN")
    vlan = None if vlan is None else int(vlan)
    require(vlan is None or 1 <= vlan <= 4094, "invalid WAN VLAN")
    return {**raw, "wan_ip": str(wan), "wan_upstream_router": str(gateway),
            "remote_endpoint": str(endpoint), "wan_vlan": vlan}


def cases(vm, endpoint, nat, source_port):
    return [
        {"source": vm["address"], "source_port": source_port + index,
         "destination": endpoint["remote_endpoint"], "destination_port": endpoint[key],
         "protocol": protocol, "duration_seconds": 90, "expected_nat_address": nat,
         "echo_format": "observed-peer"}
        for index, (protocol, key) in enumerate((("tcp", "tcp_port"), ("udp", "udp_port")))
    ]


def validate_results(groups):
    require(set(groups) == {"first-masquerade", "second-masquerade", "second-fixed-snat"},
            "NAT proof must cover all three independent TCP/UDP workloads")
    addresses = {}
    for label, group in groups.items():
        expected, results = group["cases"], group["results"]
        require(len(expected) == len(results) == 2, "NAT proof lacks both original sockets")
        require({case["protocol"] for case in expected} == {"tcp", "udp"},
                "NAT proof requires distinct TCP/UDP sockets")
        expected = sorted(expected, key=lambda case: case["protocol"])
        results = sorted(results, key=lambda result: result["protocol"])
        ha.networking.validate_held_results(expected, results)
        addresses[label] = {case["expected_nat_address"] for case in expected}
        for case, result in zip(expected, results):
            require(len(result["samples"]) >= 200
                    and not result["error"] and not result["failures"]
                    and result["max_response_gap_seconds"] <= 5,
                    f"{label}/{case['protocol']} failed stable held-flow acceptance")
            require(len(result["observed_peers"]) == 1
                    and result["observed_peers"][0][0] == case["expected_nat_address"],
                    "unexpected or unstable observed NAT source")
            if label == "second-fixed-snat":
                index = 0 if case["protocol"] == "tcp" else 1
                require(result["observed_peers"][0][1] == 53000 + index,
                        "fixed outbound NAT source port was not observed")
    require(len(addresses["first-masquerade"]) == len(addresses["second-masquerade"]) == 1
            and addresses["first-masquerade"].isdisjoint(addresses["second-masquerade"])
            and addresses["second-fixed-snat"] == addresses["second-masquerade"],
            "NAT proof does not distinguish both public endpoints")


class SecondEndpointLab(ha.SingleSegmentLab):
    def router_policy(self):
        router = self.request("GET", f"/north-south-routers/{self.state['router']}")
        require(router["deployment_mode"] == "standalone" and router["status"] == "active"
                and all(router.get(key) == value
                        for key, value in self.state["router_identity"].items()),
                "second NSR ownership changed")
        policy = {key: router[key] for key in ha.networking.POLICY_KEYS}
        require(policy == self.state["expected_wan_policy"]
                and router.get("static_routes", []) == self.state.get("expected_static_routes", []),
                "second NSR policy changed outside this gate")
        return policy


def unfinished(run):
    return [record for record in run.state.get("second_endpoint_runs", [])
            if record.get("cleanup_complete") is not True]


def owned_router(run, record):
    routers = run.api.json("GET", "/north-south-routers")
    require(isinstance(routers, list) and all(isinstance(item, dict) for item in routers),
            "invalid NSR inventory; cleanup refused")
    matches = [item for item in routers if item.get("id") == record["router_id"]]
    require(len(matches) <= 1, "ambiguous second NSR ownership")
    if not matches:
        return None
    router = matches[0]
    require(router["name"] == record["router_id"] and router["tenant_id"] == record["tenant_id"]
            and router["wan_address_cidr"] == record["endpoint"]["wan_ip"]
            and router["deployment_mode"] == "standalone"
            and (record.get("router_vmid") is None or router["vmid"] == record["router_vmid"]),
            "second NSR identity changed; cleanup refused")
    return router


def cleanup(run, record):
    require(record["router_id"].startswith(run.state["prefix"] + "-nsr2-")
            and record["tenant_name"].startswith(run.state["prefix"] + "-tenant2-"),
            "second endpoint resource prefix changed; cleanup refused")
    directory = Path(record["lab_directory"])
    require(directory.parent == run.directory and re.fullmatch(r"two-endpoint-[a-f0-9]{16}", directory.name),
            "second workload directory changed; cleanup refused")
    ports = {record.get("segment_id")}
    if (directory / "state.json").exists():
        ports |= {segment.get("id") for segment in
                  json.loads((directory / "state.json").read_text()).get("segments", [])}
    ports.discard(None)
    guard = getattr(run, "platform_health", None)
    with guard.retiring(ports) if guard is not None else contextlib.nullcontext():
        teardown(run, record, directory)
    record["cleanup_complete"] = True
    run.save()


def teardown(run, record, directory):
    if (directory / "state.json").exists():
        lab = SecondEndpointLab(directory)
        try:
            require(lab.state["router"] == record["router_id"]
                    and lab.state["config"] == run.state["config"],
                    "second workload ownership changed")
            lab.destroy()
        finally:
            lab.api.close()
    router = owned_router(run, record)
    if router is not None:
        run.api.json("DELETE", f"/north-south-routers/{record['router_id']}?_version={router['_version']}")
        require(owned_router(run, record) is None, "second router teardown did not complete")
    tenants = run.api.json("GET", "/tenants")
    require(isinstance(tenants, list) and all(isinstance(item, dict) for item in tenants),
            "invalid tenant inventory; cleanup refused")
    matches = [tenant for tenant in tenants if tenant.get("id") == record["tenant_id"]]
    require(len(matches) <= 1, "ambiguous second tenant ownership")
    if matches:
        tenant = matches[0]
        require(tenant["name"] == record["tenant_name"], "second tenant ownership changed")
        run.api.json("DELETE", f"/tenants/{record['tenant_id']}?_version={tenant['_version']}")
        require(all(item["id"] != record["tenant_id"] for item in run.api.json("GET", "/tenants")),
                "second tenant teardown did not complete")


def finish_resources(run, record, report, *, retain):
    if retain and report.get("measurements_passed") is True and not report["cleanup_errors"]:
        require(owned_router(run, record) is not None, "second NSR disappeared before retention")
        record["retained"] = True
        run.save()
        report["resources_retained"] = True
    else:
        cleanup(run, record)
        report["resources_retained"] = False


def standalone_request(first, record, node, policy):
    endpoint = record["endpoint"]
    keys = (
        "cluster", "image_storage", "image_volume", "management_bridge", "management_vlan_id",
        "management_gateway", "management_dns", "management_allowlist", "vtep_bridge", "vtep_vlan_id",
    )
    return {
        **{key: copy.deepcopy(first[key]) for key in keys},
        "id": record["router_id"], "name": record["router_id"], "tenant_id": record["tenant_id"],
        "node": node, "deployment_mode": "standalone", "ha_replication_mode": "standalone",
        "wan_bridge": endpoint["wan_bridge"], "wan_vlan_id": endpoint["wan_vlan"],
        "wan_address_cidr": endpoint["wan_ip"], "wan_gateway": endpoint["wan_upstream_router"],
        "management_address_cidr": "", "static_routes": [], **policy,
    }


def workload_state(run, record, router, node, network, segment_id, policy):
    image = run.lab.state["image_volume"]
    return {
        "run_id": uuid.uuid4().hex, "config": run.state["config"], "nodes": [node],
        "segments": [{"id": segment_id, "name": record["router_id"] + "-segment",
                      "gateway_cidr": str(network.network_address + 1) + "/24",
                      "network": str(network), "tenant_id": record["tenant_id"], "created": False}],
        "vms": [], "router": record["router_id"], "image_volume": image,
        "storage": image.split(":", 1)[0], "dns_address": record["endpoint"]["remote_endpoint"],
        "console_password": secrets.token_urlsafe(32), "settle_seconds": 35,
        "results": [], "ready": False, "expected_wan_policy": policy,
        "expected_static_routes": copy.deepcopy(router.get("static_routes", [])),
        "router_identity": {key: router[key] for key in ("id", "name", "vmid", "tenant_id")},
    }


ATTACH_READY_SECONDS = 120


def egress_ready_command(endpoint, seconds=ATTACH_READY_SECONDS):
    program = (
        "import socket,time\n"
        f"end=time.monotonic()+{seconds}\n"
        "while True:\n"
        "    try:\n"
        f"        socket.create_connection(({endpoint['remote_endpoint']!r},{endpoint['tcp_port']}),timeout=2).close()\n"
        "        break\n"
        "    except OSError:\n"
        "        if time.monotonic()>end:\n"
        "            raise\n"
        "        time.sleep(1)\n"
    )
    return "python3 -c " + shlex.quote(program)


def wait_egress_ready(lab, vm, endpoint):
    """The standalone NSR applies a fresh segment attachment on its next poll;
    held-flow acceptance measures stability, not that initial convergence."""
    started = time.monotonic()
    lab.serial(vm, egress_ready_command(endpoint), timeout=ATTACH_READY_SECONDS + 60)
    return round(time.monotonic() - started, 3)


def measure_nat(run, first, second, endpoint, report, save, probes):
    first_vm, second_vm = run.lab.state["vms"][0], second.state["vms"][0]
    report["second_attach_ready_seconds"] = wait_egress_ready(second, second_vm, endpoint)
    save()
    nat = str(ipaddress.IPv4Interface(first["wan_address_cidr"]).ip)
    batches = (
        ("first-masquerade", run.lab, first_vm, cases(first_vm, endpoint, nat, 20000 + secrets.randbelow(9000) * 2)),
        ("second-masquerade", second, second_vm,
         cases(second_vm, endpoint, str(ipaddress.IPv4Interface(endpoint["wan_ip"]).ip), 42000)),
        ("second-fixed-snat", second, second_vm,
         cases(second_vm, endpoint, str(ipaddress.IPv4Interface(endpoint["wan_ip"]).ip), 43000)),
    )
    report["groups"] = {}
    for label, lab, vm, batch in batches:
        token = secrets.token_hex(8)
        remote, unit = "/var/lib/swiftfabric-two-endpoint-" + token, "swiftfabric-ha-probes-" + token
        probes.append((lab, vm, remote, unit, label, batch))
        report["groups"][label] = {"cases": batch, "probe_directory": remote, "probe_unit": unit}
        save()
        run.start_probes(vm, batch, remote, unit=unit, lab=lab)
    deadline = time.monotonic() + 150
    while time.monotonic() < deadline:
        completed = True
        for lab, vm, remote, unit, label, batch in probes:
            status = run.probe_status(vm, remote, lab=lab)
            report["groups"][label]["status"] = status
            completed = completed and status.get("completed") is True
            if status.get("completed"):
                report["groups"][label]["results"] = status["results"]
        save()
        if completed:
            break
        time.sleep(3)
    else:
        raise TimeoutError("second endpoint bounded probes did not finish")
    validate_results(report["groups"])
    current = run.router()
    require(ha.pair_identity(current) == ha.pair_identity(first)
            and current["active_member"] == first["active_member"]
            and current["ha_generation"] == first["ha_generation"],
            "first HA pair ownership changed during NAT-only acceptance")
    require(all(current[key] == first[key] for key in (*ha.networking.POLICY_KEYS, "static_routes"))
            and current.get("pending_configuration") == first.get("pending_configuration"),
            "first HA policy changed during NAT-only acceptance")
    report["first_after"] = inspect_protected_guests(run, current)
    report["measurements_passed"] = True


def stop_nat_probes(run, probes, report):
    errors = []
    for lab, vm, remote, unit, label, batch in probes:
        try:
            report.setdefault("probe_cleanup", {})[label] = run.stop_probes(vm, unit, lab=lab)
        except (OSError, ValueError, RuntimeError) as failure:
            errors.append(f"{label}: {type(failure).__name__}: {failure}")
    return errors


def upgrade_retained(run, record, first):
    router = owned_router(run, record)
    require(router is not None and router["status"] == "active"
            and not router.get("pending_configuration"), "retained endpoint is not active/idle")
    target = (first["current_runtime_version"], first["current_agent_version"])
    if (router["runtime_version"], router["agent_version"]) == target:
        return router
    if not router.get("upgrade_in_progress"):
        reply = run.api.json("POST", f"/north-south-routers/{record['router_id']}/upgrade")
        require(reply.get("upgrade_started") is True, "retained standalone upgrade not admitted")
    deadline = time.monotonic() + 600
    while time.monotonic() < deadline:
        run.require_platform_healthy()
        router = owned_router(run, record)
        require(router is not None and router["status"] == "active", "retained upgrade lost active endpoint")
        if not router.get("upgrade_in_progress"):
            require((router["runtime_version"], router["agent_version"]) == target,
                    "retained upgrade did not reach the exact target; see router upgrade status")
            return router
        time.sleep(3)
    raise TimeoutError("retained standalone upgrade exceeded 600 seconds")


def run_retained(run, *, upgrade=False):
    records = unfinished(run)
    require(len(records) == 1 and records[0].get("retained") is True,
            "require exactly one successfully retained endpoint and no pending cleanup")
    record = records[0]
    directory = Path(record["lab_directory"])
    require(directory.parent == run.directory
            and re.fullmatch(r"two-endpoint-[a-f0-9]{16}", directory.name)
            and record["router_id"].startswith(run.state["prefix"] + "-nsr2-")
            and record["tenant_name"].startswith(run.state["prefix"] + "-tenant2-"),
            "retained endpoint ownership changed")
    endpoint = endpoint_configuration(record["endpoint"])
    first = run.router()
    ha.require_pair(first, deployed=True)
    require(protected(first) and not first.get("pending_configuration"), "first endpoint is not protected/idle")
    report = {"passed": False, "started_epoch": time.time(), "resources": record,
              "first_preflight": inspect_protected_guests(run, first),
              "scope": "retained two-public-endpoint NAT; optional supported standalone upgrade",
              "resources_retained": True, "upgrade_requested": upgrade}
    output = run.directory / f"two-endpoint-retained-{time.time_ns()}-report.json"
    probes, second, lock = [], None, None

    def save():
        ha.deployment.private_write(output, report)

    try:
        save()
        lock = os.open(directory / "run.lock", os.O_WRONLY | os.O_CREAT, 0o600)
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        second = SecondEndpointLab(directory)
        require(second.state["router"] == record["router_id"]
                and second.state["config"] == run.state["config"]
                and second.state.get("ready") is True and len(second.state["vms"]) == 1,
                "retained workload ownership/readiness changed")
        second.router_policy()
        router = upgrade_retained(run, record, first) if upgrade else owned_router(run, record)
        require(router is not None and router["status"] == "active"
                and not router.get("upgrade_in_progress") and not router.get("pending_configuration")
                and router["runtime_version"] == first["current_runtime_version"]
                and router["agent_version"] == first["current_agent_version"],
                "retained endpoint is not idle/current; use --upgrade-retained")
        second.router_policy()
        report["second_router"] = {key: router[key] for key in ("id", "tenant_id", "vmid", "runtime_version")}
        save()
        measure_nat(run, first, second, endpoint, report, save, probes)
        second.router_policy()
        require(owned_router(run, record) is not None, "retained endpoint disappeared after NAT proof")
    except (OSError, ValueError, RuntimeError, ha.deployment.requests.RequestException,
            ha.deployment.ProxmoxAPIError) as failure:
        report["error"] = f"{type(failure).__name__}: {failure}"
        raise
    finally:
        errors = stop_nat_probes(run, probes, report)
        if second is not None:
            second.api.close()
        if lock is not None:
            os.close(lock)
        report.update(passed=bool(report.get("measurements_passed")) and not errors and "error" not in report,
                      cleanup_errors=errors, completed_epoch=time.time())
        save()
        print(output, flush=True)
        require(not errors, "retained NAT probe cleanup incomplete; resources preserved; see report")


def run_gate(run, endpoint, *, retain=False):
    require(not unfinished(run), "second endpoint cleanup pending; run --cleanup first")
    first = run.router()
    ha.require_pair(first, deployed=True)
    require(protected(first) and not first.get("pending_configuration"),
            "first endpoint must be protected without pending configuration")
    before = inspect_protected_guests(run, first)
    require(all(ipaddress.IPv4Interface(router["wan_address_cidr"]).ip
                != ipaddress.IPv4Interface(endpoint["wan_ip"]).ip
                for router in run.api.json("GET", "/north-south-routers")),
            "second WAN address already belongs to a configured NSR")
    original_cases = run.state["held_flow_cases"]
    require({case["destination"] for case in original_cases} == {endpoint["remote_endpoint"]}
            and {case["protocol"]: case["destination_port"] for case in original_cases}
            == {"tcp": endpoint["tcp_port"], "udp": endpoint["udp_port"]},
            "second profile must use the same controlled observed-peer echo endpoint")
    identifier = secrets.token_hex(8)
    directory = run.directory / ("two-endpoint-" + identifier)
    record = {
        "router_id": run.state["prefix"] + "-nsr2-" + identifier[:8],
        "tenant_id": "tenant-" + str(uuid.uuid4()),
        "tenant_name": run.state["prefix"] + "-tenant2-" + identifier[:8],
        "endpoint": endpoint, "lab_directory": str(directory), "cleanup_complete": False,
        "retain_on_success": retain,
    }
    run.state.setdefault("second_endpoint_runs", []).append(record)
    run.save()
    report = {"passed": False, "started_epoch": time.time(), "resources": record,
              "first_preflight": before, "scope": "simultaneous distinct tenant/public NAT; no HA fault"}
    output = run.directory / f"two-endpoint-nat-{time.time_ns()}-report.json"
    probes = []
    second = None
    lock = None

    def save():
        ha.deployment.private_write(output, report)

    try:
        save()
        run.api.json("POST", "/tenants", {"id": record["tenant_id"], "name": record["tenant_name"]})
        segments, reserved = run.lab.network_inventory()
        used = {segment["id"] for segment in segments}
        segment_id = next((value for value in range(49101, 50001) if value not in used), None)
        network = next((ipaddress.IPv4Network(f"10.253.{value}.0/24") for value in range(243, -1, -1)
                        if all(not ipaddress.IPv4Network(f"10.253.{value}.0/24").overlaps(item)
                               for item in reserved if item.version == 4)), None)
        require(segment_id is not None and network is not None, "no unused second segment/subnet")
        policy = {key: [] for key in ha.networking.POLICY_KEYS}
        policy["masquerade_source_cidrs"] = [str(network)]
        policy["wan_egress_rules"] = [
            ha.networking.acl_rule(str(network), endpoint["remote_endpoint"] + "/32", protocol, str(endpoint[key]))
            for protocol, key in (("tcp", "tcp_port"), ("udp", "udp_port"))
        ]
        policy["outbound_port_mappings"] = [
            {"protocol": protocol, "source_ip": str(network.network_address + 10),
             "source_port": 43000 + index, "external_port": 53000 + index}
            for index, protocol in enumerate(("tcp", "udp"))
        ]
        node = first["standby"]["node"]
        request = standalone_request(first, record, node, policy)
        run.api.json("POST", "/north-south-routers", request)
        run.api.json("POST", f"/north-south-routers/{record['router_id']}/deploy")
        deadline = time.monotonic() + 1800
        while time.monotonic() < deadline:
            run.require_platform_healthy()
            router = owned_router(run, record)
            require(router is not None and router["status"] != "failed", "second NSR deployment failed")
            if router["status"] == "active":
                record["router_vmid"] = router["vmid"]
                run.save()
                break
            time.sleep(5)
        else:
            raise TimeoutError("second NSR deployment exceeded 1800 seconds")
        require(router["runtime_version"] == first["current_runtime_version"],
                "second NSR did not deploy the current package payload")
        directory.mkdir(mode=0o700)
        lock = os.open(directory / "run.lock", os.O_WRONLY | os.O_CREAT, 0o600)
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        ha.deployment.private_write(
            directory / "state.json", workload_state(run, record, router, node, network, segment_id, policy),
        )
        second = SecondEndpointLab(directory)
        second.create()
        report["second_router"] = {key: router[key] for key in ("id", "tenant_id", "vmid", "runtime_version")}
        measure_nat(run, first, second, endpoint, report, save, probes)
    except (OSError, ValueError, RuntimeError, ha.deployment.requests.RequestException,
            ha.deployment.ProxmoxAPIError) as failure:
        report["error"] = f"{type(failure).__name__}: {failure}"
        raise
    finally:
        errors = stop_nat_probes(run, probes, report)
        if second is not None:
            second.api.close()
        if lock is not None:
            os.close(lock)
        report["cleanup_errors"] = errors
        try:
            finish_resources(run, record, report, retain=retain)
        except (OSError, ValueError, RuntimeError, ha.deployment.requests.RequestException,
                ha.deployment.ProxmoxAPIError) as failure:
            errors.append(f"resources: {type(failure).__name__}: {failure}")
        report.update(passed=bool(report.get("measurements_passed")) and not errors,
                      cleanup_errors=errors, completed_epoch=time.time())
        save()
        print(output, flush=True)
        require(not errors, "two-endpoint cleanup incomplete; see report and rerun --cleanup")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", type=Path, required=True)
    parser.add_argument("--nsr-config", type=Path, default=ha.ROOT / "nsr2.json")
    parser.add_argument("--cleanup", action="store_true", help="clean only unfinished owned second endpoints")
    parser.add_argument("--retain-on-success", action="store_true",
                        help="leave a passing second NSR, tenant, segment and workload for inspection; remove with --cleanup")
    parser.add_argument("--verify-retained", action="store_true",
                        help="repeat six-flow NAT proof without replacing the retained endpoint or workload")
    parser.add_argument("--upgrade-retained", action="store_true",
                        help="with --verify-retained, use the normal standalone upgrade API first")
    args = parser.parse_args(argv)
    if sum((args.cleanup, args.retain_on_success, args.verify_retained)) > 1:
        parser.error("--cleanup, --retain-on-success and --verify-retained are mutually exclusive")
    if args.upgrade_retained and not args.verify_retained:
        parser.error("--upgrade-retained requires --verify-retained")
    if args.cleanup:
        def action(run):
            for record in unfinished(run):
                cleanup(run, record)
    elif args.verify_retained:
        def action(run):
            run_retained(run, upgrade=args.upgrade_retained)
    else:
        endpoint = endpoint_configuration(ha.read_config_object(args.nsr_config.expanduser().resolve()))
        def action(run):
            run_gate(run, endpoint, retain=args.retain_on_success)
    with ha.automated_ssh_tofu():
        name = "two-endpoint-cleanup" if args.cleanup else (
            "two-endpoint-retained" if args.verify_retained else "two-endpoint-nat")
        ha.with_saved_run(args.state, action, action_name=name)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
