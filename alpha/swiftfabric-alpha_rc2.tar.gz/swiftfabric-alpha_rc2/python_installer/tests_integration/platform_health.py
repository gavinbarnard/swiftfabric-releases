"""Fail-closed platform monitoring for retained NSR acceptance."""

import concurrent.futures
import contextlib
import ipaddress
import json
import shlex
import subprocess
import threading
import re
import time
import xml.etree.ElementTree as ET

from disaster_recovery import private_write


COLLECT = r"""
import json,os,pathlib,re,shlex,subprocess,xml.etree.ElementTree as ET
def command(args):
    return subprocess.run(args,capture_output=True,text=True,check=True,timeout=10).stdout
monitor=command(["crm_mon","--one-shot","--inactive","--failcounts","--output-as=xml"])
root=ET.fromstring(monitor)
cib=ET.fromstring(command(["cibadmin","--query"]))
limits={}
for clone in cib.findall("./configuration/resources/clone"):
    meta={e.get("name"):e.get("value") for e in clone.findall("./meta_attributes/nvpair")}
    limits[clone.get("id")]={k:meta[k] for k in ("clone-max","promoted-max") if k in meta}
replication={}
node=command(["crm_node","-n"]).strip()
for resource in root.findall(".//resource"):
    if resource.get("resource_agent")!="ocf:swiftfabric:valkey-segment":
        continue
    if not any(n.get("name")==node for n in resource.findall("node")):
        continue
    match=re.fullmatch(r"swiftfabric-valkey-(\d+)(?::\d+)?",resource.get("id",""))
    if match is None:
        raise RuntimeError("unrecognized Valkey resource identity")
    port=match[1]
    conf=pathlib.Path("/etc/swiftfabric/valkey")/(port+".conf")
    password=next(shlex.split(line)[1] for line in conf.read_text().splitlines()
                  if line.startswith("requirepass "))
    try:
        reply=subprocess.run(["valkey-cli","--no-auth-warning","--raw","-h","127.0.0.1",
                              "-p",port,"INFO","replication"],
                             env={**os.environ,"VALKEYCLI_AUTH":password},
                             capture_output=True,text=True,check=True,timeout=5).stdout
    except (subprocess.CalledProcessError,subprocess.TimeoutExpired):
        replication[port]={"unavailable":"1"}
        continue
    info=dict(line.split(":",1) for line in reply.splitlines()
              if ":" in line and not line.startswith("#"))
    replication[port]={key:value for key,value in info.items()
                       if key in ("role","master_host","master_link_status",
                                  "master_sync_in_progress","connected_slaves")
                       or re.fullmatch(r"slave\d+",key)}
print(json.dumps({"node":node,"monitor":monitor,"clone_limits":limits,
                  "resource_ids":[e.get("id") for e in cib.findall("./configuration/resources//primitive")],
                  "corosync":command(["corosync-quorumtool","-s"]),
                  "replication":replication}))
"""


# Bounded start/promotion/initial-sync window for Valkey instances created after admission.
CONVERGENCE_SECONDS = 120
# Declared controller faults: bounded survivor failover, then bounded rejoin/resync.
FAULT_CONVERGENCE_SECONDS = 60
RECOVERY_SECONDS = 300
VALKEY_ID = re.compile(r"swiftfabric-valkey-(\d+)(?:-clone)?")


def require(condition, reason):
    if not condition:
        raise RuntimeError("platform unhealthy; stop testing and repair services: " + reason)


def valkey_port(identifier):
    if not isinstance(identifier, str):
        return None
    match = VALKEY_ID.fullmatch(identifier.split(":")[0])
    return match[1] if match else None


def valkey_ports(snapshot):
    identifiers = snapshot.get("resource_ids")
    return {port for port in map(valkey_port, identifiers if isinstance(identifiers, list) else ()) if port}


def validate(snapshot, expected_nodes, converging_ports=frozenset(), *, absent=None, relax_all=False):
    """Validate one receipt; only listed new Valkey ports may still be starting/syncing.

    ``absent`` names one deliberately stopped controller: survivors must stay
    quorate and healthy and hold every placement the survivors can.
    ``relax_all`` is a bounded declared-fault failover/rejoin window in which
    placement/sync convergence, never failures, may still be in progress.
    """
    converging = set()
    survivors = expected_nodes - {absent}

    def settle(port, condition, reason):
        if not condition and (relax_all or port in converging_ports):
            converging.add(port or "cluster")
            return
        require(condition, reason)

    require(isinstance(snapshot, dict)
            and all(isinstance(snapshot.get(key), str) for key in ("monitor", "corosync", "node"))
            and isinstance(snapshot.get("clone_limits"), dict)
            and isinstance(snapshot.get("resource_ids"), list)
            and isinstance(snapshot.get("replication"), dict), "malformed health receipt")
    root = ET.fromstring(snapshot["monitor"])
    dc = root.find("./summary/current_dc")
    settle(None, dc is not None and dc.get("present") == "true" and dc.get("with_quorum") == "true",
           "Pacemaker DC/quorum missing")
    options = root.find("./summary/cluster_options")
    require(options is not None and options.get("maintenance-mode") == "false"
            and options.get("stop-all-resources") == "false", "cluster maintenance/stopped")
    nodes = root.findall("./nodes/node")
    require(len(nodes) == len(expected_nodes) and {n.get("name") for n in nodes} == expected_nodes,
            "controller membership differs")
    for node in nodes:
        if node.get("name") == absent:
            continue
        require(all(node.get(key) == "false" for key in ("standby", "standby_onfail", "maintenance")),
                "controller standby/maintenance: " + node.get("name", "unknown"))
        # A rejoining controller may briefly be pending/offline inside a declared window.
        settle(None, node.get("online") == "true" and node.get("health") == "green"
               and all(node.get(key) == "false" for key in ("pending", "unclean", "shutdown")),
               "controller unavailable or unhealthy: " + node.get("name", "unknown"))
    require(not root.findall(".//failure"), "failed resource operations remain")
    require(all(e.get("fail-count") == "0" for e in root.findall(".//*[@fail-count]")),
            "resource failure counters remain")
    resources = root.findall(".//resource")
    require(bool(resources), "resource inventory empty")
    status_ids = {resource.get("id", "").split(":")[0] for resource in resources}
    for identifier in status_ids - set(snapshot["resource_ids"]):
        # A declared retiring segment may linger as a stopping orphan after deletion.
        settle(valkey_port(identifier), False, "unconfigured resource in status")
    for identifier in set(snapshot["resource_ids"]) - status_ids:
        settle(valkey_port(identifier), False, "configured resource missing from status")
    for resource in (*root.findall(".//clone"), *root.findall(".//group"), *resources):
        require(resource.get("managed") == "true"
                and all(resource.get(key, "false") == "false" for key in
                        ("failed", "blocked", "maintenance", "failure_ignored")),
                "resource failed or unmanaged: " + resource.get("id", "unknown"))
        settle(valkey_port(resource.get("id")), resource.get("orphaned", "false") == "false",
               "resource orphaned: " + resource.get("id", "unknown"))
        # Segment clones are created disabled, constrained, then enabled.
        settle(valkey_port(resource.get("id")), resource.get("disabled", "false") == "false",
               "resource disabled: " + resource.get("id", "unknown"))
    clones = root.findall(".//clone")
    clone_members = {id(member) for clone in clones for member in clone.findall(".//resource")}
    for resource in resources:
        if absent is not None and id(resource) in clone_members and resource.find("node") is None:
            continue  # the absent controller's instance; clone placement is checked below
        settle(valkey_port(resource.get("id")),
               resource.get("active") == "true"
               and resource.get("role") in ("Started", "Promoted", "Unpromoted")
               and resource.get("nodes_running_on") == "1"
               and len(resource.findall("node")) == 1
               and resource.find("node").get("name") in survivors,
               "resource stopped/misplaced: " + resource.get("id", "unknown"))
    for identifier in {clone.get("id") for clone in clones} - set(snapshot["clone_limits"]):
        settle(valkey_port(identifier), False, "unconfigured clone in status")
    for identifier in set(snapshot["clone_limits"]) - {clone.get("id") for clone in clones}:
        settle(valkey_port(identifier), False, "configured clone missing from status")
    for clone in clones:
        port = valkey_port(clone.get("id"))
        if clone.get("id") not in snapshot["clone_limits"]:
            continue  # declared retiring orphan, accepted above
        limits = snapshot["clone_limits"][clone.get("id")]
        count = int(limits.get("clone-max", len(expected_nodes)))
        wanted_placed = min(count, len(survivors))
        instances = clone.findall(".//resource")
        placed = [r.find("node").get("name") for r in instances if r.find("node") is not None]
        # Survivors may still list the stopped controller's instances until membership loss is detected.
        settle(port, absent not in placed, "clone placed on absent controller: " + clone.get("id"))
        settle(port, len(instances) == count and len(placed) == wanted_placed
               and len(set(placed)) == wanted_placed,
               "clone lacks all configured replicas: " + clone.get("id"))
        require(len(placed) == len(set(placed)), "clone replicas share a controller: " + clone.get("id"))
        if clone.get("multi_state") == "true":
            promoted = sum(r.get("role") == "Promoted" for r in instances)
            wanted = int(limits.get("promoted-max", 1))
            require(promoted <= wanted, "promoted clone count differs: " + clone.get("id"))
            settle(port, promoted == wanted, "promoted clone count differs: " + clone.get("id"))
    quorum = dict(line.split(":", 1) for line in snapshot["corosync"].splitlines() if ":" in line)
    settle(None, quorum.get("Quorate", "").strip() == "Yes"
           and quorum.get("Nodes", "").strip() == str(len(survivors))
           and quorum.get("Total votes", "").strip() == str(len(survivors)),
           "Corosync membership/votes degraded")
    require(snapshot["node"] in survivors, "SSH/controller identity differs")
    local_segments = {
        valkey_port(r.get("id"))
        for r in resources if r.get("resource_agent") == "ocf:swiftfabric:valkey-segment"
        and r.find("node") is not None and r.find("node").get("name") == snapshot["node"]
    }
    require(set(snapshot["replication"]) == local_segments, "Valkey replication inventory incomplete")
    for port, info in snapshot["replication"].items():
        if info.get("unavailable"):
            settle(port, False, "Valkey instance unreachable: " + port)
        elif info.get("role") == "slave":
            settle(port, info.get("master_link_status") == "up"
                   and info.get("master_sync_in_progress") == "0",
                   "Valkey replica not synchronized: " + port)
        else:
            peers = [value for key, value in info.items() if key.startswith("slave") and key[5:].isdecimal()]
            settle(port, info.get("role") == "master"
                   and info.get("connected_slaves") == str(len(survivors) - 1)
                   and len(peers) == len(survivors) - 1
                   and all("state=online," in peer for peer in peers),
                   "Valkey primary lacks online replicas: " + port)
    return {"node": snapshot["node"], "resources": len(resources),
            "controllers": len(nodes), "healthy": not converging,
            "converging": sorted(converging), "valkey": snapshot["replication"]}


class PlatformHealth:
    def __init__(self, run, *, recovering_cluster=False):
        self.run = run
        self.stop = threading.Event()
        self.failure = None
        self.thread = None
        self.output = run.directory / f"platform-health-{time.time_ns()}.json"
        self.report = {"passed": False, "started_epoch": time.time()}
        # Admission ports are strict; later-created Valkey ports converge once, within a bound.
        self.admitted_ports = None
        self.first_seen = {}
        self.settled_ports = set()
        self.converging = set()
        # Declared owned segment deletions: port -> grace deadline (None while deleting).
        self.retiring_ports = {}
        self.finished = False
        self.capture_version = 0
        # Declared controller fault scope (one owned controller deliberately stopped/returning).
        self.lock = threading.Lock()
        self.fault_version = 0
        self.absent = None
        self.fault_started = None
        self.returning = None
        self.recovery_deadline = None
        self.cluster_recovery_deadline = time.time() + RECOVERY_SECONDS if recovering_cluster else None
        if recovering_cluster:
            self.report["expected_recovery"] = {
                "scope": "whole controller cluster restart",
                "deadline_epoch": self.cluster_recovery_deadline,
            }

    @contextlib.contextmanager
    def controller_fault(self, name):
        """Declare one owned controller deliberately down for the enclosed block.

        Survivors stay strictly validated (after a bounded failover window).
        On exit the controller must rejoin and fully resynchronize within
        RECOVERY_SECONDS, after which validation is strict again.
        """
        if name not in {controller["name"] for controller in self.run.state["controllers"]}:
            raise ValueError("declared controller fault is not an owned controller")
        with self.lock:
            if self.absent is not None or self.returning is not None:
                raise RuntimeError("another declared controller fault is still active")
            self.absent, self.fault_started = name, time.time()
            self.fault_version += 1
            self.report.setdefault("declared_faults", []).append(
                {"controller": name, "started_epoch": self.fault_started})
            private_write(self.output, self.report)
        try:
            yield self
        finally:
            with self.lock:
                self.absent, self.returning = None, name
                self.recovery_deadline = time.time() + RECOVERY_SECONDS
                self.fault_version += 1
                self.report["declared_faults"][-1]["returned_epoch"] = time.time()
                private_write(self.output, self.report)

    @contextlib.contextmanager
    def retiring(self, ports):
        """Declare owned Valkey segment ports deleted inside the enclosed block.

        Their resources may stop, orphan, and disappear while the block runs and
        for CONVERGENCE_SECONDS after it. Failed operations stay fatal. A later
        segment reusing a port is treated as newly created.
        """
        ports = {str(port) for port in ports if port is not None}
        with self.lock:
            for port in ports:
                self.retiring_ports[port] = None
        try:
            yield self
        finally:
            with self.lock:
                deadline = time.time() + CONVERGENCE_SECONDS
                for port in ports:
                    self.retiring_ports[port] = deadline
                    self.settled_ports.discard(port)
                    self.first_seen.pop(port, None)

    def mode(self, now):
        with self.lock:
            if self.absent is not None:
                return (self.fault_version, self.absent, None,
                        now - self.fault_started <= FAULT_CONVERGENCE_SECONDS)
            if self.returning is not None and now <= self.recovery_deadline:
                return self.fault_version, None, self.returning, True
            if self.cluster_recovery_deadline is not None and now <= self.cluster_recovery_deadline:
                return self.fault_version, None, None, True
            return self.fault_version, None, None, False

    def collect(self, skip=None, tolerate=None):
        """Collect receipts; ``skip`` is not contacted and ``tolerate`` may be unreachable (None)."""
        names = [controller["name"] for controller in self.run.state["controllers"]]
        targets = [(name, str(ipaddress.IPv4Address(self.run.config["ip_range_start"]) + index))
                   for index, name in enumerate(names[:3]) if name != skip]
        command = shlex.join(["sudo", "-n", "python3", "-c", COLLECT])

        def one(target):
            name, address = target
            try:
                return json.loads(self.run.api.ssh.run(address, command, timeout=60))
            except (OSError, ValueError, RuntimeError, subprocess.SubprocessError):
                if name != tolerate:
                    raise
                return None

        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            return list(pool.map(one, targets))

    def capture(self):
        nodes = {controller["name"] for controller in self.run.state["controllers"]}
        self.capture_version, absent, returning, relaxed = self.mode(time.time())
        snapshots = (self.collect(skip=absent) if absent is not None
                     else self.collect(tolerate=returning) if returning is not None else self.collect())
        unreachable = None in snapshots
        snapshots = [item for item in snapshots if item is not None]
        missing = absent if absent is not None else returning if unreachable else None
        now = time.time()
        ports = set().union(*(valkey_ports(item) for item in snapshots if isinstance(item, dict)))
        if self.admitted_ports is None:
            grace = set()
        else:
            for port in ports - self.admitted_ports:
                self.first_seen.setdefault(port, now)
            grace = {port for port in ports - self.admitted_ports - self.settled_ports
                     if now - self.first_seen[port] <= CONVERGENCE_SECONDS}
        with self.lock:
            for port, deadline in list(self.retiring_ports.items()):
                if deadline is not None and now > deadline:
                    del self.retiring_ports[port]
            retiring = set(self.retiring_ports)
            for port in retiring - ports:
                # Gone: a later segment reusing the port gets new-port grace from first sight.
                self.settled_ports.discard(port)
                self.first_seen.pop(port, None)
                if self.admitted_ports is not None:
                    self.admitted_ports.discard(port)
        grace |= retiring
        receipts = [validate(item, nodes, frozenset(grace), absent=missing, relax_all=relaxed)
                    for item in snapshots]
        require({receipt["node"] for receipt in receipts} == nodes - {missing}
                and len(receipts) == len(nodes - {missing}), "duplicate/missing controller receipts")
        self.converging = set().union(*(receipt["converging"] for receipt in receipts))
        if returning is not None and missing is not None:
            self.converging.add("controller:" + returning)
        if returning is not None and not self.converging:
            with self.lock:
                if self.returning == returning and self.capture_version == self.fault_version:
                    self.returning = self.recovery_deadline = None  # rejoined; strict from now on
        if self.cluster_recovery_deadline is not None:
            if self.converging and relaxed:
                self.report["expected_recovery"]["last_converging"] = sorted(self.converging)
            elif not self.converging:
                self.report["expected_recovery"]["settled_epoch"] = now
                self.cluster_recovery_deadline = None
        if self.admitted_ports is None:
            self.admitted_ports = ports
        else:
            self.settled_ports |= ports - self.admitted_ports - self.converging
        self.report["latest"] = {"epoch": now, "controllers": receipts,
                                 "converging": sorted(self.converging),
                                 "declared_absent": missing, "fault_window_relaxed": relaxed}
        private_write(self.output, self.report)

    def settle(self):
        self.capture()
        while self.converging:
            time.sleep(3)
            self.capture()

    def check(self):
        if self.failure is not None:
            raise RuntimeError(str(self.failure)) from self.failure

    def monitor(self):
        while not self.stop.wait(3):
            try:
                self.capture()
            except (OSError, ValueError, RuntimeError, subprocess.SubprocessError, ET.ParseError) as failure:
                with self.lock:
                    # A sample begun before a fault was declared/ended is stale, not a verdict.
                    if self.capture_version != self.fault_version:
                        continue
                self.failure = failure
                self.report.update(error=f"{type(failure).__name__}: {failure}", passed=False)
                private_write(self.output, self.report)
                print("Platform health failed; testing must stop: " + str(failure), flush=True)
                return

    def __enter__(self):
        try:
            self.capture()
        except (OSError, ValueError, RuntimeError, subprocess.SubprocessError, ET.ParseError) as failure:
            self.report.update(error=f"{type(failure).__name__}: {failure}",
                               completed_epoch=time.time())
            private_write(self.output, self.report)
            raise
        self.thread = threading.Thread(target=self.monitor, name="platform-health")
        self.thread.start()
        return self

    def close(self):
        """Finish with the final strict check and stop monitoring, e.g. before owned controller teardown."""
        self.finish(None)

    def __exit__(self, kind, value, traceback):
        self.finish(kind)

    def finish(self, kind):
        if self.finished:
            return
        self.finished = True
        self.stop.set()
        self.thread.join()
        try:
            if kind is None:
                self.check()
                self.settle()
                self.report["passed"] = True
        except (OSError, ValueError, RuntimeError, subprocess.SubprocessError, ET.ParseError) as failure:
            self.report.update(error=f"{type(failure).__name__}: {failure}", passed=False)
            raise
        finally:
            self.report["completed_epoch"] = time.time()
            private_write(self.output, self.report)
