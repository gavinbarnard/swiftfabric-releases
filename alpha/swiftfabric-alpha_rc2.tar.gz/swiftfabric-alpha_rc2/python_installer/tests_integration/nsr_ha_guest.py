"""Retained held-flow worker, executed only inside the disposable workload VM."""

import argparse
import concurrent.futures
import importlib
import json
import os
from pathlib import Path
import sys
import threading

sys.path.insert(0, "/opt")
hold_flow = importlib.import_module("guest").hold_flow


def run(cases, directory):
    directory = Path(directory)
    directory.mkdir(mode=0o700, exist_ok=False)
    lock = threading.Lock()
    state = {"completed": False, "progress": {}, "results": []}

    def save():
        temporary = directory / "status.tmp"
        descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(descriptor, "w") as stream:
            json.dump(state, stream, allow_nan=False)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, directory / "status.json")

    def progress(value):
        with lock:
            state["progress"][value["protocol"]] = value
            save()

    save()
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        futures = [executor.submit(hold_flow, case, progress=progress) for case in cases]
        for future in concurrent.futures.as_completed(futures):
            with lock:
                state["results"].append(future.result())
                save()
    with lock:
        state["completed"] = True
        save()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("cases")
    parser.add_argument("directory")
    args = parser.parse_args()
    run(json.loads(args.cases), args.directory)
