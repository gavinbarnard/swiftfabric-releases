"""Controller-local ownership checks for an unmodified failed restore target.

Sent over SSH as root; archived credentials never leave the controller.
"""

import hashlib
import json
from pathlib import Path
import re
import ssl
import stat
import subprocess
import sys
import urllib.request
from urllib.parse import quote


def secure_json(path):
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or stat.S_IMODE(info.st_mode) != 0o600:
        raise RuntimeError("cleanup input must be root-owned regular 0600")
    return json.loads(path.read_bytes())


def records(provisioning, key):
    value = provisioning.get(key)
    if not isinstance(value, dict):
        raise RuntimeError("staged cleanup inventory is missing")
    return {name: json.loads(raw) for name, raw in value.items()}


def staged_plan(spec):
    for directory in (Path("/var/lib/swiftfabric/restore-journals"),
                      Path("/var/lib/swiftfabric/restore-staging")):
        if directory.exists():
            info = directory.lstat()
            if (not stat.S_ISDIR(info.st_mode) or info.st_uid != 0
                    or stat.S_IMODE(info.st_mode) != 0o700):
                raise RuntimeError("cleanup staging directory must be root-owned 0700")
    for journal in Path("/var/lib/swiftfabric/restore-journals").glob("*/state.json"):
        state = secure_json(journal)
        if state.get("phase") != "planned":
            raise RuntimeError("restore may have mutated controllers; orphan cleanup forbidden")
    candidates = []
    for path in Path("/var/lib/swiftfabric/restore-staging").glob("*.json"):
        if not re.fullmatch(r"[0-9a-f]{32}\.json", path.name):
            raise RuntimeError("invalid staged cleanup filename")
        payload = secure_json(path)
        if (payload["manifest"]["product_version"] == spec["product_version"]
                and hashlib.sha256(payload["components"]["ca_certificate"].encode()).hexdigest()
                == spec["backup_ca_sha256"]
                and payload["deployment"]["controller_ips"] == spec["controller_ips"]
                and payload["deployment"]["controller_names"] == spec["controller_names"]
                and payload["deployment"]["api_vip"] == spec["api_vip"]):
            candidates.append((path, payload))
    if not candidates:
        raise RuntimeError("no matching authenticated staged backup; cleanup forbidden")
    digests = {hashlib.sha256(path.read_bytes()).hexdigest() for path, _ in candidates}
    if len(digests) != 1:
        raise RuntimeError("ambiguous staged backups; cleanup forbidden")
    payload = candidates[0][1]
    provisioning = payload["components"]["provisioning"]
    hosts = records(provisioning, "swiftfabric:hosts")
    identities = sorted(
        ({key: host[key] for key in ("host_id", "cluster", "node", "agent_version")}
         for host in hosts.values()), key=lambda host: host["host_id"])
    if identities != sorted(spec["hosts"], key=lambda host: host["host_id"]):
        raise RuntimeError("staged hosts differ from saved ownership")
    routers = records(provisioning, "swiftfabric:north_south_routers")
    if set(routers) != {spec["router"]["id"]}:
        raise RuntimeError("staged router inventory differs from saved ownership")
    router = routers[spec["router"]["id"]]
    if (any(router.get(key) != value for key, value in spec["router"].items())
            or router.get("deployment_mode", "standalone") != "standalone"
            or router.get("ha_state_sync_enabled")
            or not re.fullmatch(r"[0-9a-f]{64}", router.get("vm_owner_token", ""))):
        raise RuntimeError("staged standalone router lacks exact ownership")
    clusters = records(provisioning, "swiftfabric:proxmox:clusters")
    if set(clusters) != {spec["cluster"]["name"]}:
        raise RuntimeError("staged cluster inventory differs from saved ownership")
    cluster = clusters[spec["cluster"]["name"]]
    if any(cluster.get(key) != value for key, value in spec["cluster"].items()):
        raise RuntimeError("staged cluster endpoint differs from deployment configuration")
    return {
        "staging_sha256": next(iter(digests)),
        "router": {"node": router["node"], "vmid": router["vmid"],
                   "name": spec["router_vm_name"],
                   "description": f"SwiftFabric N/S router {router['id']} member a",
                   "owner_tag": "swiftfabric_owner_" + router["vm_owner_token"]},
    }, cluster


def api(config, method, path, body=None):
    context = ssl.create_default_context(cafile="/etc/swiftfabric/swiftfabric-ca.crt")
    token = Path("/etc/swiftfabric/segment-manager.token").read_text().strip()
    if not token or "\n" in token:
        raise RuntimeError("invalid cleanup API credential")
    request = urllib.request.Request(
        f"https://{config['api_vip']}/api/v1{path}", method=method,
        data=None if body is None else json.dumps(body).encode(),
        headers={"Authorization": "Bearer " + token, "Content-Type": "application/json"})
    with urllib.request.urlopen(request, context=context, timeout=120) as response:
        return json.loads(response.read())


def dispatch(spec):
    plan, cluster = staged_plan(spec)
    config = secure_json(Path("/etc/swiftfabric/api-service.json"))
    if (config["node_ips"] != spec["controller_ips"]
            or config["node_names"] != spec["controller_names"] or config["api_vip"] != spec["api_vip"]):
        raise RuntimeError("replacement controller topology differs")
    version = subprocess.check_output(
        ["dpkg-query", "-W", "-f=${Version}", "swiftfabric-api-service"], text=True).strip()
    if version != spec["product_version"]:
        raise RuntimeError("replacement controller package differs")
    tenants = api(config, "GET", "/tenants")
    if (not isinstance(tenants, list) or len(tenants) != 1
            or tenants[0].get("id") != "default"):
        raise RuntimeError("replacement controller has restored tenants; orphan cleanup forbidden")
    for key in ("hosts", "north-south-routers"):
        if api(config, "GET", "/" + key) != []:
            raise RuntimeError("replacement controller has live inventory; orphan cleanup forbidden")
    if spec["operation"] == "register-cluster":
        if plan != spec["plan"]:
            raise RuntimeError("staged cleanup ownership changed")
        existing = api(config, "GET", "/proxmox/clusters")
        if existing:
            if len(existing) != 1 or any(existing[0].get(key) != value
                                        for key, value in spec["cluster"].items()):
                raise RuntimeError("replacement cluster registration differs")
        else:
            cluster.pop("_version", None)
            api(config, "PUT", "/proxmox/clusters/" + quote(cluster["name"], safe=""), cluster)
    elif spec["operation"] != "probe":
        raise RuntimeError("invalid cleanup operation")
    return plan


if __name__ == "__main__":
    try:
        print(json.dumps(dispatch(json.loads(sys.stdin.read()))))
    except (OSError, ValueError, KeyError, TypeError, RuntimeError, subprocess.CalledProcessError):
        # Archive, urllib and subprocess diagnostics can contain credentials.
        print("Failed-restore ownership verification failed; details withheld.", file=sys.stderr)
        sys.exit(1)
