#!/usr/bin/env python3
"""Disposable pair-local NSR HA acceptance with held TCP/UDP sessions.

The two NSR members own HA themselves (mTLS liveness on TCP 4244, replication
on TCP 4243). The controller only observes them through
``GET .../ha-status`` and requests planned handoffs; it is not in the failover
path. Everything executed on NSR guests is POSIX shell plus the installed
``swiftfabric-router`` CLI and system tools (nft, systemd-run); no Python is
shipped to or run on NSR guests.

A new run verifies, in order: converged pair status, a planned handoff with
held sessions, a replication-link cut, a controller-path cut, and an abrupt
active-member power-off with non-preemptive rejoin. Then it cleans up, or with
--retain leaves the passing lab for these saved-state actions:

--test-partitions --state repeats the replication and controller-path cuts.
--test-vip --state stops and restores the API-VIP controller VM.
--test-controller-loss --state stops all controllers for twenty minutes, then
verifies a active -> a crash -> b takeover -> a standby rejoin -> b crash ->
a takeover without controllers. Both rejoined members must reconnect session
replication. Proxmox serial diagnostics capture boot/network state during SSH
recovery; temporary console passwords are private and re-locked afterwards.
Replica resynchronization is expected during bounded controller restoration;
failed operations and failure to reach strict health remain fatal.
--test-double-failover-migration --state keeps controllers healthy, fails a then
b, and live-migrates the original held-flow VM hunsn3 -> hunsn4 -> hunsn5.
--test-rolling-upgrade --state upgrades controllers to a newer prebuilt package,
then the pair (standby, handoff, former active; no failback), then cleans up.
"""

import argparse
import fcntl
import html
import importlib
import ipaddress
import json
import math
import os
from pathlib import Path
import re
import secrets
import shlex
import shutil
import subprocess
import sys
import time
import uuid
from urllib.parse import urlencode, urlparse

import disaster_recovery as deployment
from platform_health import PlatformHealth
from integration_common import ROOT, automated_ssh_tofu, read_config_object

sys.path.insert(0, str(ROOT / "network-lab"))
networking = importlib.import_module("lab")


ASYNC_MODE = "asynchronous"
ROUTER_CLI = "/usr/lib/swiftfabric/swiftfabric-router --config /etc/swiftfabric/router.json"
REPLICATION_PORT = 4243
CUT_SECONDS = 60
CONTROLLER_CUT_DELAY = 15
TAKEOVER_LIMIT_SECONDS = 10
REJOIN_OBSERVATION_SECONDS = 30
ROLLING_HELD_SECONDS = 600  # network-lab held-flow maximum
REQUIRED_SCENARIOS = (
    "pair-status", "planned-handoff", "replication-cut", "controller-path-cut", "active-crash",
)


class CapabilityBlocked(RuntimeError):
    pass


def other(member):
    return "b" if member == "a" else "a"


def public_ha_report(summary):
    """Select credential-free scenario outcomes for HTML and release reports."""
    scenarios = {}
    for name, result in summary.get("scenarios", {}).items():
        details = {}
        for key in ("owner", "term", "passed", "takeover_observed_seconds",
                    "controller_free_forwarding_seconds", "controller_absence_seconds"):
            if key in result:
                details[key] = result[key]
        for key in ("fault", "successor"):
            value = result.get(key)
            if isinstance(value, dict):
                details[key] = {
                    field: value[field] for field in
                    ("member", "term", "takeover_observed_seconds")
                    if field in value
                }
        flows = result.get("flows")
        if isinstance(flows, list):
            details["flows"] = [
                {key: flow[key] for key in (
                    "protocol", "survived", "event_response_gap_seconds",
                    "max_response_gap_seconds",
                ) if key in flow}
                for flow in flows if isinstance(flow, dict)
            ]
        scenarios[name] = {"passed": result.get("passed") is True, "details": details}
    return {
        "schema_version": 1,
        "passed": summary.get("passed") is True,
        "scenarios": scenarios,
    }


def write_ha_report(directory, title="NSR HA acceptance"):
    summary = read_config_object(directory / "ha-report.json")
    report = public_ha_report(summary)
    deployment.private_write(directory / "report-data.json", report)
    rows = []
    for name, result in report["scenarios"].items():
        status = "PASS" if result["passed"] else "FAIL"
        detail = html.escape(json.dumps(result["details"], indent=2, sort_keys=True))
        rows.append(
            "<tr><th>{}</th><td class=\"{}\">{}</td><td><pre>{}</pre></td></tr>".format(
                html.escape(name), status.lower(), status, detail,
            )
        )
    verdict = "PASS" if report["passed"] else "INCOMPLETE"
    content = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>NSR HA acceptance report</title>
<style>
body{{font:15px system-ui,sans-serif;max-width:1100px;margin:2rem auto;padding:0 1rem;color:#17212b}}
h1{{margin-bottom:.25rem}}.verdict{{font-weight:700}}.pass{{color:#176b35}}.fail{{color:#a12727}}
table{{border-collapse:collapse;width:100%;margin-top:1.5rem}}th,td{{border:1px solid #ccd3da;padding:.7rem;text-align:left;vertical-align:top}}
pre{{white-space:pre-wrap;overflow-wrap:anywhere;margin:0;font-size:.85rem}}
</style></head><body><h1>{}</h1>
<p>Overall result: <span class="verdict {}">{}</span></p>
<table><thead><tr><th>Scenario</th><th>Result</th><th>Measurements</th></tr></thead>
<tbody>{}</tbody></table></body></html>
""".format(html.escape(title), verdict.lower(), verdict, "".join(rows))
    deployment.private_write(directory / "report.html", content.encode("utf-8"))
    return directory / "report.html"


def require_pair(router, *, deployed=False):
    """Explicit pair-local HA contract; never substitute earlier HA modes."""
    if (
        router.get("deployment_mode") != "active-standby"
        or router.get("ha_replication_mode") != ASYNC_MODE
        or router.get("ha_shared_vtep") is not True
        or any(key in router for key in ("synchronous_ha", "ha_edge_pair_id"))
    ):
        raise CapabilityBlocked("pair-local NSR HA deployment contract is not implemented")
    if deployed and (router.get("status") != "active" or router.get("ha_state_sync_enabled") is not True):
        raise CapabilityBlocked("NSR pair is not deployed with state synchronization; no fault was injected")


def protected(router):
    return router.get("status") == "active" and not router.get("upgrade_in_progress")


def inspect_protected_guests(run, router):
    """Controller observation proving both members converged on the recorded owner."""
    if not protected(router):
        raise RuntimeError("NSR pair is not protected; guest inspection refused")
    observation = run.pair_status()
    current = converged(observation, run.state["router_requested"])
    if current is None or current[0] != router.get("active_member"):
        raise RuntimeError("NSR pair members are not converged on the recorded active member")
    return {"owner": current[0], "term": current[1], "observation": observation}


def converged(observation, router_id):
    """Return ``(owner, term)`` when both members agree on one connected owner, else None."""
    if not isinstance(observation, dict) or observation.get("router_id") != router_id:
        raise RuntimeError("controller returned HA status for another router")
    owner, term = observation.get("active_member"), observation.get("term")
    if (
        observation.get("healthy") is not True or observation.get("split_brain") is not False
        or owner not in ("a", "b") or type(term) is not int or term < 1
    ):
        return None
    for member in ("a", "b"):
        view = (observation.get(member) or {}).get("status")
        if (
            not isinstance(view, dict) or view.get("member") != member or view.get("fresh") is not True
            or view.get("role") != ("active" if member == owner else "standby")
            or view.get("owner") != owner or view.get("term") != term or view.get("peer_heard") is not True
        ):
            return None
    return owner, term


def ownership_conflict(observation, owner, term):
    """Describe any reachable member that contradicts ``owner``/``term``."""
    if observation.get("split_brain") is not False:
        return "both members forward (split brain)"
    for member in ("a", "b"):
        view = (observation.get(member) or {}).get("status")
        if not isinstance(view, dict) or view.get("fresh") is not True:
            continue
        if (view.get("role") == "active") != (member == owner):
            return f"member {member} changed role to {view.get('role')}"
        if view.get("term") != term or view.get("owner") != owner:
            return f"member {member} reports owner {view.get('owner')} term {view.get('term')}"
    return None


def member_status(raw, router_id, member):
    status = json.loads(raw)
    if (
        not isinstance(status, dict) or status.get("router_id") != router_id
        or status.get("member") != member or not isinstance(status.get("pair"), dict)
    ):
        raise RuntimeError(f"member {member} --ha-status reported another router or member")
    return status


def dropped_packets(listing):
    data = json.loads(listing) if isinstance(listing, str) else listing
    return sum(
        expression["counter"]["packets"]
        for item in data.get("nftables", [])
        for expression in item.get("rule", {}).get("expr", [])
        if "counter" in expression
    )


def cut_script(table, inbound, outbound, *, delay, seconds):
    """Shell that schedules a self-healing nft cut; evidence is saved before removal."""
    if (
        not re.fullmatch(r"sf_ha_[a-z]+_[0-9a-f]{8}", table)
        or type(delay) is not int or not 1 <= delay <= 60
        or type(seconds) is not int or not 10 <= seconds <= 600
    ):
        raise ValueError("invalid owned cut table or timing")
    rules = f"""table inet {table} {{
  chain input {{ type filter hook input priority -300; policy accept; {inbound} }}
  chain output {{ type filter hook output priority -300; policy accept; {outbound} }}
}}
"""
    heal = f"nft -j list table inet {table} > /run/{table}.json; nft delete table inet {table}"
    return f"""set -eu
nft delete table inet {table} 2>/dev/null || true
rm -f /run/{table}.json
cat > /run/{table}.nft <<'EOF'
{rules}EOF
systemd-run --quiet --collect --unit {table}-heal --on-active={delay + seconds} /bin/sh -c {shlex.quote(heal)}
systemd-run --quiet --collect --unit {table}-cut --on-active={delay} /usr/sbin/nft -f /run/{table}.nft
echo scheduled
"""


def heal_script(table):
    if not re.fullmatch(r"sf_ha_[a-z]+_[0-9a-f]{8}", table):
        raise ValueError("invalid owned cut table")
    return f"""set -eu
systemctl stop {table}-cut.timer {table}-heal.timer 2>/dev/null || true
nft delete table inet {table} 2>/dev/null || true
echo healed
"""


def require_rolling_version_scope(versions, target):
    if not isinstance(versions, dict) or set(versions) != {"a", "b"} or any(
        not isinstance(version, str) or not version for version in versions.values()
    ):
        raise CapabilityBlocked("rolling acceptance requires exact recorded member versions")
    for version in {target, *versions.values()}:
        validation = subprocess.run(["dpkg", "--validate-version", version], capture_output=True, check=False)
        if validation.returncode != 0:
            raise RuntimeError("recorded or target runtime version is not a valid Debian version")
    for current in versions.values():
        result = subprocess.run(
            ["dpkg", "--compare-versions", current, "lt", target], capture_output=True, check=False,
        )
        if result.returncode not in (0, 1):
            raise RuntimeError("could not compare recorded runtime and target versions")
        if result.returncode != 0:
            raise CapabilityBlocked("rolling acceptance needs both guests on a genuinely older package")


def pair_identity(router):
    standby = router.get("standby")
    if not isinstance(standby, dict):
        raise RuntimeError("HA inventory lacks the second physical member")
    members = {
        "a": {key: router.get(key) for key in ("node", "vmid", "management_address_cidr", "vtep_ip")},
        "b": {key: standby.get(key) for key in ("node", "vmid", "management_address_cidr", "vtep_ip")},
    }
    management = []
    for member in members.values():
        if (
            not isinstance(member["node"], str)
            or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]*", member["node"])
            or type(member["vmid"]) is not int or member["vmid"] <= 0
        ):
            raise RuntimeError("HA inventory has invalid physical VM identity")
        management.append(ipaddress.IPv4Interface(member["management_address_cidr"]).ip)
        ipaddress.IPv4Address(member["vtep_ip"])
    if (
        members["a"]["node"] == members["b"]["node"]
        or members["a"]["vmid"] == members["b"]["vmid"]
        or management[0] == management[1]
        or members["a"]["vtep_ip"] != members["b"]["vtep_ip"]
    ):
        raise RuntimeError("HA members require separate hosts/VMs/management identities and a shared VTEP")
    return members


def measurements(cases, results, event_guest_bounds):
    if (
        len(cases) != 2 or {case["protocol"] for case in cases} != {"tcp", "udp"}
        or any(case.get("echo_format") != "observed-peer" for case in cases)
    ):
        raise ValueError("HA acceptance requires exactly one observed-peer TCP and UDP flow")
    networking.validate_held_results(cases, results)
    lower, upper = event_guest_bounds
    if not all(math.isfinite(value) for value in (lower, upper)) or lower > upper:
        raise ValueError("invalid fault clock bounds")
    flows = []
    for case, result in zip(cases, results):
        samples = result["samples"]
        start = result["started_monotonic"]
        before = [sample for sample in samples if start + sample["received_seconds"] < lower]
        after = [sample for sample in samples if start + sample["sent_seconds"] > upper]
        failures = list(result["failures"])
        if len(before) < 2:
            failures.append("flow was not established before the fault")
        if len(after) < 2:
            failures.append("fewer than two post-fault requests received verified replies")
        gap = recovery = None
        if before and after:
            last = start + before[-1]["received_seconds"]
            first = start + after[0]["received_seconds"]
            gap = first - last
            recovery = [max(0, first - upper), max(0, first - lower)]
        peers = result["observed_peers"]
        preserved = not failures and len(peers) == 1 and peers[0][0] == case["expected_nat_address"]
        flows.append({
            "protocol": case["protocol"], "survived": preserved, "failures": failures,
            "pre_fault_responses": len(before), "post_fault_responses": len(after),
            "event_response_gap_seconds": gap, "recovery_delay_seconds_bounds": recovery,
            "max_response_gap_seconds": result["max_response_gap_seconds"],
            "nat_tuples": peers, "application_bytes_sent": result["application_bytes_sent"],
            "application_bytes_received": result["application_bytes_received"],
        })
    return {
        "flows": flows, "survival_percent": 100 * sum(flow["survived"] for flow in flows) / len(flows),
        "passed": all(flow["survived"] for flow in flows),
        "scope": "held TCP/UDP session survival, observed NAT tuples and response interruption; no packet replay",
    }


class SingleSegmentLab(networking.LiveLab):
    def vm_config(self, vm):
        if self.state.get("migration_events"):
            inventory = self.proxmox.get("/cluster/resources", params={"type": "vm"})["data"]
            matches = [item for item in inventory if item.get("vmid") == vm["vmid"]]
            if len(matches) != 1 or matches[0].get("type") != "qemu":
                raise RuntimeError("migrating workload VM location is missing or ambiguous")
            location = matches[0]["node"]
            if location not in self.state["migration_nodes"]:
                raise RuntimeError("workload moved outside its authorized migration nodes")
            candidate = {**vm, "node": location}
            config = super().vm_config(candidate)
            if vm["node"] != location:
                vm["node"] = location
                self.save()
            return config
        return super().vm_config(vm)

    def router_policy(self):
        router = self.request("GET", f"/north-south-routers/{self.state['router']}")
        require_pair(router)
        return {key: router[key] for key in networking.POLICY_KEYS}

    def preflight(self):
        hosts = self.request("GET", "/hosts")
        if not any(
            host["node"] == self.state["nodes"][0] and host["status"] == "enrolled"
            and host["cluster"] == self.config["proxmox_cluster_name"] for host in hosts
        ):
            raise RuntimeError("workload host is not enrolled in the disposable cluster")
        existing, reserved = self.network_inventory()
        segment = self.state["segments"][0]
        network = ipaddress.IPv4Network(segment["network"])
        if any(item["id"] == segment["id"] for item in existing) or any(
            network.overlaps(item) for item in reserved if item.version == 4
        ):
            raise RuntimeError("test segment ID/subnet is already in use")
        images = self.proxmox.get(
            f"/nodes/{self.state['nodes'][0]}/storage/{self.state['storage']}/content",
        )["data"]
        if not any(image["volid"] == self.state["image_volume"] for image in images):
            raise RuntimeError("workload image is unavailable")

    def set_wan(self, allowed, restore=False):
        if not restore or allowed:
            raise RuntimeError("HA test WAN policy is fixed at router creation")
        if self.router_policy() != self.state["original_wan_policy"]:
            raise RuntimeError("HA test router policy changed outside this run; cleanup refused")
        # The owned router will be deleted next; there is no borrowed WAN policy to restore.
        self.state.pop("original_wan_policy")
        self.save()

    def configure(self):
        if len(self.state["vms"]) != 1 or len(self.state["segments"]) != 1:
            raise RuntimeError("HA workload must contain exactly one segment and one VM")
        vm = self.state["vms"][0]
        self.setup_serial(vm, "systemctl is-active --quiet swiftfabric-network-lab")
        segment = self.state["segments"][0]
        current = self.owned_segment(segment)
        self.request("PUT", f"/segments/{segment['id']}/north-south-router", {
            "router_id": self.state["router"], "_version": current["_version"],
        })
        self.state["ready"] = True
        # Policy is configured at router creation; teardown must not mutate live HA policy.
        self.state.pop("original_wan_policy", None)
        self.save()


def execute_owned_guest(run, router_id, member, physical, fingerprint, program, *, timeout=90):
    if type(timeout) is not int or not 1 <= timeout <= 240:
        raise ValueError("owned guest command timeout must be between 1 and 240 seconds")
    address = str(ipaddress.IPv4Interface(physical["management_address_cidr"]).ip)
    candidate = run.api.json(
        "GET", f"/north-south-routers/{router_id}/ssh-host-key?member={member}",
    )
    if not isinstance(candidate, dict):
        raise RuntimeError("owned guest SSH trust response is invalid")
    trusted = candidate.get("trusted")
    if (
        candidate.get("changed") is not False or not isinstance(trusted, dict)
        or trusted.get("endpoint") != f"[{address}]:22"
        or trusted.get("fingerprint") != fingerprint
    ):
        raise RuntimeError("owned guest SSH trust changed; guest command refused")
    key = trusted["public_key"]
    if not isinstance(key, str) or len(key.split()) != 2:
        raise RuntimeError("owned guest SSH public key is invalid")
    if deployment.SSHCommandRunner._fingerprint(key.split()[1]) != trusted["fingerprint"]:
        raise RuntimeError("owned guest SSH key no longer matches its approved fingerprint")
    bindings = (
        f"ROUTER={router_id!r};MEMBER={member!r};"
        f"ADDRESS={address!r};EXPECTED={physical!r};PINS={address + ' ' + key + chr(10)!r};"
        f"PROGRAM={program!r};TIMEOUT={timeout!r};"
    )
    transport = """
import json,os,pathlib,subprocess,sys,tempfile
segments=json.loads(pathlib.Path("/var/lib/swiftfabric/segments.json").read_text())
env=dict(os.environ,REDISCLI_AUTH=segments["4999"]["password"])
raw=subprocess.run(["valkey-cli","--raw","-p","4999","HGET",
    "swiftfabric:north_south_routers",ROUTER],env=env,capture_output=True,text=True,check=True).stdout
router=json.loads(raw)
physical=router if MEMBER=="a" else router["standby"]
if any(physical.get(k)!=v for k,v in EXPECTED.items()):
    raise RuntimeError("controller-local physical identity changed; guest command refused")
with tempfile.TemporaryDirectory(prefix="ha-guest-",dir="/var/lib/swiftfabric/router-deploy") as directory:
    key=pathlib.Path(directory)/"key"
    key.write_text(physical["ssh_private_key"])
    key.chmod(0o600)
    pins=pathlib.Path(directory)/"known_hosts"
    pins.write_text(PINS)
    pins.chmod(0o600)
    result=subprocess.run(["ssh","-i",str(key),"-o","IdentitiesOnly=yes",
        "-o","BatchMode=yes","-o","StrictHostKeyChecking=yes",
        "-o","GlobalKnownHostsFile=/dev/null","-o","UserKnownHostsFile="+str(pins),
        "-o","ConnectTimeout=5","ubuntu@"+ADDRESS,"sudo -n /bin/sh -s"],
        input=PROGRAM,capture_output=True,text=True,timeout=TIMEOUT)
    if result.returncode:
        raise RuntimeError("owned guest command failed: "+result.stderr[-2000:])
    sys.stdout.write(result.stdout)
"""
    result = run.api.ssh.run(
        run.config["ip_range_start"],
        shlex.join(["sudo", "-n", "/usr/bin/python3", "-c", bindings + transport]),
        timeout=timeout + 20,
    )
    return result


class HARun(deployment.RecoveryRun):
    def require_platform_healthy(self):
        guard = getattr(self, "platform_health", None)
        if guard is not None:
            guard.check()

    def stage(self, name, operation):
        def guarded():
            if self.api is None:
                operation()
                if self.api is not None:
                    with PlatformHealth(self):
                        pass
                return
            previous = getattr(self, "platform_health", None)
            with PlatformHealth(self) as guard:
                self.platform_health = guard
                try:
                    operation()
                finally:
                    # Keep any enclosing saved-action guard reachable for cleanup.
                    self.platform_health = previous

        if name == "cleanup" and getattr(self, "platform_health", None) is not None:
            # Final strict verdict before owned controllers are deliberately destroyed.
            self.platform_health.close()
        return super().stage(name, operation if name == "cleanup" else guarded)

    def cleanup(self):
        if any(record.get("cleanup_complete") is not True
               for record in self.state.get("second_endpoint_runs", [])):
            raise RuntimeError("second endpoint cleanup pending; run nsr_two_endpoint.py --cleanup first")
        return super().cleanup()

    def router(self):
        self.require_platform_healthy()
        return self.api.json("GET", f"/north-south-routers/{self.state['router_requested']}")

    def create_router(self):
        request = read_config_object(self.args.router_config)
        identifier = self.state.get("router_requested", self.state["prefix"] + "-nsr")
        network = str(ipaddress.IPv4Interface(self.args.segment).network)
        request.update({
            "id": identifier, "name": identifier, "tenant_id": "default",
            "cluster": self.config["proxmox_cluster_name"], "deployment_mode": "active-standby",
            "ha_shared_vtep": True,
            "ha_replication_mode": ASYNC_MODE, "standby_node": self.args.nodes[1],
            "masquerade_source_cidrs": [network], "wan_ingress_rules": [],
            "inbound_port_mappings": [], "outbound_port_mappings": [],
            "wan_egress_rules": [
                networking.acl_rule(network, f"{self.args.endpoint}/32", protocol, str(port))
                for protocol, port in (("tcp", self.args.tcp_port), ("udp", self.args.udp_port))
            ],
        })
        self.state["router_requested"] = identifier
        self.save()
        router = self.api.json("POST", "/north-south-routers", request)
        if router.get("id") != identifier or router.get("name") != identifier:
            raise RuntimeError("controller returned a foreign NSR identity")
        # Old controllers may ignore unknown request fields; verify persisted mode before deploying VMs.
        require_pair(router)
        self.state["router"] = {key: router[key] for key in ("id", "name")}
        self.save()

    def create_lab(self):
        directory = self.directory / "network-lab"
        directory.mkdir(mode=0o700)
        self.lab_lock = os.open(directory / "run.lock", os.O_WRONLY | os.O_CREAT, 0o600)
        fcntl.flock(self.lab_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        run_id = uuid.uuid4().hex
        interface = ipaddress.IPv4Interface(self.args.segment)
        deployment.private_write(directory / "state.json", {
            "run_id": run_id, "config": str(self.args.config), "nodes": [self.args.nodes[0]],
            "segments": [{
                "id": self.args.segment_id, "name": f"sf-ha-{run_id[:8]}",
                "gateway_cidr": str(interface), "network": str(interface.network), "created": False,
            }],
            "vms": [], "router": self.state["router_requested"], "image_volume": self.args.image_volume,
            "storage": self.args.image_volume.split(":", 1)[0], "dns_address": self.args.endpoint,
            "console_password": secrets.token_urlsafe(32), "settle_seconds": 35,
            "results": [], "ready": False,
        })
        self.lab = SingleSegmentLab(directory)
        self.lab.create()

    def deploy_pair(self):
        self.api.json("POST", f"/north-south-routers/{self.state['router_requested']}/deploy")
        deadline = time.monotonic() + 1800
        while time.monotonic() < deadline:
            router = self.router()
            require_pair(router)
            if router.get("status") == "failed":
                raise RuntimeError("asynchronous NSR deployment failed")
            if router.get("status") == "active":
                require_pair(router, deployed=True)
                self.state["pair"] = pair_identity(router)
                self.state["router"] = {key: router[key] for key in ("id", "name", "vmid")}
                self.save()
                self.trust_pair()
                return
            time.sleep(5)
        raise TimeoutError("NSR pair did not become ready within 1800 seconds")

    def trust_pair(self):
        if os.environ.get("SWIFTFABRIC_INTEGRATION_TOFU") != "1":
            raise CapabilityBlocked("NSR first-use trust requires an authorized integration SSH session")
        if pair_identity(self.router()) != self.state["pair"]:
            raise RuntimeError("physical NSR identities changed before first-use trust")
        fingerprints = {}
        for member, physical in self.state["pair"].items():
            address = str(ipaddress.IPv4Interface(physical["management_address_cidr"]).ip)
            endpoint = f"[{address}]:22"
            path = f"/north-south-routers/{self.state['router_requested']}/ssh-host-key?member={member}"
            candidate = self.api.json("GET", path)
            if (not isinstance(candidate, dict) or candidate.get("endpoint") != endpoint
                    or candidate.get("changed") is not False):
                raise CapabilityBlocked("owned NSR SSH candidate is invalid or changed; trust not replaced")
            observed = candidate.get("observed")
            if (not isinstance(observed, list) or not observed
                    or any(not isinstance(key, dict) for key in observed)):
                raise CapabilityBlocked("owned NSR supplied no valid SSH candidate")
            trusted = candidate.get("trusted")
            selected = trusted if trusted is not None else observed[0]
            if (not isinstance(selected, dict) or not isinstance(selected.get("public_key"), str)
                    or len(selected["public_key"].split()) != 2):
                raise CapabilityBlocked("owned NSR SSH trust record is invalid")
            fingerprint = deployment.SSHCommandRunner._fingerprint(selected["public_key"].split()[1])
            if (selected.get("fingerprint") != fingerprint
                    or not any(key.get("public_key") == selected["public_key"]
                               and key.get("fingerprint") == fingerprint for key in observed)
                    or trusted is not None and trusted.get("endpoint") != endpoint):
                raise CapabilityBlocked("owned NSR SSH fingerprint does not match; trust not replaced")
            if trusted is None:
                print(f"First-use NSR SSH host key for {address}: {fingerprint}\n"
                      "TOFU cannot detect interception on this first connection.\n"
                      "Integration test: automatically trusting this owned disposable guest.", flush=True)
                approved = self.api.json(
                    "POST", path.replace("/ssh-host-key?", "/ssh-host-key/approve?"),
                    {"endpoint": endpoint, "public_key": selected["public_key"]},
                )
                record = approved.get("trusted") if isinstance(approved, dict) else None
                if (not isinstance(approved, dict) or approved.get("approved") is not True
                        or not isinstance(record, dict) or record.get("endpoint") != endpoint
                        or record.get("public_key") != selected["public_key"]
                        or record.get("fingerprint") != fingerprint):
                    raise RuntimeError("controller did not acknowledge exact NSR first-use trust")
            fingerprints[member] = fingerprint
        self.state["guest_ssh_fingerprints"] = fingerprints
        self.save()

    def run_owned_guest(self, member, program, *, timeout=90):
        self.owned_member_path(member)
        return execute_owned_guest(
            self, self.state["router_requested"], member, self.state["pair"][member],
            self.state["guest_ssh_fingerprints"][member], program, timeout=timeout,
        )

    def guest_clock(self, vm):
        before = time.monotonic()
        value = float(self.lab.serial(vm, "python3 -c 'import time; print(time.monotonic())'", timeout=30))
        after = time.monotonic()
        if not math.isfinite(value) or value < 0:
            raise ValueError("invalid guest monotonic clock")
        return [before - value, after - value]

    def probe_status(self, vm, directory, *, lab=None):
        self.require_platform_healthy()
        command = (
            f"if test -f {shlex.quote(directory + '/status.json')}; then "
            f"cat {shlex.quote(directory + '/status.json')}; else printf '{{}}'; fi"
        )
        # Read-only, so lost serial console markers can be retried safely.
        return json.loads((lab or self.lab).setup_serial(vm, "sudo -n sh -c " + shlex.quote(command), timeout=30))

    def start_probes(self, vm, cases, directory, *, unit="swiftfabric-ha-probes", lab=None):
        self.require_platform_healthy()
        if not re.fullmatch(r"swiftfabric-ha-probes(?:-[a-f0-9]{16})?", unit):
            raise ValueError("invalid owned HA probe service unit")
        sources = {
            "/opt/guest.py": (ROOT / "network-lab" / "guest.py").read_bytes(),
            "/opt/nsr_ha_guest.py": Path(__file__).with_name("nsr_ha_guest.py").read_bytes(),
        }
        program = "import pathlib,base64,gzip;"
        for path, source in sources.items():
            program += (
                f"pathlib.Path({path!r}).write_bytes("
                f"gzip.decompress(base64.b64decode({networking.encode(source)!r})));"
            )
        command = "sudo -n python3 -c " + "\\\n".join(
            shlex.quote(program[index:index + 512]) for index in range(0, len(program), 512)
        )
        # Idempotent source upload; systemd-run below is not retried.
        (lab or self.lab).setup_serial(vm, command, timeout=120)
        command = shlex.join([
            "sudo", "-n", "systemd-run", "--collect", "--unit", unit,
            "/usr/bin/python3", "/opt/nsr_ha_guest.py", json.dumps(cases), directory,
        ])
        (lab or self.lab).serial(vm, command, timeout=30)

    def stop_probes(self, vm, unit, *, lab=None):
        if not re.fullmatch(r"swiftfabric-ha-probes(?:-[a-f0-9]{16})?", unit):
            raise ValueError("invalid owned HA probe service unit")
        program = f"""import json,subprocess
unit={unit + ".service"!r}
def state(property):
    return subprocess.run(["systemctl","show",unit,"--property="+property,"--value"],
                          check=True,capture_output=True,text=True,timeout=10).stdout.strip()
load=state("LoadState")
if load!="not-found":
    if load!="loaded":raise RuntimeError("unknown probe unit load state: "+load)
    subprocess.run(["systemctl","stop",unit],check=True,capture_output=True,text=True,timeout=15)
    if state("ActiveState") not in ("inactive","failed"):
        raise RuntimeError("owned probe service did not stop")
print(json.dumps({{"unit":unit,"stopped_or_collected":True}}))
"""
        return json.loads((lab or self.lab).serial(
            vm, shlex.join(["sudo", "-n", "/usr/bin/python3", "-c", program]), timeout=30,
        ))

    def owned_member_path(self, member):
        physical = self.state["pair"][member]
        path = f"/nodes/{physical['node']}/qemu/{physical['vmid']}"
        configuration = self.proxmox.get(path + "/config")["data"]
        if (
            configuration.get("name") != f"{self.state['router_requested']}-{member}"
            or f"ip={physical['management_address_cidr']}" not in configuration.get("ipconfig0", "").split(",")
        ):
            raise RuntimeError("physical member ownership changed; power operation refused")
        return path

    def power_member(self, member, action):
        if action not in ("start", "stop"):
            raise ValueError("unsupported member power action")
        path = self.owned_member_path(member)
        self.state.setdefault("power_events", []).append({
            "member": member, "action": action, "requested_epoch": time.time(),
        })
        self.save()
        deployment.wait_task(self.proxmox, self.proxmox.post(path + "/status/" + action))
        expected = "running" if action == "start" else "stopped"
        if self.proxmox.get(path + "/status/current")["data"]["status"] != expected:
            raise RuntimeError(f"member {member} did not become {expected}")

    def pair_status(self):
        self.require_platform_healthy()
        return self.api.json("GET", f"/north-south-routers/{self.state['router_requested']}/ha-status")

    def member_status(self, member):
        raw = self.run_owned_guest(member, f"set -eu\n{ROUTER_CLI} --ha-status\n", timeout=30)
        return member_status(raw, self.state["router_requested"], member)

    def wait_converged(self, owner=None, *, term=None, minimum_term=None, timeout=240):
        """Wait for one converged owner; with ``term`` any other converged owner/term fails."""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            current = converged(self.pair_status(), self.state["router_requested"])
            if current is not None:
                if term is not None and current != (owner, term):
                    raise RuntimeError(
                        f"pair converged on member {current[0]} term {current[1]}; expected {owner} term {term}")
                if (owner is None or current[0] == owner) and (minimum_term is None or current[1] >= minimum_term):
                    return current
            time.sleep(2)
        raise TimeoutError("NSR pair members did not converge on one owner and term")

    def observe_stable(self, owner, term, seconds, *, reachable=True):
        """Sample controller observations; any contradicting member fails immediately."""
        started = time.monotonic()
        samples = []
        while not samples or time.monotonic() - started < seconds:
            observation = self.pair_status()
            conflict = ownership_conflict(observation, owner, term)
            if conflict:
                raise RuntimeError(f"forwarding ownership changed: {conflict}")
            current = converged(observation, self.state["router_requested"])
            if reachable and current is None:
                raise RuntimeError("pair lost owner/term convergence or peer liveness")
            samples.append({
                "seconds": time.monotonic() - started, "converged": current is not None,
                "errors": {member: (observation.get(member) or {}).get("error") for member in ("a", "b")},
            })
            time.sleep(2)
        return samples

    def record(self, name, report):
        path = self.directory / "ha-report.json"
        summary = read_config_object(path) if path.exists() else {"scenarios": {}}
        summary["scenarios"][name] = report
        summary["passed"] = set(REQUIRED_SCENARIOS) <= set(summary["scenarios"]) and all(
            item.get("passed") is True for item in summary["scenarios"].values())
        deployment.private_write(path, summary)
        write_ha_report(self.directory)

    def run_integrated_scenarios(self):
        for name, action in (
            ("pair-status", self.baseline_status),
            ("planned-handoff", self.planned_scenario),
            ("replication-cut", self.replication_cut),
            ("controller-path-cut", self.controller_cut),
            ("active-crash", self.crash_scenario),
        ):
            self.stage(name, action)

    def cleanup_integrated_resources(self):
        router_id = self.state["router_requested"]
        routers = self.api.json("GET", "/north-south-routers")
        if not isinstance(routers, list) or any(not isinstance(item, dict) for item in routers):
            raise RuntimeError("Controller returned invalid router inventory; HA cleanup refused.")
        matches = [item for item in routers if item.get("id") == router_id]
        if len(matches) > 1:
            raise RuntimeError("HA router identity is ambiguous; cleanup refused.")
        if matches:
            router = matches[0]
            require_pair(router, deployed=True)
            if pair_identity(router) != self.state.get("pair"):
                raise RuntimeError("HA router member ownership changed; cleanup refused.")
            version = router.get("_version")
            if type(version) is not int or version < 1:
                raise RuntimeError("HA router inventory lacks a valid _version; cleanup refused.")
            self.api.json("DELETE", f"/north-south-routers/{router_id}?_version={version}")
            remaining = self.api.json("GET", "/north-south-routers")
            if not isinstance(remaining, list) or any(item.get("id") == router_id for item in remaining):
                raise RuntimeError("HA router teardown did not complete.")
        if self.lab is not None:
            self.lab.destroy(router_retired=True)
        self.state["cleanup_status"] = "complete"
        self.save()

    def flow_cases(self, port, duration):
        return [{**case, "source_port": port + index, "duration_seconds": duration}
                for index, case in enumerate(self.state["held_flow_cases"])]

    def wait_established(self, vm, remote, nat=None):
        deadline = time.monotonic() + 90
        while time.monotonic() < deadline:
            status = self.probe_status(vm, remote)
            deployment.private_write(
                self.directory / f"{Path(remote).name}-preflight.json", status,
            )
            if status.get("results") or status.get("completed"):
                errors = "; ".join(
                    f"{result.get('protocol', 'unknown')}: "
                    f"{result.get('error') or 'flow ended before HA event'}"
                    for result in status.get("results", [])
                )
                raise RuntimeError(
                    "held probe terminated early; endpoint/traffic preflight failed"
                    + (f": {errors}" if errors else ""),
                )
            progress = status.get("progress", {})
            if all(
                progress.get(protocol, {}).get("verified_responses", 0) >= 8
                and (nat is None or progress[protocol]["sample"]["peer"][0] == nat)
                for protocol in ("tcp", "udp")
            ):
                return progress
            time.sleep(1)
        raise TimeoutError("both held flows must exchange verified WAN replies before the HA event")

    def held_traffic(self, label, duration, during=None):
        """Run uninterrupted held TCP/UDP flows, optionally around ``during()``."""
        vm = self.lab.state["vms"][0]
        token = secrets.token_hex(8)
        unit = "swiftfabric-ha-probes-" + token
        cases = self.flow_cases(20000 + 2 * secrets.randbelow(20000), duration)
        remote = f"/var/lib/swiftfabric-ha-test-{self.lab.state['run_id']}-{label}-{token}"
        output = self.directory / f"{label}-{token}-probes.json"
        report = {"passed": False, "cases": cases, "probe_directory": remote, "probe_unit": unit}
        traffic_passed = False
        try:
            self.start_probes(vm, cases, remote, unit=unit)
            if during is not None:
                self.wait_established(vm, remote)
                report["during"] = during()
            deadline = time.monotonic() + duration + 60
            while time.monotonic() < deadline:
                status = self.probe_status(vm, remote)
                if status.get("completed"):
                    report["status"] = status
                    results = sorted(status["results"], key=lambda item: ("tcp", "udp").index(item["protocol"]))
                    networking.validate_held_results(cases, results)
                    if any(result["failures"] or len(result["samples"]) < 10 for result in results):
                        raise RuntimeError(f"{label}: held TCP/UDP WAN traffic was interrupted")
                    traffic_passed = True
                    return report
                time.sleep(2)
            raise TimeoutError(f"{label}: held traffic probes did not complete")
        finally:
            report["traffic_passed"] = traffic_passed
            deployment.private_write(output, report)
            print(output)
            report["cleanup"] = self.stop_probes(vm, unit)
            report["passed"] = traffic_passed
            deployment.private_write(output, report)

    def baseline_status(self):
        vm = self.lab.state["vms"][0]
        nat = str(ipaddress.IPv4Interface(self.router()["wan_address_cidr"]).ip)
        self.state["held_flow_cases"] = [
            {"source": vm["address"], "destination": self.args.endpoint, "destination_port": port,
             "protocol": protocol, "expected_nat_address": nat, "echo_format": "observed-peer"}
            for protocol, port in (("tcp", self.args.tcp_port), ("udp", self.args.udp_port))
        ]
        self.save()
        owner, term = self.wait_converged()
        report = {"passed": True, "owner": owner, "term": term,
                  "members": {member: self.member_status(member) for member in ("a", "b")}}
        self.record("pair-status", report)
        return report

    def planned_handoff(self, source, term, fault):
        target = other(source)
        result = self.api.json(
            "POST", f"/north-south-routers/{self.state['router_requested']}/ha-failover/planned",
            {"target_member": target},
        )
        if (
            not isinstance(result, dict) or result.get("planned_handoff_completed") is not True
            or result.get("active_member") != target
        ):
            raise RuntimeError("controller did not report a completed planned handoff")
        fault["completed_monotonic"] = time.monotonic()
        self.save()
        owner, new_term = self.wait_converged(target, minimum_term=term + 1, timeout=60)
        return {"member": owner, "term": new_term, "observed_monotonic": time.monotonic()}

    def crash_active(self, source, term, fault):
        path = self.owned_member_path(source)
        if self.proxmox.get(path + "/status/current")["data"]["status"] != "running":
            raise RuntimeError("active NSR is not running before fault injection")
        deployment.wait_task(self.proxmox, self.proxmox.post(path + "/status/stop"))
        if self.proxmox.get(path + "/status/current")["data"]["status"] != "stopped":
            raise RuntimeError("abrupt NSR stop did not complete")
        fault["completed_monotonic"] = time.monotonic()
        self.save()
        survivor = other(source)
        deadline = fault["completed_monotonic"] + 60
        while time.monotonic() < deadline:
            status = self.member_status(survivor)
            pair = status["pair"]
            if (
                status.get("role") == "active" and pair.get("owner") == survivor
                and type(pair.get("term")) is int and pair["term"] > term
            ):
                observed = time.monotonic()
                return {"member": survivor, "term": pair["term"], "observed_monotonic": observed,
                        "takeover_observed_seconds": observed - fault["completed_monotonic"],
                        "status": status}
            time.sleep(0.5)
        raise TimeoutError("standby did not promote itself after the active member stopped")

    def rolling_upgrade(self, source, term, fault):
        targets = self.state["rolling_targets"]
        receipt = self.api.json("POST", f"/north-south-routers/{self.state['router_requested']}/upgrade")
        summary = receipt.get("router") if isinstance(receipt, dict) else None
        journal = summary.get("ha_rolling_upgrade") if isinstance(summary, dict) else None
        if (
            receipt.get("upgrade_started") is not True or not isinstance(journal, dict)
            or journal.get("source_member") != source or journal.get("successor_member") != other(source)
            or journal.get("target_runtime") != targets["runtime"]
            or journal.get("target_agent") != targets["agent"]
        ):
            raise CapabilityBlocked("controller did not record the exact rolling upgrade intent")
        deadline = time.monotonic() + ROLLING_HELD_SECONDS - 60
        while time.monotonic() < deadline:
            router = self.router()
            journal = router.get("ha_rolling_upgrade") or {}
            if journal.get("failure"):
                raise RuntimeError("rolling upgrade paused: " + str(journal["failure"])[:200])
            if journal.get("phase") == "completed" and router.get("upgrade_in_progress") is False:
                break
            time.sleep(5)
        else:
            raise TimeoutError("rolling upgrade did not complete within the held-session window")
        fault["completed_monotonic"] = time.monotonic()
        self.save()
        owner, new_term = self.wait_converged(other(source), minimum_term=term + 1, timeout=120)
        return {"member": owner, "term": new_term, "observed_monotonic": time.monotonic(), "journal": journal}

    def measure(self, event, label, duration):
        """Hold original TCP/UDP sockets across one HA event and measure their interruption."""
        events = {"planned": self.planned_handoff, "crash": self.crash_active, "rolling": self.rolling_upgrade}
        vm = self.lab.state["vms"][0]
        previous = self.state.pop("held_probe_unit", None)
        if previous is not None:
            self.state["held_probe_cleanup"] = self.stop_probes(vm, previous)
            self.save()
        router = self.router()
        require_pair(router, deployed=True)
        if pair_identity(router) != self.state["pair"]:
            raise RuntimeError("physical NSR identities changed; HA event refused")
        source, term = self.wait_converged()
        nat = str(ipaddress.IPv4Interface(router["wan_address_cidr"]).ip)
        cases = self.flow_cases(20000 + 2 * secrets.randbelow(20000), duration)
        unit = "swiftfabric-ha-probes-" + secrets.token_hex(8)
        remote = f"/var/lib/swiftfabric-ha-test-{self.lab.state['run_id']}-{label}-{time.time_ns()}"
        self.state.update(held_probe_directory=remote, held_probe_unit=unit)
        self.save()
        try:
            offset_before = self.guest_clock(vm)
            self.start_probes(vm, cases, remote, unit=unit)
            self.wait_established(vm, remote, nat)
            fault = {"kind": event, "member": source, "term": term,
                     "started_monotonic": time.monotonic(), "started_epoch": time.time()}
            self.state["fault"] = fault
            self.save()
            successor = events[event](source, term, fault)
            deadline = time.monotonic() + duration + 120
            while time.monotonic() < deadline:
                status = self.probe_status(vm, remote)
                deployment.private_write(self.directory / f"{label}-held-probes.json", status)
                if status.get("completed"):
                    break
                time.sleep(1)
            else:
                raise TimeoutError("held-flow observation did not finish")
            stopped = self.state["pair"][source]
            source_state = self.proxmox.get(
                f"/nodes/{stopped['node']}/qemu/{stopped['vmid']}/status/current")["data"]["status"]
            if source_state != ("stopped" if event == "crash" else "running"):
                raise RuntimeError(f"former active VM is unexpectedly {source_state}")
            offset_after = self.guest_clock(vm)
            offsets = [min(offset_before[0], offset_after[0]), max(offset_before[1], offset_after[1])]
            bounds = [fault["started_monotonic"] - offsets[1], fault["completed_monotonic"] - offsets[0]]
            results = sorted(status["results"], key=lambda result: ("tcp", "udp").index(result["protocol"]))
            report = measurements(cases, results, bounds)
            report.update(fault=fault, successor=successor, guest_fault_clock_bounds=bounds,
                          operator_guest_clock_offset_bounds=offsets)
            if event == "crash":
                report["takeover_limit_seconds"] = TAKEOVER_LIMIT_SECONDS
                report["passed"] = (report["passed"]
                                    and successor["takeover_observed_seconds"] <= TAKEOVER_LIMIT_SECONDS)
            deployment.private_write(self.directory / f"{label}-report.json", report)
            if not report["passed"]:
                raise RuntimeError(f"{label}: HA session acceptance failed; inspect {label}-report.json")
            return report
        finally:
            unit = self.state.pop("held_probe_unit", None)
            if unit is not None:
                self.state["held_probe_cleanup"] = self.stop_probes(vm, unit)
                self.save()

    def planned_scenario(self):
        report = self.measure("planned", "planned-handoff", self.args.duration)
        self.record("planned-handoff", report)

    def crash_scenario(self):
        report = self.measure("crash", "active-crash", self.args.duration)
        source, successor = report["fault"]["member"], report["successor"]
        self.power_member(source, "start")
        owner, term = self.wait_converged(successor["member"], term=successor["term"])
        report["rejoin_samples"] = self.observe_stable(owner, term, REJOIN_OBSERVATION_SECONDS)
        report["rejoin_traffic"] = self.held_traffic("old-active-rejoined", 60)
        self.record("active-crash", report)

    def cut(self, kind, members, inbound, outbound, delay, verify):
        """Cut traffic on ``members`` with self-healing nft rules while held flows continue."""
        owner, term = self.wait_converged()
        table = f"sf_ha_{kind}_{secrets.token_hex(4)}"
        script = cut_script(table, inbound, outbound, delay=delay, seconds=CUT_SECONDS)
        report = {"passed": False, "owner": owner, "term": term, "table": table, "members": members}
        output = self.directory / f"{kind}-cut-{time.time_ns()}-report.json"

        def during():
            report["scheduled_epoch"] = time.time()
            for member in members:
                self.run_owned_guest(member, script)
            time.sleep(delay + 2)
            report["samples"] = verify(owner, term, table)
            return report["samples"]

        try:
            report["traffic"] = self.held_traffic(f"{kind}-cut", delay + CUT_SECONDS + 30, during)
        finally:
            deployment.private_write(output, report)
            print(output)
        report["healed"] = self.wait_converged(owner, term=term, timeout=CUT_SECONDS + 180)
        report["dropped_packets"] = {
            member: dropped_packets(self.run_owned_guest(member, f"set -eu\ncat /run/{table}.json\n"))
            for member in members
        }
        if any(count <= 0 for count in report["dropped_packets"].values()):
            raise RuntimeError(f"{kind} cut dropped no packets; the partition was not proven")
        return report, output

    def replication_cut(self):
        owner, _ = self.wait_converged()
        standby = other(owner)
        rules = f"tcp dport {REPLICATION_PORT} counter drop; tcp sport {REPLICATION_PORT} counter drop;"

        def verify(owner, term, table):
            try:
                return self.observe_stable(owner, term, CUT_SECONDS - 10)
            except BaseException:
                self.run_owned_guest(standby, heal_script(table))
                raise

        report, output = self.cut("replication", [standby], rules, rules, 2, verify)
        deadline = time.monotonic() + 120
        while time.monotonic() < deadline:
            active, passive = self.member_status(owner), self.member_status(standby)
            if (
                (active.get("replication") or {}).get("sender", {}).get("connected") is True
                and (passive.get("replication") or {}).get("receiver", {}).get("connected") is True
            ):
                report["replication_after"] = {owner: active["replication"], standby: passive["replication"]}
                break
            time.sleep(2)
        else:
            raise TimeoutError("replication did not reconnect after the cut healed")
        report["passed"] = True
        deployment.private_write(output, report)
        self.record("replication-cut", report)

    def controller_addresses(self):
        start = ipaddress.IPv4Address(self.config["ip_range_start"])
        addresses = {str(start + index) for index in range(3)}
        addresses.add(str(ipaddress.IPv4Address(self.config["ip_range_end"])))
        addresses.add(str(ipaddress.IPv4Address(urlparse(self.api.base_url).hostname)))
        return sorted(addresses)

    def controller_cut(self):
        addresses = ", ".join(self.controller_addresses())

        def verify(owner, term, table):
            samples = self.observe_stable(owner, term, CUT_SECONDS - 10, reachable=False)
            if not any(all(sample["errors"].values()) for sample in samples):
                raise RuntimeError("controller still reached both members during the controller-path cut")
            return samples

        report, output = self.cut(
            "controller", ["a", "b"], f"ip saddr {{ {addresses} }} counter drop;",
            f"ip daddr {{ {addresses} }} counter drop;", CONTROLLER_CUT_DELAY, verify,
        )
        report["passed"] = True
        deployment.private_write(output, report)
        self.record("controller-path-cut", report)

    def test_partitions(self):
        router = self.router()
        require_pair(router, deployed=True)
        self.trust_pair()
        self.replication_cut()
        self.controller_cut()

    def test_rolling_upgrade(self):
        if self.state.get("cleanup_status") != "retained":
            raise RuntimeError("rolling acceptance requires a passing retained owned lab")
        cases = self.state.get("held_flow_cases")
        if (
            not isinstance(cases, list) or len(cases) != 2
            or any(not isinstance(c, dict) for c in cases)
            or {c.get("protocol") for c in cases} != {"tcp", "udp"}
        ):
            raise RuntimeError("retained lab does not have exact held-flow cases")
        if read_config_object(self.directory / "ha-report.json").get("passed") is not True:
            raise RuntimeError("rolling acceptance requires passing durable baseline evidence")
        import upgrade
        import agent_upgrade
        package = upgrade.ApiServiceDeployment.find_package(ROOT / "packages")
        version = upgrade._package_metadata(package)
        target_agent = agent_upgrade.package_agent_version(package)
        router = self.router()
        require_pair(router, deployed=True)
        require_rolling_version_scope(router.get("member_runtime_versions"), version)
        preflight = self.api.json(
            "GET", f"/north-south-routers/{self.state['router_requested']}/upgrade-preflight?"
            + urlencode({"target_runtime": version, "target_agent": target_agent}))
        journal = preflight.get("ha_rolling_upgrade") if isinstance(preflight, dict) else None
        if (
            not isinstance(preflight, dict) or preflight.get("supported") is not True
            or preflight.get("planned_source_capable") is not True
            or preflight.get("requested_runtime") != version or preflight.get("requested_agent") != target_agent
            or preflight.get("already_current") is not False
            or (journal is not None and (not isinstance(journal, dict) or journal.get("phase") != "completed"))
        ):
            raise CapabilityBlocked("baseline controller did not verify a fresh rolling upgrade")
        if pair_identity(router) != self.state["pair"]:
            raise RuntimeError("rolling acceptance needs both guests on their owned physical identities")
        self.state["rolling_targets"] = {"runtime": version, "agent": target_agent}
        self.state["rolling_package_sha256"] = deployment.fingerprint(package)
        self.state["rolling_test_status"] = "running"
        self.save()
        authorization = self.api.session.headers.get("Authorization", "")
        if not authorization.startswith("Bearer ") or not authorization[7:]:
            raise RuntimeError("saved lab did not authenticate its controller upgrade")
        self.stage("controller-package-upgrade", lambda: upgrade.run_upgrade(
            self.args.config, authorization[7:], prefix=self.state["prefix"],
            yes=True, package_dir=ROOT / "packages", auto_agent_upgrade=False,
        ))
        self.api.refresh()
        self.stage("rolling-upgrade-held-sessions", self.rolling_scenario)
        self.state["rolling_test_status"] = "passed"
        self.save()
        self.stage("cleanup", self.cleanup)
        self.state["cleanup_status"] = "complete"

    def rolling_scenario(self):
        report = self.measure("rolling", "rolling-upgrade", ROLLING_HELD_SECONDS)
        router = self.router()
        target = self.state["rolling_targets"]
        report["passed"] = (
            router.get("active_member") == report["successor"]["member"] != report["fault"]["member"]
            and router.get("runtime_version") == target["runtime"]
            and router.get("agent_version") == target["agent"]
            and router.get("member_runtime_versions") == {m: target["runtime"] for m in ("a", "b")}
            and router.get("member_agent_versions") == {m: target["agent"] for m in ("a", "b")}
        )
        report.update(target_versions=target, target_api_package_sha256=self.state["rolling_package_sha256"])
        if report["passed"]:
            report["after_traffic"] = self.held_traffic("rolling-upgrade-after", 60)
        self.record("rolling-upgrade", report)
        if not report["passed"]:
            raise RuntimeError("rolling upgrade did not finish on the successor with target software")

    def run_test(self):
        try:
            for name, action in (
                ("install", self.install), ("configure-nsr", self.create_router),
                ("create-segment-vm", self.create_lab), ("deploy-pair", self.deploy_pair),
                ("pair-status", self.baseline_status), ("planned-handoff", self.planned_scenario),
                ("replication-cut", self.replication_cut), ("controller-path-cut", self.controller_cut),
                ("active-crash", self.crash_scenario), ("cleanup", self.cleanup),
            ):
                if name == "cleanup" and self.state.get("retain", False):
                    self.state["cleanup_status"] = "retained"
                    print("Passing lab retained; cleanup: " + shlex.join([
                        sys.executable, str(Path(__file__).resolve()), "--cleanup", "--state", str(self.directory),
                    ]))
                    continue
                self.stage(name, action)
            self.state["status"] = "passed"
        except (OSError, ValueError, RuntimeError, KeyboardInterrupt, deployment.ProxmoxAPIError,
                deployment.requests.RequestException, deployment.subprocess.CalledProcessError) as exc:
            self.state["status"] = "blocked" if isinstance(exc, CapabilityBlocked) else "failed"
            self.state["error"] = str(exc)
            print("Resources retained. Cleanup after review:\n" + shlex.join([
                sys.executable, str(Path(__file__).resolve()), "--cleanup", "--state", str(self.directory),
            ]), file=sys.stderr)
            raise
        finally:
            self.save()
            self.close()


def validate_integrated_configuration(primary_router_path, ha_router_path, ha_nsr_path, nodes):
    primary = read_config_object(primary_router_path)
    router_config = read_config_object(ha_router_path)
    nsr = read_config_object(ha_nsr_path)
    endpoint = ipaddress.IPv4Address(nsr["remote_endpoint"])
    primary_wan = ipaddress.IPv4Interface(primary["wan_address_cidr"])
    ha_wan = ipaddress.IPv4Interface(router_config["wan_address_cidr"])
    configured_wan = ipaddress.IPv4Interface(nsr["wan_ip"])
    gateway = ipaddress.IPv4Address(router_config["wan_gateway"])
    configured_gateway = ipaddress.IPv4Address(nsr["wan_upstream_router"])
    vlan = nsr.get("wan_vlan")
    if vlan is not None:
        vlan = int(vlan)
    if any(type(nsr[key]) is not int or not 1 <= nsr[key] <= 65535
           for key in ("tcp_port", "udp_port")):
        raise ValueError("NSR HA WAN endpoint ports are invalid.")
    if (ha_wan.ip != configured_wan.ip or gateway != configured_gateway
            or ha_wan.ip == primary_wan.ip or router_config.get("node") != nodes[0]
            or router_config.get("wan_bridge") != nsr.get("wan_bridge")
            or router_config.get("wan_vlan_id") != vlan
            or ha_wan.ip in (
                gateway, endpoint, ha_wan.network.network_address, ha_wan.network.broadcast_address,
            )
            or any((ha_wan.ip.is_multicast, ha_wan.ip.is_unspecified,
                    ha_wan.ip.is_loopback, ha_wan.ip.is_link_local))):
        raise ValueError("router2.json and nsr2.json must configure distinct, valid WAN addresses.")
    deployment.validate_router_request(router_config, nodes)
    return router_config, nsr, ha_wan


def accept_integrated_recovery(parent, reports):
    """Adopt authenticated replacement identities using the parent's SSH trust session."""
    directory = Path(parent.state["nsr_ha_directory"])
    saved = read_config_object(directory / "recovery.json")
    router_id = parent.state["prefix"] + "-ha-nsr"
    if saved.get("router_requested") != router_id or saved.get("prefix") != parent.state["prefix"]:
        raise RuntimeError("Saved HA ownership differs from the recovered deployment.")
    matches = [report for report in reports if report["router"]["id"] == router_id]
    if len(matches) != 1:
        raise RuntimeError("Recovery did not return exactly one owned HA pair.")
    report = matches[0]
    router = report["router"]
    if converged(report["observation"], router_id) is None:
        raise RuntimeError("Recovered HA pair is not converged; saved ownership unchanged.")
    current = pair_identity(router)
    previous = saved.get("pair")
    if not isinstance(previous, dict) or set(previous) != {"a", "b"}:
        raise RuntimeError("Saved HA pair lacks original member identities.")
    for member in ("a", "b"):
        if member not in report["replaced_members"] and current[member] != previous[member]:
            raise RuntimeError("Surviving HA member identity changed during recovery.")
        if any(current[member][key] != previous[member].get(key)
               for key in ("node", "management_address_cidr", "vtep_ip")):
            raise RuntimeError("Replacement changed reserved HA network or node configuration.")
    saved["pair"] = current
    saved["router"] = {key: router[key] for key in ("id", "name", "vmid")}
    saved["controllers"] = parent.state["replacement_controllers"]
    saved["controller_recovery"] = report
    deployment.private_write(directory / "recovery.json", saved)
    with_saved_run(directory, lambda run: run.trust_pair(), action_name="release-ha-recovery-trust")


def run_integrated_phase(parent, phase, ha_router_config_path, ha_nsr_config_path):
    """Run HA acceptance beside recovery, retaining the parent's SSH trust session."""
    directory = parent.directory / "nsr-ha"
    router_id = parent.state["prefix"] + "-ha-nsr"
    parent.state["nsr_ha_directory"] = str(directory)
    parent.save()
    if not (directory / "recovery.json").is_file():
        router_config, nsr, ha_wan = validate_integrated_configuration(
            parent.args.router_config, ha_router_config_path, ha_nsr_config_path, parent.args.nodes,
        )
        endpoint = str(ipaddress.IPv4Address(nsr["remote_endpoint"]))
        tcp_port, udp_port = nsr["tcp_port"], nsr["udp_port"]
        routers = parent.api.json("GET", "/north-south-routers")
        if not isinstance(routers, list) or any(not isinstance(item, dict) for item in routers):
            raise RuntimeError("Controller returned invalid router inventory; HA WAN validation failed.")
        if any(item.get("id") == router_id for item in routers):
            raise RuntimeError("Integrated HA router identity already exists; refusing adoption.")
        if any(item.get("wan_address_cidr")
               and ipaddress.IPv4Interface(item["wan_address_cidr"]).ip == ha_wan.ip
               for item in routers):
            raise ValueError("router2.json WAN address is already assigned to another router.")
        segment_id, segment = allocate_integrated_segment(parent)
        directory.mkdir(mode=0o700, exist_ok=True)
        shutil.copyfile(parent.directory / "controller-ca.crt", directory / "controller-ca.crt")
        os.chmod(directory / "controller-ca.crt", 0o600)
        args = argparse.Namespace(
            state=directory, config=parent.args.config, router_config=ha_router_config_path,
            nodes=parent.args.nodes, image_volume=parent.args.image_volume, endpoint=endpoint,
            tcp_port=tcp_port, udp_port=udp_port, segment=segment, segment_id=segment_id,
            duration=120,
        )
        run = HARun(args)
        run.config = parent.config
        run.api, run.proxmox, run.proxmox_ca = parent.api, parent.proxmox, parent.proxmox_ca
        run.state.update({
            "prefix": parent.state["prefix"], "config": str(parent.args.config),
            "config_sha256": parent.state["config_sha256"],
            "controllers": parent.state["controllers"], "nodes": parent.args.nodes,
            "router_requested": router_id, "router_suffix": "-ha-nsr",
            "integrated": True, "retain": True,
            "integration_args": {
                "router_config": str(ha_router_config_path),
                "nodes": parent.args.nodes, "image_volume": parent.args.image_volume,
                "endpoint": endpoint, "tcp_port": tcp_port, "udp_port": udp_port,
                "segment": segment, "segment_id": segment_id, "duration": 120,
            },
        })
        try:
            for name, action in (
                ("configure-nsr", run.create_router),
                ("create-segment-vm", run.create_lab),
                ("deploy-pair", run.deploy_pair),
            ):
                run.stage(name, action)
            run.run_integrated_scenarios()
            run.state.update(status="passed", cleanup_status="retained")
            run.save()
        except Exception as error:
            run.state.update(status="failed", error=str(error))
            run.save()
            raise
        finally:
            if run.lab is not None:
                run.lab.api.close()
                run.lab.proxmox.session.close()
                run.lab.proxmox_ca.close()
            if run.lab_lock is not None:
                os.close(run.lab_lock)
    else:
        with_saved_run(
            directory, lambda run: run.run_integrated_scenarios(),
            action_name=f"release-{phase}",
        )
    parent.state["nsr_ha_directory"] = str(directory)
    parent.save()
    write_ha_report(directory)
    publish_integrated_report(parent, phase, directory)
    return directory


def publish_integrated_report(parent, phase, directory):
    destination = parent.directory / f"nsr-ha-{phase}"
    destination.mkdir(mode=0o700, exist_ok=True)
    write_ha_report(directory, f"NSR HA acceptance - {phase}")
    for name in ("report.html", "report-data.json"):
        shutil.copyfile(directory / name, destination / name)
        os.chmod(destination / name, 0o600)
    shutil.copyfile(directory / "report-data.json", destination / "evidence.json")
    os.chmod(destination / "evidence.json", 0o600)


def allocate_integrated_segment(parent):
    existing, reserved = parent.lab.network_inventory()
    used_ids = {item["id"] for item in existing}
    reserved = [network for network in reserved if network.version == 4]
    for path in (parent.args.router_config, parent.args.ha_router_config):
        config = read_config_object(path)
        reserved.append(ipaddress.IPv4Interface(config["wan_address_cidr"]).network)
    for segment_id in range(50000, 40000, -1):
        if segment_id in used_ids:
            continue
        for octet in range(256):
            network = ipaddress.IPv4Network(f"10.254.{octet}.0/24")
            if not any(network.overlaps(item) for item in reserved):
                return segment_id, str(network.network_address + 1) + "/24"
    raise RuntimeError("No unused private IPv4 segment is available for integrated NSR HA.")


def run_integrated_controller_loss(directory):
    """Run the outage gate inside the parent recovery SSH trust session."""
    sys.path.insert(0, str(ROOT / "diag"))
    from nsr_controller_loss import run_gate

    with_saved_run(directory, run_gate, action_name="release-controller-cluster-loss")
    write_ha_report(directory)


def cleanup_integrated(parent):
    directory = parent.state.get("nsr_ha_directory")
    if not directory or not (Path(directory) / "recovery.json").is_file():
        return
    directory = Path(directory)
    saved = read_config_object(directory / "recovery.json")
    if (saved.get("prefix") != parent.state.get("prefix")
            or saved.get("router_requested") != parent.state.get("prefix", "") + "-ha-nsr"
            or saved.get("config") != parent.state.get("config")
            or saved.get("config_sha256") != parent.state.get("config_sha256")):
        raise RuntimeError("Saved HA ownership/configuration differs from the cleanup deployment.")
    replacement = parent.state.get("replacement_controllers")
    if replacement is not None:
        if saved.get("controllers") not in (parent.state.get("controllers"), replacement):
            raise RuntimeError("Saved HA controller ownership differs from the recovery history.")
        if deployment.controller_inventory(parent.proxmox, parent.state["prefix"]) != replacement:
            raise RuntimeError("Replacement controller ownership changed; HA cleanup refused.")
        # Failed reconciliation may never reach acceptance; adopt only verified
        # controller inventory for cleanup, never unverified member identities.
        saved["controllers"] = replacement
        deployment.private_write(directory / "recovery.json", saved)
    with_saved_run(
        directory, lambda run: run.cleanup_integrated_resources(),
        action_name="release-ha-cleanup",
    )


def with_saved_run(directory, action, *, allow_retired=False, action_name=None):
    directory = directory.expanduser().resolve()
    state = read_config_object(directory / "recovery.json")
    prefix = state.get("prefix", "")
    router_id = state.get("router_requested", prefix + "-nsr")
    router_suffix = state.get("router_suffix", "-nsr")
    if (directory == ROOT or ROOT in directory.parents
            or not re.fullmatch(r"sf-dr-[0-9a-f]{20}", prefix)
            or router_id != prefix + router_suffix
            or router_suffix not in ("-nsr", "-ha-nsr")):
        raise ValueError("invalid saved run directory/ownership")
    config = Path(state["config"])
    if deployment.fingerprint(config) != state["config_sha256"]:
        raise RuntimeError("deployment config changed; cleanup refused")
    run = HARun(argparse.Namespace(state=directory, config=config))
    run.state = state
    for key, value in state.get("integration_args", {}).items():
        setattr(run.args, key, value)
    try:
        run.connect_proxmox()
        if "controllers" not in state or deployment.controller_inventory(run.proxmox, prefix) != state["controllers"]:
            raise RuntimeError("saved controller ownership missing/changed; use installer retained partial-deployment cleanup")
        run.api = deployment.ControllerAPI(run.config, directory)
        if state.get("pair") is not None:
            routers = run.api.json("GET", "/north-south-routers")
            if not isinstance(routers, list) or any(not isinstance(item, dict) for item in routers):
                raise RuntimeError("invalid NSR inventory; saved action refused")
            matches = [item for item in routers if item.get("id") == router_id]
            if len(matches) > 1:
                raise RuntimeError("ambiguous NSR ownership; saved action refused")
            if matches:
                if pair_identity(matches[0]) != state["pair"]:
                    raise RuntimeError("NSR ownership changed; saved action refused")
            else:
                if not allow_retired:
                    raise RuntimeError("owned NSR is absent; saved action refused")
                members = state["pair"]
                if (not isinstance(members, dict) or set(members) != {"a", "b"}
                        or any(not isinstance(item, dict) or type(item.get("vmid")) is not int
                               or item["vmid"] <= 0 for item in members.values())):
                    raise RuntimeError("invalid retired NSR ownership evidence")
                inventory = run.proxmox.get("/cluster/resources", params={"type": "vm"})["data"]
                if (not isinstance(inventory, list)
                        or any(not isinstance(vm, dict) or type(vm.get("vmid")) is not int
                               or vm["vmid"] <= 0 for vm in inventory)
                        or any(vm.get("vmid") in {item["vmid"] for item in members.values()} for vm in inventory)):
                    raise RuntimeError("retired NSR member absence not proven; cleanup refused")
        lab_directory = directory / "network-lab"
        if lab_directory.exists():
            run.lab_lock = os.open(lab_directory / "run.lock", os.O_WRONLY | os.O_CREAT, 0o600)
            fcntl.flock(run.lab_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            saved = read_config_object(lab_directory / "state.json")
            if saved.get("config") != str(config) or saved.get("router") != router_id:
                raise RuntimeError("saved workload identity changed; cleanup refused")
            run.lab = SingleSegmentLab(lab_directory)
        name = action_name or action.__name__
        record = {"name": name, "started_epoch": time.time(), "status": "running"}
        run.state.setdefault("saved_actions", []).append(record)
        try:
            run.save()
            if name in ("cleanup", "two-endpoint-cleanup"):
                action(run)
            else:
                with PlatformHealth(run) as guard:
                    run.platform_health = guard
                    try:
                        action(run)
                    finally:
                        run.platform_health = None
        except (OSError, ValueError, RuntimeError, KeyboardInterrupt, deployment.ProxmoxAPIError,
                deployment.requests.RequestException, subprocess.CalledProcessError) as exc:
            record.update(status="failed", error=str(exc), completed_epoch=time.time())
            raise
        else:
            record.update(status="passed", completed_epoch=time.time())
    finally:
        run.save()
        run.close()

def cleanup(directory):
    def action(run):
        run.stage("cleanup", run.cleanup)
        run.state["cleanup_status"] = "complete"
    with_saved_run(directory, action, allow_retired=True, action_name="cleanup")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--test-config", type=Path, default=ROOT / "integration-test.json")
    parser.add_argument("--nsr-config", type=Path, default=ROOT / "nsr.json")
    parser.add_argument("--cleanup", action="store_true")
    parser.add_argument("--test-rolling-upgrade", action="store_true", help="upgrade and measure an owned --retain lab against a newer prebuilt package, then clean up")
    parser.add_argument("--test-partitions", action="store_true", help="repeat replication-link and controller-path cuts on an owned retained lab; leave it retained")
    parser.add_argument("--test-vip", action="store_true", help="test abrupt owned VIP-controller stop/return and original WAN sessions; leave the lab retained")
    parser.add_argument("--test-controller-loss", action="store_true", help="stop all owned controllers for twenty minutes, crash/rejoin the active NSR offline, verify original WAN sessions and controller return; leave the lab retained")
    parser.add_argument("--test-double-failover-migration", action="store_true",
                        help="keep controllers healthy; fail NSR a then b while live-migrating the held-flow VM hunsn3 -> hunsn4 -> hunsn5")
    parser.add_argument("--retain", action="store_true", help="retain a passing lab for later saved-state actions; never skips failure diagnostics")
    parser.add_argument("--state", type=Path)
    parser.add_argument("--segment", default="10.253.244.1/24")
    parser.add_argument("--segment-id", type=int, default=49100)
    parser.add_argument("--duration", type=int, default=120)
    args = parser.parse_args(argv)
    actions = (args.cleanup, args.test_rolling_upgrade, args.test_partitions, args.test_vip,
               args.test_controller_loss, args.test_double_failover_migration)
    saved_action = any(actions)
    if sum(actions) > 1 or saved_action != (args.state is not None):
        parser.error("supply --state with exactly one saved action: --cleanup, --test-rolling-upgrade, --test-partitions, --test-vip, --test-controller-loss or --test-double-failover-migration")
    if args.retain and saved_action:
        parser.error("--retain only applies to a new run")
    try:
        if saved_action:
            with automated_ssh_tofu():
                if args.cleanup:
                    cleanup(args.state)
                elif args.test_partitions:
                    with_saved_run(args.state, lambda run: run.test_partitions(), action_name="partitions")
                elif args.test_vip:
                    from nsr_ha_vip import run_gate
                    with_saved_run(args.state, run_gate, action_name="vip-controller-failover")
                elif args.test_controller_loss:
                    sys.path.insert(0, str(ROOT / "diag"))
                    from nsr_controller_loss import run_gate
                    with_saved_run(args.state, run_gate, action_name="controller-cluster-loss")
                elif args.test_double_failover_migration:
                    sys.path.insert(0, str(ROOT / "diag"))
                    from nsr_migration import run_gate
                    with_saved_run(args.state, run_gate, action_name="online-double-failover-migration")
                else:
                    with_saved_run(args.state, lambda run: run.test_rolling_upgrade(), action_name="rolling-upgrade")
            return 0
        import automation
        path = args.test_config.expanduser().resolve()
        base = argparse.Namespace()
        # Reuse existing destructive authorization, external state paths and selected-node validation.
        arguments = automation.command_arguments(path, "nsr-ha")
        base.config = Path(arguments[arguments.index("--config") + 1])
        base.state = Path(arguments[arguments.index("--state") + 1])
        base.router_config = Path(arguments[arguments.index("--router-config") + 1])
        base.nodes = arguments[arguments.index("--nodes") + 1:arguments.index("--nodes") + 4]
        base.image_volume = arguments[arguments.index("--image-volume") + 1]
        base.segment, base.segment_id, base.duration = args.segment, args.segment_id, args.duration
        nsr = read_config_object(args.nsr_config.expanduser().resolve())
        base.endpoint = str(ipaddress.IPv4Address(nsr["remote_endpoint"]))
        base.tcp_port, base.udp_port = nsr["tcp_port"], nsr["udp_port"]
        gateway = ipaddress.IPv4Interface(base.segment)
        if (
            not 5000 <= base.segment_id <= 50000 or gateway.network.prefixlen != 24
            or gateway.ip in (gateway.network.network_address, gateway.network.broadcast_address)
            or gateway.ip == gateway.network.network_address + 10
            or not any(gateway.network.subnet_of(ipaddress.IPv4Network(cidr))
                       for cidr in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"))
            or ipaddress.IPv4Address(base.endpoint) in gateway.network
            or not 60 <= base.duration <= 600 or len(set(base.nodes)) != 3
            or any(not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]*", node) for node in base.nodes)
            or any(type(port) is not int or not 1 <= port <= 65535 for port in (base.tcp_port, base.udp_port))
        ):
            raise ValueError("invalid segment, nodes, duration or WAN endpoint ports")
        request = read_config_object(base.router_config)
        if request.get("node") != base.nodes[0]:
            raise ValueError("router_config.node must match first selected node; second hosts standby")
        standalone = {**request, "deployment_mode": "standalone"}
        for key in ("ha_shared_vtep", "ha_replication_mode", "standby_node",
                    "standby_management_address_cidr", "standby_vtep_ip"):
            standalone.pop(key, None)
        deployment.validate_router_request(standalone, base.nodes)
        wan = ipaddress.IPv4Interface(request["wan_address_cidr"])
        if str(wan.ip) != str(ipaddress.IPv4Interface(nsr["wan_ip"]).ip):
            raise ValueError("nsr.json WAN service address differs from router_config")
        if base.endpoint == str(wan.ip):
            raise ValueError("WAN endpoint must differ from NSR service address")
        if gateway.network.overlaps(wan.network):
            raise ValueError("segment subnet must not overlap WAN subnet")
        if ipaddress.IPv4Address(request["wan_gateway"]) == wan.ip:
            raise ValueError("NSR WAN address must differ from its gateway")
        if request.get("standby_management_address_cidr"):
            standby = ipaddress.IPv4Interface(request["standby_management_address_cidr"])
            if request.get("management_address_cidr") and standby.ip == ipaddress.IPv4Interface(
                request["management_address_cidr"],
            ).ip:
                raise ValueError("HA management addresses must be distinct")
        with automated_ssh_tofu():
            deployment.install_preflight(base.config)
            base.state.mkdir(mode=0o700, parents=True, exist_ok=False)
            run = HARun(base)
            run.state["retain"] = args.retain
            run.save()
            run.run_test()
    except KeyboardInterrupt:
        return 130
    except (OSError, ValueError, KeyError, RuntimeError, deployment.ProxmoxAPIError,
            deployment.requests.RequestException, deployment.subprocess.CalledProcessError) as exc:
        print(f"NSR HA integration failed: {exc}", file=sys.stderr)
        return 1
    outcome = "lab retained" if args.retain else "ordered cleanup passed"
    print(f"NSR HA acceptance passed; {outcome}. Evidence: {base.state}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
