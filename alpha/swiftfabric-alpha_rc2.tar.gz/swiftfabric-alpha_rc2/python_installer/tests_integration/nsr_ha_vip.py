"""Owned retained-lab acceptance for abrupt API-VIP controller failure."""

import ipaddress
import json
import secrets
import time
from urllib.parse import urlparse

import nsr_ha as ha
from platform_health import RECOVERY_SECONDS


def require_owner(run, before, current):
    if (ha.pair_identity(current) != run.state["pair"]
            or current["active_member"] != before["active_member"]
            or current["status"] != "active"):
        raise RuntimeError("single controller/VIP fault changed NSR ownership")


def controller_path(run, controller):
    path = f"/nodes/{controller['node']}/qemu/{controller['vmid']}"
    configuration = run.proxmox.get(path + "/config")["data"]
    if (configuration.get("name") != controller["name"]
            or not controller["name"].startswith(run.state["prefix"] + "-")
            or ha.deployment.controller_configuration(configuration) != controller["configuration"]):
        raise RuntimeError("controller physical ownership changed; power operation refused")
    return path


def vip_owner(run):
    controllers = ha.deployment.controller_inventory(run.proxmox, run.state["prefix"])
    if len(controllers) != 3 or controllers != run.state["controllers"]:
        raise RuntimeError("saved controller ownership changed; VIP fault refused")
    vip = str(ipaddress.IPv4Address(urlparse(run.api.base_url).hostname))
    owners = []
    for index, controller in enumerate(controllers):
        path = controller_path(run, controller)
        if run.proxmox.get(path + "/status/current")["data"]["status"] != "running":
            raise RuntimeError("all three controllers must be running before VIP fault")
        address = str(ipaddress.IPv4Address(run.config["ip_range_start"]) + index)
        interfaces = json.loads(run.api.ssh.run(address, "ip -j -4 address show"))
        if any(value["local"] == vip for interface in interfaces for value in interface["addr_info"]):
            owners.append(controller)
    if len(owners) != 1:
        raise RuntimeError("exact single owned controller VIP owner missing")
    return owners[0]


def run_gate(run):
    before = run.router()
    ha.require_pair(before, deployed=True)
    require_owner(run, before, before)
    _, term = run.wait_converged(before["active_member"])
    if before.get("upgrade_in_progress") or before.get("pending_configuration"):
        raise RuntimeError("VIP fault requires an idle protected router")
    controller = vip_owner(run)
    initial = ha.inspect_protected_guests(run, before)
    vm = run.lab.state["vms"][0]
    token = secrets.token_hex(8)
    unit = "swiftfabric-ha-probes-" + token
    remote = "/var/lib/" + unit
    output = run.directory / f"vip-controller-{time.time_ns()}-report.json"
    port = 20000 + 2 * secrets.randbelow(20000)
    cases = sorted(
        [{**case, "duration_seconds": 120, "source_port": port + index}
         for index, case in enumerate(run.state["held_flow_cases"])],
        key=lambda case: case["protocol"],
    )
    if len(cases) != 2 or {case["protocol"] for case in cases} != {"tcp", "udp"}:
        raise RuntimeError("VIP gate requires exactly one original TCP and UDP flow")
    report = {
        "passed": False, "started_epoch": time.time(),
        "scope": "abrupt owned VIP-controller stop/return; other controllers and compute remain running",
        "stopped_controller": controller, "before_active": before["active_member"],
        "before_term": term, "cases": cases,
        "probe_directory": remote, "probe_unit": unit, "api_samples": [],
        "initial_guests": initial,
    }

    def save():
        ha.deployment.private_write(output, report)

    save()
    print(output)
    stop_attempted = False
    candidate_pass = False
    try:
        run.start_probes(vm, cases, remote, unit=unit)
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            status = run.probe_status(vm, remote)
            if status.get("completed"):
                raise RuntimeError("original WAN probes completed before VIP fault")
            if all(status.get("progress", {}).get(p, {}).get("verified_responses", 0) >= 8
                   for p in ("tcp", "udp")):
                break
            time.sleep(1)
        else:
            raise RuntimeError("VIP fault original WAN sockets not established")
        require_owner(run, before, run.router())
        report["pre_fault_guests"] = ha.inspect_protected_guests(run, before)
        save()
        if vip_owner(run) != controller:
            raise RuntimeError("VIP owner changed before fault; new target not authorized")
        path = controller_path(run, controller)
        guard = run.platform_health
        if guard is None:
            raise RuntimeError("VIP fault requires active platform health monitoring")
        # Survivors stay strictly monitored; the stopped controller must rejoin and resync.
        with guard.controller_fault(controller["name"]):
            try:
                stop_attempted = True
                report["stop_requested_epoch"] = time.time()
                save()
                ha.deployment.wait_task(run.proxmox, run.proxmox.post(path + "/status/stop"))
                if run.proxmox.get(path + "/status/current")["data"]["status"] != "stopped":
                    raise RuntimeError("controller stop was not proven")
                stopped = time.monotonic()
                api_recovered = False
                while time.monotonic() - stopped < 45:
                    run.require_platform_healthy()
                    sample = {"seconds": time.monotonic() - stopped}
                    try:
                        response = run.api.session.get(
                            run.api.base_url + "/north-south-routers/" + run.state["router_requested"],
                            timeout=(3, 5),
                        )
                    except ha.deployment.requests.RequestException as exc:
                        sample["error"] = type(exc).__name__
                    else:
                        try:
                            sample["http_status"] = response.status_code
                            if response.ok:
                                require_owner(run, before, response.json())
                                api_recovered = True
                        finally:
                            response.close()
                    report["api_samples"].append(sample)
                    save()
                    time.sleep(1)
                if not api_recovered:
                    raise RuntimeError("authenticated API VIP did not recover on remaining controllers")
            finally:
                if stop_attempted:
                    path = controller_path(run, controller)
                    state = run.proxmox.get(path + "/status/current")["data"]["status"]
                    if state == "stopped":
                        ha.deployment.wait_task(run.proxmox, run.proxmox.post(path + "/status/start"))
                    elif state != "running":
                        raise RuntimeError("unknown controller power state during restoration")
                    if run.proxmox.get(path + "/status/current")["data"]["status"] != "running":
                        raise RuntimeError("stopped controller restoration was not proven")
                    report["stopped_controller_restored"] = True
                    save()
        report["pair_after_restore"] = run.wait_converged(before["active_member"], term=term)
        require_owner(run, before, run.router())
        if ha.deployment.controller_inventory(run.proxmox, run.state["prefix"]) != run.state["controllers"]:
            raise RuntimeError("restored controller inventory differs from owned baseline")
        deadline = time.monotonic() + 150
        while time.monotonic() < deadline:
            probes = run.probe_status(vm, remote)
            if probes.get("completed"):
                report["probes"] = probes
                save()
                results = sorted(probes["results"], key=lambda result: result["protocol"])
                ha.networking.validate_held_results(cases, results)
                if any(result["failures"] or len(result["observed_peers"]) != 1
                       or result["max_response_gap_seconds"] > 30 for result in results):
                    raise RuntimeError("VIP fault original WAN sessions failed the 30-second gate")
                break
            time.sleep(2)
        else:
            raise RuntimeError("VIP fault held-flow probes did not complete")
        deadline = time.monotonic() + RECOVERY_SECONDS + 30
        while guard.returning is not None:
            run.require_platform_healthy()
            if time.monotonic() > deadline:
                raise RuntimeError("restored controller did not rejoin with strict platform health")
            time.sleep(2)
        run.require_platform_healthy()
        report["restored_controller_rejoined"] = True
        current = run.router()
        require_owner(run, before, current)
        report["final_guests"] = ha.inspect_protected_guests(run, current)
        candidate_pass = True
    finally:
        report["traffic_passed"] = candidate_pass
        save()
        report["probe_cleanup"] = run.stop_probes(vm, unit)
        report["passed"] = candidate_pass
        report["completed_epoch"] = time.time()
        save()
    return report
