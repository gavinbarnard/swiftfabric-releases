#!/usr/bin/env python3
"""Verify deployed standalone NSRs route public/private prefixes over WAN and VTEP.

Uses two temporary NSRs and two tenant VMs per transport on an owned retained
integration lab. WAN test addresses use an unused benchmarking /29 on the
existing WAN bridge; no real public allocation or external endpoint is used.
Public destination prefixes use
RFC5737 documentation space. The retained HA pair and second public NSR are
not changed. Owned resources are journaled and cleaned after either result;
nsr_two_endpoint.py --cleanup resumes interrupted resource cleanup.
"""

import argparse
import copy
import fcntl
import ipaddress
import json
import os
from pathlib import Path
import secrets
import shlex
import time
import uuid

import nsr_two_endpoint as endpoints

ha = endpoints.ha
require = endpoints.require


def allocation(run):
    segments, reserved = run.lab.network_inventory()
    reserved.extend(ipaddress.IPv4Interface(router["wan_address_cidr"]).network
                    for router in run.api.json("GET", "/north-south-routers"))
    wan = ipaddress.IPv4Network("198.18.255.0/29")
    public = ipaddress.IPv4Network("198.51.100.0/24")
    private = next((ipaddress.IPv4Network(f"10.253.{value}.0/24")
                    for value in range(242, -1, -1)
                    if all(not ipaddress.IPv4Network(f"10.253.{value}.0/24").overlaps(item)
                           for item in reserved if item.version == 4)), None)
    require(private is not None, "no unused private route workload subnet")
    require(all(not network.overlaps(item) for network in (wan, public)
                for item in reserved if item.version == 4),
            "deployed route test WAN/documentation subnet is already in use")
    used = {segment["id"] for segment in segments}
    identifiers = [value for value in range(49101, 50001) if value not in used][:2]
    require(len(identifiers) == 2, "no unused route workload segment IDs")
    return wan, (private, public), identifiers


def compute_auth_preflight(run, first):
    segment = run.lab.state["segments"][0]["id"]
    program = f"SEGMENT={segment!r};\n" + """
import json,sys
sys.path.insert(0,"/usr/lib/swiftfabric-host-agent")
from swiftfabric_host.config import load_config
from swiftfabric_host.controller import Controller
config=load_config("/etc/swiftfabric/host-agent.json")
client=Controller(config.api_url,config.api_token,config.host_id,config.vtep_ip)
result=client.list_macs(SEGMENT)
print(json.dumps({"host_id":config.host_id,"segment":SEGMENT,"authenticated":True,
                  "entries":len(result["entries"])}))
"""
    ssh = ha.deployment.SSHCommandRunner(
        run.config["proxmox_ssh_key"], run.config["proxmox_ssh_user"], "owned route compute auth preflight")
    receipts = {}
    for node in (first["node"], first["standby"]["node"]):
        receipt = json.loads(ssh.run(node, shlex.join(["python3", "-c", program]), timeout=110))
        require(receipt.get("segment") == segment and receipt.get("authenticated") is True
                and isinstance(receipt.get("host_id"), str), "compute MAC API authentication preflight failed")
        receipts[node] = receipt
    return receipts


def management_addresses(run):
    pool = run.api.json("GET", "/management/pool")
    network = pool["network"]
    used = set(pool["reserved"])
    for router in run.api.json("GET", "/north-south-routers"):
        for configuration in (router, router.get("pending_configuration")):
            if configuration is None:
                continue
            for member in (configuration, configuration.get("standby")):
                if member and member.get("management_address_cidr"):
                    used.add(str(ipaddress.IPv4Interface(member["management_address_cidr"]).ip))
    for record in run.state.get("second_endpoint_runs", []):
        if record.get("management_address_cidr"):
            used.add(str(ipaddress.IPv4Interface(record["management_address_cidr"]).ip))
    addresses = []
    for value in range(int(ipaddress.IPv4Address(network["end_ip"])),
                       int(ipaddress.IPv4Address(network["start_ip"])) - 1, -1):
        address = str(ipaddress.IPv4Address(value))
        if address not in used:
            addresses.append(f"{address}/{network['prefix_len']}")
            if len(addresses) == 2:
                return addresses
    raise RuntimeError("no fresh owned diagnostic management endpoints; existing SSH pins left intact")


def route(peer, network, transport):
    next_hop = (ipaddress.IPv4Interface(peer["wan_address_cidr"]).ip
                if transport == "wan" else ipaddress.IPv4Address(peer["vtep_ip"]))
    return {"destination_cidr": str(network), "next_hop": str(next_hop),
            "interface": transport, "metric": 100}


def policy(local, remote, egress, ingress):
    result = {key: [] for key in ha.networking.POLICY_KEYS}
    for protocol, port in (("tcp", 18080), ("udp", 18081)):
        if egress:
            result["wan_egress_rules"].append(
                ha.networking.acl_rule(str(local), str(remote), protocol, str(port)))
        if ingress:
            result["wan_ingress_rules"].append(
                ha.networking.acl_rule(str(remote), str(local), protocol, str(port)))
    return result


def set_policy(lab, desired):
    lab.router_policy()
    path = f"/north-south-routers/{lab.state['router']}/wan-policy"
    snapshot = lab.request("GET", path)
    require({key: snapshot[key] for key in ha.networking.POLICY_KEYS}
            == lab.state["expected_wan_policy"], "route test WAN policy changed outside this gate")
    updated = lab.request("PUT", path, {**desired, "_version": snapshot["_version"]})
    require({key: updated[key] for key in ha.networking.POLICY_KEYS} == desired,
            "route test WAN policy response did not match requested policy")
    lab.state["expected_wan_policy"] = copy.deepcopy(desired)
    lab.save()


def validate_observations(cases, results, events):
    require(len(cases) == len(results) == 2
            and {case["protocol"] for case in cases} == {"tcp", "udp"},
            "route proof requires exact distinct TCP/UDP results")
    for case, result in zip(cases, results):
        require(all(result.get(key) == value for key, value in case.items()),
                "route probe result does not match requested case")
        require(result.get("outcome") == case["expected"] and result.get("passed") is True,
                "deployed route traffic did not match expected ACL decision")
        if case["expected"] == "allow":
            require(isinstance(result.get("probe_id"), str) and len(result["probe_id"]) == 64,
                    "route probe lacks verified request nonce digest")
            receipts = [event for event in events
                        if event.get("probe_id") == result["probe_id"] and event.get("stage") == "received"]
            require(len(receipts) == 1, "route probe lacks unique destination receipt")
            receipt = receipts[0]
            require(all(receipt.get(key) == case[key] for key in
                        ("source", "source_port", "destination", "destination_port", "protocol")),
                    "route packet was NATed or reached the wrong destination")


def probes(labs, phase, expected, evidence, save):
    for index, lab in enumerate(labs):
        source = lab.state["vms"][0]
        peer = labs[1 - index]
        target = peer.state["vms"][0]
        cases = [
            {"source": source["address"], "source_port": 30000 + phase * 10 + index * 2 + offset,
             "destination": target["address"], "destination_port": port,
             "protocol": protocol, "expected": expected}
            for offset, (protocol, port) in enumerate((("tcp", 18080), ("udp", 18081)))
        ]
        encoded = ha.networking.encode(json.dumps(cases).encode("utf-8"))
        results = json.loads(lab.serial(
            source, "python3 /opt/swiftfabric-network-lab.py probe " + shlex.quote(encoded)))
        script = (
            "import json,sys;"
            "print(json.dumps([json.loads(line) for line in sys.stdin "
            "if line.startswith('{')]))"
        )
        events = json.loads(peer.serial(
            target, "sudo -n journalctl -u swiftfabric-network-lab --output=cat --no-pager | "
            "python3 -c " + shlex.quote(script)))
        item = {"cases": cases, "results": results, "destination_events": events}
        evidence.append(item)
        save()
        validate_observations(cases, results, events)


def guest_diagnostics(run, record):
    router = endpoints.owned_router(run, record)
    require(router is not None and router["status"] == "active", "diagnostic NSR is not active")
    physical = {key: router[key] for key in ("node", "vmid", "management_address_cidr", "vtep_ip")}
    address = str(ipaddress.IPv4Interface(physical["management_address_cidr"]).ip)
    path = f"/north-south-routers/{record['router_id']}/ssh-host-key?member=a"
    candidate = run.api.json("GET", path)
    require(isinstance(candidate, dict) and candidate.get("changed") is False,
            "diagnostic NSR host key changed; trust not replaced")
    observed = candidate.get("observed")
    require(isinstance(observed, list) and observed, "diagnostic NSR lacks observed SSH keys")
    trusted = candidate.get("trusted")
    selected = trusted if trusted is not None else observed[0]
    require(isinstance(selected, dict) and isinstance(selected.get("public_key"), str)
            and len(selected["public_key"].split()) == 2, "invalid diagnostic NSR public key")
    fingerprint = ha.deployment.SSHCommandRunner._fingerprint(selected["public_key"].split()[1])
    require(selected.get("fingerprint") == fingerprint
            and any(key.get("public_key") == selected["public_key"] and key.get("fingerprint") == fingerprint
                    for key in observed if isinstance(key, dict))
            and (trusted is None or trusted.get("endpoint") == f"[{address}]:22"),
            "diagnostic NSR host key does not match endpoint/observed fingerprint")
    if trusted is None:
        print(f"First-use owned diagnostic NSR SSH key for {address}: {fingerprint}\n"
              "TOFU cannot detect interception on this first connection.", flush=True)
        approved = run.api.json("POST", path.replace("/ssh-host-key?", "/ssh-host-key/approve?"), {
            "endpoint": f"[{address}]:22", "public_key": selected["public_key"],
        })
        receipt = approved.get("trusted") if isinstance(approved, dict) else None
        require(isinstance(approved, dict) and approved.get("approved") is True
                and isinstance(receipt, dict) and receipt.get("public_key") == selected["public_key"]
                and receipt.get("fingerprint") == fingerprint and receipt.get("endpoint") == f"[{address}]:22",
                "diagnostic NSR exact first-use trust was not acknowledged")
    source = str(ipaddress.IPv4Network(record["network"]).network_address + 10)
    target = str(ipaddress.IPv4Network(record["remote_network"]).network_address + 10)
    bridge = "sf-br" + str(int(record["segment_id"]))
    commands = {
        "links": "ip -n sf-router -j address show",
        "routes": "ip -n sf-router -j -4 route show table all",
        "rules": "ip -n sf-router -j -4 rule show",
        "neighbors": "ip -n sf-router -j neigh show",
        "firewall": "ip netns exec sf-router nft -j list table inet swiftfabric_router",
        "connections": "ip netns exec sf-router conntrack -L -o extended",
        "selected_route": shlex.join(["ip", "-n", "sf-router", "-j", "route", "get", target,
                                      "from", source, "iif", bridge]),
        "bridge_fdb": shlex.join(["ip", "netns", "exec", "sf-router", "bridge", "-j", "fdb", "show",
                                  "br", bridge]),
        "agent_log": "journalctl -u swiftfabric-host-agent --no-pager --output=cat -n 80",
        "router_log": "journalctl -u swiftfabric-router --no-pager --output=cat -n 40",
    }
    # Read-only shell on the guest; NSR guests are not required to provide Python.
    program = "".join(
        f"echo '### {name}'\ntimeout 8 {command} 2>&1; echo \"### {name} rc=$?\"\n"
        for name, command in commands.items()
    )
    return {"output": ha.execute_owned_guest(run, record["router_id"], "a", physical, fingerprint, program)}


def run_transport(run, transport, report, save):
    first = run.router()
    wan, networks, segment_ids = allocation(run)
    management = management_addresses(run)
    records, labs, locks, requests = [], [], [], []
    scope = report["transports"][transport] = {"passed": False, "resources": records, "phases": {}}
    empty = {key: [] for key in ha.networking.POLICY_KEYS}
    try:
        for index in range(2):
            run.require_platform_healthy()
            token = secrets.token_hex(8)
            endpoint = endpoints.endpoint_configuration({
                "wan_ip": f"{wan.network_address + index + 2}/29",
                "wan_upstream_router": str(wan.network_address + 1),
                "remote_endpoint": str(wan.network_address + 4), "tcp_port": 18080, "udp_port": 18081,
                "wan_bridge": first["wan_bridge"], "wan_vlan": first["wan_vlan_id"],
            })
            record = {
                "router_id": run.state["prefix"] + "-nsr2-" + token[:8],
                "tenant_id": "tenant-" + str(uuid.uuid4()),
                "tenant_name": run.state["prefix"] + "-tenant2-" + token[:8],
                "endpoint": endpoint, "lab_directory": str(run.directory / ("two-endpoint-" + token)),
                "purpose": "static-routes", "transport": transport, "cleanup_complete": False,
                "management_address_cidr": management[index], "network": str(networks[index]),
                "remote_network": str(networks[1 - index]), "segment_id": segment_ids[index],
            }
            records.append(record)
            run.state.setdefault("second_endpoint_runs", []).append(record)
            run.save()
            save()
            run.api.json("POST", "/tenants", {"id": record["tenant_id"], "name": record["tenant_name"]})
            node = first["node"] if index == 0 else first["standby"]["node"]
            request = endpoints.standalone_request(first, record, node, empty)
            request["management_address_cidr"] = management[index]
            requests.append(request)
            run.api.json("POST", "/north-south-routers", request)
        configured = [endpoints.owned_router(run, record) for record in records]
        for index, record in enumerate(records):
            run.require_platform_healthy()
            request = {key: value for key, value in requests[index].items()
                       if key not in ha.networking.POLICY_KEYS}
            request.update(_version=configured[index]["_version"],
                           static_routes=[route(configured[1 - index], networks[1 - index], transport)])
            run.api.json("PUT", f"/north-south-routers/{record['router_id']}", request)
            run.api.json("POST", f"/north-south-routers/{record['router_id']}/deploy")
        for index, record in enumerate(records):
            deadline = time.monotonic() + 1800
            while time.monotonic() < deadline:
                run.require_platform_healthy()
                router = endpoints.owned_router(run, record)
                require(router is not None and router["status"] != "failed", "route NSR deployment failed")
                if router["status"] == "active":
                    break
                time.sleep(5)
            else:
                raise TimeoutError("route NSR deployment exceeded 1800 seconds")
            require(router["runtime_version"] == first["current_runtime_version"],
                    "route NSR did not deploy the current package payload")
            record["router_vmid"] = router["vmid"]
            run.save()
            directory = Path(record["lab_directory"])
            directory.mkdir(mode=0o700)
            lock = os.open(directory / "run.lock", os.O_WRONLY | os.O_CREAT, 0o600)
            locks.append(lock)
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            ha.deployment.private_write(directory / "state.json", endpoints.workload_state(
                run, record, router, requests[index]["node"], networks[index], segment_ids[index], empty))
            lab = endpoints.SecondEndpointLab(directory)
            labs.append(lab)
            lab.create()
        phases = (
            ("default-deny", False, False, "drop"),
            ("ingress-deny", True, False, "drop"),
            ("allow", True, True, "allow"),
            ("egress-deny", False, True, "drop"),
            ("allow-restored", True, True, "allow"),
        )
        for phase, (label, egress, ingress, expected) in enumerate(phases):
            run.require_platform_healthy()
            for index, lab in enumerate(labs):
                set_policy(lab, policy(networks[index], networks[1 - index], egress, ingress))
            time.sleep(35)
            run.require_platform_healthy()
            scope["phases"][label] = []
            probes(labs, phase, expected, scope["phases"][label], save)
            run.require_platform_healthy()
            save()
        scope["passed"] = True
    except (OSError, ValueError, RuntimeError, ha.deployment.requests.RequestException,
            ha.deployment.ProxmoxAPIError) as failure:
        scope["error"] = f"{type(failure).__name__}: {failure}"
        scope["failure_status"] = {}
        scope["failure_workloads"] = {}
        for lab in labs:
            for vm in lab.state["vms"]:
                try:
                    program = (
                        "import json,subprocess;"
                        "print(json.dumps({key:json.loads(subprocess.run("
                        "['ip','-j',*args],capture_output=True,text=True,check=True,timeout=5).stdout)"
                        " for key,args in {'routes':['route','show','table','all'],"
                        "'neighbors':['neigh','show']}.items()}))"
                    )
                    scope["failure_workloads"][str(vm["vmid"])] = json.loads(
                        lab.serial(vm, "python3 -c " + shlex.quote(program)))
                except (OSError, ValueError, RuntimeError) as diagnostic_failure:
                    scope["failure_workloads"][str(vm["vmid"])] = {
                        "diagnostic_error": f"{type(diagnostic_failure).__name__}: {diagnostic_failure}",
                    }
        for record in records:
            scope["failure_status"][record["router_id"]] = {}
            try:
                scope["failure_status"][record["router_id"]] = run.api.json(
                    "GET", f"/north-south-routers/{record['router_id']}/status")
                scope["failure_status"][record["router_id"]]["kernel"] = guest_diagnostics(run, record)
            except (OSError, ValueError, RuntimeError, ha.deployment.requests.RequestException,
                    ha.deployment.ProxmoxAPIError) as diagnostic_failure:
                scope["failure_status"][record["router_id"]]["diagnostic_error"] = (
                    f"{type(diagnostic_failure).__name__}: {diagnostic_failure}")
        raise
    finally:
        errors = []
        for lab in labs:
            lab.api.close()
        for lock in locks:
            os.close(lock)
        for record in reversed(records):
            try:
                endpoints.cleanup(run, record)
            except (OSError, ValueError, RuntimeError, ha.deployment.requests.RequestException,
                    ha.deployment.ProxmoxAPIError) as failure:
                errors.append(f"{record['router_id']}: {type(failure).__name__}: {failure}")
        scope["cleanup_errors"] = errors
        if errors:
            scope["passed"] = False
        save()
        require(not errors, "deployed route resource cleanup incomplete; use nsr_two_endpoint.py --cleanup")


def run_gate(run, transports=("wan", "private")):
    require(transports in (("wan",), ("private",), ("wan", "private")), "invalid route transports")
    require(not any(record.get("purpose") == "static-routes" for record in endpoints.unfinished(run)),
            "deployed route cleanup pending; use nsr_two_endpoint.py --cleanup")
    first = run.router()
    ha.require_pair(first, deployed=True)
    require(endpoints.protected(first) and not first.get("pending_configuration"),
            "retained HA pair must be protected without pending configuration")
    before = endpoints.inspect_protected_guests(run, first)
    report = {"passed": False, "started_epoch": time.time(), "transports": {},
              "requested_transports": list(transports), "first_preflight": before,
              "scope": "deployed standalone public/private prefix routing, explicit ACLs, no NAT; "
                       "benchmarking WAN on existing WAN bridge, no external endpoint or HA policy edits"}
    output = run.directory / f"deployed-static-routes-{time.time_ns()}-report.json"

    def save():
        ha.deployment.private_write(output, report)

    try:
        save()
        report["compute_auth_preflight"] = compute_auth_preflight(run, first)
        save()
        for transport in transports:
            run_transport(run, transport, report, save)
        current = run.router()
        require(ha.pair_identity(current) == ha.pair_identity(first)
                and current["active_member"] == first["active_member"]
                and current["ha_generation"] == first["ha_generation"],
                "retained HA ownership changed during standalone route acceptance")
        require(all(current.get(key) == first.get(key)
                    for key in (*ha.networking.POLICY_KEYS, "static_routes", "pending_configuration")),
                "retained HA policy changed during standalone route acceptance")
        report["first_after"] = endpoints.inspect_protected_guests(run, current)
        report["passed"] = True
    except (OSError, ValueError, RuntimeError, ha.deployment.requests.RequestException,
            ha.deployment.ProxmoxAPIError) as failure:
        report["error"] = f"{type(failure).__name__}: {failure}"
        raise
    finally:
        report["completed_epoch"] = time.time()
        save()
        print(output, flush=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", type=Path, required=True)
    parser.add_argument("--transport", choices=("both", "wan", "private"), default="both",
                        help="select one transport for diagnosis, or both for full acceptance")
    args = parser.parse_args(argv)
    transports = ("wan", "private") if args.transport == "both" else (args.transport,)
    with ha.automated_ssh_tofu():
        ha.with_saved_run(args.state, lambda run: run_gate(run, transports), action_name="deployed-static-routes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
