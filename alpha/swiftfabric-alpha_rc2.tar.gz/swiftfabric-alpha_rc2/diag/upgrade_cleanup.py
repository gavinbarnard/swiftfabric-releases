"""API-independent teardown of an ownership-checked retained upgrade deployment."""

import importlib
import ipaddress
import json
from pathlib import Path
import re
import shlex
import sys


ROOT = Path(__file__).resolve().parents[1]


def cleanup(run, lab_directory, *, preflight_only=False):
    from disaster_recovery import controller_configuration, wait_task
    from deployment.ssh import SSHCommandRunner
    from main import _controller_vip

    sys.path.insert(0, str(ROOT / "network-lab"))
    assert_vm_owner = importlib.import_module("lab").assert_vm_owner
    state = run.state
    workload = state["workload_identity"]
    hosts = workload["hosts"]
    controllers = state["controllers"]
    lab = json.loads((lab_directory / "state.json").read_text())
    ca = state["original_ca_der_sha256"]
    if (not re.fullmatch(r"[0-9a-f]{64}", ca) or len(controllers) != 3
            or not hosts or len({host["host_id"] for host in hosts}) != len(hosts)
            or len({host["node"] for host in hosts}) != len(hosts)
            or lab["run_id"] != workload["run_id"]
            or lab["router"] != state["router"]["id"]
            or workload["router"] != state["router"]
            or any(not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]*", host["node"]) for host in hosts)):
        raise RuntimeError("Invalid saved upgrade cleanup ownership.")
    if any(not any(all(key == "node" or vm.get(key) == value for key, value in saved.items())
                   for saved in workload["vms"]) for vm in lab["vms"]):
        raise RuntimeError("Lab VM ownership changed since acceptance; refusing cleanup.")
    tenants = workload["tenants"]
    if (not tenants or any(type(tenant.get("routing_table")) is not int
                           or not 1 <= tenant["routing_table"] <= 2**32 - 1
                           or type(tenant.get("conntrack_zone")) is not int
                           or not 1 <= tenant["conntrack_zone"] <= 65535 for tenant in tenants)):
        raise RuntimeError("Invalid tenant residual-state ownership.")
    network = ipaddress.IPv4Network(run.config["vtep_ip_range_cidr"])
    all_vms = [*workload["vms"], *controllers, state["router"]]
    if (any(type(vm["vmid"]) is not int or vm["vmid"] <= 0 for vm in all_vms)
            or len({vm["vmid"] for vm in workload["vms"]}) != len(workload["vms"])
            or len({vm["vmid"] for vm in controllers}) != len(controllers)
            or len({vm["vmid"] for vm in all_vms}) != len(all_vms)):
        raise RuntimeError("Saved VM ownership is ambiguous; refusing cleanup.")

    controller_ssh = SSHCommandRunner(
        run.config["controller_priv_key"], "ubuntu", "retained upgrade controller cleanup")
    host_ssh = SSHCommandRunner(
        run.config["proxmox_ssh_key"], run.config["proxmox_ssh_user"], "retained upgrade host cleanup")
    helper = (ROOT / "diag/upgrade_cleanup_remote.py").read_text()
    remote = shlex.join(["sudo", "-n", "python3", "-c", helper])
    vip = _controller_vip(run.config)
    first = ipaddress.IPv4Address(run.config["ip_range_start"])
    spec = {
        "operation": "controller-plan", "ca": ca, "api_vip": vip,
        "node_ips": [str(first + index) for index in range(3)],
        "node_names": [controller["name"] for controller in controllers],
        "hosts": hosts, "router": state["router"],
    }

    def remote_json(ssh, address, payload):
        try:
            output = ssh.run(
                address, remote, input_data=json.dumps(payload).encode(), timeout=180)
        except RuntimeError as exc:
            detail = str(exc).split(f"failed on {address}: ", 1)[-1]
            raise RuntimeError(f"Cleanup {payload['operation']} on {address}: {detail}") from None
        return json.loads(output)

    def inventory():
        resources = run.proxmox.get("/cluster/resources", params={"type": "vm"})["data"]
        if not isinstance(resources, list) or any(not isinstance(vm, dict) for vm in resources):
            raise RuntimeError("Invalid Proxmox inventory; refusing cleanup.")
        return resources

    def owned(vm, kind):
        resources = inventory()
        matches = [item for item in resources if item.get("vmid") == vm["vmid"]]
        if not matches:
            if any(item.get("name") == vm["name"] for item in resources):
                raise RuntimeError("Owned VM name was reused; refusing cleanup.")
            return None
        if len(matches) != 1 or matches[0].get("type") != "qemu":
            raise RuntimeError("Owned VM inventory is ambiguous; refusing cleanup.")
        node = matches[0]["node"]
        if not isinstance(node, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]*", node):
            raise RuntimeError("Owned VM node is invalid; refusing cleanup.")
        path = f"/nodes/{node}/qemu/{vm['vmid']}"
        config = run.proxmox.get(path + "/config")["data"]
        if kind == "controller":
            if node != vm["node"] or controller_configuration(config) != vm["configuration"]:
                raise RuntimeError("Controller ownership changed; refusing cleanup.")
        elif kind == "lab":
            assert_vm_owner(config, vm, lab["run_id"])
        elif (config.get("name") != vm["name"] or config.get("description") != vm["description"]
              or config.get("tags", "").split(";").count(vm["owner_tag"]) != 1):
            raise RuntimeError("Router VM ownership changed; refusing cleanup.")
        return path, config

    def host_spec(host, operation="host-plan"):
        return {"operation": operation, "host_id": host["host_id"], "ca": ca, "api_vip": vip}

    def clean_host(host):
        probe = (ROOT / "python_installer/tests_integration/host_cleanup_probe.py").read_text()
        tables = sorted({str(tenant["routing_table"]) for tenant in tenants})
        zones = sorted({tenant["conntrack_zone"] for tenant in tenants})
        command = shlex.join(["sudo", "-n", "python3", "-c", probe, str(network),
                              json.dumps(tables), json.dumps(zones)])
        if host_ssh.run(host["node"], command, timeout=120).strip() != "SWIFTFABRIC_HOST_CLEAN":
            raise RuntimeError("Host teardown is not verified; controllers retained.")

    for controller in controllers:
        owned(controller, "controller")
    for vm in workload["vms"]:
        owned(vm, "lab")

    plan = state.get("offline_cleanup_plan")
    if plan is None:
        plans = [remote_json(controller_ssh, address, spec) for address in spec["node_ips"]]
        if any(item != plans[0] for item in plans):
            raise RuntimeError("Controllers disagree on cleanup ownership; refusing cleanup.")
        router = plans[0]["router"]
        if router is None:
            if any(vm.get("vmid") == state["router"]["vmid"]
                   or vm.get("name") == state["router"]["name"] for vm in inventory()):
                raise RuntimeError("Router VM lacks saved ownership marker; refusing cleanup.")
        else:
            owned(router, "router")
        host_plans = {}
        for host in hosts:
            host_plans[host["node"]] = remote_json(host_ssh, host["node"], host_spec(host))
            if host_plans[host["node"]] is None:
                clean_host(host)
        plan = {"router": router, "hosts": host_plans, "run_id": lab["run_id"], "ca": ca}
    if (plan["run_id"] != lab["run_id"] or plan["ca"] != ca
            or set(plan["hosts"]) != {host["node"] for host in hosts}
            or (plan["router"] is not None and any(
                plan["router"].get(key) != value for key, value in state["router"].items()
                if key != "id"))):
        raise RuntimeError("Saved cleanup plan differs from run ownership.")
    if plan["router"] is not None:
        if (plan["router"]["description"] != f"SwiftFabric N/S router {state['router']['id']} member a"
                or not re.fullmatch(r"swiftfabric_owner_[0-9a-f]{64}", plan["router"]["owner_tag"])):
            raise RuntimeError("Saved router cleanup marker is invalid.")
        owned(plan["router"], "router")
    elif any(vm.get("vmid") == state["router"]["vmid"]
             or vm.get("name") == state["router"]["name"] for vm in inventory()):
        raise RuntimeError("Router VM lacks saved ownership marker; refusing cleanup.")
    allowed = {vm["vmid"] for vm in workload["vms"]} | {state["router"]["vmid"]}
    for vm in inventory():
        if vm.get("node") not in plan["hosts"] or vm.get("vmid") in allowed:
            continue
        kind = vm.get("type")
        if kind not in ("qemu", "lxc"):
            raise RuntimeError("Unexpected guest type on cleanup host.")
        config = run.proxmox.get(f"/nodes/{vm['node']}/{kind}/{vm['vmid']}/config")["data"]
        if any("bridge=sf-br" in value for key, value in config.items()
               if re.fullmatch(r"net\d+", key) and isinstance(value, str)):
            raise RuntimeError("Foreign guest uses SwiftFabric; refusing host cleanup.")
    for host in hosts:
        current = remote_json(host_ssh, host["node"], host_spec(host))
        if current is not None and current != plan["hosts"][host["node"]]:
            raise RuntimeError("Host configuration changed; refusing cleanup.")
        expected = plan["hosts"][host["node"]]
        if expected is not None and (
                not re.fullmatch(r"[0-9a-f]{64}", expected["sha256"])
                or ipaddress.IPv4Address(expected["vtep_ip"]) not in network):
            raise RuntimeError("Saved host cleanup plan has invalid ownership.")
        if plan["hosts"][host["node"]] is None:
            clean_host(host)
    if preflight_only:
        return
    state["offline_cleanup_plan"] = plan
    run.save()

    # Freeze reconciliation before deleting guests or removing host agents.
    for vm in controllers:
        observed = owned(vm, "controller")
        if observed is not None:
            path, _ = observed
            if run.proxmox.get(path + "/status/current")["data"]["status"] != "stopped":
                wait_task(run.proxmox, run.proxmox.post(path + "/status/stop"))
            if run.proxmox.get(path + "/status/current")["data"]["status"] != "stopped":
                raise RuntimeError("Controller did not stop; refusing cleanup.")

    def delete_vm(vm, kind):
        observed = owned(vm, kind)
        if observed is None:
            return
        path, config = observed
        if run.proxmox.get(path + "/status/current")["data"]["status"] != "stopped":
            wait_task(run.proxmox, run.proxmox.post(path + "/status/stop"))
        if owned(vm, kind) != (path, config):
            raise RuntimeError("VM configuration changed before deletion.")
        wait_task(run.proxmox, run.proxmox.delete(
            path, params={"purge": 1, "destroy-unreferenced-disks": 1}))
        if owned(vm, kind) is not None:
            raise RuntimeError("VM deletion did not complete.")

    for vm in reversed(workload["vms"]):
        delete_vm(vm, "lab")
    if plan["router"] is not None:
        delete_vm(plan["router"], "router")
    for host in hosts:
        payload = {**host_spec(host, "remove-host"), "plan": plan["hosts"][host["node"]]}
        if remote_json(host_ssh, host["node"], payload) != "removed":
            raise RuntimeError("Host cleanup returned an invalid response.")
        clean_host(host)
    state["cleanup_verified_hosts"] = hosts
    run.save()
    for vm in controllers:
        delete_vm(vm, "controller")
