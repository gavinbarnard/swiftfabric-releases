"""Read-only timing check on the owned retained NSR HA lab workload VM.

Runs over the Proxmox serial console (no controller dependency) and reports how
long `sudo`, hostname resolution, DNS and a WAN TCP connect take, plus the
guest's routes and resolver configuration. Use it when harness serial commands
on the workload VM time out. `--probes` prints the newest retained held
probe status files (for "held probe terminated early" failures).
`--traffic-seconds` runs verified held TCP/UDP traffic without injecting faults.
"""

from pathlib import Path

PROGRAM = r"""set -u
t() { s=$(date +%s%3N); "$@" >/dev/null 2>&1; rc=$?; printf '%-40s rc=%s %sms\n' "$*" "$rc" "$(( $(date +%s%3N) - s ))"; }
t sudo -n true
t getent hosts "$(hostname)"
t timeout 10 getent hosts example.com
t timeout 10 python3 -c 'import socket,sys; socket.create_connection((sys.argv[1], int(sys.argv[2])), 5).close()' ENDPOINT PORT
echo '--- route'; ip -4 route
echo '--- neigh'; ip -4 neigh
echo '--- resolv'; grep -v '^#' /etc/resolv.conf
echo '--- hosts'; grep -v '^#' /etc/hosts
echo '--- probe units'; systemctl list-units --no-pager --plain 'swiftfabric-ha-probes*' 2>&1 | head
"""


def main(argv=None):
    import argparse
    import shlex
    import sys

    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root / "python_installer" / "tests_integration"))
    import nsr_ha as ha

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", type=Path, required=True)
    parser.add_argument("--timeout", type=int, default=120)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--journal", nargs=2, type=int, metavar=("SINCE_EPOCH", "UNTIL_EPOCH"),
                        help="print the guest journal (without resolver noise) for the window instead")
    mode.add_argument("--probes", action="store_true",
                        help="print retained HA probe status files (newest last) instead")
    mode.add_argument("--traffic-seconds", type=int,
                      help="run held TCP/UDP WAN validation for 10-120 seconds, without an HA event")
    args = parser.parse_args(argv)
    if not 10 <= args.timeout <= 300:
        parser.error("--timeout must be between 10 and 300 seconds")
    if args.journal and not 0 < args.journal[0] < args.journal[1]:
        parser.error("--journal window must be positive")
    if args.traffic_seconds is not None and not 10 <= args.traffic_seconds <= 120:
        parser.error("--traffic-seconds must be between 10 and 120")

    def check(run):
        if args.traffic_seconds is not None:
            report = run.held_traffic("diagnostic-wan", args.traffic_seconds)
            if report.get("passed") is not True:
                raise RuntimeError("held TCP/UDP WAN validation failed")
            print("Held TCP/UDP WAN validation passed; no HA fault injected.")
            return
        endpoint = run.state["held_flow_cases"][0]
        program = PROGRAM.replace("ENDPOINT", shlex.quote(endpoint["destination"])).replace(
            "PORT", shlex.quote(str(endpoint["destination_port"]))
        )
        if args.journal:
            since, until = args.journal
            program = (
                f"journalctl --no-pager -o short-unix --since @{since} --until @{until}"
                " 2>&1 | grep -v systemd-resolved | tail -n 300"
            )
        if args.probes:
            program = (
                "for f in $(ls -1tr -d /var/lib/swiftfabric-ha-test-*/ 2>/dev/null | tail -n 4); do "
                "echo \"--- $f\"; sudo -n head -c 6000 \"$f/status.json\" 2>&1; echo; done"
            )
        print(run.lab.serial(run.lab.state["vms"][0], program, timeout=args.timeout))

    with ha.automated_ssh_tofu():
        ha.with_saved_run(args.state, check, action_name="ha-workload-check")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
