"""Owned NSR acceptance through full controller-cluster loss and offline takeover."""

from contextlib import contextmanager
import json
import secrets
import subprocess
import time

from nsr_transport import DirectMembers
from nsr_serial import SerialMembers, capture as capture_serial


CONTROLLER_ABSENCE_SECONDS = 20 * 60
HELD_SECONDS = 30 * 60


def guest_view(run, member):
    from nsr_ha import ROUTER_CLI, member_status

    # Read the clock after the status so a heartbeat written mid-read is not "future".
    raw = run.run_owned_guest(member, f"set -eu\n{ROUTER_CLI} --ha-status\ndate +%s%3N\n", timeout=15)
    payload, clock = raw.rstrip("\n").rsplit("\n", 1)
    now = int(clock)
    status = member_status(payload, run.state["router_requested"], member)
    updated = status.get("updated_at_ms")
    if type(updated) is not int or not 0 <= now - updated <= 10_000:
        raise RuntimeError(
            f"member {member} published stale or future HA status "
            f"(guest clock {now} ms, updated_at_ms {updated!r})"
        )
    return status


def require_view(status, member, owner, term, *, controllers_down=True):
    pair = status["pair"]
    if (
        status.get("role") != ("active" if member == owner else "standby")
        or pair.get("owner") != owner or pair.get("term") != term
        or pair.get("peer_heard") is not True
        or type(pair.get("peer_silent_ms")) is not int or pair["peer_silent_ms"] >= 5_000
    ):
        raise RuntimeError(f"member {member} lost pair-local ownership or peer connectivity")
    if controllers_down:
        if status.get("policy_from_cache") is not True:
            raise RuntimeError(f"member {member} did not reconcile from its offline policy cache")
        reach = status.get("reachability") or {}
        if reach.get("management_reachable") is not True or (reach.get("gateway") or {}).get("reachable") is not True:
            raise RuntimeError(f"member {member} cannot reach its management gateway with controllers down")
        if any(target.get("reachable") is True for target in reach.get("controllers", [])):
            raise RuntimeError(f"member {member} still sees a controller TCP endpoint")
        if (status.get("witness") or {}).get("peer_recently_forwarding") is not False:
            raise RuntimeError(f"member {member} retained a stale controller witness veto")


def healthy_return(run, report, save):
    import nsr_ha as ha
    from platform_health import PlatformHealth

    deadline = time.monotonic() + 300
    while time.monotonic() < deadline:
        try:
            run.api.refresh()
            with PlatformHealth(run, recovering_cluster=True) as guard:
                guard.settle()
                report["controller_recovery"] = guard.report
            report["controllers_restored_epoch"] = time.time()
            save()
            return
        except (OSError, ValueError, RuntimeError, subprocess.SubprocessError,
                ha.deployment.requests.RequestException) as failure:
            report["controller_recovery_wait"] = str(failure)
            save()
            time.sleep(5)
    raise TimeoutError("controller cluster did not return healthy after full-cluster outage")


@contextmanager
def controllers_absent(run, controllers, report, save):
    import nsr_ha as ha
    from nsr_ha_vip import controller_path

    guard = run.platform_health
    if guard is None:
        raise RuntimeError("full-cluster outage requires initial platform-health admission")
    stopped = []
    guard.close()
    run.platform_health = None
    try:
        for controller in controllers:
            path = controller_path(run, controller)
            stopped.append(controller)
            event = {"controller": controller["name"], "action": "stop", "requested_epoch": time.time()}
            report.setdefault("controller_power_events", []).append(event)
            save()
            ha.deployment.wait_task(run.proxmox, run.proxmox.post(path + "/status/stop"))
            if run.proxmox.get(path + "/status/current")["data"]["status"] != "stopped":
                raise RuntimeError("owned controller stop did not complete")
            event["completed_epoch"] = time.time()
            save()
        report["all_controllers_stopped_epoch"] = time.time()
        save()
        yield time.monotonic()
    finally:
        failures = []
        for controller in stopped:
            try:
                path = controller_path(run, controller)
                power = run.proxmox.get(path + "/status/current")["data"]["status"]
                if power == "stopped":
                    ha.deployment.wait_task(run.proxmox, run.proxmox.post(path + "/status/start"))
                elif power != "running":
                    raise RuntimeError("unknown owned controller power state during restoration")
                if run.proxmox.get(path + "/status/current")["data"]["status"] != "running":
                    raise RuntimeError("controller VM restoration failed")
            except (OSError, ValueError, KeyError, RuntimeError, subprocess.SubprocessError,
                    ha.deployment.ProxmoxAPIError,
                    ha.deployment.requests.RequestException) as failure:
                failures.append(f"controller {controller['name']}: {failure}")
        report["restoration_errors"] = failures
        save()
        if failures:
            raise RuntimeError("owned controller restoration incomplete: " + "; ".join(failures))
        healthy_return(run, report, save)


@contextmanager
def original_sockets(run, vm, cases, remote, unit, report, save):
    try:
        run.start_probes(vm, cases, remote, unit=unit)
        run.wait_established(vm, remote)
        yield
    finally:
        report["probe_cleanup"] = run.stop_probes(vm, unit)
        save()


def run_gate(run):
    import nsr_ha as ha
    from nsr_ha_vip import controller_path
    from platform_health import PlatformHealth

    router = run.router()
    ha.require_pair(router, deployed=True)
    if ha.pair_identity(router) != run.state["pair"]:
        raise RuntimeError("NSR physical ownership changed; controller outage refused")
    owner, term = run.wait_converged()
    if owner != "a":
        prepared = run.planned_handoff(owner, term, {})
        owner, term = prepared["member"], prepared["term"]
        if owner != "a":
            raise RuntimeError("double failover requires initial member a ownership")
    controllers = ha.deployment.controller_inventory(run.proxmox, run.state["prefix"])
    if len(controllers) != 3 or controllers != run.state["controllers"]:
        raise RuntimeError("controller ownership changed; full-cluster outage refused")
    for controller in controllers:
        path = controller_path(run, controller)
        if run.proxmox.get(path + "/status/current")["data"]["status"] != "running":
            raise RuntimeError("all three controllers must be running before full-cluster outage")

    vm = run.lab.state["vms"][0]
    token = secrets.token_hex(8)
    unit = "swiftfabric-ha-probes-" + token
    remote = "/var/lib/" + unit
    cases = run.flow_cases(20000 + 2 * secrets.randbelow(20000), HELD_SECONDS)
    output = run.directory / f"controller-loss-{time.time_ns()}-report.json"
    report = {
        "passed": False, "started_epoch": time.time(),
        "scope": "all controllers stopped, twenty-minute forwarding, a crash, b takeover, a rejoin, b crash, a takeover",
        "initial_owner": owner, "initial_term": term, "controllers": controllers,
        "held_seconds": HELD_SECONDS, "minimum_controller_absence_seconds": CONTROLLER_ABSENCE_SECONDS,
        "cases": cases, "samples": [], "fresh_traffic": [], "restoration_errors": [],
    }

    def save():
        ha.deployment.private_write(output, report)

    print(output, flush=True)
    save()
    original_transport = run.run_owned_guest
    with SerialMembers(run), DirectMembers(run) as direct:
        run.run_owned_guest = direct.execute
        try:
            held_deadline = time.monotonic() + HELD_SECONDS + 120
            with original_sockets(run, vm, cases, remote, unit, report, save):
                offset_before = run.guest_clock(vm)
                report["initial_guests"] = {member: guest_view(run, member) for member in ("a", "b")}
                for status in report["initial_guests"].values():
                    witness = status.get("witness") or {}
                    if witness.get("exchanged") is not True or witness.get("last_failure") is not None:
                        raise RuntimeError("controller witness exchange did not work before outage")
                with controllers_absent(run, controllers, report, save) as offline:
                    next_fresh = offline + 60
                    while time.monotonic() - offline < CONTROLLER_ABSENCE_SECONDS:
                        for controller in controllers:
                            path = controller_path(run, controller)
                            if run.proxmox.get(path + "/status/current")["data"]["status"] != "stopped":
                                raise RuntimeError("a controller restarted during the declared outage")
                        views = {member: guest_view(run, member) for member in ("a", "b")}
                        for member, status in views.items():
                            # Permit one policy poll after the last controller stops.
                            require_view(status, member, owner, term, controllers_down=time.monotonic() - offline >= 20)
                        progress = run.probe_status(vm, remote)
                        if progress.get("completed") or progress.get("results"):
                            report["early_probes"] = progress
                            raise RuntimeError("original held WAN sockets terminated during controller outage")
                        report["samples"].append({"seconds": time.monotonic() - offline, "members": views})
                        if time.monotonic() >= next_fresh:
                            report["fresh_traffic"].append(run.held_traffic("controller-free-new-sessions", 10))
                            next_fresh = time.monotonic() + 300
                        save()
                        time.sleep(5)
                    report["controller_free_forwarding_seconds"] = time.monotonic() - offline
                    double_failover(run, owner, term, report, save)
                    report["controller_absence_seconds"] = time.monotonic() - offline
                    save()
                with PlatformHealth(run) as restored:
                    run.platform_health = restored
                    try:
                        report["returned_pair"] = run.wait_converged(
                            report["successor"]["member"], term=report["successor"]["term"])
                        while time.monotonic() < held_deadline:
                            probes = run.probe_status(vm, remote)
                            if probes.get("completed"):
                                break
                            time.sleep(2)
                        else:
                            raise TimeoutError("controller-loss held-flow probes did not finish")
                        report["probes"] = probes
                        offset_after = run.guest_clock(vm)
                        offsets = [min(offset_before[0], offset_after[0]), max(offset_before[1], offset_after[1])]
                        results = sorted(probes["results"], key=lambda item: ("tcp", "udp").index(item["protocol"]))
                        for failover in report["failovers"]:
                            fault = failover["fault"]
                            bounds = [fault["started_monotonic"] - offsets[1],
                                      fault["completed_monotonic"] - offsets[0]]
                            failover["measurements"] = ha.measurements(cases, results, bounds)
                            if failover["measurements"]["passed"] is not True:
                                raise RuntimeError("held TCP/UDP sessions did not survive both controller-free takeovers")
                        report["measurements"] = {
                            "passed": True, "survival_percent": 100.0,
                            "scope": "original TCP/UDP sockets and NAT tuples survived both failovers",
                        }
                    finally:
                        run.platform_health = None
            report["passed"] = True
            save()
            run.record("controller-cluster-loss", report)
        finally:
            run.run_owned_guest = original_transport


def double_failover(run, owner, term, report, save):
    if owner != "a":
        raise RuntimeError("double failover must start with member a active")
    report["failovers"] = []
    for source in ("a", "b"):
        leg = {"passed": False}
        report["failovers"].append(leg)
        save()
        offline_crash(run, source, term, leg, save, serial_diagnostics=True,
                      traffic_label=f"controller-free-after-{source}-crash")
        successor = leg["successor"]
        wait_replication(run, successor["member"], successor["term"], leg, save)
        leg["passed"] = True
        term = successor["term"]
        report["successor"] = successor
        save()


def wait_replication(run, owner, term, report, save):
    deadline = time.monotonic() + 120
    while time.monotonic() < deadline:
        views = {member: guest_view(run, member) for member in ("a", "b")}
        for member, status in views.items():
            require_view(status, member, owner, term)
        standby = "b" if owner == "a" else "a"
        if (
            (views[owner].get("replication") or {}).get("sender", {}).get("connected") is True
            and (views[standby].get("replication") or {}).get("receiver", {}).get("connected") is True
        ):
            report["replication_after_rejoin"] = {
                member: status["replication"] for member, status in views.items()
            }
            save()
            return
        time.sleep(2)
    raise TimeoutError("controller-free replication did not reconnect before next failover")


def offline_crash(run, owner, term, report, save, *, serial_diagnostics=False,
                  traffic_label="controller-free-after-takeover"):
    import nsr_ha as ha

    fault = {"kind": "controller-free-active-crash", "member": owner, "term": term,
             "started_monotonic": time.monotonic(), "started_epoch": time.time()}
    report["fault"] = fault
    restart_needed = True
    try:
        run.power_member(owner, "stop")
        fault["completed_monotonic"] = time.monotonic()
        successor = ha.other(owner)
        deadline = fault["completed_monotonic"] + ha.TAKEOVER_LIMIT_SECONDS
        while time.monotonic() < deadline:
            status = guest_view(run, successor)
            pair = status["pair"]
            if status.get("role") == "active" and pair.get("owner") == successor and pair.get("term", 0) > term:
                reach = status.get("reachability") or {}
                if (
                    (reach.get("gateway") or {}).get("reachable") is not True
                    or (status.get("witness") or {}).get("peer_recently_forwarding") is not False
                    or status.get("policy_from_cache") is not True
                ):
                    raise RuntimeError("offline takeover lacked gateway reachability, expired witness or cached policy")
                report["successor"] = {
                    "member": successor, "term": pair["term"], "status": status,
                    "takeover_observed_seconds": time.monotonic() - fault["completed_monotonic"],
                }
                if report["successor"]["takeover_observed_seconds"] > ha.TAKEOVER_LIMIT_SECONDS:
                    raise RuntimeError("offline takeover exceeded ten seconds")
                break
            time.sleep(0.25)
        else:
            raise TimeoutError("standby did not self-promote within ten seconds with all controllers stopped")
        save()
        run.power_member(owner, "start")
        restart_needed = False
        new_term = report["successor"]["term"]
        deadline = time.monotonic() + 240
        diagnostic_attempted = False
        while time.monotonic() < deadline:
            try:
                views = {member: guest_view(run, member) for member in ("a", "b")}
            except (OSError, RuntimeError, subprocess.SubprocessError) as failure:
                report.setdefault("rejoin_waits", []).append({
                    "classification": "expected reboot transport recovery",
                    "epoch": time.time(), "error": str(failure),
                })
                if serial_diagnostics and not diagnostic_attempted:
                    capture_serial(run, owner, report, save)
                    diagnostic_attempted = True
                save()
                time.sleep(2)
                continue
            if views[owner].get("role") == "active":
                raise RuntimeError("former active preempted the offline successor")
            # A rebooted member stays fenced until its cached policy is applied.
            if all(
                status["pair"].get("peer_heard") is True
                and status["pair"].get("owner") == successor and status["pair"].get("term") == new_term
                and status.get("role") == ("active" if member == successor else "standby")
                for member, status in views.items()
            ):
                for member, status in views.items():
                    require_view(status, member, successor, new_term)
                report["rejoined_epoch"] = time.time()
                if serial_diagnostics:
                    capture_serial(run, owner, report, save)
                break
            time.sleep(2)
        else:
            raise TimeoutError("former active did not rejoin from cache without controllers")
        report["rejoin_samples"] = []
        started = time.monotonic()
        while time.monotonic() - started < ha.REJOIN_OBSERVATION_SECONDS:
            views = {member: guest_view(run, member) for member in ("a", "b")}
            for member, status in views.items():
                require_view(status, member, successor, new_term)
            report["rejoin_samples"].append(views)
            save()
            time.sleep(2)
        report["offline_takeover_new_traffic"] = run.held_traffic(traffic_label, 10)
    finally:
        if restart_needed:
            path = run.owned_member_path(owner)
            power = run.proxmox.get(path + "/status/current")["data"]["status"]
            if power == "stopped":
                run.power_member(owner, "start")
            elif power != "running":
                raise RuntimeError("former active has an unknown power state during restoration")
        save()


def inspect_run(run):
    router = run.router()
    if router.get("id") != run.state["router_requested"] or router.get("name") != router["id"]:
        raise RuntimeError("saved NSR identity changed; inspection refused")
    fields = ("id", "status", "status_message", "deployment_mode", "active_member",
              "node", "vmid", "management_address_cidr", "ha_replication_mode")
    print(json.dumps({field: router.get(field) for field in fields}, indent=2))


def main(argv=None):
    import argparse
    from pathlib import Path
    import sys

    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root / "python_installer" / "tests_integration"))
    import nsr_ha as ha

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inspect", action="store_true", required=True,
                        help="read owned router deployment status; no fault injection")
    parser.add_argument("--state", type=Path, required=True)
    args = parser.parse_args(argv)
    with ha.automated_ssh_tofu():
        ha.with_saved_run(args.state, inspect_run, action_name="ha-inspect")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
