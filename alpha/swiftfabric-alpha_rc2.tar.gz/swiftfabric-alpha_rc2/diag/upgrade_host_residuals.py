"""Read-only residual file metadata on owned hosts of a retained upgrade cleanup."""

import argparse
from pathlib import Path
import re
import shlex
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_installer/tests_integration"))
import disaster_recovery as recovery
from deployment.ssh import SSHCommandRunner


PROGRAM = (
    "set -eu; "
    "for path in /etc/swiftfabric /var/lib/swiftfabric /usr/lib/swiftfabric-host-agent; do "
    "if test -e \"$path\"; then "
    "find \"$path\" -maxdepth 3 -printf '%y %m %u:%g %p\\n'; fi; done; "
    "systemctl show swiftfabric-host-agent.service swiftfabric-neighbors.service "
    "--property=Id,LoadState,ActiveState; "
    "dpkg-query -W -f='${binary:Package} ${db:Status-Status}\\n' "
    "| grep '^swiftfabric-' || test \"$?\" -eq 1"
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", required=True, type=Path)
    args = parser.parse_args()
    directory = args.state.expanduser().resolve()
    state = recovery.read_config_object(directory / "recovery.json")
    config = Path(state["config"])
    if (directory == ROOT or ROOT in directory.parents
            or not re.fullmatch(r"sf-dr-[0-9a-f]{20}", state["prefix"])
            or recovery.fingerprint(config) != state["config_sha256"]):
        raise RuntimeError("Saved deployment ownership changed; inspection refused.")
    run = recovery.RecoveryRun(argparse.Namespace(state=directory, config=config))
    run.state = state
    try:
        with recovery.automated_ssh_tofu():
            run.connect_proxmox()
            if recovery.controller_inventory(run.proxmox, state["prefix"]) != state["controllers"]:
                raise RuntimeError("Controller ownership changed; inspection refused.")
            ssh = SSHCommandRunner(
                run.config["proxmox_ssh_key"], run.config["proxmox_ssh_user"],
                "retained upgrade host residual inspection",
            )
            hosts = state["workload_identity"]["hosts"]
            for host in hosts:
                node = host["node"]
                if (not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]*", node)
                        or node not in state["offline_cleanup_plan"]["hosts"]):
                    raise RuntimeError("Saved cleanup host ownership missing.")
                output = ssh.run(node, shlex.join(["sudo", "-n", "sh", "-c", PROGRAM]))
                recovery.private_write(directory / f"host-residuals-{node}.txt", output.encode())
                print(f"--- {node} ---\n{output}")
    finally:
        run.close()


if __name__ == "__main__":
    main()
