"""Read-only network state dump for owned retained NSR HA lab members.

Runs through the controller-tunnelled guest path and prints links, addresses,
routes, rules, sockets and nftables for the root and `sf-router` namespaces,
or with `--journal` the router units and kernel journal for a time window.
"""

from pathlib import Path

PROGRAM = r"""set -u
section() { printf '\n===== %s =====\n' "$*"; }
for ns in root sf-router; do
  if [ "$ns" = root ]; then x=""; else x="ip netns exec $ns"; fi
  section "$ns links"; $x ip -d -br link
  section "$ns addrs"; $x ip -br -4 addr
  section "$ns rules"; $x ip -4 rule
  section "$ns routes (all tables)"; $x ip -4 route show table all | grep -v '^local\|^broadcast'
  section "$ns neigh"; $x ip -4 neigh
  section "$ns sysctl"; $x sysctl net.ipv4.ip_forward net.ipv4.conf.all.rp_filter net.ipv4.conf.default.rp_filter 2>&1
  section "$ns nft"; $x nft list ruleset 2>&1
done
section "netns list"; ip netns list
section "listen"; ss -ltnup
section "netplan"; ls -l /etc/netplan /run/systemd/network 2>&1; cat /etc/netplan/*.yaml 2>&1 | grep -v -i 'password\|key'
section "networkd"; networkctl list --no-pager 2>&1
section "resolved"; resolvectl status --no-pager 2>&1 | head -40
"""


def main(argv=None):
    import argparse
    import sys

    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root / "python_installer" / "tests_integration"))
    import nsr_ha as ha

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", type=Path, required=True)
    parser.add_argument("--member", choices=("a", "b"), action="append", required=True)
    parser.add_argument("--journal", nargs=2, type=int, metavar=("SINCE_EPOCH", "UNTIL_EPOCH"),
                        help="print swiftfabric-router* journal for the window instead of network state")
    parser.add_argument("--all-units", action="store_true",
                        help="with --journal, include all guest units when unit filtering misses records")
    args = parser.parse_args(argv)
    program = PROGRAM
    if args.journal:
        since, until = args.journal
        if not 0 < since < until or until - since > 86400:
            parser.error("--journal window must be positive and at most one day")
        program = (
            # journalctl ANDs -k with -u, so read units and kernel separately.
            "set -u\nfor match in \"-u swiftfabric-router* -u swiftfabric-api-proxy* -u swiftfabric-host-agent*\" -k; do\n"
            f"  journalctl --no-pager -o short-unix --since @{since} --until @{until} $match 2>&1 | tail -n 3000\n"
            "done\n"
        )
        if args.all_units:
            program = f"journalctl --no-pager -o short-unix --since @{since} --until @{until} -n 1500\n"
    elif args.all_units:
        parser.error("--all-units requires --journal")

    def dump(run):
        for member in args.member:
            print(f"\n######## member {member} ########")
            print(run.run_owned_guest(member, program, timeout=90))

    with ha.automated_ssh_tofu():
        ha.with_saved_run(args.state, dump, action_name="ha-net-dump")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
