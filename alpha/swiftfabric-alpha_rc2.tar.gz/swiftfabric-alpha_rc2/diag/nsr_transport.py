"""Pinned, controller-independent SSH transport for owned disposable NSR tests."""

import ipaddress
from pathlib import Path
import re
import shlex
import subprocess
import tempfile


class DirectMembers:
    """Temporarily authorize one test key; retain existing guest SSH trust."""

    def __init__(self, run):
        self.run = run
        self.directory = None
        self.authorized = []
        self.public_key = None

    def __enter__(self):
        self.directory = Path(tempfile.mkdtemp(prefix="nsr-direct-", dir=self.run.directory))
        directory = self.directory
        self.key = directory / "key"
        self.pins = directory / "known_hosts"
        try:
            subprocess.run(
                ["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-C", "swiftfabric-ha-test",
                 "-f", str(self.key)],
                check=True, capture_output=True, text=True,
            )
            self.public_key = self.key.with_suffix(".pub").read_text().strip()
            pins = []
            for member, physical in self.run.state["pair"].items():
                self.run.owned_member_path(member)
                address = str(ipaddress.IPv4Interface(physical["management_address_cidr"]).ip)
                candidate = self.run.api.json(
                    "GET", f"/north-south-routers/{self.run.state['router_requested']}/"
                    f"ssh-host-key?member={member}",
                )
                trusted = candidate.get("trusted") if isinstance(candidate, dict) else None
                if (
                    not isinstance(trusted, dict) or candidate.get("changed") is not False
                    or trusted.get("endpoint") != f"[{address}]:22"
                    or trusted.get("fingerprint") != self.run.state["guest_ssh_fingerprints"][member]
                ):
                    raise RuntimeError("approved NSR SSH trust changed; direct transport refused")
                public = trusted.get("public_key")
                parts = public.split() if isinstance(public, str) else []
                if (
                    len(parts) != 2 or not re.fullmatch(r"[A-Za-z0-9+/=]+", parts[1])
                    or self.run.api.ssh._fingerprint(parts[1]) != trusted["fingerprint"]
                ):
                    raise RuntimeError("NSR public key does not match approved fingerprint")
                pins.append(f"{address} {public}\n")
                self.pins.write_text("".join(pins))
                self.pins.chmod(0o600)
                self.authorized.append(member)
                self.run.run_owned_guest(member, self.authorize_script())
            for member in self.authorized:
                if self.execute(member, "printf 'direct-ready\\n'").strip() != "direct-ready":
                    raise RuntimeError("direct NSR transport readiness check failed")
            return self
        except (OSError, ValueError, RuntimeError, subprocess.SubprocessError, KeyboardInterrupt):
            self.close()
            raise

    def authorize_script(self):
        key = shlex.quote(self.public_key)
        return (
            "set -eu\n"
            "install -d -o ubuntu -g ubuntu -m 0700 /home/ubuntu/.ssh\n"
            "touch /home/ubuntu/.ssh/authorized_keys\n"
            "chown ubuntu:ubuntu /home/ubuntu/.ssh/authorized_keys\n"
            "chmod 0600 /home/ubuntu/.ssh/authorized_keys\n"
            f"printf '%s\\n' {key} >> /home/ubuntu/.ssh/authorized_keys\n"
            "sync -f /home/ubuntu/.ssh/authorized_keys\n"
        )

    def execute(self, member, program, *, timeout=90):
        if type(timeout) is not int or not 1 <= timeout <= 240:
            raise ValueError("direct NSR command timeout must be 1-240 seconds")
        self.run.owned_member_path(member)
        physical = self.run.state["pair"][member]
        address = str(ipaddress.IPv4Interface(physical["management_address_cidr"]).ip)
        result = subprocess.run(
            ["ssh", "-F", "/dev/null", "-i", str(self.key), "-o", "IdentitiesOnly=yes",
             "-o", "IdentityAgent=none",
             "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes",
             "-o", "GlobalKnownHostsFile=/dev/null", "-o", "UserKnownHostsFile=" + str(self.pins),
             "-o", "ConnectTimeout=5", "ubuntu@" + address, "sudo -n /bin/sh -s"],
            input=program, capture_output=True, text=True, timeout=timeout,
        )
        if result.returncode:
            raise RuntimeError(f"direct NSR member {member} command failed: {result.stderr[-2000:]}")
        return result.stdout

    def close(self):
        failures = []
        if self.public_key is not None:
            key = shlex.quote(self.public_key)
            program = (
                "set -eu\n"
                "file=/home/ubuntu/.ssh/authorized_keys\n"
                "temporary=$(mktemp /home/ubuntu/.ssh/ha-test-cleanup.XXXXXX)\n"
                "trap 'rm -f \"$temporary\"' EXIT\n"
                f"awk -v key={key} '$0 != key' \"$file\" > \"$temporary\"\n"
                "chown ubuntu:ubuntu \"$temporary\"\n"
                "chmod 0600 \"$temporary\"\n"
                "mv \"$temporary\" \"$file\"\n"
                "sync -f \"$file\"\n"
            )
            for member in self.authorized:
                try:
                    self.execute(member, program)
                except (OSError, ValueError, KeyError, RuntimeError, subprocess.SubprocessError) as failure:
                    failures.append(f"{member}: {failure}")
        if failures:
            # Keep the owner-only key so failed cleanup can be retried.
            raise RuntimeError(
                "temporary NSR authorization cleanup failed; private transport retained at "
                f"{self.directory}: " + "; ".join(failures)
            )
        if self.directory is not None:
            for path in (self.key, self.key.with_suffix(".pub"), self.pins):
                path.unlink(missing_ok=True)
            self.directory.rmdir()

    def __exit__(self, kind, value, traceback):
        self.close()
