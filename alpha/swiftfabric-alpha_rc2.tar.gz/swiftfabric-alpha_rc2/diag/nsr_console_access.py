"""Temporary Proxmox-console login for owned retained NSR HA lab members.

The NSR test deploys members without a cloud-init password, so `ubuntu` is
key-only. This sets a random console password through the controller-tunnelled
guest path. Only a SHA-512 crypt hash leaves this machine; the plaintext is
written owner-only (0600) into the run directory. SSH password login stays
disabled by the guest's sshd configuration.
"""

import os
from pathlib import Path
import re
import secrets
import shlex
import subprocess

HASH = re.compile(r"\$6\$[./0-9A-Za-z]{1,16}\$[./0-9A-Za-z]{86}")


def crypt_hash(password):
    result = subprocess.run(
        ["openssl", "passwd", "-6", "-stdin"], input=password + "\n",
        capture_output=True, text=True, check=True, timeout=10,
    )
    value = result.stdout.strip()
    if not HASH.fullmatch(value):
        raise RuntimeError("openssl returned an invalid SHA-512 crypt hash")
    return value


def set_program(hashed):
    return f"set -eu\nusermod -p {shlex.quote(hashed)} ubuntu\nsync -f /etc/shadow\npasswd -S ubuntu\n"


def lock_program():
    return "set -eu\nusermod -p '!' ubuntu\nsync -f /etc/shadow\npasswd -S ubuntu\n"


def remove_key_program(public_key):
    key = shlex.quote(public_key)
    return (
        "set -eu\n"
        "file=/home/ubuntu/.ssh/authorized_keys\n"
        "temporary=$(mktemp /home/ubuntu/.ssh/ha-test-cleanup.XXXXXX)\n"
        "trap 'rm -f \"$temporary\"' EXIT\n"
        f"awk -v key={key} '$0 != key' \"$file\" > \"$temporary\"\n"
        "chown ubuntu:ubuntu \"$temporary\"\n"
        "chmod 0600 \"$temporary\"\n"
        "mv \"$temporary\" \"$file\"\n"
        "sync -f \"$file\"\n"
        f"! grep -qxF {key} \"$file\"\n"
    )


def write_private(path, text):
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o600)
    with os.fdopen(descriptor, "w") as handle:
        handle.write(text)


def apply(run, members, lock, cleanup_direct, check=False):
    if check:
        for member in members:
            program = "set -eu\npasswd -S ubuntu\nfindmnt -n -o SOURCE,FSTYPE,OPTIONS /\n"
            for directory in sorted(run.directory.glob("nsr-direct-*")):
                public = directory / "key.pub"
                if public.exists():
                    key = shlex.quote(public.read_text().strip())
                    program += (
                        f"if grep -qxF {key} /home/ubuntu/.ssh/authorized_keys; then "
                        f"echo '{directory.name}: key present'; else "
                        f"echo '{directory.name}: key absent'; fi\n"
                    )
            print(f"member {member}: {run.run_owned_guest(member, program, timeout=30).strip()}")
        return
    for directory in sorted(run.directory.glob("nsr-direct-*")) if cleanup_direct else ():
        public = directory / "key.pub"
        if public.exists():
            text = public.read_text().strip()
            for member in ("a", "b"):
                run.run_owned_guest(member, remove_key_program(text), timeout=30)
            print(f"removed retained test key {directory.name} from both members")
        for name in ("key", "key.pub", "known_hosts"):
            (directory / name).unlink(missing_ok=True)
        directory.rmdir()
    for member in members:
        output = run.directory / f"console-password-{member}"
        if lock:
            status = run.run_owned_guest(member, lock_program(), timeout=30)
            output.unlink(missing_ok=True)
        else:
            password = secrets.token_urlsafe(18)
            status = run.run_owned_guest(member, set_program(crypt_hash(password)), timeout=30)
            write_private(output, password + "\n")
            print(f"member {member}: password saved to {output}")
        print(f"member {member}: {status.strip()}")


def main(argv=None):
    import argparse
    import sys

    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root / "python_installer" / "tests_integration"))
    import nsr_ha as ha

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", type=Path, required=True)
    parser.add_argument("--member", choices=("a", "b"), action="append", default=[])
    parser.add_argument("--lock", action="store_true", help="re-lock the console password")
    parser.add_argument("--check", action="store_true",
                        help="read password lock, root storage and retained test-key presence")
    parser.add_argument("--cleanup-direct-key", action="store_true",
                        help="remove retained nsr-direct-* temporary test keys from both members")
    args = parser.parse_args(argv)
    if args.check and (args.lock or args.cleanup_direct_key):
        parser.error("--check cannot change credentials")
    if not args.member and not args.cleanup_direct_key:
        parser.error("choose --member and/or --cleanup-direct-key")
    with ha.automated_ssh_tofu():
        ha.with_saved_run(
            args.state, lambda run: apply(run, args.member, args.lock, args.cleanup_direct_key, args.check),
            action_name="ha-console-access",
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
