# SwiftFabric diagnostics

Run from the supervisor checkout using its Python environment. Tool source lives
here; credentials and run output do not belong in this repository.

## Retained release cleanup

```sh
venv/bin/python diag/release_cleanup_inventory.py --state /private/integration/release-RUN-upgrade
```

Verifies saved controller configurations and deployment CA, then reads host,
router, and cluster inventories. Saves credential-free, owner-only
`release-cleanup-inventory.json`; no target resources are changed.
After ordered cleanup completes, add `--verify-cleanup` to check Proxmox for all
saved guest identities and run the existing read-only host residual probe.
This saves `release-cleanup-verification.json` without contacting deleted controllers.

`upgrade_test.py --cleanup` uses `baseline_release_cleanup.py` before upgrade:
the verified historical installer/API kit remains in use, while current lab
teardown handles retries after the router was already deleted. Historical
acceptance files are not modified. If failed acceptance never published
workload identity, matching saved lab evidence supplies host ownership without
marking acceptance successful. Host unenrollment still precedes controller deletion.

## Interrupted upgrade cleanup residuals

```sh
venv/bin/python diag/upgrade_host_residuals.py --state /private/integration/release-RUN-upgrade
```

Reads bounded file metadata, service/package state on saved cleanup-plan hosts.
Requires matching deployment config and controller VM inventory. Saves private
`host-residuals-NODE.txt` evidence without printing file contents or credentials.
The upgrade teardown removes recognized `swiftfabric-host-helper-<sha256>`
cache files after stopping agents; unknown entries or symlinks block removal.
Saved host plans allow retries after partial removal of host configuration.
Strict residual verification still gates controller deletion.
Lab VMs may migrate after acceptance: cleanup locates each saved VM by its
current Proxmox node and rechecks its ownership marker and bridge before
deletion. Changes to other saved VM identity fields still block cleanup.

## NSR Ubuntu repository access

```sh
venv/bin/python diag/nsr_repository_access.py --state /private/integration/release-RUN-upgrade
```

Verifies saved controller and standalone-router VM ownership, uses authenticated
HTTPS to obtain an owner-only temporary guest key, and verifies the existing SSH
host pin. Reads root-namespace routes/firewall, Ubuntu DNS and installed
`conntrack` state; sends two bounded IPv4 HTTP HEAD probes. No firewall changes,
package downloads/installation, or service restarts. Temporary credentials are
removed on exit. Output is saved owner-only as `nsr-repository-access.json`.
No interpreter is uploaded to or executed on controllers or NSRs.

## Retained tenancy migration startup

Inspect restored compute forwarding without taking the active test's SSH lock
or clearing its pins:

```sh
SWIFTFABRIC_INTEGRATION_KNOWN_HOSTS="$HOME/.ssh/swiftfabric-integration-known-hosts" \
  venv/bin/python diag/forwarding_readiness.py --state /private/integration/release-RUN
```

The pin file must already exist. This reads owned VM configuration and kernel
links/TC/FDB/guards, checks host-agent activity and demand-driven cache
consistency, and saves owner-only snapshots and `forwarding-diagnostic.json`.
No faults, cache programming, policy changes or traffic tests are performed.
This is a kernel preflight, not full traffic acceptance.

Read held-flow progress, per-case result summaries and bounded guest journals
without restarting services, changing policies or migrating VMs:

```sh
venv/bin/python diag/tenancy_migration_check.py \
  --state /private/integration/release-RUN/network-lab
```

Use `--tenant-index 1` for the second tenant. Normal lab ownership checks apply.
After migration, saved migration events select the original endpoint VMs and
the source VM's saved current host, rather than planning another migration.
The deployment config and retained console credentials must remain available.

## Full controller loss during NSR HA

Inspect a failed parent disaster-recovery run's replacement controller inventory,
HA status, nginx configuration/error logs and API journal:

```sh
venv/bin/python diag/nsr_controller_journal.py --recovery-state \
  --state /private/integration/release-RUN --validate-nginx
```

Controller ownership and config hash must match saved replacement inventory.
Evidence is saved owner-only in the run directory. Optional `--validate-nginx`
syntax-checks the checkout's rendered TLS proxy config on each controller
without installing it or reloading nginx. No recovery mutation is sent.

The retained HA runner uses `nsr_controller_loss.py` and `nsr_transport.py`:

Read deployment status without printing credentials or injecting a fault:

```sh
venv/bin/python diag/nsr_controller_loss.py --inspect \
  --state /private/integration/nsr-ha-RUN
```

Run the outage gate:

```sh
venv/bin/python python_installer/tests_integration/nsr_ha.py \
  --test-controller-loss --state /private/integration/nsr-ha-RUN
```

**Destructive, owned disposable retained HA lab only.** Stops all three
controllers for at least twenty minutes, checks cached forwarding and new WAN
sessions, then runs the double failover **a active -> a fails -> b takes over ->
a rejoins as standby -> b fails -> a takes over** with controllers still
stopped. Both promotions must complete within ten seconds; each restored
member must rejoin without preemption and reconnect session replication.
Original TCP/UDP sockets remain open for thirty minutes without reconnecting.
Controller return must adopt the guest-selected owner and term.

Direct SSH uses approved guest host-key fingerprints and one temporary local
test key, not production member private keys. Key authorization is removed on
exit. If removal fails, the tool fails and retains its owner-only key directory
for explicit cleanup; it never silently discards access needed to retry cleanup.
The controller health monitor is explicitly closed with a strict verdict before
the whole-cluster fault. Owned Proxmox power states, fresh direct guest status,
gateway reachability and WAN traffic are checked during the declared interval.
Controller VMs are restored in `finally`, and strict controller health must pass
again before acceptance. Replica resynchronization during the bounded
five-minute controller recovery window is classified as expected convergence,
not a failed platform alarm. Actual failed operations remain fatal; once
settled, or after the window expires, validation is strict.
Fault evidence remains private in the run directory.

The gate verifies Proxmox serial connectivity before stopping controllers and
captures rejoining members' boot, management routes, SSH status and journals
through `qm terminal`, including when direct SSH is unavailable. Temporary
console passwords are 0600 files, never printed, and are re-locked/deleted at
exit. Failed cleanup retains credentials and reports an error.

For an owned retained lab, prepare temporary authenticated serial access or
capture diagnostics using existing credentials:

```sh
venv/bin/python diag/nsr_serial.py --state /private/integration/nsr-ha-RUN --member a --prepare
venv/bin/python diag/nsr_serial.py --state /private/integration/nsr-ha-RUN --member a
venv/bin/python diag/nsr_console_access.py --state /private/integration/nsr-ha-RUN --member a --lock
```

New router packages provision the socket device and guest getty. Adding a
serial socket to an older running VM may require a reboot before `qm terminal`
can connect; the diagnostic does not reboot it automatically.

## Controllers-online double failover with live workload migration

Temporary guest console passwords and direct SSH authorization are flushed
to the guest filesystem before abrupt power cuts. Cleanup is flushed too;
delayed ext4 journal commits must not discard access or resurrect credentials.
For retained failed runs, `diag/nsr_console_access.py --check --member a
--member b --state RUN` reports password-lock and retained test-key presence
without printing credential contents.

```sh
venv/bin/python python_installer/tests_integration/nsr_ha.py \
  --test-double-failover-migration --state /private/integration/nsr-ha-RUN
```

Uses the same owned retained NSR HA lab, without controller failure injection.
Requires all three controllers healthy and hunsn3/hunsn4/hunsn5 online,
enrolled, and hosting the workload segment bridge. The original traffic-source
VM starts on hunsn3. A fails and B takes over; the running workload migrates
to hunsn4; A rejoins and reconnects replication. B then fails and A takes over;
the same workload migrates to hunsn5; B rejoins. Local disks are copied during
live migration. Only that owned workload VM is moved.

Original TCP/UDP sockets run for fifteen minutes with unchanged source IP,
MAC, guest boot ID and observed NAT tuples. Each power fault and migration
gets a separate held-flow survival measurement. New WAN sessions and
controller IP/MAC/VTEP learning must pass on each target; workload gateway
ARP must still resolve the shared NSR MAC. This proves the L2 path supporting
those routed flows, not a standalone same-segment guest-to-guest L2 matrix.
Strict platform monitoring stays active throughout. Guest role checks use
temporary fingerprint-pinned direct SSH, so controller-tunnel delays cannot
be mistaken for slow HA promotion. Test keys are removed from both members
at completion. The report preserves the primary scenario failure even if later
cleanup also fails; serial setup errors retain their original cause alongside
cleanup errors. Serial diagnostics remain
available during NSR reboot. Migration task IDs and current workload location
are saved for safe cleanup, even after failure. Successful saved actions leave
the lab retained on hunsn5; use the standard HA cleanup command afterwards.

To retry a failed run after resolving its cause, return only its owned workload
to hunsn3 with `venv/bin/python diag/nsr_migration.py --return-workload --state RUN`.
This validates the same identities, enrolled hosts and bridges, journals the
live migration, and does not count the reset as acceptance evidence.

Source: `nsr_migration.py`. The separate dual-tenancy acceptance also checks
held L2, East/West and North/South traffic across live workload migration; see
`network-lab/README.md`.

## Retained tenancy WAN failure

Read controller inventory, segment attachments, NSR routing-namespace addresses,
rules, routes, firewall, Geneve statistics, return-path TC filters and marked
transport lookups:

```sh
venv/bin/python diag/wan.py --state /private/integration/tenancy-RUN
```

Existing controller and NSR SSH pins are verified. If pins were removed by the
integration session, independently verify fingerprints first, or explicitly
authorize integration-style first-use trust with `--trust-first-use`. TOFU cannot
detect interception on the first connection. Changed NSR keys are never accepted.
Temporary private-key copies remain on the controller, owner-only, and are
removed after use. TLS chain and hostname verification remain enabled.

Trace a fresh TCP/UDP DNS probe from an owned VM in the active WAN tenant:

```sh
venv/bin/python diag/wan.py --state /private/integration/tenancy-RUN \
  --trust-first-use --capture-seconds 30 --probe-vmid 112 --source-port 62010
```

Choose unused source ports each time; the tool does not flush conntrack. Optional
`--compute-node NODE` captures on an owned compute host instead of the NSR.
`--dns ADDRESS` selects a DNS endpoint already allowed by the existing WAN policy.
Captures are bounded to 60 seconds. No forwarding configuration, service restart,
enrollment, deployment or teardown is performed. Probes generate traffic and
captures contain private network data; store output outside Git with `umask 077`.
Failures return nonzero and expose command status/stderr, not controller secrets.
Packet captures and guest probes must be correlated; a successful tool exit is
not a passing traffic assertion.

NSR routing marks select segment tables for inner packets. If a marked compute
VTEP lookup points at WAN while unmarked transport uses VTEP, and replies reach
`sf-gnv` but its transmit drop count grows, inspect return-packet mark clearing
before Geneve encapsulation. Preserve conntrack marks and tenant isolation.

Unit tests:

```sh
venv/bin/python -m unittest discover -s diag/tests
```

For a retained upgrade failure, collect router service status, up to 250 journal
entries plus 100 filtered startup errors from the last two hours, and non-secret
HA configuration:

```sh
venv/bin/python diag/wan.py --state /private/integration/upgrade-RUN \
  --trust-first-use --router-upgrade-logs
```

This mode uses the same ownership and SSH-pin checks. It does not restart services
or print configuration credentials. Journal output is private diagnostic evidence;
save it outside Git with `umask 077`.

## Retained upgrade teardown

[`upgrade_cleanup.py`](./upgrade_cleanup.py) and
[`upgrade_cleanup_remote.py`](./upgrade_cleanup_remote.py) implement the
API-independent teardown used by `upgrade_test.py --cleanup --state ...`.
They are not standalone force-delete commands. The integration entry point
checks the unchanged deployment configuration and locks retained state first.
Add `--cleanup-preflight` to that command for read-only ownership/access checks.
The helpers verify VM ownership markers and host deployment identities over
Proxmox/SSH, save a resumable plan, freeze controllers, remove owned guests and
host networking, verify residual state, and delete controllers last. They do
not require functioning controller HTTP endpoints or matching package versions.
No CA private keys or service credentials are returned from controllers.

## Temporary NSR console login

HA lab NSR members have no `ubuntu` password (key-only). To log in on the
Proxmox console of a retained owned lab member:

```sh
venv/bin/python diag/nsr_console_access.py --state /private/integration/nsr-ha-RUN --member a
```

Only a SHA-512 crypt hash is sent through the controller tunnel; the plaintext
is saved owner-only as `RUN/console-password-a`. SSH password auth stays off.
Re-lock with `--lock`. `--cleanup-direct-key` removes temporary test keys left
by a failed controller-loss gate (`RUN/nsr-direct-*`) from both members.

## NSR network state dump

Read-only links/addrs/rules/routes/neigh/nft for root and `sf-router`
namespaces of retained owned HA lab members, via the controller tunnel:

```sh
venv/bin/python diag/nsr_net_dump.py --state /private/integration/nsr-ha-RUN --member a --member b
```

`--journal SINCE_EPOCH UNTIL_EPOCH` prints the router, proxy and host-agent
unit journals plus the kernel journal for that window instead. Add
`--all-units` when guest unit filtering misses the router's records.

## NSR lab workload check

Read-only timing of `sudo`, hostname/DNS resolution and a WAN TCP connect on
the retained lab workload VM, over the Proxmox serial console (no controller
dependency). `--journal SINCE_EPOCH UNTIL_EPOCH` prints the guest journal
(minus resolver noise) to correlate harness serial timeouts:

```sh
venv/bin/python diag/nsr_workload_check.py --state /private/integration/nsr-ha-RUN
```

`--probes` prints the newest retained held-probe `status.json` files, which
explain "held probe terminated early" failures (for example a TCP connect
timeout while UDP still answered).

`--traffic-seconds 30` runs verified held TCP/UDP WAN traffic on the owned
workload without injecting an HA fault. It uploads current probe source,
validates the expected NAT address, stable socket tuples and the unchanged
30-second response-gap limit, then stops the owned probe unit. Private
`diagnostic-wan-*-probes.json` evidence stays in the retained HA run directory.
This verifies current connectivity, not HA handoff or a full release.

## NSR lab controller journal

Read-only `swiftfabric*`, Pacemaker and Corosync journals of the three lab
controllers for a window, plus each controller's addresses (showing the API
VIP holder). `--grep REGEX` filters lines. `--time-crm` instead times five
`crm_mon --one-shot --output-as=xml` runs per controller, the query behind
uncached segment-primary lookups:

```sh
venv/bin/python diag/nsr_controller_journal.py --state /private/integration/nsr-ha-RUN --journal SINCE UNTIL
venv/bin/python diag/nsr_controller_journal.py --state /private/integration/nsr-ha-RUN --time-crm
```
