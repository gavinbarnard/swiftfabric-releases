# Controller health collector

`controller-health.sh` captures a read-only health snapshot from the controller
where it runs. Run it on **each** controller; one healthy node or API VIP does
not prove cluster health.

```sh
sudo ./diag/controller-health.sh \
  --controller-ip '<controller-management-ip>' \
  --api-vip '<api-vip>'
```

The script reports host capacity, failed units, API package version, service
activity, Corosync quorum/membership/KNET links, Pacemaker state, recent
controller logs, TCP listeners, and the installed server certificate's dates
and SANs. Supplying both IPs also verifies the leaf against the installed
deployment CA for the controller address and API VIP. It writes no files and
does not restart services, alter cluster state, make API requests, or access
private keys.

## Read the results

- Full health requires all three Corosync members and Pacemaker nodes online,
  expected votes `3`, total votes `3`, quorum present, connected KNET links, and
  expected resources running. Two votes may retain quorum but indicate
  degraded redundancy.
- Any inactive service, missing package/certificate, failed command, or
  certificate verification error needs investigation. The script keeps running
  to collect remaining evidence and exits nonzero if a command fails.
- A certificate verification failure can indicate an untrusted/wrong CA,
  expiry, or missing IP SAN. Do not retry with disabled TLS verification.
- An API VIP or HTTPS listener being healthy does not establish Pacemaker,
  replication, or all-node health. Compare snapshots from all controllers.

The output can contain internal addresses and log details. Keep it local and
redact before sharing. If saving output, create an owner-only file:

```sh
sudo sh -c 'umask 077; ./diag/controller-health.sh \
  --controller-ip "<controller-management-ip>" --api-vip "<api-vip>" \
  > /root/controller-health.txt 2>&1'
```

For interpretation and recovery boundaries, see the repository's
[troubleshooting guide](../TROUBLESHOOTING.md), especially its TLS and
Corosync/Pacemaker sections. This collector is evidence gathering only; do not
force quorum, change resource policy, or restart cluster services as a
diagnostic shortcut.
