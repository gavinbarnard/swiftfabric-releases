"""Read retained tenancy migration progress, result summaries and unit journals."""

import argparse
from pathlib import Path
import shlex
import sys


def inspect(args):
    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root / "network-lab"))
    from tenancy import TenantLab

    lab = TenantLab(args.state)
    tenant_id = lab.state["tenant_ids"][args.tenant_index]
    events = [event for event in lab.state.get("migration_events", [])
              if event["tenant_id"] == tenant_id]
    if events:
        event = events[-1]
        source = next(vm for vm in lab.state["vms"] if vm["vmid"] == event["vmid"])
        endpoint_node = next(node for node in lab.state["nodes"]
                             if node not in (event["source"], event["target"]))
        segments = [segment for segment in lab.state["segments"]
                    if segment["tenant_id"] == tenant_id]
        endpoints = [
            next(vm for vm in lab.state["vms"]
                 if vm["tenant_id"] == tenant_id and vm["segment_id"] == segment["id"]
                 and vm["node"] == endpoint_node)
            for segment in segments[:2]
        ]
    else:
        plan = lab.migration_plan(tenant_id)
        source, endpoints = plan["source"], plan["endpoints"]
    run_id = lab.state["run_id"][:8]
    for vm in [source, *endpoints]:
        kind = "vm" if vm is source else "ep"
        unit = f"sf-lab-migration-{run_id}-t{args.tenant_index}-{kind}-{vm['vmid']}"
        commands = []
        if kind == "vm":
            stem = (
                f"/run/swiftfabric-network-lab-migration/"
                f"{run_id}-t{args.tenant_index}-vm-{vm['vmid']}"
            )
            program = f"""import json,pathlib
for suffix in ("progress", "results"):
    path = pathlib.Path({stem!r} + "-" + suffix + ".json")
    if not path.exists():
        print(suffix + ": missing")
        continue
    value = json.loads(path.read_text())
    if suffix == "results":
        value = [{{key: item.get(key) for key in
                  ("case_id", "connected", "error", "passed", "failures",
                   "requests", "application_bytes_received", "elapsed_seconds",
                   "max_response_gap_seconds")}} for item in value]
    print(suffix + ": " + json.dumps(value))
"""
            commands.append(shlex.join(["sudo", "-n", "python3", "-c", program]))
        journal = f"""import subprocess
result = subprocess.run(
    ["journalctl", "--no-pager", "-n", "40", "-u", {unit + ".service"!r}],
    capture_output=True, text=True, check=True,
)
for line in result.stdout.splitlines():
    print(line[:600] + (" [truncated]" if len(line) > 600 else ""))
"""
        commands.append(shlex.join(["sudo", "-n", "python3", "-c", journal]))
        print(f"--- VM {vm['vmid']} on {vm['node']}: {unit}", flush=True)
        print(lab.serial(vm, " && ".join(commands), timeout=120), flush=True)
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", type=Path, required=True, help="network-lab state directory")
    parser.add_argument("--tenant-index", type=int, default=0, choices=(0, 1))
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root / "python_installer" / "tests_integration"))
    from integration_common import automated_ssh_tofu

    with automated_ssh_tofu():
        return inspect(args)


if __name__ == "__main__":
    raise SystemExit(main())
