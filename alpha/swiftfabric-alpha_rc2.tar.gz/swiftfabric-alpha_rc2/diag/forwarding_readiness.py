"""Capture read-only compute forwarding state for a retained recovery run."""

import argparse
import json
from pathlib import Path
import shlex
import sys


def main(argv=None):
    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root / "python_installer/tests_integration"))
    sys.path.insert(0, str(root / "network-lab"))
    import disaster_recovery as recovery

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", type=Path, required=True)
    args = parser.parse_args(argv)
    directory = args.state.resolve()
    state = recovery.read_config_object(directory / "recovery.json")
    config_path = Path(state["config"])
    if recovery.fingerprint(config_path) != state["config_sha256"]:
        raise ValueError("Deployment configuration changed; diagnostics refused.")
    config = recovery.load_deployment_config(config_path)
    lab = recovery.read_config_object(directory / "network-lab/state.json")
    if lab["config"] != str(config_path) or lab["router"] != state["prefix"] + "-nsr":
        raise ValueError("Saved lab ownership differs from the recovery run.")
    ssh = recovery.SSHCommandRunner(
        config["proxmox_ssh_key"], config["proxmox_ssh_user"], "read-only forwarding diagnostics",
    )
    snapshots = {}
    vteps = {}
    for node in sorted({host["node"] for host in state["host_identities"]}):
        ports = {
            str(segment["id"]): [
                f"fwpr{vm['vmid']}p0" for vm in lab["vms"]
                if vm["node"] == node and vm["segment_id"] == segment["id"]
            ] for segment in lab["segments"]
        }
        snapshot = json.loads(ssh.run(
            node, "sudo -n python3 -c " + shlex.quote(recovery.FORWARDING_SNAPSHOT)
            + " " + shlex.quote(json.dumps(ports)), timeout=60,
        ))
        destination = directory / f"forwarding-snapshot-{node}.json"
        recovery.private_write(destination, snapshot)
        print(destination)
        snapshots[node] = snapshot
        sources = {
            action["src_ip"] for segment in snapshot["segments"].values()
            for rule in segment["remote"]
            for action in rule.get("options", {}).get("actions", [])
            if action.get("kind") == "tunnel_key" and action.get("src_ip")
        }
        if len(sources) != 1:
            raise ValueError(f"{node}: kernel tunnel source is ambiguous or absent.")
        vteps[node] = sources.pop()
    from lab import assert_vm_owner

    expected = {}
    for vm in lab["vms"]:
        if type(vm["vmid"]) is not int or vm["vmid"] <= 0 or vm["node"] not in snapshots:
            raise ValueError("Saved VM identity is invalid; diagnostics refused.")
        program = (
            "import json,subprocess\n"
            f"raw=subprocess.check_output(['qm','config',{str(vm['vmid'])!r}],text=True)\n"
            "fields=dict(line.split(': ',1) for line in raw.splitlines() if ': ' in line)\n"
            "print(json.dumps({key:fields[key] for key in ('name','description','net0')}))\n"
        )
        vm_config = json.loads(ssh.run(
            vm["node"], "sudo -n python3 -c " + shlex.quote(program), timeout=60,
        ))
        assert_vm_owner(vm_config, vm, lab["run_id"])
        net0 = dict(part.split("=", 1) for part in vm_config["net0"].split(",") if "=" in part)
        expected.setdefault(vm["segment_id"], []).append({
            "node": vm["node"], "mac": net0["virtio"].lower(),
            "vtep": vteps[vm["node"]], "port": f"fwpr{vm['vmid']}p0",
        })
    blockers = [
        f"{node}: {blocker}" for node, snapshot in snapshots.items()
        for blocker in recovery.forwarding_blockers(snapshot, expected, node)
    ]
    recovery.private_write(directory / "forwarding-diagnostic.json", {
        "passed": not blockers, "blockers": blockers,
    })
    print(f"Kernel forwarding preflight: {len(blockers)} blockers.")
    for blocker in blockers:
        print(blocker)
    return 1 if blockers else 0


if __name__ == "__main__":
    raise SystemExit(main())
