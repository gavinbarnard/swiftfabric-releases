"""Controllers-online NSR A -> B -> A failover with held-flow VM live migration."""

import ipaddress
import json
import secrets
import shlex
import subprocess
import time

from nsr_controller_loss import guest_view, require_view
from nsr_serial import SerialMembers, capture
from nsr_transport import DirectMembers


NODES = ("hunsn3", "hunsn4", "hunsn5")
HELD_SECONDS = 900
MIGRATION_TIMEOUT = 180


def workload_view(run):
    vm = run.lab.state["vms"][0]
    source = vm["address"]
    destination = run.state["held_flow_cases"][0]["destination"]
    ipaddress.IPv4Address(source)
    ipaddress.IPv4Address(destination)
    program = f"""import json,pathlib,subprocess
route=json.loads(subprocess.check_output(["ip","-j","-4","route","get",{destination!r},"from",{source!r}]))[0]
device=route["dev"]
addresses=json.loads(subprocess.check_output(["ip","-j","-4","addr","show","dev",device]))[0]
link=json.loads(subprocess.check_output(["ip","-j","link","show","dev",device]))[0]
if not any(address["local"]=={source!r} for address in addresses["addr_info"]):
    raise RuntimeError("workload source address missing")
neighbors=json.loads(subprocess.check_output(["ip","-j","-4","neigh","show","dev",device]))
gateway=route["gateway"]
print(json.dumps({{"boot_id":pathlib.Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    "source":{source!r},"device":device,"mac":link["address"],"gateway":gateway,
    "neighbors":[entry for entry in neighbors if entry["dst"]==gateway]}}))
"""
    return json.loads(run.lab.setup_serial(vm, "python3 -c " + shlex.quote(program), timeout=30))


def preflight(run, *, returning=False):
    vm = run.lab.state["vms"][0]
    if len(run.lab.state["vms"]) != 1:
        raise RuntimeError("migration acceptance requires exactly one owned workload on hunsn3")
    run.lab.vm_config(vm)
    if vm["node"] not in (NODES if returning else NODES[:1]):
        raise RuntimeError("migration acceptance requires exactly one owned workload on hunsn3")
    hosts = run.api.json("GET", "/hosts")
    enrolled = {}
    nodes = run.proxmox.get("/nodes")["data"]
    online = {item["node"] for item in nodes if item.get("status") == "online"}
    for node in NODES:
        matches = [host for host in hosts if host.get("node") == node
                   and host.get("cluster") == run.config["proxmox_cluster_name"]
                   and host.get("status") == "enrolled"]
        if len(matches) != 1 or node not in online:
            raise RuntimeError(f"migration target {node} must be online and uniquely enrolled")
        enrolled[node] = {"host_id": matches[0]["host_id"], "vtep_ip": matches[0]["vtep_ip"]}
        interfaces = run.proxmox.get(f"/nodes/{node}/network")["data"]
        if not any(item.get("iface") == f"sf-br{vm['segment_id']}" and item.get("active") == 1
                   for item in interfaces):
            raise RuntimeError(f"migration target {node} lacks active workload segment bridge")
    return enrolled


def controller_check(run, controllers):
    import nsr_ha as ha
    from nsr_ha_vip import controller_path

    run.require_platform_healthy()
    if ha.deployment.controller_inventory(run.proxmox, run.state["prefix"]) != controllers:
        raise RuntimeError("controller identity changed during online migration acceptance")
    for controller in controllers:
        path = controller_path(run, controller)
        if run.proxmox.get(path + "/status/current")["data"]["status"] != "running":
            raise RuntimeError("controller stopped during controllers-online acceptance")


def require_learning(run, expected, baseline, report, save):
    vm = run.lab.state["vms"][0]
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        listing = run.api.json("GET", f"/segments/{vm['segment_id']}/macs")
        records = [entry for entry in listing["entries"] if entry.get("mac") == baseline["mac"]]
        if len(records) == 1 and all(records[0].get(key) == value for key, value in {
            **expected, "ip": vm["address"],
        }.items()):
            current = workload_view(run)
            for field in ("boot_id", "source", "device", "mac", "gateway"):
                if current[field] != baseline[field]:
                    raise RuntimeError(f"live migration changed workload {field}")
            gateway_mac = f"02:53:46:00:{vm['segment_id'] >> 8:02x}:{vm['segment_id'] & 255:02x}"
            if not any(entry.get("lladdr") == gateway_mac
                       and not {"FAILED", "INCOMPLETE"} & set(entry.get("state", []))
                       for entry in current["neighbors"]):
                raise RuntimeError("workload gateway ARP did not converge after migration")
            report.update(controller_binding=records[0], workload=current, learning_passed=True)
            save()
            return
        time.sleep(2)
    raise TimeoutError(f"controller L2 binding did not move to workload host {vm['node']}")


def migrate(run, target, report, save, *, returning=False):
    vm = run.lab.state["vms"][0]
    run.lab.vm_config(vm)
    source = vm["node"]
    allowed = (tuple((node, NODES[0]) for node in NODES[1:]) if returning
               else tuple(zip(NODES, NODES[1:])))
    if (source, target) not in allowed:
        raise RuntimeError("workload migration is outside hunsn3 -> hunsn4 -> hunsn5")
    path = f"/nodes/{source}/qemu/{vm['vmid']}"
    if run.proxmox.get(path + "/status/current")["data"]["status"] != "running":
        raise RuntimeError("workload must be running before live migration")
    precondition = run.proxmox.get(path + "/migrate", params={"target": target})["data"]
    allowed = precondition.get("allowed_nodes")
    if isinstance(allowed, list) and target not in allowed:
        raise RuntimeError(f"Proxmox rejects migration to {target}")
    if precondition.get("local_resources"):
        raise RuntimeError("workload has local resources blocking live migration")
    event = {"source": source, "target": target, "vmid": vm["vmid"],
             "started_monotonic": time.monotonic(), "passed": False}
    report["migration"] = event
    run.lab.state["migration_nodes"] = list(NODES)
    run.lab.state.setdefault("migration_events", []).append(event)
    run.lab.save()
    save()
    try:
        response = run.proxmox.post(path + "/migrate", {
            "target": target, "online": 1, "with-local-disks": 1,
        })
        task = response.get("data")
        if not isinstance(task, str) or not task.startswith(f"UPID:{source}:"):
            raise RuntimeError("migration did not return an owned source-node task")
        event["task"] = task
        run.lab.save()
        save()
        run.proxmox.wait_for_task(task, timeout=MIGRATION_TIMEOUT)
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            run.lab.vm_config(vm)
            if vm["node"] == target:
                status = run.proxmox.get(f"/nodes/{target}/qemu/{vm['vmid']}/status/current")["data"]
                if status["status"] == "running":
                    event.update(passed=True, completed_monotonic=time.monotonic())
                    return
            time.sleep(2)
        raise TimeoutError("migrating workload did not become running on target")
    finally:
        run.lab.vm_config(vm)
        run.lab.save()
        save()


def rejoin(run, source, owner, term, report, save):
    run.power_member(source, "start")
    deadline = time.monotonic() + 240
    diagnosed = False
    while time.monotonic() < deadline:
        try:
            views = {member: guest_view(run, member) for member in ("a", "b")}
        except (OSError, RuntimeError, subprocess.SubprocessError) as failure:
            report["rejoin_wait"] = str(failure)
            if not diagnosed:
                capture(run, source, report, save)
                diagnosed = True
            save()
            time.sleep(2)
            continue
        if views[source]["role"] == "active":
            raise RuntimeError("former active preempted successor during online rejoin")
        if all(status.get("role") == ("active" if member == owner else "standby")
               and status["pair"].get("owner") == owner and status["pair"].get("term") == term
               and status["pair"].get("peer_heard") is True for member, status in views.items()):
            for member, status in views.items():
                require_view(status, member, owner, term, controllers_down=False)
            if ((views[owner].get("replication") or {}).get("sender", {}).get("connected") is True
                    and (views[source].get("replication") or {}).get("receiver", {}).get("connected") is True):
                report.update(rejoined_epoch=time.time(), replication=views)
                save()
                return
        time.sleep(2)
    raise TimeoutError("NSR former active did not rejoin and reconnect replication")


def run_gate(run):
    import nsr_ha as ha

    if run.platform_health is None:
        raise RuntimeError("online migration acceptance requires strict controller health monitoring")
    router = run.router()
    ha.require_pair(router, deployed=True)
    if ha.pair_identity(router) != run.state["pair"]:
        raise RuntimeError("physical NSR ownership changed before migration acceptance")
    hosts = preflight(run)
    owner, term = run.wait_converged()
    if owner != "a":
        preparation = run.planned_handoff(owner, term, {})
        owner, term = preparation["member"], preparation["term"]
    if owner != "a":
        raise RuntimeError("online double failover requires initial owner a")
    controllers = ha.deployment.controller_inventory(run.proxmox, run.state["prefix"])
    if controllers != run.state["controllers"] or len(controllers) != 3:
        raise RuntimeError("controller ownership changed before online acceptance")
    report = {"passed": False, "started_epoch": time.time(), "initial_owner": owner,
              "initial_term": term, "nodes": list(NODES), "controllers": controllers,
              "scope": "controllers online; original TCP/UDP through A-B-A crashes and workload live migration",
              "legs": []}
    output = run.directory / f"online-migration-{time.time_ns()}-report.json"

    def save():
        ha.deployment.private_write(output, report)

    print(output, flush=True)
    save()
    vm = run.lab.state["vms"][0]
    unit = "swiftfabric-ha-probes-" + secrets.token_hex(8)
    remote = "/var/lib/" + unit
    cases = run.flow_cases(20000 + 2 * secrets.randbelow(20000), HELD_SECONDS)
    original_transport = run.run_owned_guest
    with SerialMembers(run), DirectMembers(run) as direct:
        try:
            run.run_owned_guest = direct.execute
            run.start_probes(vm, cases, remote, unit=unit)
            run.wait_established(vm, remote)
            offsets_before = run.guest_clock(vm)
            baseline = workload_view(run)
            require_learning(run, hosts[NODES[0]], baseline, report, save)
            for source, target in zip(("a", "b"), NODES[1:]):
                controller_check(run, controllers)
                leg = {"source": source, "passed": False}
                report["legs"].append(leg)
                fault = {"member": source, "started_monotonic": time.monotonic()}
                leg["fault"] = fault
                save()
                try:
                    successor = run.crash_active(source, term, fault)
                    leg["successor"] = successor
                    if successor["takeover_observed_seconds"] > ha.TAKEOVER_LIMIT_SECONDS:
                        raise RuntimeError("online takeover exceeded ten seconds")
                    owner, term = successor["member"], successor["term"]
                    migrate(run, target, leg, save)
                    leg["new_traffic"] = run.held_traffic(f"online-{source}-crash-{target}", 10)
                    require_learning(run, hosts[target], baseline, leg, save)
                    controller_check(run, controllers)
                    rejoin(run, source, owner, term, leg, save)
                    leg["stability"] = run.observe_stable(owner, term, ha.REJOIN_OBSERVATION_SECONDS)
                    progress = run.probe_status(vm, remote)
                    if progress.get("results") or progress.get("completed"):
                        raise RuntimeError("original sockets terminated before double migration completed")
                    leg["passed"] = True
                    save()
                finally:
                    path = run.owned_member_path(source)
                    if run.proxmox.get(path + "/status/current")["data"]["status"] == "stopped":
                        run.power_member(source, "start")
            report["final_pair"] = run.wait_converged("a", term=term)
            deadline = time.monotonic() + HELD_SECONDS + 60
            while time.monotonic() < deadline:
                controller_check(run, controllers)
                status = run.probe_status(vm, remote)
                if status.get("completed"):
                    break
                time.sleep(3)
            else:
                raise TimeoutError("original migration held probes did not finish")
            report["probes"] = status
            offsets_after = run.guest_clock(vm)
            offsets = [min(offsets_before[0], offsets_after[0]), max(offsets_before[1], offsets_after[1])]
            results = sorted(status["results"], key=lambda item: ("tcp", "udp").index(item["protocol"]))
            for leg in report["legs"]:
                for key in ("fault", "migration"):
                    event = leg[key]
                    bounds = [event["started_monotonic"] - offsets[1], event["completed_monotonic"] - offsets[0]]
                    leg[key]["measurements"] = ha.measurements(cases, results, bounds)
                    if not leg[key]["measurements"]["passed"]:
                        raise RuntimeError(f"original sessions failed across {key}")
            report.update(completed_epoch=time.time(), final_workload=workload_view(run))
        except (OSError, ValueError, RuntimeError, subprocess.SubprocessError,
                ha.deployment.ProxmoxAPIError, ha.deployment.requests.RequestException) as failure:
            report["error"] = f"{type(failure).__name__}: {failure}"
            save()
            raise
        finally:
            run.run_owned_guest = original_transport
            try:
                report["probe_cleanup"] = run.stop_probes(vm, unit)
            finally:
                save()
    report["passed"] = True
    save()
    run.record("online-double-failover-migration", report)


def return_workload(run):
    import nsr_ha as ha

    preflight(run, returning=True)
    controller_check(run, run.state["controllers"])
    if run.lab.state["vms"][0]["node"] == NODES[0]:
        raise RuntimeError("owned workload already on hunsn3")
    report = {"passed": False, "scope": "return owned workload to hunsn3 for acceptance retry"}
    output = run.directory / f"migration-return-{time.time_ns()}-report.json"

    def save():
        ha.deployment.private_write(output, report)

    migrate(run, NODES[0], report, save, returning=True)
    report["passed"] = True
    save()
    run.record("return-migration-workload", report)
    print(output)


def main(argv=None):
    import argparse
    import sys
    from pathlib import Path

    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root / "python_installer" / "tests_integration"))
    import nsr_ha as ha

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", type=Path, required=True)
    parser.add_argument("--return-workload", action="store_true", required=True,
                        help="return only the owned migrated workload to hunsn3 for a fresh acceptance attempt")
    args = parser.parse_args(argv)
    with ha.automated_ssh_tofu():
        ha.with_saved_run(args.state, return_workload, action_name="return-migration-workload")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
