"""Read-only controller journal dump for the owned retained NSR HA lab.

Prints the `swiftfabric*`, Pacemaker and Corosync journal of each of the three
lab controllers for a time window, plus which controller held the API VIP.
Use it when an NSR guest's controller request stalled (for example a slow
first ARP lookup through the API VIP). `--time-crm` instead times
`crm_mon`, which uncached segment-primary lookups run.
"""

import ipaddress
from pathlib import Path


CRM_TIMING = (
    "for i in 1 2 3 4 5; do s=$(date +%s%3N); crm_mon --one-shot --output-as=xml >/dev/null 2>&1; "
    "echo \"crm_mon rc=$? $(( $(date +%s%3N) - s ))ms\"; done"
)


def program(since, until, grep=None):
    command = (
        f"journalctl --no-pager -o short-unix --since @{since} --until @{until} "
        "-u 'swiftfabric*' -u pacemaker -u corosync 2>&1"
    )
    if grep:
        command += " | grep -E -- " + _quote(grep)
    return f"set -u; ip -br -4 addr | grep -v '^lo'; {command} | tail -n 1500"


def _quote(value):
    import shlex
    return shlex.quote(value)


def controller_addresses(config):
    start = ipaddress.IPv4Address(config["ip_range_start"])
    return [str(start + offset) for offset in range(3)]


def inspect_recovery(directory, *, validate_nginx=False):
    """Capture private, read-only evidence from owned replacement controllers."""
    import argparse
    import re
    import shlex
    import disaster_recovery as recovery

    directory = directory.expanduser().resolve()
    root = Path(__file__).resolve().parents[1]
    if directory == root or root in directory.parents:
        raise ValueError("recovery evidence must be outside the checkout")
    state = recovery.read_config_object(directory / "recovery.json")
    config = Path(state["config"])
    if not config.is_absolute() or not re.fullmatch(r"sf-dr-[0-9a-f]{20}", state["prefix"]):
        raise ValueError("invalid saved deployment configuration/ownership")
    if recovery.fingerprint(config) != state["config_sha256"]:
        raise RuntimeError("deployment configuration changed; diagnostics refused")
    run = recovery.RecoveryRun(argparse.Namespace(state=directory, config=config))
    run.state = state
    try:
        run.connect_proxmox()
        expected = state.get("replacement_controllers") or state.get("controllers")
        if not expected or recovery.controller_inventory(run.proxmox, state["prefix"]) != expected:
            raise RuntimeError("controller ownership changed; diagnostics refused")
        run.api = recovery.ControllerAPI(run.config, directory)
        routers = run.api.json("GET", "/north-south-routers")
        if not isinstance(routers, list) or any(
            not isinstance(router, dict) or not isinstance(router.get("id"), str)
            for router in routers
        ):
            raise RuntimeError("invalid router inventory; diagnostics refused")
        recovery.private_write(directory / "ha-recovery-inventory.json", routers)
        for router in routers:
            if router["id"] == state["prefix"] + "-ha-nsr":
                recovery.private_write(
                    directory / "ha-recovery-status.json",
                    run.api.json("GET", f"/north-south-routers/{router['id']}/ha-status"),
                )
        script = (
            "set -eu; date -u; "
            "systemctl show swiftfabric-api-service.service --property=ActiveState,SubState; "
            "nginx -T 2>&1; "
            "tail -n 100 /var/log/nginx/error.log; "
            "journalctl --no-pager -u swiftfabric-api-service.service --since '-2h' -n 300"
        )
        for address in controller_addresses(run.config):
            output = run.api.ssh.run(
                address, "sudo -n sh -c " + shlex.quote(script), timeout=90,
            )
            recovery.private_write(
                directory / f"ha-recovery-controller-{address}.log", output.encode(),
            )
            if validate_nginx:
                from deployment.api_service import ApiServiceDeployment

                candidate = "events {}\nhttp {\n" + ApiServiceDeployment._render_nginx_config() + "}\n"
                validation = run.api.ssh.run(
                    address, "sudo -n sh -c " + shlex.quote(
                        "set -eu; config=$(mktemp /run/swiftfabric-nginx-check.XXXXXX); "
                        "trap 'rm -f \"$config\"' EXIT; cat > \"$config\"; "
                        "nginx -t -c \"$config\" 2>&1"
                    ),
                    input_data=candidate.encode(), timeout=30,
                )
                recovery.private_write(
                    directory / f"ha-recovery-nginx-validation-{address}.log", validation.encode(),
                )
    finally:
        run.close()
    print(f"Private HA recovery inventory and controller logs saved: {directory}")


def main(argv=None):
    import argparse
    import shlex
    import sys

    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root / "python_installer" / "tests_integration"))
    import nsr_ha as ha

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", type=Path, required=True)
    parser.add_argument("--journal", nargs=2, type=int, metavar=("SINCE_EPOCH", "UNTIL_EPOCH"))
    parser.add_argument("--time-crm", action="store_true",
                        help="instead time five `crm_mon --one-shot --output-as=xml` runs per controller")
    parser.add_argument("--recovery-state", action="store_true",
                        help="inspect replacement controllers using parent recovery state; save private evidence")
    parser.add_argument("--validate-nginx", action="store_true",
                        help="also syntax-check checkout TLS proxy config, without installing or reloading it")
    parser.add_argument("--grep", help="extended regex to filter journal lines")
    args = parser.parse_args(argv)
    if sum((args.time_crm, bool(args.journal), args.recovery_state)) != 1:
        parser.error("use exactly one of --journal, --time-crm or --recovery-state")
    if args.validate_nginx and not args.recovery_state:
        parser.error("--validate-nginx requires --recovery-state")
    if args.journal and (not 0 < args.journal[0] < args.journal[1] or args.journal[1] - args.journal[0] > 86400):
        parser.error("--journal window must be positive and at most one day")

    def dump(run):
        for address in controller_addresses(run.config):
            print(f"\n######## controller {address} ########")
            script = CRM_TIMING if args.time_crm else program(*args.journal, args.grep)
            command = "sudo -n sh -c " + shlex.quote(script)
            print(run.api.ssh.run(address, command, timeout=90))

    with ha.automated_ssh_tofu():
        if args.recovery_state:
            inspect_recovery(args.state, validate_nginx=args.validate_nginx)
        else:
            ha.with_saved_run(args.state, dump, action_name="ha-controller-journal")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
