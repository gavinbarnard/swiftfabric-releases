#!/usr/bin/env python3
"""Inspect retained tenancy deployments without changing forwarding policy."""

import argparse
import concurrent.futures
from contextlib import nullcontext
import ipaddress
import json
from pathlib import Path
import shlex
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_installer/tests_integration"))
sys.path.insert(0, str(ROOT / "network-lab"))
from disaster_recovery import ControllerAPI
from integration_common import automated_ssh_tofu
from lab import LiveLab, POLICY_KEYS, encode
from main import load_deployment_config
from deployment.ssh import SSHCommandRunner


ROUTER_FIELDS = (
    "id", "name", "node", "vmid", "tenant_id", "status", "status_message",
    "wan_address_cidr", "wan_gateway", "management_address_cidr", "vtep_ip",
    "static_routes", *POLICY_KEYS,
)

TRANSPORT = """
import json,os,pathlib,subprocess,tempfile
segments=json.loads(pathlib.Path("/var/lib/swiftfabric/segments.json").read_text())
env=dict(os.environ,REDISCLI_AUTH=segments["4999"]["password"])
raw=subprocess.run(["valkey-cli","--raw","-p","4999","HGET",
    "swiftfabric:north_south_routers",ROUTER],env=env,capture_output=True,text=True,check=True).stdout
router=json.loads(raw)
if any(router.get(k)!=v for k,v in EXPECTED.items()):
    raise RuntimeError("NSR identity changed; diagnostics refused")
with tempfile.TemporaryDirectory(prefix="wan-diagnostics-",dir="/var/lib/swiftfabric/router-deploy") as directory:
    key=pathlib.Path(directory)/"key"
    key.write_text(router["ssh_private_key"])
    key.chmod(0o600)
    pins=pathlib.Path(directory)/"known_hosts"
    pins.write_text(PINS)
    pins.chmod(0o600)
    result=subprocess.run(["ssh","-i",str(key),"-o","IdentitiesOnly=yes",
        "-o","BatchMode=yes","-o","StrictHostKeyChecking=yes",
        "-o","GlobalKnownHostsFile=/dev/null","-o","UserKnownHostsFile="+str(pins),
        "-o","ConnectTimeout=5","ubuntu@"+ADDRESS,"sudo -n /usr/bin/python3 -"],
        input=PROGRAM,capture_output=True,text=True,timeout=110)
    if result.returncode:
        raise RuntimeError("NSR diagnostics failed: "+result.stderr)
    print(result.stdout)
"""


def trusted_key(candidate, address, first_use):
    if candidate.get("changed") is not False or candidate.get("endpoint") != f"[{address}]:22":
        raise RuntimeError("NSR SSH endpoint changed; diagnostics refused")
    trusted = candidate.get("trusted")
    if trusted is None:
        if not first_use:
            raise RuntimeError("NSR has no approved SSH pin; verify it or use --trust-first-use")
        trusted = next(
            (key for key in candidate.get("observed", [])
             if key.get("public_key", "").startswith("ssh-ed25519 ")), None,
        )
        if trusted is None:
            raise RuntimeError("NSR did not provide an Ed25519 SSH key")
        print(
            "First-use NSR SSH trust: " + trusted["fingerprint"]
            + ". TOFU cannot detect interception on this first connection.",
            file=sys.stderr,
        )
    elif trusted.get("endpoint") != f"[{address}]:22":
        raise RuntimeError("NSR approved SSH endpoint differs from its management address")
    key = trusted.get("public_key", "")
    parts = key.split()
    if len(parts) != 2 or SSHCommandRunner._fingerprint(parts[1]) != trusted.get("fingerprint"):
        raise RuntimeError("NSR SSH key fingerprint is invalid")
    return key


def command_program(commands, capture=None):
    return (
        "import json,subprocess\n"
        f"COMMANDS={commands!r}\nCAPTURE={capture!r}\n"
        "def execute(name,command,timeout,allowed=(0,)):\n"
        "    result=subprocess.run(command,capture_output=True,text=True,timeout=timeout)\n"
        "    print(json.dumps({'kind':name,'status':result.returncode,"
        "'stdout':result.stdout,'stderr':result.stderr}),flush=True)\n"
        "    if result.returncode not in allowed:\n"
        "        raise RuntimeError(name+' failed; inspect diagnostic stderr')\n"
        "if CAPTURE:\n"
        "    prefix,seconds,packet_filter=CAPTURE\n"
        "    execute('capture',prefix+['timeout',str(seconds),'tcpdump','-l','-nn','-e',"
        "'-i','any',packet_filter],seconds+10,(0,124))\n"
        "for name,command in COMMANDS.items():\n"
        "    execute(name,command,20)\n"
    )


def router_program(router, segments, seconds, dns):
    prefix = ["ip", "netns", "exec", "sf-router"]
    commands = {
        "addresses": prefix + ["ip", "-br", "addr"],
        "rules": prefix + ["ip", "-4", "rule"],
        "routes": prefix + ["ip", "-4", "route", "show", "table", "all"],
        "neighbors": prefix + ["ip", "-4", "neigh"],
        "firewall": prefix + ["nft", "list", "ruleset"],
        "geneve_stats": prefix + ["ip", "-s", "-j", "link", "show", "dev", "sf-gnv"],
        "forwarding": prefix + ["sysctl", "net.ipv4.ip_forward"],
        "runtime_log": ["journalctl", "--no-pager", "-u", "swiftfabric-router", "-n", "30"],
    }
    for segment in segments:
        identifier = segment["id"]
        commands[f"return_tc_{identifier}"] = prefix + [
            "tc", "-s", "filter", "show", "dev", f"sf-tq{identifier}", "ingress",
        ]
        for node in router["compute_vteps"]:
            commands[f"marked_route_{identifier}_{node}"] = prefix + [
                "ip", "-4", "route", "get", node, "mark", str(10000 + identifier),
            ]
    capture = (
        prefix, seconds,
        f"(host {dns} and port 53) or (udp port 6081 and src host {router['vtep_ip']})",
    ) if seconds else None
    return command_program(commands, capture)


def router_upgrade_program():
    units = [
        "swiftfabric-router.service",
        "swiftfabric-api-proxy.service", "swiftfabric-host-agent.service",
        "swiftfabric-router-netns.service",
    ]
    return command_program({
        "upgrade_services": [
            "systemctl", "show", "--no-pager",
            "--property=Id,ActiveState,SubState,Result,ExecMainStatus", *units,
        ],
        "upgrade_journal": [
            "journalctl", "--no-pager", "--output=short-iso", "--since=-2h", "-n", "250",
            *[argument for unit in units for argument in ("-u", unit)],
        ],
        "upgrade_startup_errors": [
            "journalctl", "--no-pager", "--output=short-iso", "--since=-2h", "-n", "100",
            "--grep=ha_replication_mode|unsupported keys|Failed at step|Failed to set up|"
            "ModuleNotFoundError|Main process exited|Failed to start",
            *[argument for unit in units for argument in ("-u", unit)],
        ],
    }) + (
        "import pathlib\n"
        "config=json.loads(pathlib.Path('/etc/swiftfabric/router.json').read_text())\n"
        "fields=('ha_enabled','ha_replication_mode','ha_state_sync_enabled',"
        "'ha_shared_vtep','role','ha_member','ha_active_member')\n"
        "print(json.dumps({'kind':'upgrade_configuration','keys':sorted(config),"
        "'ha':{key:config[key] for key in fields if key in config}}))\n"
    )


def execute_router(api, router, program, first_use):
    address = str(ipaddress.ip_interface(router["management_address_cidr"]).ip)
    candidate = api.json("GET", f"/north-south-routers/{router['id']}/ssh-host-key?member=a")
    key = trusted_key(candidate, address, first_use)
    expected = {key: router[key] for key in ("id", "name", "vmid", "management_address_cidr")}
    bindings = (
        f"ROUTER={router['id']!r};ADDRESS={address!r};EXPECTED={expected!r};"
        f"PINS={address + ' ' + key + chr(10)!r};PROGRAM={program!r};"
    )
    return api.ssh.run(
        api.config["ip_range_start"],
        shlex.join(["sudo", "-n", "/usr/bin/python3", "-c", bindings + TRANSPORT]),
        timeout=130,
    )


def probe_cases(vm, dns, source_port):
    return [{
        "source": vm["address"], "destination": dns, "protocol": protocol,
        "dns": True, "expected": "allow", "source_port": source_port + offset,
        "destination_port": 53,
    } for offset, protocol in enumerate(("tcp", "udp"))]


def run(args):
    state_path = args.state / "network-lab/state.json"
    state = json.loads(state_path.read_text())
    config = load_deployment_config(Path(state["config"]))
    with tempfile.TemporaryDirectory(prefix="swiftfabric-wan-") as temporary:
        api = ControllerAPI(config, Path(temporary))
        try:
            router = api.json("GET", "/north-south-routers/" + state["router"])
            original = state.get("router_identity")
            if not original or any(router.get(key) != original.get(key) for key in ("id", "name", "vmid")):
                raise RuntimeError("NSR no longer matches saved lab identity; diagnostics refused")
            if router.get("deployment_mode") != "standalone":
                raise RuntimeError("This diagnostic currently supports standalone NSRs only")
            print(json.dumps({"kind": "router", "router": {
                key: router.get(key) for key in ROUTER_FIELDS
            }}), flush=True)
            if args.router_upgrade_logs:
                print(execute_router(api, router, router_upgrade_program(), args.trust_first_use))
                return
            ids = {segment["id"] for segment in state["segments"]}
            segments = [segment for segment in api.json("GET", "/segments") if segment["id"] in ids]
            for segment in segments:
                print(json.dumps({"kind": "routing", "segment": segment["id"], "routing": api.json(
                    "GET", f"/segments/{segment['id']}/routing",
                )}), flush=True)
            router["compute_vteps"] = [
                str(ipaddress.IPv4Address(host["vtep_ip"]))
                for host in api.json("GET", "/hosts") if host["node"] in state["nodes"]
            ]
            attached = [
                segment for segment in segments
                if (segment.get("north_south_router") or {}).get("id") == router["id"]
            ]
            program = router_program(router, attached, args.capture_seconds, args.dns)
            if args.compute_node:
                if args.compute_node not in state["nodes"]:
                    raise ValueError("--compute-node must belong to saved lab")
                prefix = []
                capture = (prefix, args.capture_seconds, f"host {args.dns} and port 53") if args.capture_seconds else None
                program = command_program({
                    "geneve_tc": ["tc", "-s", "filter", "show", "dev", "sf-gnv", "ingress"],
                    "firewall": ["nft", "list", "ruleset"],
                    "geneve_stats": ["ip", "-s", "-j", "link", "show", "dev", "sf-gnv"],
                }, capture)
                ssh = SSHCommandRunner(
                    config["proxmox_ssh_key"], config["proxmox_ssh_user"], "WAN compute diagnostics",
                )
                ssh.ensure_host_key(args.compute_node)

                def inspect():
                    return ssh.run(args.compute_node, shlex.join(["python3", "-c", program]), timeout=130)
            else:
                def inspect():
                    return execute_router(api, router, program, args.trust_first_use)

            if args.probe_vmid is None:
                print(inspect())
            else:
                vm = next((vm for vm in state["vms"] if vm["vmid"] == args.probe_vmid), None)
                if vm is None or vm["tenant_id"] != router["tenant_id"]:
                    raise ValueError("--probe-vmid must be an owned VM in active WAN tenant")
                if args.capture_seconds < 25:
                    raise ValueError("--probe-vmid requires --capture-seconds of at least 25")
                lab = LiveLab(args.state / "network-lab")
                try:
                    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                        future = pool.submit(inspect)
                        time.sleep(10)
                        if future.done():
                            print(future.result())
                            raise RuntimeError("Capture ended before guest probe")
                        command = "python3 /opt/swiftfabric-network-lab.py probe " + shlex.quote(
                            encode(json.dumps(probe_cases(vm, args.dns, args.source_port)).encode()),
                        )
                        print(json.dumps({"kind": "guest_probe", "results": json.loads(lab.serial(vm, command))}))
                        print(future.result())
                finally:
                    lab.api.close()
        finally:
            api.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", required=True, type=Path, help="Retained integration run directory")
    parser.add_argument("--trust-first-use", action="store_true", help="Explicit TOFU authorization; cannot detect first-connection interception")
    parser.add_argument("--compute-node", help="Inspect owned compute host instead of NSR")
    parser.add_argument("--router-upgrade-logs", action="store_true", help="Read bounded router service journals and non-secret HA configuration only")
    parser.add_argument("--capture-seconds", type=int, default=0, help="Bounded packet capture (0 or 5-60)")
    parser.add_argument("--probe-vmid", type=int, help="Send TCP/UDP DNS from owned active-tenant guest")
    parser.add_argument("--source-port", type=int, default=62000, help="Two unused guest source ports")
    parser.add_argument("--dns", default="1.1.1.1", type=lambda value: str(ipaddress.IPv4Address(value)))
    args = parser.parse_args(argv)
    if args.capture_seconds != 0 and not 5 <= args.capture_seconds <= 60:
        parser.error("--capture-seconds must be 0 or 5-60")
    if not 1024 <= args.source_port <= 65534:
        parser.error("--source-port must be 1024-65534")
    if args.router_upgrade_logs and (
        args.compute_node or args.probe_vmid or args.capture_seconds
    ):
        parser.error("--router-upgrade-logs cannot be combined with packet diagnostics")
    context = automated_ssh_tofu() if args.trust_first_use else nullcontext()
    try:
        with context:
            run(args)
    except (OSError, RuntimeError, ValueError) as error:
        print(f"WAN diagnostics failed: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
