"""Clean a pre-upgrade baseline using its installer and current lab teardown."""

import importlib
import sys
from pathlib import Path


def restore_cleanup_identity(run):
    if run.state.get("workload_identity") is not None:
        return
    from disaster_recovery import read_config_object

    lab = read_config_object(run.directory / "network-lab/state.json")
    evidence = read_config_object(run.directory / "network-lab/evidence.json")
    hosts = evidence.get("hosts")
    if (evidence.get("run_id") != lab.get("run_id")
            or not isinstance(evidence.get("router"), dict)
            or any(evidence["router"].get(key) != value
                   for key, value in run.state["router"].items())
            or not isinstance(hosts, list) or not hosts
            or any(not isinstance(host, dict)
                   or not isinstance(host.get("node"), str)
                   or not isinstance(host.get("host_id"), str) for host in hosts)
            or len({host["host_id"] for host in hosts}) != len(hosts)
            or len({host["node"] for host in hosts}) != len(hosts)
            or {host["node"] for host in hosts} != set(lab["nodes"])):
        raise RuntimeError("Saved baseline host ownership is invalid; refusing cleanup.")
    # Failed traffic is not acceptance, but its saved inventory still proves identity.
    run.state["workload_identity"] = {
        "run_id": evidence["run_id"],
        "vms": sorted(({key: value for key, value in vm.items() if key != "witness"}
                       for vm in evidence["vms"]), key=lambda vm: vm["vmid"]),
        "segments": sorted(evidence["segments"], key=lambda segment: segment["id"]),
        "tenants": sorted(evidence["tenant_metadata"], key=lambda tenant: tenant["id"]),
        "router": {key: evidence["router"][key] for key in ("id", "name", "vmid")},
        "hosts": sorted(({key: host[key] for key in ("node", "host_id")} for host in hosts),
                        key=lambda host: host["node"]),
    }
    run.save()


def main():
    baseline = Path(sys.argv[1]).resolve()
    directory = Path(sys.argv[2]).resolve()
    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(baseline / "python_installer/tests_integration"))
    from disaster_recovery import cleanup_saved_run

    # Acceptance stays historical; cleanup must not replay fixed teardown bugs.
    sys.path.insert(0, str(root / "network-lab"))
    importlib.import_module("tenancy")
    cleanup_saved_run(directory, preflight=restore_cleanup_identity)


if __name__ == "__main__":
    main()
