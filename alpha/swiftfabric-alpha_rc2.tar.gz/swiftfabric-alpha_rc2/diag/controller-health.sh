#!/usr/bin/env bash

set -u

usage() {
    cat <<'EOF'
Usage: sudo ./diag/controller-health.sh [--controller-ip IPv4] [--api-vip IPv4]

Collect a read-only health snapshot from one SwiftFabric controller. Run once
on each controller. IP arguments enable local certificate SAN verification.
Output goes to the terminal; no files or configuration are changed.
EOF
}

controller_ip=
api_vip=
while (($#)); do
    case "$1" in
        --controller-ip|--api-vip)
            if (($# < 2)) || [[ -z "$2" || "$2" == --* ]]; then
                printf 'Missing value for %s\n' "$1" >&2
                exit 2
            fi
            if [[ "$1" == --controller-ip ]]; then
                controller_ip=$2
            else
                api_vip=$2
            fi
            shift 2
            ;;
        --help|-h)
            usage
            exit 0
            ;;
        *)
            printf 'Unknown argument: %s\n' "$1" >&2
            usage >&2
            exit 2
            ;;
    esac
done

if [[ $EUID -ne 0 ]]; then
    printf 'Run as root, for example: sudo %s\n' "$0" >&2
    exit 2
fi

failures=0

run_check() {
    local label=$1
    shift
    printf '\n== %s ==\n' "$label"
    "$@"
    local result=$?
    printf '[command exit %d] %s\n' "$result" "$label"
    if ((result != 0)); then
        failures=$((failures + 1))
    fi
}

printf '%s\n' 'SwiftFabric controller health snapshot (read-only)'
run_check 'UTC time' date -u
run_check 'Host identity' hostnamectl --static
run_check 'Uptime' uptime
run_check 'Filesystem capacity' df -h
run_check 'Filesystem inodes' df -i
run_check 'Memory' free -h
run_check 'Failed systemd units' systemctl --failed --no-pager
run_check 'SwiftFabric package version' dpkg-query -W \
    '-f=${binary:Package} ${Version} ${db:Status-Status}\n' swiftfabric-api-service

run_check 'Controller service activity' systemctl is-active \
    corosync pacemaker nginx.service swiftfabric-api-service \
    swiftfabric-tls-renew.timer
run_check 'Corosync quorum summary' corosync-quorumtool -s
run_check 'Corosync membership' corosync-quorumtool -l
run_check 'Corosync link status' corosync-cfgtool -s
run_check 'Pacemaker node name' crm_node -n
run_check 'Pacemaker resources and nodes' pcs status --full
run_check 'Recent cluster and API logs' journalctl \
    -u corosync -u pacemaker -u swiftfabric-api-service \
    --since '-30 minutes' --no-pager
run_check 'Listening TCP sockets' ss -lntp

ca_cert=/etc/swiftfabric/swiftfabric-ca.crt
server_cert=/etc/swiftfabric/tls/server.crt
run_check 'Controller certificate metadata and SANs' openssl x509 \
    -in "$server_cert" -noout -subject -issuer -serial -dates -ext subjectAltName
run_check 'Deployment CA SHA-256 fingerprint' openssl x509 \
    -in "$ca_cert" -noout -fingerprint -sha256

if [[ -n "$controller_ip" && -n "$api_vip" ]]; then
    run_check 'Controller certificate IP SAN' openssl verify \
        -purpose sslserver -CAfile "$ca_cert" -verify_ip "$controller_ip" "$server_cert"
    run_check 'API VIP certificate IP SAN' openssl verify \
        -purpose sslserver -CAfile "$ca_cert" -verify_ip "$api_vip" "$server_cert"
else
    printf '\n[skipped] Certificate IP verification; pass both --controller-ip and --api-vip.\n'
fi

if ((failures)); then
    printf '\nSnapshot completed with %d command failure(s); inspect output above.\n' "$failures" >&2
    exit 1
fi

printf '\nSnapshot completed; review quorum, all three members, resource state, and certificate SANs.\n'
