"""Inspect an owned retained standalone NSR's repository access over pinned SSH."""

import argparse
import ipaddress
from pathlib import Path
import re
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_installer/tests_integration"))
import disaster_recovery as recovery
from wan import trusted_key


PROGRAM = r"""
set -eu
date -u
ip -br address
ip -4 route show table all
ip -6 route show table all
nft list ruleset
printf '\n--- Ubuntu DNS ---\n'
getent ahostsv4 archive.ubuntu.com
printf '\n--- Installed dependencies ---\n'
if dpkg-query -W -f='${Package} ${Version} ${db:Status-Status}\n' conntrack; then
    :
else
    result=$?
    printf 'Dependency query exit=%s\n' "$result"
    test "$result" -eq 1
fi
printf '\n--- IPv4 HTTP probes ---\n'
addresses=$(getent ahostsv4 archive.ubuntu.com | awk '!seen[$1]++ {print $1}' | head -n 2)
for address in $addresses; do
    ip -4 route get "$address"
    set +e
    timeout 8 bash -c 'exec 3<>/dev/tcp/"$1"/80; printf "HEAD /ubuntu/ HTTP/1.0\r\nHost: archive.ubuntu.com\r\n\r\n" >&3; head -n 1 <&3' bash "$address"
    result=$?
    set -e
    printf 'HTTP probe %s exit=%s\n' "$address" "$result"
done
"""


def owned_router_path(run, router):
    saved = run.state["router"]
    if (any(router.get(key) != saved[key] for key in ("id", "name", "vmid"))
            or router.get("deployment_mode") != "standalone"
            or router.get("standby") is not None):
        raise RuntimeError("Standalone router identity changed; diagnostics refused.")
    node = router["node"]
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]*", node):
        raise ValueError("Invalid router node.")
    path = f"/nodes/{node}/qemu/{saved['vmid']}"
    config = run.proxmox.get(path + "/config")["data"]
    tags = config.get("tags", "").split(";")
    if (config.get("name") != saved["name"]
            or config.get("description") != f"SwiftFabric N/S router {saved['id']} member a"
            or len([tag for tag in tags if re.fullmatch(
                r"swiftfabric_owner_[0-9a-f]{64}", tag)]) != 1):
        raise RuntimeError("Router VM ownership changed; diagnostics refused.")
    return node


def inspect(directory):
    directory = directory.expanduser().resolve()
    state = recovery.read_config_object(directory / "recovery.json")
    config = Path(state["config"])
    if (directory == ROOT or ROOT in directory.parents
            or not re.fullmatch(r"sf-dr-[0-9a-f]{20}", state["prefix"])
            or state["router"]["id"] != state["prefix"] + "-nsr"
            or recovery.fingerprint(config) != state["config_sha256"]):
        raise RuntimeError("Saved deployment ownership/config changed; diagnostics refused.")
    run = recovery.RecoveryRun(argparse.Namespace(state=directory, config=config))
    run.state = state
    try:
        run.connect_proxmox()
        if recovery.controller_inventory(run.proxmox, state["prefix"]) != state["controllers"]:
            raise RuntimeError("Controller ownership changed; diagnostics refused.")
        run.api = recovery.ControllerAPI(run.config, directory)
        router = run.api.json("GET", f"/north-south-routers/{state['router']['id']}")
        owned_router_path(run, router)
        address = str(ipaddress.IPv4Interface(router["management_address_cidr"]).ip)
        candidate = run.api.json(
            "GET", f"/north-south-routers/{router['id']}/ssh-host-key?member=a",
        )
        public = trusted_key(candidate, address, False)
        with tempfile.TemporaryDirectory(prefix="nsr-repository-", dir=directory) as temporary:
            key = Path(temporary) / "key"
            pins = Path(temporary) / "known_hosts"
            recovery.private_write(key, run.api.request(
                "GET", f"/north-south-routers/{router['id']}/ssh-private-key",
            ).content)
            recovery.private_write(pins, f"{address} {public}\n".encode())
            process = subprocess.run([
                "ssh", "-F", "/dev/null", "-i", str(key), "-o", "IdentitiesOnly=yes",
                "-o", "IdentityAgent=none", "-o", "BatchMode=yes",
                "-o", "StrictHostKeyChecking=yes", "-o", "GlobalKnownHostsFile=/dev/null",
                "-o", f"UserKnownHostsFile={pins}", "-o", "ConnectTimeout=5",
                f"ubuntu@{address}", "sudo -n /bin/sh -s",
            ], input=PROGRAM, capture_output=True, text=True, timeout=90)
        result = {"exitcode": process.returncode, "out-data": process.stdout,
                  "err-data": process.stderr}
        recovery.private_write(directory / "nsr-repository-access.json", result)
        if result.get("exitcode") != 0:
            raise RuntimeError("NSR diagnostic failed; inspect private SSH output.")
        print(result.get("out-data", ""))
        if result.get("err-data"):
            print(result["err-data"], file=sys.stderr)
        print(f"Private evidence saved: {directory / 'nsr-repository-access.json'}")
    finally:
        run.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", required=True, type=Path)
    args = parser.parse_args()
    with recovery.automated_ssh_tofu():
        inspect(args.state)


if __name__ == "__main__":
    main()
