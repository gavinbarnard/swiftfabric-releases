"""Read-only inventory for an ownership-checked retained release deployment."""

import argparse
import ipaddress
import json
from pathlib import Path
import re
import shlex
import sys


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_installer/tests_integration"))
import disaster_recovery as recovery


def verify_cleanup(run):
    state = run.state
    identity = state["workload_identity"]
    if (state.get("cleanup_status") != "complete"
            or state.get("cleanup_verified_hosts") != identity["hosts"]):
        raise RuntimeError("Saved ordered cleanup is incomplete; verification refused.")
    expected = [*state["controllers"], *identity["vms"], state["router"]]
    ids = {vm["vmid"] for vm in expected}
    names = {vm["name"] for vm in expected}
    resources = run.proxmox.get("/cluster/resources", params={"type": "vm"})["data"]
    if not isinstance(resources, list) or any(not isinstance(vm, dict) for vm in resources):
        raise RuntimeError("Invalid Proxmox inventory; verification refused.")
    if any(vm.get("vmid") in ids or vm.get("name") in names
           or str(vm.get("name", "")).startswith(state["prefix"] + "-") for vm in resources):
        raise RuntimeError("Saved release VM remains or its identity was reused; cleanup not verified.")
    probe = (ROOT / "python_installer/tests_integration/host_cleanup_probe.py").read_text()
    network = str(ipaddress.IPv4Network(run.config["vtep_ip_range_cidr"]))
    tables = sorted({str(tenant["routing_table"]) for tenant in identity["tenants"]})
    zones = sorted({tenant["conntrack_zone"] for tenant in identity["tenants"]})
    command = shlex.join(["sudo", "-n", "python3", "-c", probe, network,
                          json.dumps(tables), json.dumps(zones)])
    ssh = recovery.SSHCommandRunner(
        run.config["proxmox_ssh_key"], run.config["proxmox_ssh_user"], "release cleanup verification")
    for host in identity["hosts"]:
        node = host["node"]
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]*", node):
            raise RuntimeError("Invalid saved host node; verification refused.")
        if ssh.run(node, command, timeout=120).strip() != "SWIFTFABRIC_HOST_CLEAN":
            raise RuntimeError(f"Host {node} still has release residuals; cleanup not verified.")
    return {"prefix": state["prefix"], "cleanup_status": "verified",
            "owned_vms_remaining": [], "verified_hosts": identity["hosts"]}


def inspect(directory, *, completed=False):
    directory = directory.expanduser().resolve()
    if directory == ROOT or ROOT in directory.parents:
        raise ValueError("Release evidence must be outside the checkout.")
    state = recovery.read_config_object(directory / "recovery.json")
    config = Path(state["config"])
    if (not config.is_absolute()
            or not re.fullmatch(r"sf-dr-[0-9a-f]{20}", state["prefix"])
            or recovery.fingerprint(config) != state["config_sha256"]):
        raise RuntimeError("Saved deployment ownership/configuration changed; inspection refused.")
    run = recovery.RecoveryRun(argparse.Namespace(state=directory, config=config))
    run.state = state
    try:
        run.connect_proxmox()
        if completed:
            report = verify_cleanup(run)
            recovery.private_write(directory / "release-cleanup-verification.json", report)
            return report
        controllers = recovery.controller_inventory(run.proxmox, state["prefix"])
        expected = state.get("replacement_controllers") or state.get("controllers")
        if not expected or controllers != expected:
            raise RuntimeError("Controller ownership changed; inspection refused.")
        run.api = recovery.ControllerAPI(run.config, directory)
        if (state.get("original_ca_der_sha256")
                and recovery.ca_fingerprint(directory / "controller-ca.crt")
                != state["original_ca_der_sha256"]):
            raise RuntimeError("Controller CA changed; inspection refused.")
        report = {
            "prefix": state["prefix"],
            "stage": state.get("current_stage"),
            "cleanup_status": state.get("cleanup_status"),
            "controllers": [
                {key: vm[key] for key in ("vmid", "node", "name")} for vm in controllers
            ],
        }
        for key, endpoint, fields in (
            ("hosts", "/hosts", ("host_id", "node")),
            ("routers", "/north-south-routers", ("id", "name", "vmid", "_version")),
            ("clusters", "/proxmox/clusters", ("name", "_version")),
        ):
            records = run.api.json("GET", endpoint)
            if not isinstance(records, list) or any(not isinstance(item, dict) for item in records):
                raise RuntimeError(f"Invalid {key} inventory; inspection refused.")
            report[key] = [{field: item.get(field) for field in fields} for item in records]
        recovery.private_write(directory / "release-cleanup-inventory.json", report)
        return report
    finally:
        run.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", type=Path, required=True)
    parser.add_argument("--verify-cleanup", action="store_true",
                        help="verify completed cleanup via Proxmox and compute-host residual probes")
    args = parser.parse_args()
    with recovery.automated_ssh_tofu():
        print(json.dumps(inspect(args.state, completed=args.verify_cleanup), indent=2))


if __name__ == "__main__":
    main()
