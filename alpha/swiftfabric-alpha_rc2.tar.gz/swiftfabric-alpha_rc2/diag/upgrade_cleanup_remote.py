"""SSH-only ownership checks and host teardown for retained upgrade tests."""

import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import shutil
import ssl
import subprocess
import sys


def command(*args, **kwargs):
    return subprocess.run(
        args, check=True, capture_output=True, text=True, timeout=120, **kwargs,
    ).stdout


def ca_matches(path, expected):
    return hashlib.sha256(ssl.PEM_cert_to_DER_cert(path.read_text())).hexdigest() == expected


def controller_plan(spec):
    config = json.loads(Path("/etc/swiftfabric/api-service.json").read_text())
    for key in ("node_ips", "node_names", "api_vip"):
        if config.get(key) != spec[key]:
            raise RuntimeError(f"Controller topology {key} changed; refusing cleanup.")
    if not ca_matches(Path("/etc/swiftfabric/swiftfabric-ca.crt"), spec["ca"]):
        raise RuntimeError("Controller CA changed; refusing cleanup.")
    segments = json.loads(Path("/var/lib/swiftfabric/segments.json").read_text())
    env = dict(os.environ, REDISCLI_AUTH=segments["4999"]["password"])

    def records(key):
        raw = command("valkey-cli", "--raw", "-p", "4999", "HVALS", key, env=env)
        values = [json.loads(line) for line in raw.splitlines() if line.strip()]
        if any(not isinstance(value, dict) for value in values):
            raise RuntimeError("Invalid stored cleanup inventory.")
        return values

    hosts = records("swiftfabric:hosts")
    expected = {(host["host_id"], host["node"]) for host in spec["hosts"]}
    actual = {(host.get("host_id"), host.get("node")) for host in hosts}
    if len(actual) != len(hosts) or not actual.issubset(expected):
        raise RuntimeError("Unexpected enrolled hosts; refusing cleanup.")
    routers = records("swiftfabric:north_south_routers")
    if not routers:
        return {"router": None}
    if len(routers) != 1:
        raise RuntimeError("Unexpected router inventory; refusing cleanup.")
    router = routers[0]
    if (any(router.get(key) != value for key, value in spec["router"].items())
            or router.get("deployment_mode", "standalone") != "standalone"
            or router.get("standby") is not None or router.get("ha_state_sync_enabled")
            or not re.fullmatch(r"[0-9a-f]{64}", router.get("vm_owner_token", ""))):
        raise RuntimeError("Router ownership changed; refusing cleanup.")
    return {"router": {
        "vmid": router["vmid"], "name": spec["router"]["name"],
        "description": f"SwiftFabric N/S router {router['id']} member a",
        "owner_tag": "swiftfabric_owner_" + router["vm_owner_token"],
    }}


def host_plan(spec):
    path = Path("/etc/swiftfabric/host-agent.json")
    anchors = sorted(Path("/usr/local/share/ca-certificates").glob("swiftfabric-deployment-ca*.crt"))
    if any(not ca_matches(anchor, spec["ca"]) for anchor in anchors):
        raise RuntimeError("Host has another deployment CA; refusing cleanup.")
    ca = Path("/etc/swiftfabric/swiftfabric-ca.crt")
    if ca.exists() and not ca_matches(ca, spec["ca"]):
        raise RuntimeError("Host CA changed; refusing cleanup.")
    if Path("/etc/swiftfabric/router.json").exists():
        raise RuntimeError("Compute host has router state; refusing cleanup.")
    if not path.exists():
        return None
    raw = path.read_bytes()
    config = json.loads(raw)
    if (config.get("host_id") != spec["host_id"] or config.get("router_id") is not None
            or config.get("api_url", "").rstrip("/") != f"https://{spec['api_vip']}"
            or not anchors):
        raise RuntimeError("Host ownership changed; refusing cleanup.")
    address = config.get("vtep_ip")
    interface = config.get("vtep_interface")
    prefix = config.get("vtep_prefix_len", 32)
    vlan = config.get("vtep_vlan")
    if (not isinstance(address, str) or not isinstance(interface, str)
            or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,15}", interface)
            or type(prefix) is not int or not 1 <= prefix <= 32
            or (vlan is not None and (type(vlan) is not int or not 1 <= vlan <= 4094))):
        raise RuntimeError("Host lacks saved VTEP settings; refusing cleanup.")
    ipaddress.IPv4Address(address)
    return {
        "sha256": hashlib.sha256(raw).hexdigest(),
        "vtep_ip": address, "vtep_interface": interface,
        "vtep_prefix_len": prefix, "vtep_vlan": vlan,
    }


def remove_host(spec):
    expected = spec["plan"]
    current = host_plan(spec)
    if current is not None and current != expected:
        raise RuntimeError("Host configuration changed after preflight; refusing cleanup.")
    if expected is None:
        return
    helper_directory = Path("/var/lib/swiftfabric/helpers")
    helper_files = []
    if helper_directory.is_symlink():
        raise RuntimeError("Host helper cache is a symlink; refusing cleanup.")
    if helper_directory.exists():
        if not helper_directory.is_dir():
            raise RuntimeError("Host helper cache is not a directory; refusing cleanup.")
        helper_files = list(helper_directory.iterdir())
        if any(path.is_symlink() or not path.is_file()
               or not re.fullmatch(r"swiftfabric-host-helper-[0-9a-f]{64}", path.name)
               for path in helper_files):
            raise RuntimeError("Unknown host helper cache entry; refusing cleanup.")
    for unit in ("swiftfabric-host-agent.service", "swiftfabric-neighbors.service"):
        state = command("systemctl", "show", unit, "--property=LoadState", "--value").strip()
        if state != "not-found":
            command("systemctl", "disable", "--now", unit)
    executable = Path("/usr/bin/swiftfabric-host-agent")
    if executable.exists():
        teardown = [str(executable), "teardown"]
    elif Path("/usr/lib/swiftfabric-host-agent").exists():
        teardown = ["/usr/bin/python3", "-m", "swiftfabric_host", "teardown"]
    else:
        teardown = None
    if teardown is not None:
        args = [
            "--vtep-ip", expected["vtep_ip"], "--vtep-interface", expected["vtep_interface"],
            "--vtep-prefix-len", str(expected["vtep_prefix_len"]),
        ]
        if expected["vtep_vlan"] is not None:
            args.extend(["--vtep-vlan", str(expected["vtep_vlan"])])
        command(*teardown, *args, env=dict(os.environ, PYTHONPATH="/usr/lib/swiftfabric-host-agent"))
    packages = command("dpkg-query", "-W", "-f=${binary:Package} ${db:Status-Status}\\n")
    if any(line.startswith("swiftfabric-host-agent ") and not line.endswith(" not-installed")
           for line in packages.splitlines()):
        command("dpkg", "--purge", "swiftfabric-host-agent")
    for name in (
        "/etc/swiftfabric/host-agent.json", "/etc/swiftfabric/host-agent.json.example",
        "/etc/swiftfabric/neighbor-peers.json", "/etc/swiftfabric/neighbor-identity.key",
        "/etc/swiftfabric/neighbor-identity.crt", "/etc/swiftfabric/.neighbor-provision.lock",
        "/usr/bin/swiftfabric-host-agent", "/usr/bin/sf-cli",
        "/etc/modules-load.d/swiftfabric-host-agent.conf",
    ):
        Path(name).unlink(missing_ok=True)
    for directory in ("/usr/lib/systemd/system", "/lib/systemd/system", "/etc/systemd/system"):
        for unit in ("swiftfabric-host-agent.service", "swiftfabric-neighbors.service"):
            (Path(directory) / unit).unlink(missing_ok=True)
    for name in ("/var/lib/swiftfabric/host-bindings", "/usr/lib/swiftfabric-host-agent"):
        path = Path(name)
        if path.exists():
            shutil.rmtree(path)
    for path in helper_files:
        path.unlink()
    if helper_directory.exists():
        helper_directory.rmdir()
    for anchor in Path("/usr/local/share/ca-certificates").glob("swiftfabric-deployment-ca*.crt"):
        if not ca_matches(anchor, spec["ca"]):
            raise RuntimeError("Host CA changed before removal; refusing cleanup.")
        anchor.unlink()
    command("update-ca-certificates")
    ca = Path("/etc/swiftfabric/swiftfabric-ca.crt")
    if ca.exists():
        if not ca_matches(ca, spec["ca"]):
            raise RuntimeError("Host CA changed before removal; refusing cleanup.")
        ca.unlink()
    for name in ("/etc/swiftfabric", "/var/lib/swiftfabric"):
        path = Path(name)
        if path.exists() and not any(path.iterdir()):
            path.rmdir()
    command("systemctl", "daemon-reload")


def dispatch(spec):
    if spec["operation"] == "controller-plan":
        return controller_plan(spec)
    if spec["operation"] == "host-plan":
        return host_plan(spec)
    if spec["operation"] == "remove-host":
        remove_host(spec)
        return "removed"
    raise ValueError("Invalid cleanup operation.")


if __name__ == "__main__":
    try:
        print(json.dumps(dispatch(json.load(sys.stdin))))
    except RuntimeError as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
    except subprocess.CalledProcessError as exc:
        print(
            f"Upgrade cleanup command {Path(exc.cmd[0]).name} failed (exit {exc.returncode}); "
            "remote output withheld.",
            file=sys.stderr,
        )
        sys.exit(1)
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as exc:
        # Remote command output and configuration may contain credentials.
        print(f"Upgrade cleanup {type(exc).__name__}; remote details withheld.", file=sys.stderr)
        sys.exit(1)
