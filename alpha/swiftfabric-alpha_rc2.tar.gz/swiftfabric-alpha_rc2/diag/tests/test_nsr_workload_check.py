import contextlib
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest import mock

import nsr_workload_check as workload


class WorkloadCheckTests(unittest.TestCase):
    def test_traffic_mode_runs_only_owned_held_traffic(self):
        import nsr_ha as ha

        run = SimpleNamespace(held_traffic=mock.Mock(return_value={"passed": True}))
        with mock.patch.object(ha, "automated_ssh_tofu", return_value=contextlib.nullcontext()), \
                mock.patch.object(ha, "with_saved_run") as saved, mock.patch("builtins.print"):
            saved.side_effect = lambda path, action, **kwargs: action(run)
            self.assertEqual(workload.main([
                "--state", "/owned/run", "--traffic-seconds", "30",
            ]), 0)
        run.held_traffic.assert_called_once_with("diagnostic-wan", 30)
        self.assertEqual(saved.call_args.args[0], Path("/owned/run"))

    def test_traffic_mode_does_not_hide_failed_verdict(self):
        import nsr_ha as ha

        run = SimpleNamespace(held_traffic=mock.Mock(return_value={"passed": False}))
        with mock.patch.object(ha, "automated_ssh_tofu", return_value=contextlib.nullcontext()), \
                mock.patch.object(ha, "with_saved_run") as saved:
            saved.side_effect = lambda path, action, **kwargs: action(run)
            with self.assertRaisesRegex(RuntimeError, "validation failed"):
                workload.main(["--state", "/owned/run", "--traffic-seconds", "30"])

    def test_traffic_mode_rejects_unbounded_or_ambiguous_requests(self):
        for options in (["--traffic-seconds", "9"], ["--traffic-seconds", "121"],
                        ["--traffic-seconds", "30", "--probes"]):
            with self.subTest(options=options), self.assertRaises(SystemExit):
                workload.main(["--state", "/owned/run", *options])


if __name__ == "__main__":
    unittest.main()
