import argparse
import copy
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python_installer" / "tests_integration"))
sys.path.insert(0, str(ROOT / "diag"))
import nsr_ha as ha
import nsr_migration as migration


VM = {"vmid": 109, "node": "hunsn3", "name": "owned-workload",
      "address": "10.253.244.10", "segment_id": 49100}
BASELINE = {"boot_id": "same-boot", "source": VM["address"], "device": "eth0",
            "mac": "bc:24:11:00:00:11", "gateway": "10.253.244.1",
            "neighbors": [{"lladdr": "02:53:46:00:bf:cc", "state": ["REACHABLE"]}]}


class MigrationTests(unittest.TestCase):
    def run_fixture(self):
        lab = SimpleNamespace(
            state={"vms": [copy.deepcopy(VM)]},
            vm_config=mock.Mock(), save=mock.Mock(), setup_serial=mock.Mock(),
        )
        run = SimpleNamespace(lab=lab, proxmox=mock.Mock(), api=mock.Mock(),
                              config={"proxmox_cluster_name": "owned"})
        return run

    def test_workload_identity_reads_mac_from_link_not_ipv4_address_receipt(self):
        run = self.run_fixture()
        run.state = {"held_flow_cases": [{"destination": "203.0.113.2"}]}
        run.lab.setup_serial.return_value = json.dumps(BASELINE)
        self.assertEqual(migration.workload_view(run), BASELINE)
        command = run.lab.setup_serial.call_args.args[1]
        self.assertIn('"link","show","dev"', command)
        self.assertIn('link["address"]', command)
        self.assertNotIn('addresses["address"]', command)

    def test_preflight_requires_three_online_enrolled_hosts_with_bridge(self):
        run = self.run_fixture()
        hosts = [{"node": node, "cluster": "owned", "status": "enrolled",
                  "host_id": node, "vtep_ip": f"172.16.25.{index}"}
                 for index, node in enumerate(migration.NODES, 1)]
        run.api.json.return_value = hosts

        def get(path):
            if path == "/nodes":
                return {"data": [{"node": node, "status": "online"} for node in migration.NODES]}
            return {"data": [{"iface": "sf-br49100", "active": 1}]}

        run.proxmox.get.side_effect = get
        self.assertEqual(set(migration.preflight(run)), set(migration.NODES))
        hosts[1]["status"] = "unenrolled"
        with self.assertRaisesRegex(RuntimeError, "uniquely enrolled"):
            migration.preflight(run)
        run.proxmox.post.assert_not_called()

    def test_migration_is_live_scoped_journaled_and_updates_location(self):
        run = self.run_fixture()
        vm = run.lab.state["vms"][0]
        run.proxmox.get.side_effect = lambda path, **kwargs: {
            "data": {"status": "running"} if path.endswith("/status/current") else {"allowed_nodes": ["hunsn4"]}
        }
        run.proxmox.post.return_value = {"data": "UPID:hunsn3:owned"}
        run.proxmox.wait_for_task.side_effect = lambda *args, **kwargs: vm.update(node="hunsn4")
        report = {}
        migration.migrate(run, "hunsn4", report, mock.Mock())
        run.proxmox.post.assert_called_once_with(
            "/nodes/hunsn3/qemu/109/migrate", {"target": "hunsn4", "online": 1, "with-local-disks": 1})
        self.assertTrue(report["migration"]["passed"])
        self.assertEqual(run.lab.state["migration_events"][0]["task"], "UPID:hunsn3:owned")
        self.assertEqual(vm["node"], "hunsn4")
        self.assertEqual(run.lab.state["migration_nodes"], list(migration.NODES))

    def test_wrong_target_and_failed_task_do_not_claim_success(self):
        run = self.run_fixture()
        with self.assertRaisesRegex(RuntimeError, "outside"):
            migration.migrate(run, "hunsn5", {}, mock.Mock())
        run.proxmox.post.assert_not_called()
        run.proxmox.get.side_effect = lambda path, **kwargs: {
            "data": {"status": "running"} if path.endswith("/status/current") else {}}
        run.proxmox.post.return_value = {"data": "UPID:hunsn3:owned"}
        run.proxmox.wait_for_task.side_effect = RuntimeError("migration failed")
        report = {}
        with self.assertRaisesRegex(RuntimeError, "migration failed"):
            migration.migrate(run, "hunsn4", report, mock.Mock())
        self.assertFalse(report["migration"]["passed"])
        self.assertEqual(report["migration"]["task"], "UPID:hunsn3:owned")
        self.assertGreaterEqual(run.lab.save.call_count, 3)

    def test_return_requires_explicit_mode_and_only_owned_path_to_hunsn3(self):
        run = self.run_fixture()
        vm = run.lab.state["vms"][0]
        vm["node"] = "hunsn4"
        with self.assertRaisesRegex(RuntimeError, "outside"):
            migration.migrate(run, "hunsn3", {}, mock.Mock())
        with self.assertRaisesRegex(RuntimeError, "outside"):
            migration.migrate(run, "hunsn5", {}, mock.Mock(), returning=True)
        run.proxmox.post.assert_not_called()
        run.proxmox.get.side_effect = lambda path, **kwargs: {
            "data": {"status": "running"} if path.endswith("/status/current") else {}}
        run.proxmox.post.return_value = {"data": "UPID:hunsn4:owned"}
        run.proxmox.wait_for_task.side_effect = lambda *args, **kwargs: vm.update(node="hunsn3")
        report = {}
        migration.migrate(run, "hunsn3", report, mock.Mock(), returning=True)
        run.proxmox.post.assert_called_once_with(
            "/nodes/hunsn4/qemu/109/migrate", {"target": "hunsn3", "online": 1, "with-local-disks": 1})
        self.assertTrue(report["migration"]["passed"])

    def test_learning_requires_same_guest_identity_and_new_controller_vtep(self):
        run = self.run_fixture()
        record = {"mac": BASELINE["mac"], "ip": VM["address"],
                  "host_id": "hunsn4", "vtep_ip": "172.16.25.2"}
        run.api.json.return_value = {"entries": [record]}
        expected = {key: record[key] for key in ("host_id", "vtep_ip")}
        with mock.patch.object(migration, "workload_view", return_value=BASELINE):
            report = {}
            migration.require_learning(run, expected, BASELINE, report, mock.Mock())
        self.assertTrue(report["learning_passed"])
        for changed in ({"boot_id": "rebooted"}, {"mac": "bc:24:11:00:00:22"}, {"neighbors": []}):
            with self.subTest(changed=changed), \
                    mock.patch.object(migration, "workload_view", return_value={**BASELINE, **changed}):
                with self.assertRaises(RuntimeError):
                    migration.require_learning(run, expected, BASELINE, {}, mock.Mock())

    def test_old_mac_location_cannot_pass_learning_gate(self):
        run = self.run_fixture()
        run.api.json.return_value = {"entries": [{"mac": BASELINE["mac"], "ip": VM["address"],
                                                  "host_id": "hunsn3", "vtep_ip": "172.16.25.1"}]}
        clock = iter((0, 0, 61))
        with mock.patch.object(migration.time, "monotonic", side_effect=lambda: next(clock)), \
                mock.patch.object(migration.time, "sleep"):
            with self.assertRaisesRegex(TimeoutError, "binding did not move"):
                migration.require_learning(run, {"host_id": "hunsn4", "vtep_ip": "172.16.25.2"},
                                           BASELINE, {}, mock.Mock())

    def test_controller_power_loss_is_not_relaxed(self):
        run = self.run_fixture()
        controllers = [{"name": "owned"}]
        run.state = {"prefix": "owned"}
        run.require_platform_healthy = mock.Mock()
        run.proxmox.get.return_value = {"data": {"status": "stopped"}}
        with mock.patch.object(ha.deployment, "controller_inventory", return_value=controllers), \
                mock.patch("nsr_ha_vip.controller_path", return_value="/owned"):
            with self.assertRaisesRegex(RuntimeError, "controller stopped"):
                migration.controller_check(run, controllers)
        run.proxmox.post.assert_not_called()

    def test_cli_wires_new_saved_action_and_rejects_controller_fault_combination(self):
        with mock.patch.object(ha, "with_saved_run") as saved, mock.patch.object(ha, "automated_ssh_tofu"):
            self.assertEqual(ha.main(["--test-double-failover-migration", "--state", "/owned"]), 0)
        self.assertIs(saved.call_args.args[1], migration.run_gate)
        self.assertEqual(saved.call_args.kwargs["action_name"], "online-double-failover-migration")
        with mock.patch("sys.stderr"), self.assertRaises(SystemExit):
            ha.main(["--test-double-failover-migration", "--test-controller-loss", "--state", "/owned"])

    def test_scenario_keeps_same_sockets_through_two_crashes_and_migrations(self):
        with tempfile.TemporaryDirectory() as directory:
            run = self.run_fixture()
            run.directory = Path(directory)
            run.platform_health = mock.Mock()
            run.run_owned_guest = mock.Mock()
            original_transport = run.run_owned_guest
            run.state = {"prefix": "owned", "controllers": [{"name": str(i)} for i in range(3)],
                         "router_requested": "owned"}
            router = {"id": "owned", "standby": {}}
            run.router = mock.Mock(return_value=router)
            run.wait_converged = mock.Mock(return_value=("a", 3))
            run.planned_handoff = mock.Mock()
            run.flow_cases = mock.Mock(return_value=[{"protocol": "tcp"}, {"protocol": "udp"}])
            run.start_probes, run.wait_established = mock.Mock(), mock.Mock()
            run.guest_clock = mock.Mock(return_value=[0, 0])
            run.held_traffic = mock.Mock(return_value={"passed": True})
            run.observe_stable = mock.Mock(return_value=[])
            run.probe_status = mock.Mock(side_effect=[
                {"completed": False}, {"completed": False},
                {"completed": True, "results": [{"protocol": "tcp"}, {"protocol": "udp"}]},
            ])
            run.owned_member_path = mock.Mock(return_value="/owned")
            run.proxmox.get.return_value = {"data": {"status": "running"}}
            run.power_member, run.stop_probes, run.record = mock.Mock(), mock.Mock(), mock.Mock()
            run.stop_probes.return_value = {"stopped_or_collected": True}
            sequence = []

            def crash(source, term, fault):
                self.assertIs(run.run_owned_guest, direct.return_value.__enter__.return_value.execute)
                sequence.append(("crash", source, term))
                fault["completed_monotonic"] = fault["started_monotonic"] + 1
                return {"member": ha.other(source), "term": term + 1, "takeover_observed_seconds": 4}

            def move(run, target, leg, save):
                sequence.append(("migrate", target))
                leg["migration"] = {"started_monotonic": 10, "completed_monotonic": 11}

            def restore(run, source, owner, term, leg, save):
                sequence.append(("rejoin", source, owner, term))

            run.crash_active = mock.Mock(side_effect=crash)
            with mock.patch.object(ha, "require_pair"), \
                    mock.patch.object(ha, "pair_identity", return_value=None), \
                    mock.patch.object(ha.deployment, "controller_inventory", return_value=run.state["controllers"]), \
                    mock.patch.object(migration, "SerialMembers"), \
                    mock.patch.object(migration, "DirectMembers") as direct, \
                    mock.patch.object(migration, "preflight", return_value={node: {} for node in migration.NODES}), \
                    mock.patch.object(migration, "workload_view", return_value=BASELINE), \
                    mock.patch.object(migration, "require_learning") as learned, \
                    mock.patch.object(migration, "controller_check") as checked, \
                    mock.patch.object(migration, "migrate", side_effect=move), \
                    mock.patch.object(migration, "rejoin", side_effect=restore), \
                    mock.patch.object(ha, "measurements", return_value={"passed": True}) as measured, \
                    mock.patch("sys.stdout"):
                run.state["pair"] = None
                migration.run_gate(run)
            self.assertEqual(sequence, [
                ("crash", "a", 3), ("migrate", "hunsn4"), ("rejoin", "a", "b", 4),
                ("crash", "b", 4), ("migrate", "hunsn5"), ("rejoin", "b", "a", 5),
            ])
            run.start_probes.assert_called_once()
            run.stop_probes.assert_called_once()
            self.assertEqual(measured.call_count, 4)
            self.assertEqual(learned.call_count, 3)
            self.assertGreaterEqual(checked.call_count, 5)
            run.wait_converged.assert_called_with("a", term=5)
            self.assertTrue(run.record.call_args.args[1]["passed"])
            self.assertIs(run.run_owned_guest, original_transport)

    def test_report_keeps_primary_error_when_cleanup_also_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            run = self.run_fixture()
            run.directory = Path(directory)
            run.platform_health = mock.Mock()
            original = run.run_owned_guest = mock.Mock()
            run.state = {"prefix": "owned", "controllers": [{}, {}, {}], "pair": None}
            run.router = mock.Mock()
            run.wait_converged = mock.Mock(return_value=("a", 3))
            run.flow_cases = mock.Mock(return_value=[])
            run.start_probes, run.wait_established = mock.Mock(), mock.Mock()
            run.guest_clock = mock.Mock(return_value=[0, 0])
            run.stop_probes = mock.Mock(side_effect=RuntimeError("cleanup failed"))
            with mock.patch.object(ha, "require_pair"), \
                    mock.patch.object(ha, "pair_identity", return_value=None), \
                    mock.patch.object(ha.deployment, "controller_inventory", return_value=run.state["controllers"]), \
                    mock.patch.object(migration, "SerialMembers"), \
                    mock.patch.object(migration, "DirectMembers"), \
                    mock.patch.object(migration, "preflight", return_value={}), \
                    mock.patch.object(migration, "workload_view", side_effect=RuntimeError("primary failure")), \
                    mock.patch("sys.stdout"):
                with self.assertRaisesRegex(RuntimeError, "cleanup failed") as failure:
                    migration.run_gate(run)
            self.assertEqual(str(failure.exception.__context__), "primary failure")
            report = json.loads(next(run.directory.glob("*-report.json")).read_text())
            self.assertEqual(report["error"], "RuntimeError: primary failure")
            self.assertFalse(report["passed"])
            self.assertIs(run.run_owned_guest, original)


if __name__ == "__main__":
    unittest.main()
