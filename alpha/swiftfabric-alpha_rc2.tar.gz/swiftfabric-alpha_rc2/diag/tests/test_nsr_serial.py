from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

import nsr_serial as serial


class SerialTests(unittest.TestCase):
    def run_fixture(self, directory):
        run = SimpleNamespace(
            directory=Path(directory), owned_member_path=mock.Mock(return_value="/owned"),
            proxmox=mock.Mock(), run_owned_guest=mock.Mock(return_value="ubuntu L 2026-01-01 0 99999 7 -1"),
        )
        run.proxmox.get.return_value = {"data": {"serial0": "socket"}}
        return run

    def test_prepare_enables_authenticated_getty_and_private_password(self):
        with tempfile.TemporaryDirectory() as directory:
            run = self.run_fixture(directory)
            with mock.patch.object(serial, "crypt_hash", return_value="test-hash"):
                password = serial.prepare(run, "a")
            self.assertEqual(password.stat().st_mode & 0o777, 0o600)
            self.assertIn("usermod -p test-hash ubuntu", run.run_owned_guest.call_args.args[1])
            self.assertIn("sync -f /etc/shadow", run.run_owned_guest.call_args.args[1])
            self.assertIn("enable --now serial-getty@ttyS0.service", run.run_owned_guest.call_args.args[1])
            self.assertNotIn("autologin", run.run_owned_guest.call_args.args[1])
            with self.assertRaisesRegex(RuntimeError, "already exists"):
                serial.prepare(run, "a")

    def test_foreign_vm_serial_configuration_and_unlocked_account_refused(self):
        with tempfile.TemporaryDirectory() as directory:
            run = self.run_fixture(directory)
            run.owned_member_path.side_effect = RuntimeError("ownership changed")
            with self.assertRaisesRegex(RuntimeError, "ownership changed"):
                serial.prepare(run, "a")
            run.proxmox.put.assert_not_called()
            run.owned_member_path.side_effect = None
            run.proxmox.get.return_value = {"data": {"serial0": "/dev/ttyS0"}}
            with self.assertRaisesRegex(RuntimeError, "different configuration"):
                serial.prepare(run, "a")
            run.proxmox.get.return_value = {"data": {"serial0": "socket"}}
            run.run_owned_guest.return_value = "ubuntu P 2026-01-01"
            with self.assertRaisesRegex(RuntimeError, "initially locked"):
                serial.prepare(run, "a")
            self.assertEqual(list(Path(directory).iterdir()), [])

    def test_capture_keeps_private_output_and_records_console_failure(self):
        with tempfile.TemporaryDirectory() as directory:
            run = self.run_fixture(directory)
            report = {}
            save = mock.Mock()
            with mock.patch.object(serial, "execute", return_value="boot and routes"):
                receipt = serial.capture(run, "a", report, save)
            self.assertTrue(receipt["captured"])
            self.assertEqual(Path(receipt["output"]).stat().st_mode & 0o777, 0o600)
            with mock.patch.object(serial, "execute", side_effect=subprocess.TimeoutExpired("console", 60)):
                receipt = serial.capture(run, "b", report, save)
            self.assertFalse(receipt["captured"])
            self.assertIn("timed out", receipt["error"])
            self.assertEqual(save.call_count, 2)

    def test_cleanup_locks_account_and_retains_password_if_console_unreachable(self):
        with tempfile.TemporaryDirectory() as directory:
            run = self.run_fixture(directory)
            password = run.directory / "console-password-a"
            serial.write_private(password, "test-password")
            members = serial.SerialMembers(run)
            members.members = ["a"]
            with mock.patch.object(serial, "execute", side_effect=RuntimeError("unreachable")):
                with self.assertRaisesRegex(RuntimeError, "passwords retained"):
                    members.close()
            self.assertTrue(password.exists())
            with mock.patch.object(serial, "execute", return_value="ubuntu L") as command:
                members.close()
            self.assertIn("usermod", command.call_args.args[2])
            self.assertIn("sync -f /etc/shadow", command.call_args.args[2])
            self.assertFalse(password.exists())

    def test_setup_error_survives_cleanup_failure(self):
        with tempfile.TemporaryDirectory() as directory:
            members = serial.SerialMembers(self.run_fixture(directory))
            with mock.patch.object(serial, "prepare", side_effect=RuntimeError("prepare failed")), \
                    mock.patch.object(members, "close", side_effect=RuntimeError("cleanup failed")):
                with self.assertRaisesRegex(RuntimeError, "setup failed: prepare failed; cleanup failed") as failure:
                    members.__enter__()
            self.assertEqual(str(failure.exception.__cause__), "prepare failed")


if __name__ == "__main__":
    unittest.main()
