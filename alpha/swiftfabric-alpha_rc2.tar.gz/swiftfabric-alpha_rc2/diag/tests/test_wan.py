import importlib.util
import json
from pathlib import Path
import sys
import unittest
from unittest import mock


SPEC = importlib.util.spec_from_file_location("wan_diag", Path(__file__).parents[1] / "wan.py")
sys.path.insert(0, str(Path(__file__).parents[1]))
wan = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(wan)


class WanTests(unittest.TestCase):
    def candidate(self):
        key = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIGzBtfJudR02pgXBHjR0DaTvYbMcBODu1hcNQ7Y2JJ0A"
        return {
            "changed": False, "endpoint": "[192.0.2.1]:22", "trusted": None,
            "observed": [{"public_key": key, "fingerprint": wan.SSHCommandRunner._fingerprint(key.split()[1])}],
        }

    def test_first_use_requires_explicit_authorization_and_matching_fingerprint(self):
        candidate = self.candidate()
        with self.assertRaisesRegex(RuntimeError, "no approved SSH pin"):
            wan.trusted_key(candidate, "192.0.2.1", False)
        with mock.patch("sys.stderr"):
            self.assertEqual(
                wan.trusted_key(candidate, "192.0.2.1", True),
                candidate["observed"][0]["public_key"],
            )
        candidate["observed"][0]["fingerprint"] = "invalid"
        with mock.patch("sys.stderr"), self.assertRaisesRegex(RuntimeError, "fingerprint"):
            wan.trusted_key(candidate, "192.0.2.1", True)

    def test_changed_or_mismatched_endpoints_are_never_trusted(self):
        for changes in ({"changed": True}, {"endpoint": "[192.0.2.2]:22"}):
            with self.subTest(changes=changes), self.assertRaisesRegex(RuntimeError, "endpoint changed"):
                wan.trusted_key({**self.candidate(), **changes}, "192.0.2.1", True)

    def test_existing_pin_is_reused_without_first_use_authorization(self):
        candidate = self.candidate()
        candidate["trusted"] = {**candidate["observed"][0], "endpoint": candidate["endpoint"]}
        self.assertEqual(
            wan.trusted_key(candidate, "192.0.2.1", False),
            candidate["trusted"]["public_key"],
        )

    def test_generated_programs_compile_and_scope_marked_routes_and_captures(self):
        program = wan.router_program(
            {"compute_vteps": ["192.0.2.2"], "vtep_ip": "192.0.2.1"},
            [{"id": 49100}], 25, "1.1.1.1",
        )
        compile(program, "<router diagnostics>", "exec")
        compile(wan.TRANSPORT, "<controller transport>", "exec")
        self.assertIn("'mark', '59100'", program)
        self.assertIn("'sf-tq49100'", program)
        self.assertIn("src host 192.0.2.1", program)
        self.assertIn("StrictHostKeyChecking=yes", wan.TRANSPORT)
        self.assertIn("NSR identity changed", wan.TRANSPORT)
        self.assertNotIn("1.1.1.1", wan.TRANSPORT)

    def test_guest_probes_use_separate_explicit_ports(self):
        cases = wan.probe_cases({"address": "10.0.0.10"}, "1.1.1.1", 62010)
        self.assertEqual([case["source_port"] for case in cases], [62010, 62011])
        self.assertEqual([case["protocol"] for case in cases], ["tcp", "udp"])

    def test_upgrade_diagnostics_are_read_only_bounded_and_do_not_print_credentials(self):
        program = wan.router_upgrade_program()
        config = {
            "api_token": "do-not-print-token", "ha_replication_mode": "paired",
            "ha_enabled": False, "ha_state_sync_enabled": False,
        }
        result = mock.Mock(returncode=0, stdout="", stderr="")
        with mock.patch("subprocess.run", return_value=result) as run, mock.patch(
            "pathlib.Path.read_text", return_value=json.dumps(config),
        ), mock.patch("builtins.print") as output:
            exec(compile(program, "<upgrade diagnostics>", "exec"), {})
        commands = [call.args[0] for call in run.call_args_list]
        self.assertEqual([command[0] for command in commands], ["systemctl", "journalctl", "journalctl"])
        self.assertEqual(commands[0][1], "show")
        self.assertIn("--since=-2h", commands[1])
        self.assertIn("250", commands[1])
        self.assertNotIn("do-not-print-token", str(output.call_args_list))
        record = json.loads(output.call_args.args[0])
        self.assertEqual(record["ha"]["ha_replication_mode"], "paired")

    def test_remote_command_failure_is_reported_not_success(self):
        program = wan.command_program({"missing": ["false"]})
        with mock.patch("builtins.print"), self.assertRaisesRegex(RuntimeError, "missing failed"):
            exec(compile(program, "<diagnostics>", "exec"), {})


if __name__ == "__main__":
    unittest.main()
