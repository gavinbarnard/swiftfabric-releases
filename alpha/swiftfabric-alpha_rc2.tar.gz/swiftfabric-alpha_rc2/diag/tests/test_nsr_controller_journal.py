import unittest
import sys
from pathlib import Path
from unittest import mock

import nsr_controller_journal as journal


class ControllerJournalTests(unittest.TestCase):
    def recovery(self):
        recovery = mock.Mock()
        state = {
            "config": "/synthetic/config.json", "config_sha256": "hash",
            "prefix": "sf-dr-" + "a" * 20, "replacement_controllers": [{"vmid": 100}],
        }
        recovery.read_config_object.return_value = state
        recovery.fingerprint.return_value = "hash"
        recovery.controller_inventory.return_value = state["replacement_controllers"]
        run = recovery.RecoveryRun.return_value
        run.config = {"ip_range_start": "192.0.2.10"}
        recovery.ControllerAPI.return_value.json.side_effect = [
            [{"id": state["prefix"] + "-ha-nsr"}], {"healthy": True},
        ]
        recovery.ControllerAPI.return_value.ssh.run.return_value = "private evidence"
        return recovery

    def test_recovery_inspection_only_reads_owned_replacement_controllers(self):
        recovery = self.recovery()
        with mock.patch.dict(sys.modules, {"disaster_recovery": recovery}), mock.patch("builtins.print"):
            journal.inspect_recovery(Path("/private/run"))
        api = recovery.ControllerAPI.return_value
        self.assertEqual([call.args[0] for call in api.json.call_args_list], ["GET", "GET"])
        self.assertEqual(api.ssh.run.call_count, 3)
        for call in api.ssh.run.call_args_list:
            self.assertNotIn("restart", call.args[1])
            self.assertNotIn("reload", call.args[1])
        recovery.RecoveryRun.return_value.close.assert_called_once()

    def test_recovery_inspection_rejects_changed_config_before_connecting(self):
        recovery = self.recovery()
        recovery.fingerprint.return_value = "different"
        with mock.patch.dict(sys.modules, {"disaster_recovery": recovery}):
            with self.assertRaisesRegex(RuntimeError, "configuration changed"):
                journal.inspect_recovery(Path("/private/run"))
        recovery.RecoveryRun.assert_not_called()

    def test_recovery_inspection_rejects_changed_controller_ownership(self):
        recovery = self.recovery()
        recovery.controller_inventory.return_value = [{"vmid": 101}]
        with mock.patch.dict(sys.modules, {"disaster_recovery": recovery}):
            with self.assertRaisesRegex(RuntimeError, "ownership changed"):
                journal.inspect_recovery(Path("/private/run"))
        recovery.ControllerAPI.assert_not_called()
        recovery.RecoveryRun.return_value.close.assert_called_once()

    def test_three_controllers_from_range_start(self):
        self.assertEqual(
            journal.controller_addresses({"ip_range_start": "172.16.255.2"}),
            ["172.16.255.2", "172.16.255.3", "172.16.255.4"],
        )

    def test_window_and_filter_are_quoted(self):
        script = journal.program(10, 20, "a'b")
        self.assertIn("--since @10 --until @20", script)
        self.assertIn("grep -E -- 'a'\"'\"'b'", script)

    def test_main_rejects_ambiguous_mode(self):
        with self.assertRaises(SystemExit):
            journal.main(["--state", "/nonexistent"])
        with self.assertRaises(SystemExit):
            journal.main(["--state", "/nonexistent", "--time-crm", "--journal", "1", "2"])
        with self.assertRaises(SystemExit):
            journal.main(["--state", "/nonexistent", "--time-crm", "--recovery-state"])
        with self.assertRaises(SystemExit):
            journal.main(["--state", "/nonexistent", "--time-crm", "--validate-nginx"])


if __name__ == "__main__":
    unittest.main()
