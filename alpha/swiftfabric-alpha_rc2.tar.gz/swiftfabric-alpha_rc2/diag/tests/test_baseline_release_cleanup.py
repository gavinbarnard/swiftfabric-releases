import importlib.util
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location(
    "baseline_release_cleanup", ROOT / "diag/baseline_release_cleanup.py")
cleanup = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(cleanup)


class BaselineReleaseCleanupTests(unittest.TestCase):
    def test_current_tenancy_loaded_before_historical_cleanup_rewrites_import_path(self):
        events = []
        def saved_cleanup(directory, *, preflight):
            self.assertIs(preflight, cleanup.restore_cleanup_identity)
            events.append(("cleanup", directory))
        recovery = SimpleNamespace(cleanup_saved_run=mock.Mock(side_effect=saved_cleanup))

        def load(name):
            self.assertEqual(name, "tenancy")
            self.assertEqual(sys.path[0], str(ROOT / "network-lab"))
            events.append(("load", name))

        with mock.patch.object(sys, "argv", ["cleanup", "/private/baseline", "/private/run"]), \
                mock.patch.object(sys, "path", sys.path[:]), \
                mock.patch.dict(sys.modules, {"disaster_recovery": recovery}), \
                mock.patch.object(cleanup.importlib, "import_module", side_effect=load):
            cleanup.main()
        self.assertEqual(events, [("load", "tenancy"), ("cleanup", Path("/private/run"))])

    def test_failed_acceptance_inventory_restores_hosts_without_claiming_success(self):
        run = SimpleNamespace(
            directory=Path("/private/run"), save=mock.Mock(),
            state={"router": {"id": "owned", "name": "owned", "vmid": 10}, "status": "failed"})
        evidence = {
            "run_id": "run", "router": run.state["router"],
            "hosts": [{"host_id": "cluster-node", "node": "node"}],
            "vms": [], "segments": [], "tenant_metadata": [],
        }
        recovery = SimpleNamespace(read_config_object=mock.Mock(
            side_effect=[{"run_id": "run", "nodes": ["node"]}, evidence]))
        with mock.patch.dict(sys.modules, {"disaster_recovery": recovery}):
            cleanup.restore_cleanup_identity(run)
        self.assertEqual(run.state["workload_identity"]["hosts"], evidence["hosts"])
        self.assertEqual(run.state["status"], "failed")
        run.save.assert_called_once_with()

    def test_changed_run_identity_blocks_host_reconstruction(self):
        run = SimpleNamespace(directory=Path("/private/run"), save=mock.Mock(),
                              state={"router": {"id": "owned"}})
        recovery = SimpleNamespace(read_config_object=mock.Mock(
            side_effect=[{"run_id": "original"}, {"run_id": "foreign"}]))
        with mock.patch.dict(sys.modules, {"disaster_recovery": recovery}):
            with self.assertRaisesRegex(RuntimeError, "ownership"):
                cleanup.restore_cleanup_identity(run)
        self.assertNotIn("workload_identity", run.state)
        run.save.assert_not_called()
