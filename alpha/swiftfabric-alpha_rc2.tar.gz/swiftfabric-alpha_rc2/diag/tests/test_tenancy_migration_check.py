import argparse
import contextlib
import io
from pathlib import Path
import sys
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import tenancy_migration_check


class MigrationCheckTests(unittest.TestCase):
    def test_completed_migration_uses_saved_source_and_original_endpoints(self):
        source = {"vmid": 100, "node": "b", "tenant_id": "default", "segment_id": 1}
        endpoints = [
            {"vmid": 102, "node": "c", "tenant_id": "default", "segment_id": 1},
            {"vmid": 105, "node": "c", "tenant_id": "default", "segment_id": 2},
        ]
        lab = mock.Mock()
        lab.state = {
            "tenant_ids": ["default", "other"], "nodes": ["a", "b", "c"],
            "run_id": "a" * 32, "vms": [source, *endpoints],
            "segments": [{"id": number, "tenant_id": "default"} for number in (1, 2, 3)],
            "migration_events": [
                {"tenant_id": "default", "vmid": 100, "source": "a", "target": "b"},
            ],
        }
        lab.serial.return_value = ""
        module = mock.Mock()
        module.TenantLab.return_value = lab
        args = argparse.Namespace(state=Path("/private/run"), tenant_index=0)
        with mock.patch.dict(sys.modules, {"tenancy": module}), \
                contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(tenancy_migration_check.inspect(args), 0)
        lab.migration_plan.assert_not_called()
        self.assertEqual([call.args[0] for call in lab.serial.call_args_list],
                         [source, *endpoints])
        self.assertIn("/run/swiftfabric-network-lab-migration/aaaaaaaa-t0-vm-100",
                      lab.serial.call_args_list[0].args[1])
        for endpoint, call in zip(endpoints, lab.serial.call_args_list[1:]):
            self.assertIn(f"aaaaaaaa-t0-ep-{endpoint['vmid']}", call.args[1])
