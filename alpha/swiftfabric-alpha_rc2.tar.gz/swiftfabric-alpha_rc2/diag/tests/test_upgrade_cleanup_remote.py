import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock


SPEC = importlib.util.spec_from_file_location(
    "upgrade_cleanup_remote", Path(__file__).resolve().parents[1] / "upgrade_cleanup_remote.py")
remote = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(remote)


class RemoteCleanupTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        patch = mock.patch.object(remote, "Path", side_effect=lambda path: self.root / str(path).lstrip("/"))
        patch.start()
        self.addCleanup(patch.stop)
        self.spec = {
            "operation": "controller-plan", "ca": "c" * 64, "api_vip": "192.0.2.13",
            "node_ips": ["192.0.2.10", "192.0.2.11", "192.0.2.12"],
            "node_names": ["controller-0", "controller-1", "controller-2"],
            "hosts": [{"host_id": "cluster-node1", "node": "node1"}],
            "router": {"id": "owned", "name": "owned", "vmid": 100},
        }
        self.write("/etc/swiftfabric/api-service.json", self.spec)
        self.write("/var/lib/swiftfabric/segments.json", {"4999": {"password": "test-only"}})
        self.router = {
            **self.spec["router"], "deployment_mode": "standalone",
            "ha_replication_mode": "paired", "vm_owner_token": "a" * 64,
        }
        self.records = {
            "swiftfabric:hosts": copy.deepcopy(self.spec["hosts"]),
            "swiftfabric:north_south_routers": [self.router],
        }
        self.commands = []
        patch = mock.patch.object(remote, "command", side_effect=self.command)
        patch.start()
        self.addCleanup(patch.stop)
        patch = mock.patch.object(remote, "ca_matches", return_value=True)
        self.ca_matches = patch.start()
        self.addCleanup(patch.stop)

    def write(self, name, data):
        path = self.root / name.lstrip("/")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data))
        return path

    def command(self, *args, **kwargs):
        self.commands.append(args)
        if args[0] == "valkey-cli":
            return "\n".join(json.dumps(value) for value in self.records[args[-1]]) + "\n"
        if args[0] == "systemctl" and args[1] == "show":
            return "loaded\n"
        if args[0] == "dpkg-query":
            return "swiftfabric-host-agent installed\n"
        return ""

    def host(self):
        self.write("/usr/local/share/ca-certificates/swiftfabric-deployment-ca-test.crt", "test")
        return self.write("/etc/swiftfabric/host-agent.json", {
            "host_id": "cluster-node1", "api_url": "https://192.0.2.13",
            "vtep_ip": "172.20.0.10", "vtep_interface": "vmbr0", "vtep_prefix_len": 24,
        })

    def host_spec(self):
        return {"host_id": "cluster-node1", "api_vip": "192.0.2.13", "ca": "c" * 64}

    def test_raw_legacy_router_modes_do_not_require_api_deserialization(self):
        for mode in ("paired", "edge-local", "journal-only", "standalone", "asynchronous"):
            self.router["ha_replication_mode"] = mode
            plan = remote.controller_plan(self.spec)
            self.assertEqual(plan["router"]["owner_tag"], "swiftfabric_owner_" + "a" * 64)
        self.assertTrue(all(call[0] == "valkey-cli" for call in self.commands))

    def test_foreign_controller_ca_or_topology_blocks_storage_reads(self):
        self.ca_matches.return_value = False
        with self.assertRaisesRegex(RuntimeError, "CA changed"):
            remote.controller_plan(self.spec)
        self.commands.clear()
        changed = copy.deepcopy(self.spec)
        changed["api_vip"] = "192.0.2.99"
        with self.assertRaisesRegex(RuntimeError, "topology"):
            remote.controller_plan(changed)
        self.assertEqual(self.commands, [])

    def test_foreign_router_or_host_inventory_blocks_cleanup(self):
        for change in ({"vm_owner_token": "bad"}, {"name": "foreign"}, {"standby": {}},
                       {"ha_state_sync_enabled": True}):
            original = copy.deepcopy(self.router)
            self.router.update(change)
            with self.subTest(change=change), self.assertRaisesRegex(RuntimeError, "ownership"):
                remote.controller_plan(self.spec)
            self.router.clear()
            self.router.update(original)
        self.records["swiftfabric:hosts"].append({"host_id": "foreign", "node": "other"})
        with self.assertRaisesRegex(RuntimeError, "Unexpected enrolled"):
            remote.controller_plan(self.spec)

    def test_host_identity_and_ca_are_checked_before_destructive_commands(self):
        path = self.host()
        spec = self.host_spec()
        plan = remote.host_plan(spec)
        self.assertEqual(plan["vtep_interface"], "vmbr0")
        self.assertNotIn("api_token", plan)
        path.write_text(path.read_text().replace("cluster-node1", "foreign"))
        with self.assertRaisesRegex(RuntimeError, "ownership"):
            remote.remove_host({**spec, "plan": plan})
        self.assertEqual(self.commands, [])

    def test_host_removal_uses_installed_teardown_then_purges_and_removes_trust(self):
        self.host()
        self.write("/usr/bin/swiftfabric-host-agent", "installed")
        self.write("/var/lib/swiftfabric/host-bindings/state.json", {})
        plan = remote.host_plan(self.host_spec())
        remote.remove_host({**self.host_spec(), "plan": plan})
        teardown = self.commands.index((
            str(self.root / "usr/bin/swiftfabric-host-agent"), "teardown", "--vtep-ip", "172.20.0.10",
            "--vtep-interface", "vmbr0", "--vtep-prefix-len", "24"))
        purge = self.commands.index(("dpkg", "--purge", "swiftfabric-host-agent"))
        self.assertLess(teardown, purge)
        self.assertIn(("systemctl", "disable", "--now", "swiftfabric-host-agent.service"), self.commands)
        self.assertIn(("systemctl", "disable", "--now", "swiftfabric-neighbors.service"), self.commands)
        self.assertIn(("update-ca-certificates",), self.commands)
        self.assertFalse((self.root / "etc/swiftfabric/host-agent.json").exists())
        self.assertFalse((self.root / "var/lib/swiftfabric/host-bindings").exists())
        self.assertFalse(list((self.root / "usr/local/share/ca-certificates").glob("swiftfabric*")))

    def test_teardown_failure_never_purges_or_deletes_configuration(self):
        path = self.host()
        self.write("/usr/bin/swiftfabric-host-agent", "installed")
        plan = remote.host_plan(self.host_spec())
        original = self.command
        def fail(*args, **kwargs):
            if args[0] == str(self.root / "usr/bin/swiftfabric-host-agent"):
                raise RuntimeError("teardown failed")
            return original(*args, **kwargs)
        with mock.patch.object(remote, "command", side_effect=fail), \
                self.assertRaisesRegex(RuntimeError, "teardown failed"):
            remote.remove_host({**self.host_spec(), "plan": plan})
        self.assertTrue(path.exists())
        self.assertNotIn(("dpkg", "--purge", "swiftfabric-host-agent"), self.commands)

    def test_partial_host_removal_can_resume_after_config_is_gone(self):
        path = self.host()
        self.write("/usr/bin/swiftfabric-host-agent", "installed")
        plan = remote.host_plan(self.host_spec())
        path.unlink()
        remote.remove_host({**self.host_spec(), "plan": plan})
        self.assertTrue(any(call[0] == str(self.root / "usr/bin/swiftfabric-host-agent")
                            for call in self.commands))

    def test_helper_cache_is_removed_and_partial_cleanup_is_idempotent(self):
        config = self.host()
        plan = remote.host_plan(self.host_spec())
        (self.root / "var/lib/swiftfabric/segments.json").unlink()
        helper = self.write(
            "/var/lib/swiftfabric/helpers/swiftfabric-host-helper-" + "a" * 64, "binary")
        config.unlink()
        remote.remove_host({**self.host_spec(), "plan": plan})
        self.assertFalse(helper.exists())
        self.assertFalse((self.root / "var/lib/swiftfabric").exists())
        remote.remove_host({**self.host_spec(), "plan": plan})

    def test_unknown_or_symlinked_helper_entries_block_destructive_commands(self):
        self.host()
        plan = remote.host_plan(self.host_spec())
        unknown = self.write("/var/lib/swiftfabric/helpers/foreign", "foreign")
        with self.assertRaisesRegex(RuntimeError, "Unknown host helper"):
            remote.remove_host({**self.host_spec(), "plan": plan})
        self.assertEqual(self.commands, [])
        unknown.unlink()
        target = self.write("/foreign", "preserve")
        helper = unknown.with_name("swiftfabric-host-helper-" + "a" * 64)
        helper.symlink_to(target)
        with self.assertRaisesRegex(RuntimeError, "Unknown host helper"):
            remote.remove_host({**self.host_spec(), "plan": plan})
        self.assertTrue(target.exists())
        self.assertEqual(self.commands, [])

    def test_extract_only_install_uses_python_fallback_without_package_purge(self):
        self.host()
        self.write("/usr/lib/swiftfabric-host-agent/swiftfabric_host/__init__.py", "")
        plan = remote.host_plan(self.host_spec())
        original = self.command
        def extracted(*args, **kwargs):
            if args[0] == "dpkg-query":
                return "unrelated installed\n"
            return original(*args, **kwargs)
        with mock.patch.object(remote, "command", side_effect=extracted):
            remote.remove_host({**self.host_spec(), "plan": plan})
        self.assertIn((
            "/usr/bin/python3", "-m", "swiftfabric_host", "teardown",
            "--vtep-ip", "172.20.0.10", "--vtep-interface", "vmbr0",
            "--vtep-prefix-len", "24"), self.commands)
        self.assertNotIn(("dpkg", "--purge", "swiftfabric-host-agent"), self.commands)
        self.assertFalse((self.root / "usr/lib/swiftfabric-host-agent").exists())

    def test_half_configured_package_can_be_purged_after_teardown(self):
        self.host()
        self.write("/usr/bin/swiftfabric-host-agent", "")
        plan = remote.host_plan(self.host_spec())
        original = self.command
        def half_configured(*args, **kwargs):
            if args[0] == "dpkg-query":
                return "swiftfabric-host-agent half-configured\n"
            return original(*args, **kwargs)
        with mock.patch.object(remote, "command", side_effect=half_configured):
            remote.remove_host({**self.host_spec(), "plan": plan})
        self.assertIn(("dpkg", "--purge", "swiftfabric-host-agent"), self.commands)

    def test_invalid_vtep_config_is_rejected_before_removal(self):
        path = self.host()
        original = json.loads(path.read_text())
        for change in ({"vtep_ip": "invalid"}, {"vtep_interface": "vmbr0;other"},
                       {"vtep_prefix_len": 0}, {"vtep_vlan": True}):
            path.write_text(json.dumps({**original, **change}))
            with self.subTest(change=change), self.assertRaises((ValueError, RuntimeError)):
                remote.host_plan(self.host_spec())
        self.assertEqual(self.commands, [])

    def test_rotated_or_foreign_host_ca_is_never_removed(self):
        self.host()
        plan = remote.host_plan(self.host_spec())
        self.ca_matches.return_value = False
        with self.assertRaisesRegex(RuntimeError, "another deployment CA"):
            remote.remove_host({**self.host_spec(), "plan": plan})
        self.assertEqual(self.commands, [])


if __name__ == "__main__":
    unittest.main()
