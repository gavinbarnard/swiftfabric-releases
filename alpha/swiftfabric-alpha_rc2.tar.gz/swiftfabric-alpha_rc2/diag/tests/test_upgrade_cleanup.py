import copy
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python_installer/tests_integration"))
sys.path.insert(0, str(ROOT / "python_installer"))
import disaster_recovery


SPEC = importlib.util.spec_from_file_location("offline_upgrade_cleanup", ROOT / "diag/upgrade_cleanup.py")
cleanup = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(cleanup)


class UpgradeCleanupTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        self.lab_directory = self.directory / "network-lab"
        self.lab_directory.mkdir()
        self.run_id = "1" * 32
        router = {"id": "owned-nsr", "name": "owned-nsr", "vmid": 200}
        self.router_plan = {
            "vmid": 200, "name": "owned-nsr",
            "description": "SwiftFabric N/S router owned-nsr member a",
            "owner_tag": "swiftfabric_owner_" + "a" * 64,
        }
        self.host_plan = {
            "sha256": "b" * 64, "vtep_ip": "172.20.0.10", "vtep_interface": "vmbr0",
            "vtep_prefix_len": 24, "vtep_vlan": None,
        }
        self.hosts = [{"host_id": "cluster-node1", "node": "node1"}]
        self.vm = {"vmid": 100, "name": "owned-lab", "node": "node1",
                   "segment_id": 49100, "address": "10.0.0.10"}
        self.controllers = [
            {"vmid": 300 + index, "node": "node1", "name": f"controller-{index}",
             "configuration": {"name": f"controller-{index}", "cicustom": "swiftfabric"}}
            for index in range(3)
        ]
        workload = {
            "run_id": self.run_id, "vms": [self.vm], "router": router, "hosts": self.hosts,
            "tenants": [{"routing_table": 130000, "conntrack_zone": 30000}],
        }
        self.lab = {"run_id": self.run_id, "router": router["id"],
                    "vms": [{**self.vm, "endpoint_identity": "owned-lab"}]}
        self.save_lab()
        self.run = SimpleNamespace(
            state={"workload_identity": workload, "controllers": self.controllers,
                   "router": router, "original_ca_der_sha256": "c" * 64},
            config={"controller_priv_key": "/controller-key", "proxmox_ssh_key": "/host-key",
                    "proxmox_ssh_user": "root", "ip_range_start": "192.0.2.10",
                    "ip_range_end": "192.0.2.13", "gateway_ip": "192.0.2.1", "cidr": 24,
                    "vtep_ip_range_cidr": "172.20.0.0/24"},
            proxmox=mock.Mock(), save=mock.Mock(),
            api=mock.Mock(side_effect=AssertionError("controller API must not be used")),
        )
        self.resources = {
            item["vmid"]: {"vmid": item["vmid"], "name": item["name"],
                           "node": item.get("node", "node1"), "type": "qemu"}
            for item in [self.vm, router, *self.controllers]
        }
        self.configs = {
            100: {"name": self.vm["name"],
                  "description": f"SwiftFabric live network lab {self.run_id}",
                  "net0": "virtio=AA:BB:CC:DD:EE:FF,bridge=sf-br49100"},
            200: {"name": router["name"], "description": self.router_plan["description"],
                  "tags": self.router_plan["owner_tag"]},
            **{item["vmid"]: copy.deepcopy(item["configuration"]) for item in self.controllers},
        }
        self.statuses = {vmid: "running" for vmid in self.resources}
        self.events = []
        self.run.proxmox.get.side_effect = self.get
        self.run.proxmox.post.side_effect = self.stop
        self.run.proxmox.delete.side_effect = self.delete
        self.controller_ssh = mock.Mock()
        self.controller_ssh.run.return_value = json.dumps({"router": self.router_plan})
        self.host_ssh = mock.Mock()
        self.host_ssh.run.side_effect = self.host_command
        patch = mock.patch(
            "deployment.ssh.SSHCommandRunner",
            side_effect=lambda key, *args: (
                self.controller_ssh if key == "/controller-key" else self.host_ssh),
        )
        self.runner = patch.start()
        self.addCleanup(patch.stop)

    def save_lab(self):
        (self.lab_directory / "state.json").write_text(json.dumps(self.lab))

    def get(self, path, **kwargs):
        if path == "/cluster/resources":
            return {"data": list(copy.deepcopy(self.resources).values())}
        vmid = int(path.split("/")[4])
        if path.endswith("/config"):
            return {"data": copy.deepcopy(self.configs[vmid])}
        if path.endswith("/status/current"):
            return {"data": {"status": self.statuses[vmid]}}
        raise AssertionError(path)

    def stop(self, path):
        vmid = int(path.split("/")[4])
        self.events.append(("stop", vmid))
        self.statuses[vmid] = "stopped"
        return {"data": "UPID:stop"}

    def delete(self, path, **kwargs):
        vmid = int(path.split("/")[4])
        self.events.append(("delete", vmid))
        del self.resources[vmid]
        return {"data": "UPID:delete"}

    def host_command(self, address, command, input_data=None, **kwargs):
        if input_data is None:
            self.events.append(("verify-host", address))
            return "SWIFTFABRIC_HOST_CLEAN\n"
        payload = json.loads(input_data)
        if payload["operation"] == "host-plan":
            return json.dumps(self.host_plan)
        if payload["operation"] == "remove-host":
            self.events.append(("remove-host", address))
            return json.dumps("removed")
        raise AssertionError(payload)

    def execute(self):
        cleanup.cleanup(self.run, self.lab_directory)

    def test_api_unavailable_still_removes_guests_then_agents_then_controllers(self):
        self.execute()
        self.assertEqual(self.events, [
            ("stop", 300), ("stop", 301), ("stop", 302),
            ("stop", 100), ("delete", 100), ("stop", 200), ("delete", 200),
            ("remove-host", "node1"), ("verify-host", "node1"),
            ("delete", 300), ("delete", 301), ("delete", 302),
        ])
        self.assertEqual(self.resources, {})
        self.assertEqual(self.run.state["cleanup_verified_hosts"], self.hosts)
        self.run.api.assert_not_called()
        self.assertTrue(self.run.state["offline_cleanup_plan"])

    def test_preflight_has_no_target_mutations_or_success_state(self):
        cleanup.cleanup(self.run, self.lab_directory, preflight_only=True)
        self.assertEqual(self.events, [])
        self.assertNotIn("offline_cleanup_plan", self.run.state)
        self.assertNotIn("cleanup_verified_hosts", self.run.state)
        self.run.save.assert_not_called()
        self.run.proxmox.post.assert_not_called()
        self.run.proxmox.delete.assert_not_called()

    def test_expanded_management_pool_uses_reserved_api_vip_not_pool_end(self):
        self.run.config.update(ip_range_end="192.0.2.254", mgmt_ip_range_start="192.0.2.10")
        cleanup.cleanup(self.run, self.lab_directory, preflight_only=True)
        payload = json.loads(self.controller_ssh.run.call_args.kwargs["input_data"])
        self.assertEqual(payload["api_vip"], "192.0.2.13")
        self.assertEqual(self.events, [])

    def test_foreign_vm_or_controller_marker_blocks_every_mutation(self):
        for vmid, field in ((100, "description"), (200, "tags"), (301, "name")):
            original = self.configs[vmid][field]
            self.configs[vmid][field] = "foreign"
            with self.subTest(vmid=vmid), self.assertRaisesRegex(RuntimeError, "ownership"):
                self.execute()
            self.configs[vmid][field] = original
        self.assertEqual(self.events, [])

    def test_foreign_guest_using_sf_bridge_blocks_host_teardown(self):
        self.resources[900] = {"vmid": 900, "name": "foreign", "node": "node1", "type": "lxc"}
        self.configs[900] = {"net0": "name=eth0,bridge=sf-br9000"}
        with self.assertRaisesRegex(RuntimeError, "Foreign guest"):
            self.execute()
        self.assertEqual(self.events, [])

    def test_host_preflight_failure_blocks_every_mutation(self):
        self.host_ssh.run.side_effect = RuntimeError("foreign deployment")
        with self.assertRaisesRegex(RuntimeError, "foreign deployment"):
            self.execute()
        self.assertEqual(self.events, [])

    def test_residual_host_state_retains_controllers_and_plan_for_retry(self):
        original = self.host_command
        def failure(address, command, input_data=None, **kwargs):
            if input_data is None:
                raise RuntimeError("VTEP remains")
            return original(address, command, input_data, **kwargs)
        self.host_ssh.run.side_effect = failure
        with self.assertRaisesRegex(RuntimeError, "VTEP remains"):
            self.execute()
        self.assertEqual(set(self.resources), {300, 301, 302})
        self.assertIn("offline_cleanup_plan", self.run.state)
        self.assertNotIn("cleanup_verified_hosts", self.run.state)
        self.controller_ssh.run.reset_mock()
        self.controller_ssh.run.side_effect = AssertionError("stopped controllers are unavailable")
        self.host_plan = None
        self.host_ssh.run.side_effect = self.host_command
        self.execute()
        self.assertEqual(self.resources, {})
        self.controller_ssh.run.assert_not_called()

    def test_retry_after_one_controller_deleted_does_not_need_any_controller_ssh(self):
        self.run.state["offline_cleanup_plan"] = {
            "router": self.router_plan, "hosts": {"node1": self.host_plan},
            "run_id": self.run_id, "ca": "c" * 64,
        }
        del self.resources[300]
        del self.resources[100]
        del self.resources[200]
        self.controller_ssh.run.side_effect = AssertionError("controllers unavailable")
        self.execute()
        self.assertEqual(self.resources, {})
        self.controller_ssh.run.assert_not_called()

    def test_missing_router_record_with_remaining_vm_is_not_claimed_as_absent(self):
        self.controller_ssh.run.return_value = '{"router": null}'
        with self.assertRaisesRegex(RuntimeError, "ownership marker"):
            self.execute()
        self.assertEqual(self.events, [])

    def test_missing_router_vm_and_record_are_safe_to_retry(self):
        self.controller_ssh.run.return_value = '{"router": null}'
        del self.resources[200]
        self.execute()
        self.assertEqual(self.resources, {})

    def test_reused_vmid_or_name_is_not_deleted(self):
        del self.resources[100]
        self.resources[999] = {"vmid": 999, "name": self.vm["name"], "type": "qemu", "node": "node1"}
        with self.assertRaisesRegex(RuntimeError, "name was reused"):
            self.execute()
        self.assertEqual(self.events, [])

    def test_lab_may_have_already_removed_vm_from_its_saved_state(self):
        self.lab["vms"] = []
        self.save_lab()
        self.execute()
        self.assertEqual(self.resources, {})

    def test_migrated_lab_vm_is_deleted_on_its_live_node(self):
        self.lab["vms"][0]["node"] = "node2"
        self.resources[100]["node"] = "node3"
        self.save_lab()
        self.execute()
        self.run.proxmox.post.assert_any_call("/nodes/node3/qemu/100/status/stop")
        self.run.proxmox.delete.assert_any_call(
            "/nodes/node3/qemu/100", params={"purge": 1, "destroy-unreferenced-disks": 1})
        self.assertEqual(self.resources, {})

    def test_migrated_vm_with_changed_identity_or_owner_is_not_deleted(self):
        self.lab["vms"][0]["node"] = "node2"
        self.resources[100]["node"] = "node2"
        for field in ("name", "segment_id", "address"):
            original = self.lab["vms"][0][field]
            self.lab["vms"][0][field] = "foreign"
            self.save_lab()
            with self.subTest(field=field), self.assertRaisesRegex(RuntimeError, "ownership"):
                self.execute()
            self.lab["vms"][0][field] = original
        self.save_lab()
        self.configs[100]["description"] = "foreign"
        with self.assertRaisesRegex(RuntimeError, "ownership"):
            self.execute()
        self.assertEqual(self.events, [])

    def test_host_changes_after_preflight_block_vm_mutations(self):
        responses = iter([self.host_plan, {**self.host_plan, "sha256": "e" * 64}])
        self.host_ssh.run.side_effect = lambda *args, **kwargs: json.dumps(next(responses))
        with self.assertRaisesRegex(RuntimeError, "Host configuration changed"):
            self.execute()
        self.assertEqual(self.events, [])


if __name__ == "__main__":
    unittest.main()
