import importlib.util
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location(
    "release_cleanup_inventory", ROOT / "diag/release_cleanup_inventory.py")
inventory = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(inventory)


class ReleaseCleanupVerificationTests(unittest.TestCase):
    def setUp(self):
        hosts = [{"node": "node1", "host_id": "cluster-node1"}]
        self.run = SimpleNamespace(
            state={
                "prefix": "sf-dr-" + "a" * 20, "cleanup_status": "complete",
                "cleanup_verified_hosts": hosts,
                "controllers": [{"vmid": 100, "name": "owned-controller"}],
                "router": {"vmid": 200, "name": "owned-router"},
                "workload_identity": {"hosts": hosts, "vms": [], "tenants": [
                    {"routing_table": 130000, "conntrack_zone": 30000},
                ]},
            },
            config={"vtep_ip_range_cidr": "172.20.0.0/24", "proxmox_ssh_key": "/key",
                    "proxmox_ssh_user": "root"},
            proxmox=mock.Mock(),
        )
        self.run.proxmox.get.return_value = {"data": [{"vmid": 900, "name": "foreign"}]}

    def test_absent_saved_vms_and_clean_hosts_produce_verification(self):
        with mock.patch.object(inventory.recovery, "SSHCommandRunner") as ssh:
            ssh.return_value.run.return_value = "SWIFTFABRIC_HOST_CLEAN\n"
            report = inventory.verify_cleanup(self.run)
        self.assertEqual(report["owned_vms_remaining"], [])
        self.assertEqual(report["verified_hosts"], self.run.state["cleanup_verified_hosts"])
        self.assertEqual(ssh.return_value.run.call_args.args[0], "node1")

    def test_remaining_or_reused_vm_and_host_residuals_reject_verification(self):
        for vm in ({"vmid": 100, "name": "changed"}, {"vmid": 900, "name": "owned-router"}):
            self.run.proxmox.get.return_value = {"data": [vm]}
            with self.assertRaisesRegex(RuntimeError, "remains or its identity was reused"):
                inventory.verify_cleanup(self.run)
        self.run.proxmox.get.return_value = {"data": []}
        with mock.patch.object(inventory.recovery, "SSHCommandRunner") as ssh:
            ssh.return_value.run.return_value = "residuals"
            with self.assertRaisesRegex(RuntimeError, "residuals"):
                inventory.verify_cleanup(self.run)
