import argparse
import importlib.util
from pathlib import Path
import subprocess
import sys
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).parents[1]))
SPEC = importlib.util.spec_from_file_location(
    "nsr_repository_access", Path(__file__).parents[1] / "nsr_repository_access.py",
)
diag = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(diag)


class RepositoryTests(unittest.TestCase):
    def test_shell_syntax_and_read_only_probes(self):
        subprocess.run(["sh", "-n"], input=diag.PROGRAM, text=True, check=True)
        self.assertIn("timeout 8 bash", diag.PROGRAM)
        self.assertIn("ip -4 route get", diag.PROGRAM)
        self.assertNotIn("apt-get", diag.PROGRAM)
        self.assertNotIn("nft add", diag.PROGRAM)
        self.assertNotIn("nft delete", diag.PROGRAM)
        self.assertNotIn("systemctl stop", diag.PROGRAM)

    def test_router_identity_and_owner_marker_required(self):
        router = {"id": "owned", "name": "owned", "vmid": 109,
                  "node": "host1", "deployment_mode": "standalone"}
        config = {"name": "owned", "description": "SwiftFabric N/S router owned member a",
                  "tags": "swiftfabric_owner_" + "a" * 64}
        run = argparse.Namespace(
            state={"router": {key: router[key] for key in ("id", "name", "vmid")}},
            proxmox=mock.Mock(),
        )
        run.proxmox.get.return_value = {"data": config}
        self.assertEqual(diag.owned_router_path(run, router), "host1")
        for changes in ({"name": "foreign"}, {"tags": ""},
                        {"description": "foreign"}):
            run.proxmox.get.return_value = {"data": {**config, **changes}}
            with self.assertRaisesRegex(RuntimeError, "ownership changed"):
                diag.owned_router_path(run, router)
        with self.assertRaisesRegex(RuntimeError, "identity changed"):
            diag.owned_router_path(run, {**router, "vmid": 110})


if __name__ == "__main__":
    unittest.main()
