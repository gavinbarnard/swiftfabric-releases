import json
import io
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python_installer" / "tests_integration"))
sys.path.insert(0, str(ROOT / "diag"))
import nsr_ha as ha
import nsr_controller_loss as outage
from nsr_transport import DirectMembers


PUBLIC = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIGzBtfJudR02pgXBHjR0DaTvYbMcBODu1hcNQ7Y2JJ0A"
FINGERPRINT = ha.deployment.SSHCommandRunner._fingerprint(PUBLIC.split()[1])


def view(member="a", owner="a", term=3):
    return {
        "router_id": "owned", "member": member, "updated_at_ms": 1000,
        "role": "active" if member == owner else "standby",
        "pair": {"owner": owner, "term": term, "peer_heard": True, "peer_silent_ms": 1},
        "policy_from_cache": True,
        "reachability": {"management_reachable": True, "gateway": {"reachable": True},
                         "controllers": [{"reachable": False}]},
        "witness": {"exchanged": True, "last_failure": None, "peer_recently_forwarding": False},
    }


class DirectTransportTests(unittest.TestCase):
    def run_fixture(self, directory):
        run = SimpleNamespace(
            directory=Path(directory),
            state={"router_requested": "owned", "pair": {
                member: {"management_address_cidr": f"192.0.2.{10 + index}/24"}
                for index, member in enumerate(("a", "b"))
            }, "guest_ssh_fingerprints": {"a": FINGERPRINT, "b": FINGERPRINT}},
            owned_member_path=mock.Mock(return_value="/owned"),
            run_owned_guest=mock.Mock(return_value=""),
        )

        def candidate(method, path):
            member = path[-1]
            address = "192.0.2.10" if member == "a" else "192.0.2.11"
            return {"changed": False, "trusted": {
                "endpoint": f"[{address}]:22", "fingerprint": FINGERPRINT, "public_key": PUBLIC,
            }}

        run.api = SimpleNamespace(
            json=mock.Mock(side_effect=candidate), ssh=ha.deployment.SSHCommandRunner,
        )
        return run

    def local_process(self, command, **kwargs):
        if command[0] == "ssh-keygen":
            key = Path(command[-1])
            key.write_text("test-only")
            key.chmod(0o600)
            key.with_suffix(".pub").write_text(PUBLIC)
            return subprocess.CompletedProcess(command, 0)
        self.assertEqual(command[:3], ["ssh", "-F", "/dev/null"])
        self.assertIn("StrictHostKeyChecking=yes", command)
        self.assertIn("IdentityAgent=none", command)
        self.assertIn("GlobalKnownHostsFile=/dev/null", command)
        pin = next(value.split("=", 1)[1] for value in command if value.startswith("UserKnownHostsFile="))
        self.assertEqual(Path(pin).stat().st_mode & 0o777, 0o600)
        self.assertIn(PUBLIC, Path(pin).read_text())
        output = "direct-ready\n" if "direct-ready" in kwargs["input"] else ""
        return subprocess.CompletedProcess(command, 0, stdout=output, stderr="")

    def test_pins_ownership_and_authorization_cleanup_without_controller_access(self):
        with tempfile.TemporaryDirectory() as directory:
            run = self.run_fixture(directory)
            with mock.patch("nsr_transport.subprocess.run", side_effect=self.local_process):
                with DirectMembers(run) as direct:
                    run.api.json.side_effect = AssertionError("controller contacted during outage")
                    direct.execute("a", "printf hello")
                    self.assertIn(PUBLIC, run.run_owned_guest.call_args_list[0].args[1])
                    self.assertIn("sync -f /home/ubuntu/.ssh/authorized_keys",
                                  run.run_owned_guest.call_args_list[0].args[1])
                    self.assertEqual(direct.directory.stat().st_mode & 0o777, 0o700)
                self.assertEqual(list(Path(directory).iterdir()), [])
            self.assertGreaterEqual(run.owned_member_path.call_count, 7)

    def test_changed_pin_and_ownership_changes_refuse_authorization(self):
        for fault in ("pin", "ownership", "fingerprint"):
            with self.subTest(fault=fault), tempfile.TemporaryDirectory() as directory:
                run = self.run_fixture(directory)
                if fault == "ownership":
                    run.owned_member_path.side_effect = RuntimeError("foreign member")
                else:
                    candidate = run.api.json("GET", "a")
                    if fault == "pin":
                        candidate["changed"] = True
                    else:
                        candidate["trusted"]["public_key"] = PUBLIC.replace("JJ0A", "JJ0B")
                    run.api.json.side_effect = None
                    run.api.json.return_value = candidate
                with mock.patch("nsr_transport.subprocess.run", side_effect=self.local_process):
                    with self.assertRaises(RuntimeError):
                        with DirectMembers(run):
                            self.fail("unsafe direct transport admitted")
                run.run_owned_guest.assert_not_called()
                self.assertEqual(list(Path(directory).iterdir()), [])

    def test_partial_authorization_failure_removes_added_key(self):
        with tempfile.TemporaryDirectory() as directory:
            run = self.run_fixture(directory)
            run.run_owned_guest.side_effect = [None, RuntimeError("second authorization failed")]
            commands = []

            def execute(command, **kwargs):
                commands.append(kwargs.get("input", ""))
                return self.local_process(command, **kwargs)

            with mock.patch("nsr_transport.subprocess.run", side_effect=execute):
                with self.assertRaisesRegex(RuntimeError, "second authorization"):
                    with DirectMembers(run):
                        pass
            self.assertEqual(sum("awk -v key=" in command for command in commands), 2)
            self.assertEqual(list(Path(directory).iterdir()), [])

    def test_failed_cleanup_retains_owner_only_key_and_reports_error(self):
        with tempfile.TemporaryDirectory() as directory:
            run = self.run_fixture(directory)
            with mock.patch("nsr_transport.subprocess.run", side_effect=self.local_process):
                direct = DirectMembers(run).__enter__()
                with mock.patch.object(direct, "execute", side_effect=RuntimeError("unreachable")):
                    with self.assertRaisesRegex(RuntimeError, "private transport retained"):
                        direct.close()
                self.assertTrue(direct.key.exists())
                self.assertEqual(direct.directory.stat().st_mode & 0o777, 0o700)
                direct.close()
            self.assertEqual(list(Path(directory).iterdir()), [])


class ControllerLossTests(unittest.TestCase):
    def test_double_failover_preserves_both_legs_and_waits_for_replication(self):
        run = SimpleNamespace()
        report = {}
        order = []

        def crash(run, owner, term, leg, save, **kwargs):
            order.append(("crash", owner, term))
            self.assertTrue(kwargs["serial_diagnostics"])
            self.assertEqual(kwargs["traffic_label"], f"controller-free-after-{owner}-crash")
            leg["successor"] = {"member": ha.other(owner), "term": term + 1}
            leg["fault"] = {"member": owner}
            leg["offline_takeover_new_traffic"] = {"passed": True}

        def replication(run, owner, term, leg, save):
            order.append(("replication", owner, term))

        with mock.patch.object(outage, "offline_crash", side_effect=crash), \
                mock.patch.object(outage, "wait_replication", side_effect=replication):
            outage.double_failover(run, "a", 3, report, mock.Mock())
        self.assertEqual(order, [
            ("crash", "a", 3), ("replication", "b", 4),
            ("crash", "b", 4), ("replication", "a", 5),
        ])
        self.assertEqual(report["successor"], {"member": "a", "term": 5})
        self.assertTrue(all(leg["passed"] for leg in report["failovers"]))

    def test_second_crash_refused_until_first_rejoin_replication_is_ready(self):
        report = {}

        def crash(run, owner, term, leg, save, **kwargs):
            leg["successor"] = {"member": "b", "term": 4}

        with mock.patch.object(outage, "offline_crash", side_effect=crash) as stop, \
                mock.patch.object(outage, "wait_replication", side_effect=TimeoutError("not synchronized")):
            with self.assertRaisesRegex(TimeoutError, "not synchronized"):
                outage.double_failover(SimpleNamespace(), "a", 3, report, mock.Mock())
        stop.assert_called_once()
        self.assertFalse(report["failovers"][0]["passed"])

    def test_replication_gate_requires_both_connected_and_stable_ownership(self):
        run = SimpleNamespace()
        statuses = [
            {**view("a", "b", 4), "replication": {"receiver": {"connected": False}}},
            {**view("b", "b", 4), "replication": {"sender": {"connected": True}}},
            {**view("a", "b", 4), "replication": {"receiver": {"connected": True}}},
            {**view("b", "b", 4), "replication": {"sender": {"connected": True}}},
        ]
        with mock.patch.object(outage, "guest_view", side_effect=statuses), \
                mock.patch.object(outage.time, "sleep") as sleep:
            report = {}
            outage.wait_replication(run, "b", 4, report, mock.Mock())
        sleep.assert_called_once()
        self.assertEqual(set(report["replication_after_rejoin"]), {"a", "b"})

    def test_inspection_excludes_router_credentials_and_refuses_foreign_identity(self):
        run = SimpleNamespace(
            state={"router_requested": "owned"},
            router=mock.Mock(return_value={
                "id": "owned", "name": "owned", "status": "failed",
                "status_message": "missing conntrack", "ssh_private_key": "do-not-print",
                "runtime_api_token": "do-not-print",
            }),
        )
        with mock.patch("sys.stdout", new_callable=io.StringIO) as output:
            outage.inspect_run(run)
        projection = json.loads(output.getvalue())
        self.assertEqual(projection["status_message"], "missing conntrack")
        self.assertNotIn("do-not-print", output.getvalue())
        self.assertNotIn("ssh_private_key", projection)
        run.router.return_value["id"] = "foreign"
        with self.assertRaisesRegex(RuntimeError, "identity changed"):
            outage.inspect_run(run)

    def test_controller_free_crash_promotes_and_rejoins_without_preemption(self):
        run = SimpleNamespace(power_member=mock.Mock(), held_traffic=mock.Mock(return_value={"passed": True}))
        report = {}

        def status(run, member):
            return view(member, "b", 4)

        with mock.patch.object(outage, "guest_view", side_effect=status), \
                mock.patch.object(ha, "REJOIN_OBSERVATION_SECONDS", 0):
            outage.offline_crash(run, "a", 3, report, mock.Mock())
        self.assertEqual(run.power_member.call_args_list, [mock.call("a", "stop"), mock.call("a", "start")])
        self.assertEqual(report["successor"]["member"], "b")
        self.assertEqual(report["successor"]["term"], 4)
        run.held_traffic.assert_called_once_with("controller-free-after-takeover", 10)

    def test_rebooted_member_may_stay_fenced_until_cached_policy_applies(self):
        run = SimpleNamespace(power_member=mock.Mock(), held_traffic=mock.Mock(return_value={"passed": True}))
        fenced = {**view("a", "b", 4), "role": "fenced"}
        views = iter([view("b", "b", 4), fenced, view("b", "b", 4), view("a", "b", 4), view("b", "b", 4)])
        with mock.patch.object(outage, "guest_view", side_effect=lambda *_: next(views)), \
                mock.patch.object(outage.time, "sleep"), \
                mock.patch.object(ha, "REJOIN_OBSERVATION_SECONDS", 0):
            outage.offline_crash(run, "a", 3, {}, mock.Mock())
        run.held_traffic.assert_called_once_with("controller-free-after-takeover", 10)

    def test_failed_offline_promotion_restores_original_active(self):
        run = SimpleNamespace(power_member=mock.Mock(), owned_member_path=mock.Mock(return_value="/owned"),
                              proxmox=mock.Mock())
        run.proxmox.get.return_value = {"data": {"status": "stopped"}}
        report = {}
        ticks = iter(range(0, 100, 2))
        with mock.patch.object(outage.time, "monotonic", side_effect=lambda: next(ticks)), \
                mock.patch.object(outage.time, "sleep"), \
                mock.patch.object(outage, "guest_view", return_value=view("b")):
            with self.assertRaisesRegex(TimeoutError, "ten seconds"):
                outage.offline_crash(run, "a", 3, report, mock.Mock())
        self.assertEqual(run.power_member.call_args_list, [mock.call("a", "stop"), mock.call("a", "start")])

    def test_returning_former_active_cannot_preempt(self):
        run = SimpleNamespace(power_member=mock.Mock())
        reports = [view("b", "b", 4), view("a", "a", 3), view("b", "b", 4)]
        with mock.patch.object(outage, "guest_view", side_effect=reports):
            with self.assertRaisesRegex(RuntimeError, "preempted"):
                outage.offline_crash(run, "a", 3, {}, mock.Mock())
        self.assertEqual(run.power_member.call_args_list, [mock.call("a", "stop"), mock.call("a", "start")])

    def test_guest_clock_freshness_identity_and_future_status(self):
        run = SimpleNamespace(state={"router_requested": "owned"}, run_owned_guest=mock.Mock())
        for clock, updated, passed in ((1000, 1000, True), (11000, 1000, True),
                                       (11001, 1000, False), (999, 1000, False)):
            with self.subTest(clock=clock, updated=updated):
                run.run_owned_guest.return_value = json.dumps({**view(), "updated_at_ms": updated}) + f"\n{clock}\n"
                if passed:
                    self.assertEqual(outage.guest_view(run, "a")["updated_at_ms"], updated)
                else:
                    with self.assertRaisesRegex(RuntimeError, "stale or future"):
                        outage.guest_view(run, "a")
        run.run_owned_guest.return_value = json.dumps({**view(), "router_id": "foreign"}, indent=1) + "\n1000"
        with self.assertRaisesRegex(RuntimeError, "another router"):
            outage.guest_view(run, "a")

    def test_offline_gate_requires_gateway_cached_policy_expired_witness_and_stable_pair(self):
        outage.require_view(view(), "a", "a", 3)
        for fault in ("gateway", "controllers", "witness", "cache", "role", "term", "peer"):
            with self.subTest(fault=fault):
                value = view()
                if fault == "gateway":
                    value["reachability"]["gateway"]["reachable"] = False
                elif fault == "controllers":
                    value["reachability"]["controllers"][0]["reachable"] = True
                elif fault == "witness":
                    value["witness"]["peer_recently_forwarding"] = True
                elif fault == "cache":
                    value["policy_from_cache"] = False
                elif fault == "role":
                    value["role"] = "standby"
                elif fault == "term":
                    value["pair"]["term"] = 4
                else:
                    value["pair"]["peer_silent_ms"] = 5000
                with self.assertRaises(RuntimeError):
                    outage.require_view(value, "a", "a", 3)

    def test_all_controllers_restored_when_outage_body_fails(self):
        controllers = [{"name": "one"}, {"name": "two"}, {"name": "three"}]
        run = SimpleNamespace(platform_health=mock.Mock(), proxmox=mock.Mock())
        power = {item["name"]: "running" for item in controllers}

        def post(path):
            name, _, action = path.strip("/").split("/")
            power[name] = "stopped" if action == "stop" else "running"
            return "task"

        run.proxmox.post.side_effect = post
        run.proxmox.get.side_effect = lambda path: {"data": {"status": power[path.split("/")[1]]}}
        guard = run.platform_health
        report = {}
        with mock.patch("nsr_ha_vip.controller_path", side_effect=lambda run, item: "/" + item["name"]), \
                mock.patch.object(ha.deployment, "wait_task"), \
                mock.patch.object(outage, "healthy_return") as restored:
            with self.assertRaisesRegex(RuntimeError, "injected test failure"):
                with outage.controllers_absent(run, controllers, report, mock.Mock()):
                    guard.close.assert_called_once()
                    self.assertIsNone(run.platform_health)
                    self.assertEqual(set(power.values()), {"stopped"})
                    raise RuntimeError("injected test failure")
            restored.assert_called_once()
        self.assertEqual(set(power.values()), {"running"})
        self.assertEqual(report["restoration_errors"], [])

    def test_partial_stop_failure_also_restores_attempted_controllers(self):
        controllers = [{"name": "one"}, {"name": "two"}, {"name": "three"}]
        run = SimpleNamespace(platform_health=mock.Mock(), proxmox=mock.Mock())
        run.proxmox.get.return_value = {"data": {"status": "stopped"}}
        run.proxmox.post.side_effect = ["task", RuntimeError("stop failed"), "task", "task"]
        report = {}
        # Restoration status must prove both attempted controllers running.
        run.proxmox.get.side_effect = [
            {"data": {"status": "stopped"}}, {"data": {"status": "stopped"}},
            {"data": {"status": "running"}}, {"data": {"status": "stopped"}},
            {"data": {"status": "running"}},
        ]
        with mock.patch("nsr_ha_vip.controller_path", side_effect=lambda run, item: "/" + item["name"]), \
                mock.patch.object(ha.deployment, "wait_task"), \
                mock.patch.object(outage, "healthy_return"):
            with self.assertRaisesRegex(RuntimeError, "stop failed"):
                with outage.controllers_absent(run, controllers, report, mock.Mock()):
                    self.fail("partial outage should not be admitted")
        self.assertEqual([call.args[0] for call in run.proxmox.post.call_args_list],
                         ["/one/status/stop", "/two/status/stop", "/one/status/start", "/two/status/start"])

    def test_one_failed_restoration_does_not_skip_other_controllers(self):
        controllers = [{"name": "one"}, {"name": "two"}, {"name": "three"}]
        run = SimpleNamespace(platform_health=mock.Mock(), proxmox=mock.Mock())
        run.proxmox.get.side_effect = [
            {"data": {"status": "stopped"}} for _ in controllers
        ] + [
            {"data": {"status": "unknown"}},
            {"data": {"status": "stopped"}}, {"data": {"status": "running"}},
            {"data": {"status": "stopped"}}, {"data": {"status": "running"}},
        ]
        report = {}
        with mock.patch("nsr_ha_vip.controller_path", side_effect=lambda run, item: "/" + item["name"]), \
                mock.patch.object(ha.deployment, "wait_task"), \
                mock.patch.object(outage, "healthy_return") as restored:
            with self.assertRaisesRegex(RuntimeError, "controller restoration incomplete"):
                with outage.controllers_absent(run, controllers, report, mock.Mock()):
                    pass
            restored.assert_not_called()
        self.assertIn("one", report["restoration_errors"][0])
        self.assertEqual([call.args[0] for call in run.proxmox.post.call_args_list][-2:],
                         ["/two/status/start", "/three/status/start"])

    def test_probe_cleanup_runs_after_fault_before_result_collection(self):
        run = SimpleNamespace(start_probes=mock.Mock(), wait_established=mock.Mock(),
                              stop_probes=mock.Mock(return_value={"stopped": True}))
        report = {}
        with self.assertRaisesRegex(RuntimeError, "fault failed"):
            with outage.original_sockets(run, "vm", [], "/private/probes", "unit", report, mock.Mock()):
                raise RuntimeError("fault failed")
        run.stop_probes.assert_called_once_with("vm", "unit")
        self.assertTrue(report["probe_cleanup"]["stopped"])

    def test_cli_wires_explicit_saved_action_and_rejects_conflicting_faults(self):
        with mock.patch.object(ha, "with_saved_run") as saved, \
                mock.patch.object(ha, "automated_ssh_tofu"):
            self.assertEqual(ha.main(["--test-controller-loss", "--state", "/owned/run"]), 0)
            self.assertEqual(saved.call_args.kwargs["action_name"], "controller-cluster-loss")
            self.assertIs(saved.call_args.args[1], outage.run_gate)
        with mock.patch("sys.stderr"), self.assertRaises(SystemExit):
            ha.main(["--test-controller-loss", "--test-vip", "--state", "/owned/run"])

    def test_held_worker_accepts_thirty_minutes_but_rejects_longer(self):
        guest = ha.importlib.import_module("guest")
        case = {
            "protocol": "tcp", "duration_seconds": 1800, "source": "127.0.0.1",
            "source_port": 22000, "destination": "127.0.0.1", "destination_port": 22001,
            "expected_nat_address": "127.0.0.1",
        }
        with mock.patch.object(guest.socket, "socket", side_effect=OSError("test socket unavailable")) as socket:
            result = guest.hold_flow(case)
            socket.assert_called_once()
            self.assertIn("test socket unavailable", result["error"])
        with self.assertRaisesRegex(ValueError, "1-1800"):
            guest.hold_flow({**case, "duration_seconds": 1801})


if __name__ == "__main__":
    unittest.main()
