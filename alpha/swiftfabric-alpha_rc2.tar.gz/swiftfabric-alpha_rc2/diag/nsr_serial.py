"""Proxmox serial diagnostics for owned retained NSR HA lab members."""

from pathlib import Path
import secrets
import shlex
import subprocess
import time

from nsr_console_access import crypt_hash, lock_program, set_program, write_private


DIAGNOSTICS = r"""set -eu
echo '--- boot'; cat /proc/sys/kernel/random/boot_id; uptime; cat /proc/cmdline
echo '--- services'; systemctl --failed --no-pager
echo '--- management'; ip -br -4 addr; ip -4 route; ip -4 neigh
echo '--- SSH'; ss -ltn; systemctl status ssh --no-pager || true
echo '--- router namespace'
if ip netns list | grep -q '^sf-router '; then
    sudo -n ip netns exec sf-router ip -br -4 addr
    sudo -n ip netns exec sf-router ip -4 route show table all
fi
echo '--- journal'
sudo -n journalctl -b --no-pager -o short-unix -n 200 \
    -u 'swiftfabric-router*' -u swiftfabric-host-agent -u ssh -u systemd-networkd
"""


def prepare(run, member):
    path = run.owned_member_path(member)
    config = run.proxmox.get(path + "/config")["data"]
    if config.get("serial0") not in (None, "socket"):
        raise RuntimeError("owned NSR serial0 already has a different configuration")
    if config.get("serial0") is None:
        run.proxmox.put(path + "/config", {"serial0": "socket"})
    if run.proxmox.get(path + "/config")["data"].get("serial0") != "socket":
        raise RuntimeError("NSR serial socket was not configured")
    password_file = run.directory / f"console-password-{member}"
    if password_file.exists():
        raise RuntimeError("NSR console password already exists; refusing to replace it")
    status = run.run_owned_guest(member, "passwd -S ubuntu", timeout=30).split()
    if len(status) < 2 or status[:2] != ["ubuntu", "L"]:
        raise RuntimeError("temporary NSR serial access requires an initially locked ubuntu password")
    password = secrets.token_urlsafe(18)
    write_private(password_file, password + "\n")
    run.run_owned_guest(
        member, set_program(crypt_hash(password))
        + "systemctl enable --now serial-getty@ttyS0.service\n"
        + "systemctl is-active --quiet serial-getty@ttyS0.service\n",
        timeout=30,
    )
    return password_file


def execute(run, member, command, *, timeout=60):
    import nsr_ha as ha

    class MemberConsole(ha.networking.LiveLab):
        def __init__(self):
            self.config = run.lab.config
            self.proxmox = run.proxmox
            self.state = {
                "console_password": (run.directory / f"console-password-{member}").read_text().strip(),
            }

        def vm_config(self, vm):
            path = run.owned_member_path(member)
            config = self.proxmox.get(path + "/config")["data"]
            if config.get("serial0") != "socket":
                raise RuntimeError("owned NSR has no serial socket")
            return config

    physical = run.state["pair"][member]
    vm = {key: physical[key] for key in ("node", "vmid")}
    return MemberConsole().serial(vm, command, timeout=timeout)


def capture(run, member, report, save):
    output = run.directory / f"serial-{member}-{time.time_ns()}.txt"
    receipt = {"member": member, "requested_epoch": time.time(), "output": str(output)}
    report.setdefault("serial_diagnostics", []).append(receipt)
    try:
        write_private(output, execute(run, member, DIAGNOSTICS))
        receipt["captured"] = True
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as failure:
        receipt.update(captured=False, error=str(failure))
    finally:
        save()
    return receipt


class SerialMembers:
    """Temporary console passwords; no guest SSH password login or unlocked getty."""

    def __init__(self, run):
        self.run = run
        self.members = []

    def __enter__(self):
        try:
            for member in ("a", "b"):
                # Track before mutation so partial setup can still be re-locked.
                if (self.run.directory / f"console-password-{member}").exists():
                    raise RuntimeError("existing NSR console password; refusing replacement")
                self.members.append(member)
                prepare(self.run, member)
                if execute(self.run, member, "printf 'serial-ready\\n'", timeout=60).strip() != "serial-ready":
                    raise RuntimeError("NSR serial readiness check failed")
            return self
        except (OSError, ValueError, RuntimeError, subprocess.SubprocessError, KeyboardInterrupt) as failure:
            try:
                self.close()
            except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as cleanup:
                raise RuntimeError(f"NSR serial setup failed: {failure}; cleanup failed: {cleanup}") from failure
            raise

    def close(self):
        failures = []
        for member in self.members:
            password = self.run.directory / f"console-password-{member}"
            if not password.exists():
                continue
            try:
                execute(self.run, member, "sudo -n sh -c " + shlex.quote(lock_program()), timeout=60)
                password.unlink()
            except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as failure:
                failures.append(f"{member}: {failure}")
        if failures:
            raise RuntimeError("NSR console cleanup failed; owner-only passwords retained: " + "; ".join(failures))

    def __exit__(self, kind, value, traceback):
        self.close()


def main(argv=None):
    import argparse
    import sys

    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root / "python_installer" / "tests_integration"))
    import nsr_ha as ha

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", type=Path, required=True)
    parser.add_argument("--member", choices=("a", "b"), required=True)
    parser.add_argument("--prepare", action="store_true", help="enable temporary authenticated console access")
    args = parser.parse_args(argv)

    def check(run):
        if args.prepare:
            print(f"Private console password: {prepare(run, args.member)}")
        report = {}
        receipt = capture(run, args.member, report, lambda: None)
        if not receipt["captured"]:
            raise RuntimeError("NSR serial capture failed: " + receipt["error"])
        print(receipt["output"])

    with ha.automated_ssh_tofu():
        ha.with_saved_run(args.state, check, action_name="ha-serial")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
