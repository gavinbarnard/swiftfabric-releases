#!/usr/bin/env python3
"""Deploy, inspect, and remove the SwiftFabric PostgreSQL demo lab.

Layout (segment IDs shift with --first-segment-id; /24s are carved from --subnet-start):
  5000, 5001  Config A: each has 1 PostgreSQL DB + 5 clients (same-segment L2 over VTEP unicast)
  5002        Config B clients: 8 clients querying both databases in 5003
  5003        Config B databases: 2 PostgreSQL DBs; mirrored East/West ACLs allow 5002 <-> 5003 TCP 5432 + ICMP
  5004        North/South demo: 3 idle VMs, left unattached for a live NSR attach during the demo
  5005-5008   Second tenant: replicas of 5000-5003 (Config A and Config B) reusing the same
              overlapping subnets and VM addresses, isolated in a newly created tenant
A standalone North/South router is deployed from nsr.json with an empty WAN policy and no
segments attached; it is lent to the second tenant only while its databases install PostgreSQL.
Every VM console login is ubuntu / ubuntu.
"""

import argparse
import concurrent.futures
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import shlex
import socket
import sys
import threading
import time
import tempfile
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "network-lab"))
from lab import LabAPIError, LiveLab, acl_rule, encode, private_write  # noqa: E402
from main import load_deployment_config  # noqa: E402  (path added by lab)
from proxmox.client import ProxmoxAPIError  # noqa: E402

CONSOLE_USER = "ubuntu"
CONSOLE_PASSWORD = "ubuntu"
GUEST_SCRIPT = Path(__file__).with_name("demo_guest.py")
GUEST_PATH = "/opt/sf-demo/demo_guest.py"
POSTGRES_PORT = 5432
DB_USER = "demo"
DB_NAME = "demo"
DEFAULT_STATE = Path.home() / ".local/state/swiftfabric/demo-lab"
DEFAULT_IMAGE = "import/ubuntu-resolute-server-cloudimg-amd64.qcow2"
WAN_POLICY_KEYS = (
    "wan_ingress_rules", "wan_egress_rules", "inbound_port_mappings", "outbound_port_mappings",
    "masquerade_source_cidrs",
)
EMPTY_WAN_POLICY = {key: [] for key in WAN_POLICY_KEYS}
PUBLIC_DNS = ("8.8.8.8", "1.1.1.1")
PARALLEL_WORKERS = 6
ROUTER_RETRIES = 2
STORAGE_ATTEMPTS = 5
STORAGE_RETRY_SECONDS = 10
SIZES = {"db": (2, 2048, "12G"), "client": (1, 1024, None), "idle": (1, 1024, None)}
SEGMENT_ROLES = (
    ("a1", "demo-a-l2", "Config A: 1 PostgreSQL DB + 5 clients on one segment (L2 VTEP unicast)"),
    ("a2", "demo-a-l2", "Config A: 1 PostgreSQL DB + 5 clients on one segment (L2 VTEP unicast)"),
    ("b-clients", "demo-b-clients", "Config B: 8 PostgreSQL clients routed East/West to the DB segment"),
    ("b-db", "demo-b-db", "Config B: 2 PostgreSQL DBs reachable from the client segment via ACLs"),
    ("ns", "demo-ns", "North/South demo: idle VMs; attach a North/South router live"),
)
DEFAULT_TENANT = "default"
SECOND_TENANT = "second"
# The second tenant replicates Config A and Config B on the same (overlapping) subnets.
SECOND_TENANT_ROLES = ("a1", "a2", "b-clients", "b-db")
SUBNET_COUNT = len(SEGMENT_ROLES)
SEGMENT_COUNT = SUBNET_COUNT + len(SECOND_TENANT_ROLES)
TENANT_NAME = re.compile(r"[A-Za-z0-9_.-](?:[A-Za-z0-9 _.-]{0,62}[A-Za-z0-9_.-])?")


def segment_layout():
    layout = [(DEFAULT_TENANT, index, role, prefix, description)
              for index, (role, prefix, description) in enumerate(SEGMENT_ROLES)]
    layout += [(SECOND_TENANT, index, role, f"demo-t2-{prefix.removeprefix('demo-')}",
                f"Tenant 2 {description}")
               for index, (role, prefix, description) in enumerate(SEGMENT_ROLES)
               if role in SECOND_TENANT_ROLES]
    return layout


def build_plan(first_id, subnet_start, supernet, nodes, run_id, db_password):
    supernet = ipaddress.ip_network(supernet)
    first = ipaddress.ip_network(subnet_start)
    if first.version != 4 or supernet.version != 4 or first.prefixlen != 24:
        raise ValueError("--subnet-start must be an IPv4 /24 inside an IPv4 --supernet")
    if not 5000 <= first_id <= 50001 - SEGMENT_COUNT:
        raise ValueError("segment IDs must stay within 5000-50000")
    segments = []
    for position, (tenant, index, role, prefix, description) in enumerate(segment_layout()):
        network = ipaddress.ip_network((int(first.network_address) + 256 * index, 24))
        if not network.subnet_of(supernet):
            raise ValueError(f"{network} falls outside supernet {supernet}")
        segment_id = first_id + position
        segments.append({
            "role": role, "tenant": tenant, "id": segment_id, "name": f"{prefix}-{segment_id}",
            "network": str(network), "gateway_cidr": f"{network.network_address + 1}/24",
            "description": description, "created": False, "create_requested": False,
            # The second tenant's ID is assigned by the controller when it is created.
            **({"tenant_id": DEFAULT_TENANT} if tenant == DEFAULT_TENANT else {}),
        })

    def host(segment, offset):
        return str(ipaddress.ip_network(segment["network"]).network_address + offset)

    vms = []

    def add(segment, name, kind, offset, **extra):
        vms.append({
            "name": name, "kind": kind, "segment_id": segment["id"],
            "address": host(segment, offset), "gateway": segment["gateway_cidr"].split("/")[0],
            "vmid": None, "node": None, "created": False, "bootstrapped": False,
            "db_ready": False, "client_started": False, **extra,
        })

    for tenant, name in ((DEFAULT_TENANT, "demo"), (SECOND_TENANT, "demo-t2")):
        by_role = {segment["role"]: segment for segment in segments if segment["tenant"] == tenant}
        for number, role in ((1, "a1"), (2, "a2")):
            segment = by_role[role]
            add(segment, f"{name}-a{number}-db", "db", 10, allow_networks=[segment["network"]])
            for client in range(1, 6):
                add(segment, f"{name}-a{number}-client{client}", "client", 100 + client,
                    servers=[host(segment, 10)])
        clients, databases = by_role["b-clients"], by_role["b-db"]
        for number in (1, 2):
            add(databases, f"{name}-b-db{number}", "db", 9 + number, allow_networks=[clients["network"]])
        for client in range(1, 9):
            add(clients, f"{name}-b-client{client}", "client", 100 + client,
                servers=[host(databases, 10), host(databases, 11)])
        if "ns" in by_role:
            for number in (1, 2, 3):
                add(by_role["ns"], f"{name}-ns-vm{number}", "idle", 9 + number)
    # Spread each segment over every host so same-segment traffic crosses VTEP unicast tunnels.
    for index, segment in enumerate(segments):
        members = [vm for vm in vms if vm["segment_id"] == segment["id"]]
        for position, vm in enumerate(members):
            vm["node"] = nodes[(position + index) % len(nodes)]
    return {"segments": segments, "vms": vms, "run_id": run_id, "db_password": db_password}


def segment_tenant(segment):
    return segment.get("tenant", DEFAULT_TENANT)


def b_acls(segments):
    result = {}
    for tenant in dict.fromkeys(segment_tenant(segment) for segment in segments):
        by_role = {segment["role"]: segment for segment in segments if segment_tenant(segment) == tenant}
        if "b-clients" not in by_role or "b-db" not in by_role:
            continue
        clients, databases = by_role["b-clients"]["network"], by_role["b-db"]["network"]
        requests = [
            acl_rule(clients, databases, "tcp", str(POSTGRES_PORT)),
            acl_rule(clients, databases, "icmp"),
        ]
        replies = [
            acl_rule(databases, clients, "tcp", source_port=str(POSTGRES_PORT)),
            acl_rule(databases, clients, "icmp"),
        ]
        # Mirrored on both segments so either host's forward path admits each direction explicitly.
        result[by_role["b-clients"]["id"]] = {"egress": requests, "ingress": replies}
        result[by_role["b-db"]["id"]] = {"egress": replies, "ingress": requests}
    return result


def attached_router(segment):
    attachment = segment.get("north_south_router")
    return attachment.get("id") if isinstance(attachment, dict) else attachment


def deployer_source(controller_ip):
    """Local IPv4 address the kernel uses to reach the controller/management network."""
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
        probe.connect((controller_ip, 22))
        return probe.getsockname()[0]


def merge_allowlist(allowlist, *extra):
    networks = [ipaddress.ip_network(cidr, strict=False) for cidr in allowlist]
    for cidr in extra:
        candidate = ipaddress.ip_network(cidr, strict=False)
        if not any(candidate.subnet_of(network) for network in networks):
            networks.append(candidate)
    return [str(network) for network in networks]


def router_request(nsr_config, config, router_id, node, image_volume, allowlist, console_password):
    wan = ipaddress.IPv4Interface(nsr_config["wan_ip"])
    if ipaddress.IPv4Address(nsr_config["wan_upstream_router"]) not in wan.network:
        raise ValueError("nsr.json wan_upstream_router must be inside wan_ip's subnet")
    body = {
        "id": router_id, "name": router_id, "cluster": config["proxmox_cluster_name"],
        "deployment_mode": "standalone", "node": node,
        "image_storage": image_volume.split(":", 1)[0], "image_volume": image_volume,
        "wan_bridge": nsr_config["wan_bridge"], "wan_address_cidr": str(wan),
        "wan_gateway": nsr_config["wan_upstream_router"],
        "vtep_bridge": config["vtep_interface"],
        "management_allowlist": allowlist,
        **EMPTY_WAN_POLICY,
    }
    if nsr_config.get("wan_vlan") not in (None, ""):
        body["wan_vlan_id"] = int(nsr_config["wan_vlan"])
    if config.get("vtep_vlan_id") is not None:
        body["vtep_vlan_id"] = int(config["vtep_vlan_id"])
    if console_password:
        body["cloud_init_password"] = console_password
    return body


class DemoLab(LiveLab):
    def __init__(self, directory):
        self.lock = threading.RLock()
        # Proxmox takes a cluster-wide cfs-lock per storage for allocation, import and purge;
        # concurrent imports time out, so storage-touching tasks run one at a time.
        self.storage_lock = threading.Lock()
        super().__init__(directory)
        self.state["console_password"] = CONSOLE_PASSWORD

    def save(self):
        with self.lock:
            private_write(self.path, self.state)

    def vm_config(self, vm):
        config = self.proxmox.get(f"/nodes/{vm['node']}/qemu/{vm['vmid']}/config")["data"]
        network = dict(part.split("=", 1) for part in config.get("net0", "").split(",") if "=" in part)
        if (config.get("name") != vm["name"]
                or config.get("description") != f"SwiftFabric demo lab {self.state['run_id']}"
                or network.get("bridge") != f"sf-br{vm['segment_id']}"):
            raise RuntimeError(f"VM {vm['vmid']} ownership mismatch; refusing to touch it")
        return config

    def wait_task(self, response, timeout=900):
        task = response.get("data") if isinstance(response, dict) else None
        if isinstance(task, str) and task.startswith("UPID:"):
            self.proxmox.wait_for_task(task, timeout=timeout)

    def log(self, message):
        with self.lock:
            print(f"[{time.strftime('%H:%M:%S')}] {message}", flush=True)

    # ---- preflight -------------------------------------------------------------------------
    def network_inventory(self):
        segments = self.request("GET", "/segments")
        reserved = [
            ipaddress.ip_network(f"{self.config['ip_range_start']}/{self.config['cidr']}", strict=False),
            ipaddress.ip_network(self.request("GET", "/vteps/pool")["cidr"], strict=False),
        ]
        owned = {segment["id"] for segment in self.state["segments"] if segment.get("create_requested")}
        for segment in segments:
            if segment["id"] not in owned and segment.get("gateway_cidr"):
                reserved.append(ipaddress.ip_network(segment["gateway_cidr"], strict=False))
        for node in self.proxmox.get("/nodes")["data"]:
            for device in self.proxmox.get(f"/nodes/{node['node']}/network")["data"]:
                if device.get("cidr"):
                    reserved.append(ipaddress.ip_network(device["cidr"], strict=False))
        return segments, reserved

    def select_plan(self, first_id, subnet_start, supernet):
        segments, reserved = self.network_inventory()
        used = {segment["id"] for segment in segments}
        count = SEGMENT_COUNT
        last_start = 50001 - count
        starts = (*range(first_id, last_start + 1), *range(5000, first_id))
        selected_id = next((start for start in starts
                            if not used.intersection(range(start, start + count))), None)
        if selected_id is None:
            raise RuntimeError(f"no block of {count} unused segment IDs available")
        count = SUBNET_COUNT
        pool = ipaddress.ip_network(supernet)
        first = int(ipaddress.ip_network(subnet_start).network_address)
        lower = int(pool.network_address)
        upper = int(pool.broadcast_address) + 1
        selected_subnet = None
        for begin, end in ((first, upper), (lower, min(upper, first + (count - 1) * 256))):
            candidate = begin
            while candidate + count * 256 <= end:
                block_end = candidate + count * 256 - 1
                overlaps = [network for network in reserved if network.version == pool.version
                            and int(network.network_address) <= block_end
                            and int(network.broadcast_address) >= candidate]
                if not overlaps:
                    selected_subnet = str(ipaddress.ip_network((candidate, 24)))
                    break
                candidate = max(int(network.broadcast_address) + 1 for network in overlaps)
                candidate = (candidate + 255) // 256 * 256
            if selected_subnet:
                break
        if selected_subnet is None:
            raise RuntimeError(f"no block of {count} non-overlapping /24s available in {pool}")
        self.state.update(build_plan(
            selected_id, selected_subnet, supernet, self.state["nodes"],
            self.state["run_id"], self.state["db_password"],
        ))

    def preflight(self):
        enrolled = {
            host["node"] for host in self.request("GET", "/hosts")
            if host["cluster"] == self.config["proxmox_cluster_name"] and host["status"] == "enrolled"
        }
        missing = set(self.state["nodes"]) - enrolled
        if missing:
            raise RuntimeError(f"nodes not enrolled in this cluster: {', '.join(sorted(missing))}")
        existing, reserved = self.network_inventory()
        ours = {segment["id"]: segment for segment in self.state["segments"]}
        for current in existing:
            mine = ours.get(current["id"])
            if mine and not mine.get("create_requested"):
                raise RuntimeError(f"segment {current['id']} already exists; choose another --first-segment-id")
        for segment in self.state["segments"]:
            network = ipaddress.ip_network(segment["network"])
            for other in reserved:
                if network.overlaps(other):
                    raise RuntimeError(f"{network} overlaps existing network {other}; choose another --subnet-start")
        router = self.state["router"]
        if not router.get("create_requested"):
            try:
                self.request("GET", f"/north-south-routers/{router['id']}")
            except LabAPIError as failure:
                if failure.status != 404:
                    raise
            else:
                raise RuntimeError(f"router {router['id']} already exists; choose another --router-id")
        tenant = self.state.get("tenant")
        if tenant and not tenant.get("create_requested") and any(
                str(item.get("name", "")).lower() == tenant["name"].lower()
                for item in self.request("GET", "/tenants")):
            raise RuntimeError(f"tenant {tenant['name']} already exists; choose another --tenant-name")
        need = {}
        for vm in self.state["vms"]:
            if not vm["created"]:
                need[vm["node"]] = need.get(vm["node"], 0) + SIZES[vm["kind"]][1] * 1024**2
        for node, required in need.items():
            memory = self.proxmox.get(f"/nodes/{node}/status")["data"]["memory"]
            if memory["total"] - memory["used"] < required + 2 * 1024**3:
                raise RuntimeError(f"{node} needs {required / 1024**3:.0f} GiB + 2 GiB headroom free")
            images = self.proxmox.get(f"/nodes/{node}/storage/{self.state['storage']}/content")["data"]
            if not any(image["volid"] == self.state["image_volume"] for image in images):
                raise RuntimeError(f"{self.state['image_volume']} is not available on {node}")

    # ---- router ----------------------------------------------------------------------------
    def deployer_cidr(self):
        return f"{deployer_source(self.config['ip_range_start'])}/32"

    def ensure_router_allowlist(self, current):
        """Stage the deploying system's SSH source on the router; applied by the next deploy/retry."""
        router = self.state["router"]
        allowlist = merge_allowlist(router["request"]["management_allowlist"], self.deployer_cidr())
        applied = (current.get("pending_configuration") or current).get("management_allowlist", [])
        if set(allowlist) <= set(applied):
            return current
        router["request"]["management_allowlist"] = allowlist
        self.save()
        # An omitted cloud_init_password keeps the router's existing console password hash.
        body = {
            key: value for key, value in router["request"].items()
            if key != "cloud_init_password" and key not in EMPTY_WAN_POLICY
        }
        body["_version"] = current["_version"]
        self.request("PUT", f"/north-south-routers/{router['id']}", body)
        self.log(f"Router {router['id']}: management SSH allowlist {', '.join(allowlist)} "
                 f"({'staged for redeploy' if current.get('vmid') is not None else 'updated'})")
        return self.request("GET", f"/north-south-routers/{router['id']}")

    def start_router(self):
        router = self.state["router"]
        if not router.get("create_requested"):
            router["create_requested"] = True
            self.save()
            self.request("POST", "/north-south-routers", router["request"])
            self.log(f"Configured North/South router {router['id']} (WAN {router['request']['wan_address_cidr']})")
        current = self.request("GET", f"/north-south-routers/{router['id']}")
        if current["status"] not in ("deploying", "starting", "redeploying", "ha-async-bootstrapping") \
                and not current.get("upgrade_in_progress"):
            current = self.ensure_router_allowlist(current)
        if current["status"] == "failed":
            self.retry_router(current.get("status_message", ""))
            return
        if current.get("vmid") is None and current["status"] not in ("deploying", "starting"):
            self.request("POST", f"/north-south-routers/{router['id']}/deploy")
            self.log(f"Deploying North/South router {router['id']} on {router['request']['node']}")

    def retry_router(self, reason):
        router_id = self.state["router"]["id"]
        self.log(f"Router {router_id} failed ({reason.strip()}); retrying deployment")
        self.request("POST", f"/north-south-routers/{router_id}/retry")

    def wait_router(self, timeout=2400, retries=ROUTER_RETRIES):
        router_id = self.state["router"]["id"]
        deadline, last = time.monotonic() + timeout, None
        while True:
            current = self.request("GET", f"/north-south-routers/{router_id}")
            status = (current["status"], current.get("status_message", ""))
            if status != last:
                self.log(f"Router {router_id}: {status[0]} {status[1]}".rstrip())
                last = status
            if current["status"] == "active":
                return current
            if current["status"] == "failed" and retries > 0:
                retries -= 1
                self.retry_router(status[1])
                last = None
                time.sleep(10)
                continue
            if current["status"] in ("failed", "error"):
                raise RuntimeError(f"router {router_id} deployment failed: {status[1]}")
            if time.monotonic() > deadline:
                raise TimeoutError(f"router {router_id} did not become active")
            time.sleep(10)

    def set_wan_policy(self, policy):
        router_id = self.state["router"]["id"]
        current = self.request("GET", f"/north-south-routers/{router_id}/wan-policy")
        self.request(
            "PUT",
            f"/north-south-routers/{router_id}/wan-policy",
            {**policy, "_version": current["_version"]},
        )

    def attach(self, segment, router_id):
        current = self.owned_segment(segment)
        self.request("PUT", f"/segments/{segment['id']}/north-south-router", {
            "router_id": router_id, "_version": current["_version"],
        })

    def set_router_tenant(self, tenant_id):
        """Reassign the unattached, policy-free router; the controller rejects any other handoff."""
        router_id = self.state["router"]["id"]
        current = self.request("GET", f"/north-south-routers/{router_id}")
        if current.get("tenant_id", DEFAULT_TENANT) == tenant_id:
            return
        self.request("PUT", f"/north-south-routers/{router_id}/tenant", {
            "tenant_id": tenant_id, "_version": current["_version"],
        })
        self.log(f"Router {router_id}: reassigned to tenant {tenant_id}")

    # ---- tenants ---------------------------------------------------------------------------
    def tenant_id(self, segment):
        if segment_tenant(segment) == DEFAULT_TENANT:
            return DEFAULT_TENANT
        return self.state["tenant"]["id"]

    def find_tenant(self):
        """Find the second tenant by recorded request/resource ID or legacy name."""
        tenant = self.state.get("tenant")
        if not tenant:
            return None
        expected_id = tenant.get("id") or tenant.get("request_id")
        for current in self.request("GET", "/tenants"):
            if expected_id and current.get("id") == expected_id:
                if current.get("name") != tenant["name"]:
                    raise RuntimeError(f"tenant {expected_id} ownership mismatch; refusing to touch it")
                return current
            if (not expected_id
                    and str(current.get("name", "")).lower() == tenant["name"].lower()):
                return current
        return None

    def ensure_tenant(self):
        tenant = self.state.get("tenant")
        if not tenant or tenant.get("id"):
            return
        request_id = tenant.get("request_id")
        # New requests replay the same POST after an uncertain response. The
        # controller durably returns the original result for a stable create ID.
        current = (self.find_tenant()
                   if tenant.get("create_requested") and not request_id else None)
        if current is None:
            if not request_id:
                request_id = f"tenant-{uuid.uuid4()}"
                tenant["request_id"] = request_id
            tenant["create_requested"] = True
            self.save()
            current = self.request("POST", "/tenants", {"id": request_id, "name": tenant["name"]})
            if current.get("id") != request_id:
                raise RuntimeError(f"tenant creation ID mismatch for {tenant['name']}")
            self.log(f"Created tenant {tenant['name']} ({current['id']})")
        tenant["id"] = current["id"]
        tenant.pop("request_id", None)
        for segment in self.state["segments"]:
            if segment_tenant(segment) == SECOND_TENANT:
                segment["tenant_id"] = current["id"]
        self.save()

    # ---- segments and VMs ------------------------------------------------------------------
    def create_segments(self):
        self.ensure_tenant()
        for segment in self.state["segments"]:
            if segment["created"]:
                continue
            segment["create_requested"] = True
            self.save()
            self.request("POST", "/segments", {
                "id": segment["id"], "name": segment["name"], "gateway_cidr": segment["gateway_cidr"],
                "tenant_id": self.tenant_id(segment),
            })
            segment["created"] = True
            self.save()
            self.log(f"Created segment {segment['id']} {segment['name']} {segment['network']} "
                     f"(tenant {self.tenant_id(segment)})")
        for segment_id, acl in b_acls(self.state["segments"]).items():
            segment = next(item for item in self.state["segments"] if item["id"] == segment_id)
            self.owned_segment(segment)
            current = self.request("GET", f"/segments/{segment_id}/acl")
            self.request(
                "PUT",
                f"/segments/{segment_id}/acl",
                {**acl, "_version": current["_version"]},
            )
        self.log("Applied Config B East/West ACLs (TCP 5432 + ICMP, mirrored ingress/egress)")

    def allocate_vmids(self):
        used = {int(item["vmid"]) for item in self.proxmox.get("/cluster/resources", {"type": "vm"})["data"]}
        candidate = int(self.proxmox.get("/cluster/nextid")["data"])
        for vm in self.state["vms"]:
            if vm["vmid"] is None:
                while candidate in used:
                    candidate += 1
                vm["vmid"] = candidate
                used.add(candidate)
        self.save()

    def storage_task(self, request, attempts=STORAGE_ATTEMPTS):
        for attempt in range(1, attempts + 1):
            try:
                with self.storage_lock:
                    return self.wait_task(request())
            except (ProxmoxAPIError, RuntimeError) as failure:
                if "cfs-lock" not in str(failure) or attempt == attempts:
                    raise
                time.sleep(STORAGE_RETRY_SECONDS * attempt)

    def existing_vm(self, vm):
        try:
            return self.vm_config(vm)
        except ProxmoxAPIError as failure:
            if failure.status_code in (404, 500):
                return None
            raise

    def remove_partial_vm(self, vm):
        node, vmid = vm["node"], vm["vmid"]
        self.storage_task(lambda: self.proxmox.delete(
            f"/nodes/{node}/qemu/{vmid}", {"purge": 1, "destroy-unreferenced-disks": 1},
        ))
        self.log(f"Removed partial {vm['name']} (VM {vmid}) before retrying")

    def create_vm(self, vm):
        if vm["created"]:
            return
        cores, memory, disk = SIZES[vm["kind"]]
        node, vmid = vm["node"], vm["vmid"]
        payload = {
            "vmid": vmid, "name": vm["name"],
            "description": f"SwiftFabric demo lab {self.state['run_id']}",
            "tags": "swiftfabric-demo", "cores": cores, "memory": memory, "onboot": 0, "ciupgrade": 0,
            "net0": f"virtio,bridge=sf-br{vm['segment_id']},firewall=1",
            "scsihw": "virtio-scsi-pci",
            "scsi0": f"{self.state['storage']}:0,import-from={self.state['image_volume']}",
            "ide2": f"{self.state['storage']}:cloudinit",
            "boot": "order=scsi0", "serial0": "socket", "vga": "std",
            "ciuser": CONSOLE_USER, "cipassword": CONSOLE_PASSWORD,
            "ipconfig0": f"ip={vm['address']}/24,gw={vm['gateway']}",
            "nameserver": " ".join(PUBLIC_DNS),
        }
        for attempt in range(1, STORAGE_ATTEMPTS + 1):
            config = self.existing_vm(vm)
            if config is not None and config.get("lock"):
                raise RuntimeError(
                    f"VM {vmid} is a partial create still locked ({config['lock']}); "
                    f"run 'qm unlock {vmid}' on {node}, then rerun deploy"
                )
            if config is not None and ("scsi0" not in config or "ide2" not in config):
                self.remove_partial_vm(vm)
                config = None
            try:
                if config is None:
                    self.storage_task(lambda: self.proxmox.post(f"/nodes/{node}/qemu", data=payload), attempts=1)
                if disk:
                    self.storage_task(lambda: self.proxmox._make_request(
                        "PUT", f"/nodes/{node}/qemu/{vmid}/resize", data={"disk": "scsi0", "size": disk},
                    ))
                break
            except (ProxmoxAPIError, RuntimeError) as failure:
                if "cfs-lock" not in str(failure) or attempt == STORAGE_ATTEMPTS:
                    raise
                self.log(f"{vm['name']}: storage lock busy; retry {attempt}/{STORAGE_ATTEMPTS - 1}")
                time.sleep(STORAGE_RETRY_SECONDS * attempt)
        status = self.proxmox.get(f"/nodes/{node}/qemu/{vmid}/status/current")["data"]
        if status.get("status") != "running":
            self.wait_task(self.proxmox.post(f"/nodes/{node}/qemu/{vmid}/status/start"))
        vm["created"] = True
        self.save()
        self.log(f"Created {vm['name']} (VM {vmid}) on {node} at {vm['address']}")

    def create_vms(self):
        """Create VMs (storage work serialized) and bootstrap each one as soon as it exists."""
        self.allocate_vmids()

        def provision(vm):
            self.create_vm(vm)
            self.bootstrap(vm)

        self.parallel_vms("VM provisioning", provision, self.state["vms"])

    def parallel_vms(self, phase, operation, vms):
        failures = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=PARALLEL_WORKERS) as executor:
            futures = {executor.submit(operation, vm): vm for vm in vms}
            for future in concurrent.futures.as_completed(futures):
                try:
                    future.result()
                except Exception as failure:
                    failures.append(f"{futures[future]['name']}: {failure}")
        if failures:
            raise RuntimeError(f"{phase} failed:\n  " + "\n  ".join(failures))

    # ---- guests ----------------------------------------------------------------------------
    def guest(self, vm, arguments, timeout=300):
        return self.serial(vm, f"sudo -n /usr/bin/python3 {GUEST_PATH} {arguments}", timeout=timeout)

    def bootstrap(self, vm):
        if vm["bootstrapped"]:
            return
        for attempt in range(1, 6):
            try:
                self.serial(vm, "cloud-init status --wait >/dev/null 2>&1; true", timeout=420)
                break
            except (TimeoutError, RuntimeError) as failure:
                if attempt == 5:
                    raise
                self.log(f"{vm['name']}: console not ready ({failure}); retrying")
                time.sleep(15)
        payload = encode(GUEST_SCRIPT.read_bytes())
        program = (
            "import base64,gzip,pathlib;"
            f"p=pathlib.Path('{GUEST_PATH}');p.parent.mkdir(exist_ok=True);"
            f"p.write_bytes(gzip.decompress(base64.b64decode('{payload}')))"
        )
        segment = next(item for item in self.state["segments"] if item["id"] == vm["segment_id"])
        role = {
            "name": vm["name"], "kind": vm["kind"], "segment": vm["segment_id"], "address": vm["address"],
            "description": segment["description"], "user": DB_USER, "password": self.state["db_password"],
            "database": DB_NAME, "port": POSTGRES_PORT, "servers": vm.get("servers", []),
            "allow_networks": vm.get("allow_networks", []), "interval_min": 1.0, "interval_max": 4.0,
        }
        self.serial(vm, "sudo -n python3 -c " + shlex.quote(program))
        self.guest(vm, "setup " + encode(json.dumps(role).encode()))
        self.serial(vm, "sudo -n systemctl enable --now getty@tty1.service")
        vm["bootstrapped"] = True
        self.save()
        self.log(f"{vm['name']}: guest bootstrap complete")

    def install_databases(self):
        databases = [vm for vm in self.state["vms"] if vm["kind"] == "db" and not vm["db_ready"]]
        if not databases:
            return
        segments = {segment["id"]: segment for segment in self.state["segments"]}
        tenants = dict.fromkeys(self.tenant_id(segments[vm["segment_id"]]) for vm in databases)
        # One shared router serves each tenant in turn; it is detached, emptied and returned
        # to the default tenant between windows.
        for tenant_id in tenants:
            group = [vm for vm in databases if self.tenant_id(segments[vm["segment_id"]]) == tenant_id]
            try:
                self.install_tenant_databases(tenant_id, group, segments)
            finally:
                self.revoke_mirror_access()

    def install_tenant_databases(self, tenant_id, databases, segments):
        segment_ids = sorted({vm["segment_id"] for vm in databases})
        router_id = self.state["router"]["id"]
        if tenant_id != DEFAULT_TENANT:
            self.state["router_tenant"] = tenant_id
            self.save()
            self.set_router_tenant(tenant_id)
        self.log(f"Temporarily attaching tenant {tenant_id} DB segments {segment_ids} to {router_id} for "
                 "public Ubuntu archive access (DNS 8.8.8.8/1.1.1.1, HTTP/HTTPS)")
        self.state["mirror_access"] = segment_ids
        self.save()
        for segment_id in segment_ids:
            self.attach(segments[segment_id], router_id)
        self.set_wan_policy(apt_wan_policy([segments[segment_id]["network"] for segment_id in segment_ids]))
        time.sleep(self.state["settle_seconds"])

        def install(vm):
            self.log(f"{vm['name']}: installing PostgreSQL and seeding 1000 people rows")
            output = self.guest(vm, "install-db", timeout=1800)
            vm["db_ready"] = True
            self.save()
            self.log(f"{vm['name']}: {output.splitlines()[-1] if output else 'ready'}")

        with concurrent.futures.ThreadPoolExecutor(max_workers=len(databases)) as executor:
            list(executor.map(install, databases))

    def revoke_mirror_access(self):
        attached = self.state.get("mirror_access")
        if attached:
            self.set_wan_policy(EMPTY_WAN_POLICY)
            for segment in self.state["segments"]:
                if segment["id"] in attached:
                    try:
                        self.attach(segment, None)
                    except LabAPIError as failure:
                        if failure.status != 404:
                            raise
            self.state["mirror_access"] = []
            self.save()
            self.log("Removed temporary archive access: WAN policy empty, no segments attached to the router")
        if self.state.get("router_tenant", DEFAULT_TENANT) != DEFAULT_TENANT:
            try:
                self.set_router_tenant(DEFAULT_TENANT)
            except LabAPIError as failure:
                if failure.status != 404:
                    raise
            self.state["router_tenant"] = DEFAULT_TENANT
            self.save()

    def start_clients(self):
        def start(vm):
            self.guest(vm, "start-client")
            vm["client_started"] = True
            self.save()

        pending = [
            vm for vm in self.state["vms"]
            if vm["kind"] == "client" and not vm["client_started"]
        ]
        self.parallel_vms("Client startup", start, pending)
        self.log("All PostgreSQL clients are running randomized queries")

    def verify(self):
        checked = set()
        for vm in self.state["vms"]:
            if vm["kind"] != "client" or vm["segment_id"] in checked:
                continue
            checked.add(vm["segment_id"])
            output = self.guest(vm, "query " + shlex.quote("SELECT count(*) AS people FROM people"), timeout=120)
            self.log(f"Verified from {vm['name']} ({vm['address']}):\n" + output)

    # ---- actions ---------------------------------------------------------------------------
    def configure_console(self):
        for vm in self.state["vms"]:
            if not vm["created"]:
                continue
            config = self.vm_config(vm)
            status = self.proxmox.get(
                f"/nodes/{vm['node']}/qemu/{vm['vmid']}/status/current",
            )["data"]["status"]
            if config.get("vga") != "std":
                if status != "stopped":
                    raise RuntimeError(
                        f"{vm['name']}: fully shut down VM {vm['vmid']} before configure-console; "
                        "display hardware cannot be changed while running"
                    )
                self.wait_task(self.proxmox.configure_vm(vm["node"], vm["vmid"], vga="std"))
            if status == "running":
                self.serial(vm, "sudo -n systemctl enable --now getty@tty1.service")
            else:
                self.log(f"{vm['name']}: stopped; tty1 login will use Ubuntu's default getty on boot")
            self.log(f"{vm['name']}: standard VGA configured; serial0 retained for automation")
        self.log("Standard VGA configured; start any stopped VMs to use the noVNC console")

    def deploy(self):
        self.preflight()
        self.start_router()
        self.create_segments()
        self.create_vms()
        self.wait_router()
        self.install_databases()
        self.start_clients()
        self.set_wan_policy(EMPTY_WAN_POLICY)
        self.log(f"Waiting {self.state['settle_seconds']}s for final network policy to converge")
        time.sleep(self.state["settle_seconds"])
        self.verify()
        self.state["ready"] = True
        self.save()
        self.status()

    def status(self):
        router_id = self.state["router"]["id"]
        try:
            router = self.request("GET", f"/north-south-routers/{router_id}")
            print(f"\nNorth/South router {router_id}: {router['status']} on {router.get('node')} "
                  f"WAN {router.get('wan_address_cidr')} (VM {router.get('vmid')}); "
                  f"egress rules {len(router.get('wan_egress_rules', []))}, "
                  f"ingress rules {len(router.get('wan_ingress_rules', []))}")
        except LabAPIError as failure:
            print(f"\nNorth/South router {router_id}: unavailable ({failure})")
        segments = {item["id"]: item for item in self.request("GET", "/segments")}
        print("\nSegments:")
        tenant = self.state.get("tenant")
        if tenant:
            print(f"  Second tenant {tenant['name']} ({tenant.get('id') or 'not created'}) "
                  "reuses the default tenant's Config A/B subnets")
        for segment in self.state["segments"]:
            current = segments.get(segment["id"], {})
            attached = attached_router(current) or "-"
            label = "t2" if segment_tenant(segment) == SECOND_TENANT else "default"
            print(f"  {segment['id']}  {label:<7} {segment['name']:<22} {segment['network']:<16} "
                  f"{'present' if current else 'absent':<8} NSR {attached:<12} {segment['description']}")
        print(f"\nVMs (console login {CONSOLE_USER} / {CONSOLE_PASSWORD}; "
              f"PostgreSQL {DB_USER} / {self.state['db_password']} db {DB_NAME}):")
        print(f"  {'name':<18} {'vmid':>5}  {'node':<8} {'segment':>7}  {'address':<14} {'role':<7} state")
        for vm in self.state["vms"]:
            state = "-"
            if vm["vmid"] is not None and vm["created"]:
                try:
                    state = self.proxmox.get(
                        f"/nodes/{vm['node']}/qemu/{vm['vmid']}/status/current")["data"]["status"]
                except ProxmoxAPIError:
                    state = "missing"
            print(f"  {vm['name']:<18} {vm['vmid'] or '-':>5}  {vm['node']:<8} {vm['segment_id']:>7}  "
                  f"{vm['address']:<14} {vm['kind']:<7} {state}")
        print("\nOn a client console:  journalctl -u sf-demo-client -f   |   sf-demo-query \"SELECT ...\"")
        print(f"State directory: {self.directory}\n")

    def destroy(self):
        self.revoke_mirror_access()
        vm_nodes = {
            int(resource["vmid"]): resource["node"]
            for resource in self.proxmox.get("/cluster/resources", {"type": "vm"})["data"]
            if resource.get("type") == "qemu"
        }

        def delete_vm(vm):
            node = vm_nodes.get(int(vm["vmid"]))
            if node is not None:
                vm["node"] = node
                self.vm_config(vm)
                status = self.proxmox.get(f"/nodes/{vm['node']}/qemu/{vm['vmid']}/status/current")["data"]
                if status["status"] != "stopped":
                    self.wait_task(self.proxmox.post(f"/nodes/{vm['node']}/qemu/{vm['vmid']}/status/stop"))
                self.storage_task(lambda: self.proxmox.delete(
                    f"/nodes/{vm['node']}/qemu/{vm['vmid']}", {"purge": 1, "destroy-unreferenced-disks": 1},
                ))
                self.log(f"Deleted {vm['name']} (VM {vm['vmid']})")
            vm.update(vmid=None, created=False, bootstrapped=False, db_ready=False, client_started=False)
            self.save()

        self.parallel_vms(
            "VM deletion", delete_vm,
            [vm for vm in reversed(self.state["vms"]) if vm["vmid"] is not None],
        )
        router_id = self.state["router"]["id"]
        for segment in reversed(self.state["segments"]):
            if not segment.get("create_requested"):
                continue
            try:
                self.owned_segment(segment)
            except LabAPIError as failure:
                if failure.status != 404:
                    raise
            else:
                self.attach(segment, None)
                current = self.owned_segment(segment)
                self.request("DELETE", f"/segments/{segment['id']}?_version={current['_version']}")
                self.log(f"Deleted segment {segment['id']}")
            segment.update(created=False, create_requested=False)
            self.save()
        if self.state["router"].get("create_requested"):
            try:
                current = self.request("GET", f"/north-south-routers/{router_id}")
            except LabAPIError as failure:
                if failure.status != 404:
                    raise
            else:
                if current.get("name") != router_id or current.get("wan_address_cidr") != \
                        self.state["router"]["request"]["wan_address_cidr"]:
                    raise RuntimeError(f"router {router_id} ownership mismatch; refusing to delete it")
                attached = [item["id"] for item in self.request("GET", "/segments")
                            if attached_router(item) == router_id]
                if attached:
                    raise RuntimeError(f"router {router_id} still has segments attached {attached}; "
                                       "detach them (they are not part of this lab) and rerun destroy")
                self.request(
                    "DELETE",
                    f"/north-south-routers/{router_id}?_version={current['_version']}",
                )
                self.log(f"Deleted North/South router {router_id}")
            self.state["router"]["create_requested"] = False
        self.destroy_tenant()
        self.state["ready"] = False
        self.save()

    def destroy_tenant(self):
        tenant = self.state.get("tenant")
        if not tenant or not tenant.get("create_requested"):
            return
        current = self.find_tenant()
        if current is not None:
            self.request(
                "DELETE",
                f"/tenants/{current['id']}?_version={current['_version']}",
            )
            self.log(f"Deleted tenant {tenant['name']} ({current['id']})")
        tenant.update(id=None, create_requested=False)
        for segment in self.state["segments"]:
            if segment_tenant(segment) == SECOND_TENANT:
                segment.pop("tenant_id", None)
        self.save()

    def destroy_state(self):
        if self.directory in (Path.home().resolve(), *ROOT.parents) or self.directory == ROOT:
            raise RuntimeError(f"refusing to remove state from protected directory {self.directory}")
        files = [self.path, self.directory / "controller-ca.crt"]
        unexpected = set(self.directory.iterdir()) - set(files)
        if unexpected:
            raise RuntimeError(f"unexpected files in state directory; refusing cleanup: "
                               f"{', '.join(sorted(path.name for path in unexpected))}")
        if any(path.is_symlink() or (path.exists() and not path.is_file()) for path in files):
            raise RuntimeError("state files must be regular files; refusing cleanup")

        remaining = []
        segment_ids = {segment["id"] for segment in self.state["segments"]}
        for segment in self.request("GET", "/segments"):
            if segment["id"] in segment_ids:
                remaining.append(f"segment {segment['id']}")
        router_id = self.state["router"]["id"]
        try:
            self.request("GET", f"/north-south-routers/{router_id}")
        except LabAPIError as failure:
            if failure.status != 404:
                raise
        else:
            remaining.append(f"router {router_id}")
        tenant = self.state.get("tenant")
        if tenant and any(current.get("id") == tenant.get("id")
                          or str(current.get("name", "")).lower() == tenant["name"].lower()
                          for current in self.request("GET", "/tenants")):
            remaining.append(f"tenant {tenant['name']}")
        vmids = {int(vm["vmid"]) for vm in self.state["vms"] if vm["vmid"] is not None}
        names = {vm["name"] for vm in self.state["vms"]} | {router_id}
        description = f"SwiftFabric demo lab {self.state['run_id']}"
        for resource in self.proxmox.get("/cluster/resources", {"type": "vm"})["data"]:
            if resource.get("type") != "qemu":
                continue
            vmid = int(resource["vmid"])
            config = self.proxmox.get(f"/nodes/{resource['node']}/qemu/{vmid}/config")["data"]
            if vmid in vmids or config.get("name") in names or config.get("description") == description:
                remaining.append(f"VM {vmid} on {resource['node']}")
        if remaining:
            raise RuntimeError(f"deployment resources remain: {', '.join(remaining)}; "
                               "run destroy before destroy-state")

        for path in files[1:]:
            path.unlink(missing_ok=True)
        self.path.unlink()
        self.directory.rmdir()
        self.log(f"Deleted local state directory {self.directory}")


def apt_wan_policy(networks):
    """Temporary NSR policy: masquerade DB subnets; only DNS to public resolvers and HTTP/HTTPS out."""
    egress = []
    for network in networks:
        for resolver in PUBLIC_DNS:
            for protocol in ("udp", "tcp"):
                egress.append(acl_rule(network, f"{resolver}/32", protocol, "53"))
        for port in ("80", "443"):
            egress.append(acl_rule(network, "0.0.0.0/0", "tcp", port))
    return {**EMPTY_WAN_POLICY, "masquerade_source_cidrs": list(networks), "wan_egress_rules": egress}


def print_plan(plan, router):
    print("Planned segments:")
    for segment in plan["segments"]:
        label = "t2" if segment_tenant(segment) == SECOND_TENANT else "default"
        print(f"  {segment['id']}  {label:<7} {segment['name']:<22} {segment['network']:<16} "
              f"{segment['description']}")
    print("Planned VMs:")
    for vm in plan["vms"]:
        print(f"  {vm['name']:<18} {vm['kind']:<7} segment {vm['segment_id']}  {vm['address']:<14} on {vm['node']}")
    if plan.get("tenant"):
        print(f"Second tenant {plan['tenant']['name']}: replicas of Config A and Config B on the same "
              "overlapping subnets and addresses (no North/South demo segment)")
    print(f"North/South router {router['id']} on {router['node']}: WAN {router['wan_address_cidr']} "
          f"via {router['wan_gateway']} ({router['wan_bridge']} VLAN {router.get('wan_vlan_id', '-')}), "
          "standalone, empty WAN policy, no segments attached")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("action", choices=("plan", "deploy", "status", "destroy", "destroy-state",
                                          "configure-console"))
    parser.add_argument("--config", type=Path, default=ROOT / "config.json")
    parser.add_argument("--nsr-config", "--edge", dest="nsr_config", type=Path,
                        default=ROOT / "nsr.json", help="North/South router WAN settings")
    parser.add_argument("--state", type=Path, default=DEFAULT_STATE, help=f"state directory (default {DEFAULT_STATE})")
    parser.add_argument("--nodes", nargs="+", help="Proxmox nodes (default: proxmox_auto_enroll_host_list)")
    parser.add_argument("--first-segment-id", type=int, default=5000, help="preferred start for free segment IDs")
    parser.add_argument("--supernet", default="10.0.0.0/8")
    parser.add_argument("--subnet-start", default="10.50.0.0/24", help="preferred start for five free /24s")
    parser.add_argument("--router-id", default="demo-nsr")
    parser.add_argument("--tenant-name", help="name for the second tenant (default demo-t2-<run id>)")
    parser.add_argument("--router-node", help="node for the router VM (default: first lab node)")
    parser.add_argument("--router-console-password", help="optional router console/management SSH password")
    parser.add_argument("--management-allowlist", nargs="+",
                        help="router management SSH source CIDRs (default: the management network)")
    parser.add_argument("--image-volume", help=f"Ubuntu cloud image (default <storage_location>:{DEFAULT_IMAGE})")
    parser.add_argument("--settle-seconds", type=int, default=35)
    parser.add_argument("--yes", action="store_true", help="skip the confirmation prompt")
    args = parser.parse_args()

    directory = args.state.expanduser().resolve()
    if directory == ROOT or ROOT in directory.parents:
        parser.error("keep the state directory outside the repository")
    state_file = directory / "state.json"
    if args.action in ("status", "destroy", "destroy-state", "configure-console") and not state_file.exists():
        parser.error(f"no demo lab state at {state_file}")

    if not state_file.exists():
        config = load_deployment_config(args.config)
        nodes = args.nodes or config.get("auto_enroll_host_list")
        if not isinstance(nodes, list) or len(nodes) < 2 or len(set(nodes)) != len(nodes):
            parser.error("pass --nodes with two or more distinct compute nodes")
        image_volume = args.image_volume or f"{config['storage_location']}:{DEFAULT_IMAGE}"
        management = ipaddress.ip_network(f"{config['ip_range_start']}/{config['cidr']}", strict=False)
        nsr_config = json.loads(args.nsr_config.read_text())
        router = router_request(
            nsr_config, config, args.router_id, args.router_node or nodes[0], image_volume,
            merge_allowlist(args.management_allowlist or [str(management)],
                            f"{deployer_source(config['ip_range_start'])}/32"),
            args.router_console_password,
        )
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", args.router_id):
            parser.error("--router-id must be letters, digits, hyphens, or underscores")
        run_id = uuid.uuid4().hex
        tenant_name = args.tenant_name or f"demo-t2-{run_id[:12]}"
        if not TENANT_NAME.fullmatch(tenant_name):
            parser.error("--tenant-name must be 1-64 letters, digits, spaces, '.', '_' or '-' "
                         "without leading or trailing spaces")
        preferred = ipaddress.ip_network(args.subnet_start)
        pool = ipaddress.ip_network(args.supernet)
        if preferred.version != 4 or pool.version != 4 or preferred.prefixlen != 24:
            parser.error("--subnet-start must be an IPv4 /24 inside an IPv4 --supernet")
        if not preferred.subnet_of(pool):
            parser.error("--subnet-start must be inside --supernet")
        plan = build_plan(args.first_segment_id, f"{pool.network_address}/24", args.supernet, nodes, run_id,
                          secrets.token_hex(8))
        state = {
            **plan, "config": str(args.config.resolve()), "nodes": nodes,
            "image_volume": image_volume, "storage": image_volume.split(":", 1)[0],
            "router": {"id": args.router_id, "request": router, "create_requested": False},
            "tenant": {"name": tenant_name, "id": None, "create_requested": False},
            "router_tenant": DEFAULT_TENANT,
            "settle_seconds": max(args.settle_seconds, 30),
            "console_password": CONSOLE_PASSWORD, "mirror_access": [], "ready": False,
        }
        with tempfile.TemporaryDirectory(prefix="swiftfabric-demo-plan-") as temporary:
            staging = Path(temporary)
            private_write(staging / "state.json", state)
            lab = DemoLab(staging)
            try:
                lab.select_plan(args.first_segment_id, args.subnet_start, args.supernet)
                lab.preflight()
                state = lab.state
            finally:
                lab.proxmox_ca.close()
            if state_file.exists():
                raise RuntimeError(f"state appeared during planning at {state_file}; refusing to overwrite it")
            directory.mkdir(mode=0o700, parents=True, exist_ok=True)
            private_write(state_file, state)
        os.chmod(directory, 0o700)
        print_plan(state, router)
        print(f"Validated plan saved to {state_file}; no deployment resources created.")
        print("Database VMs install PostgreSQL from the public Ubuntu archive via temporary NSR egress "
              f"(DNS {', '.join(PUBLIC_DNS)}; TCP 80/443); the WAN policy is emptied afterwards.")
        if args.action == "plan":
            return
    elif args.action == "plan":
        lab = DemoLab(directory)
        lab.preflight()
        print_plan(lab.state, lab.state["router"]["request"])
        print(f"Validated saved plan at {state_file}; use a new --state for a different plan.")
        return
    elif args.action == "deploy":
        print(f"Resuming the demo lab recorded in {state_file}")
    if args.action == "deploy" and not args.yes:
        if input("Deploy/resume this lab? [y/N] ").strip().lower() not in ("y", "yes"):
            raise SystemExit("aborted")
    if args.action == "destroy" and not args.yes and \
            input("Delete every demo lab VM, segment, the router, and the second tenant? [y/N] "
                  ).strip().lower() not in ("y", "yes"):
        raise SystemExit("aborted")
    if args.action == "destroy-state" and not args.yes and \
            input(f"Verify deployment is absent and delete local state at {directory}? [y/N] "
                  ).strip().lower() not in ("y", "yes"):
        raise SystemExit("aborted")
    lab = DemoLab(directory)
    getattr(lab, args.action.replace("-", "_"))()


if __name__ == "__main__":
    main()
