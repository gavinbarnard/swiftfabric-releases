import io
import ipaddress
import json
from pathlib import Path
import sys
import threading
import tempfile
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import demo_lab  # noqa: E402

NODES = ["hunsn3", "hunsn4", "hunsn5"]
CONFIG = {
    "proxmox_cluster_name": "hunsn", "vtep_interface": "vmbr2", "vtep_vlan_id": 91,
}
NSR = json.loads((demo_lab.ROOT / "nsr.example.json").read_text())


class ParallelTests(unittest.TestCase):
    def test_six_workers_execute_concurrently(self):
        lab = object.__new__(demo_lab.DemoLab)
        barrier = threading.Barrier(6, timeout=5)
        completed = []
        lock = threading.Lock()

        def operation(vm):
            barrier.wait()
            with lock:
                completed.append(vm["name"])

        vms = [{"name": str(index)} for index in range(12)]
        lab.parallel_vms("test", operation, vms)
        self.assertEqual(sorted(completed), sorted(vm["name"] for vm in vms))

    def test_storage_tasks_never_overlap(self):
        lab = object.__new__(demo_lab.DemoLab)
        lab.storage_lock = threading.Lock()
        lab.wait_task = lambda response: response
        active, peak, lock = [0], [0], threading.Lock()

        def request():
            with lock:
                active[0] += 1
                peak[0] = max(peak[0], active[0])
            threading.Event().wait(0.02)
            with lock:
                active[0] -= 1

        lab.parallel_vms("test", lambda vm: lab.storage_task(request), [{"name": str(i)} for i in range(8)])
        self.assertEqual(peak[0], 1)

    def test_storage_task_retries_cfs_lock_timeout(self):
        lab = object.__new__(demo_lab.DemoLab)
        lab.storage_lock = threading.Lock()
        lab.wait_task = lambda response: response
        calls = []

        def request():
            calls.append(1)
            if len(calls) < 3:
                raise RuntimeError("cfs-lock 'storage-VMData' error: got lock request timeout")
            return "done"

        original = demo_lab.STORAGE_RETRY_SECONDS
        demo_lab.STORAGE_RETRY_SECONDS = 0
        try:
            self.assertEqual(lab.storage_task(request), "done")
        finally:
            demo_lab.STORAGE_RETRY_SECONDS = original
        self.assertEqual(len(calls), 3)

    def test_storage_task_does_not_retry_other_errors(self):
        lab = object.__new__(demo_lab.DemoLab)
        lab.storage_lock = threading.Lock()
        lab.wait_task = lambda response: response
        request = Mock(side_effect=RuntimeError("no space left"))
        with self.assertRaisesRegex(RuntimeError, "no space"):
            lab.storage_task(request)
        self.assertEqual(request.call_count, 1)

    def test_failure_reported_after_other_workers_finish(self):
        lab = object.__new__(demo_lab.DemoLab)
        completed = threading.Event()

        def operation(vm):
            if vm["name"] == "bad":
                raise RuntimeError("broken")
            completed.set()

        with self.assertRaisesRegex(RuntimeError, "bad: broken"):
            lab.parallel_vms("test", operation, [{"name": "bad"}, {"name": "good"}])
        self.assertTrue(completed.is_set())

    def test_failed_vm_deletion_prevents_segment_and_router_cleanup(self):
        lab = object.__new__(demo_lab.DemoLab)
        lab.state = {"vms": [{"name": "demo", "vmid": 123}]}
        lab.revoke_mirror_access = Mock()
        lab.vm_config = Mock(side_effect=RuntimeError("ownership mismatch"))
        lab.proxmox = Mock()
        lab.proxmox.get.return_value = {"data": [{"type": "qemu", "vmid": 123, "node": "hunsn3"}]}
        lab.request = Mock()
        with self.assertRaisesRegex(RuntimeError, "ownership mismatch"):
            lab.destroy()
        lab.request.assert_not_called()
        self.assertEqual(lab.state["vms"][0]["vmid"], 123)

    def test_destroy_resolves_migrated_vm_to_current_node(self):
        lab = object.__new__(demo_lab.DemoLab)
        vm = {"name": "demo", "vmid": 123, "node": "hunsn3", "created": True}
        lab.state = {
            "vms": [vm], "segments": [],
            "router": {"id": "demo-router", "create_requested": False},
        }
        lab.revoke_mirror_access = Mock()
        lab.vm_config = Mock(return_value={})
        lab.proxmox = Mock()
        lab.proxmox.get.side_effect = [
            {"data": [{"type": "qemu", "vmid": 123, "node": "hunsn5"}]},
            {"data": {"status": "stopped"}},
        ]
        lab.proxmox.delete.return_value = {}
        lab.storage_task = lambda request: request()
        lab.wait_task = Mock()
        lab.save = Mock()
        lab.log = Mock()

        lab.destroy()

        lab.vm_config.assert_called_once_with(vm)
        lab.proxmox.delete.assert_called_once_with(
            "/nodes/hunsn5/qemu/123", {"purge": 1, "destroy-unreferenced-disks": 1},
        )
        self.assertIsNone(vm["vmid"])

    def test_destroy_clears_state_for_vm_missing_from_cluster(self):
        lab = object.__new__(demo_lab.DemoLab)
        vm = {"name": "demo", "vmid": 123, "node": "hunsn3"}
        lab.state = {
            "vms": [vm], "segments": [],
            "router": {"id": "demo-router", "create_requested": False},
        }
        lab.revoke_mirror_access = Mock()
        lab.vm_config = Mock()
        lab.proxmox = Mock()
        lab.proxmox.get.return_value = {"data": []}
        lab.save = Mock()
        lab.log = Mock()

        lab.destroy()

        lab.vm_config.assert_not_called()
        lab.proxmox.delete.assert_not_called()
        self.assertIsNone(vm["vmid"])


class DestroyStateTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.lab = object.__new__(demo_lab.DemoLab)
        self.lab.directory = Path(self.temporary.name) / "demo-lab"
        self.lab.directory.mkdir()
        self.lab.path = self.lab.directory / "state.json"
        self.lab.state = {
            "run_id": "run", "segments": [{"id": 5000, "create_requested": False}],
            "vms": [{"name": "demo-a1-db", "vmid": None}],
            "router": {"id": "demo-nsr", "create_requested": False},
        }
        self.lab.path.write_text(json.dumps(self.lab.state))
        (self.lab.directory / "controller-ca.crt").write_text("certificate")
        self.lab.log = Mock()
        self.lab.request = Mock(side_effect=self.absent)
        self.lab.proxmox = Mock()
        self.lab.proxmox.get.return_value = {"data": []}

    @staticmethod
    def absent(method, path):
        if path == "/segments":
            return []
        raise demo_lab.LabAPIError(404, "absent")

    def test_removes_state_only_after_live_checks(self):
        self.lab.destroy_state()
        self.assertFalse(self.lab.directory.exists())
        self.assertTrue(all(call.args[0] == "GET" for call in self.lab.request.call_args_list))
        self.lab.proxmox.delete.assert_not_called()
        self.lab.proxmox.post.assert_not_called()

    def test_remaining_segment_or_router_preserves_state(self):
        for resource in ("segment", "router"):
            with self.subTest(resource=resource):
                self.lab.request.side_effect = lambda method, path: (
                    [{"id": 5000}] if path == "/segments" and resource == "segment"
                    else {} if resource == "router" and path != "/segments"
                    else self.absent(method, path)
                )
                with self.assertRaisesRegex(RuntimeError, "run destroy before destroy-state"):
                    self.lab.destroy_state()
                self.assertTrue(self.lab.path.exists())

    def test_remaining_second_tenant_preserves_state(self):
        self.lab.state["tenant"] = {"name": "demo-t2-run", "id": None, "create_requested": True}
        self.lab.request.side_effect = lambda method, path: (
            [{"id": "tenant-x", "name": "Demo-T2-Run"}] if path == "/tenants" else self.absent(method, path)
        )
        with self.assertRaisesRegex(RuntimeError, "tenant demo-t2-run"):
            self.lab.destroy_state()
        self.assertTrue(self.lab.path.exists())
        self.lab.request.side_effect = lambda method, path: (
            [{"id": "default", "name": "default"}] if path == "/tenants" else self.absent(method, path)
        )
        self.lab.destroy_state()
        self.assertFalse(self.lab.directory.exists())

    def test_remaining_vm_detected_after_saved_id_cleared(self):
        for config in ({"name": "demo-a1-db"}, {"name": "renamed", "description": "SwiftFabric demo lab run"},
                       {"name": "demo-nsr"}):
            with self.subTest(config=config):
                self.lab.proxmox.get.side_effect = [
                    {"data": [{"type": "qemu", "vmid": 123, "node": "migrated"}]},
                    {"data": config},
                ]
                with self.assertRaisesRegex(RuntimeError, "VM 123 on migrated"):
                    self.lab.destroy_state()
                self.assertTrue(self.lab.path.exists())

    def test_recorded_vmid_blocks_cleanup_even_if_renamed(self):
        self.lab.state["vms"][0]["vmid"] = 123
        self.lab.proxmox.get.side_effect = [
            {"data": [{"type": "qemu", "vmid": 123, "node": "host"}]},
            {"data": {"name": "renamed"}},
        ]
        with self.assertRaisesRegex(RuntimeError, "VM 123"):
            self.lab.destroy_state()
        self.assertTrue(self.lab.path.exists())

    def test_unrelated_vm_does_not_block_cleanup(self):
        self.lab.proxmox.get.side_effect = [
            {"data": [{"type": "qemu", "vmid": 999, "node": "host"}]},
            {"data": {"name": "unrelated", "description": "other lab"}},
        ]
        self.lab.destroy_state()
        self.assertFalse(self.lab.directory.exists())

    def test_live_check_errors_preserve_state(self):
        for failure in (demo_lab.LabAPIError(500, "controller unavailable"),
                        demo_lab.LabAPIError(403, "forbidden")):
            with self.subTest(failure=failure):
                self.lab.request.side_effect = failure
                with self.assertRaises(demo_lab.LabAPIError):
                    self.lab.destroy_state()
                self.assertTrue(self.lab.path.exists())
        self.lab.request.side_effect = self.absent
        self.lab.proxmox.get.side_effect = RuntimeError("Proxmox unavailable")
        with self.assertRaisesRegex(RuntimeError, "Proxmox unavailable"):
            self.lab.destroy_state()
        self.assertTrue(self.lab.path.exists())

    def test_router_check_error_is_not_treated_as_absence(self):
        def unavailable(method, path):
            if path == "/segments":
                return []
            raise demo_lab.LabAPIError(403, "forbidden")

        self.lab.request.side_effect = unavailable
        with self.assertRaises(demo_lab.LabAPIError):
            self.lab.destroy_state()
        self.assertTrue(self.lab.path.exists())

    def test_vm_config_check_error_preserves_state(self):
        self.lab.proxmox.get.side_effect = [
            {"data": [{"type": "qemu", "vmid": 123, "node": "host"}]},
            RuntimeError("VM config unavailable"),
        ]
        with self.assertRaisesRegex(RuntimeError, "VM config unavailable"):
            self.lab.destroy_state()
        self.assertTrue(self.lab.path.exists())

    def test_unexpected_files_and_symlinks_preserve_state(self):
        unexpected = self.lab.directory / "keep.txt"
        unexpected.write_text("keep")
        with self.assertRaisesRegex(RuntimeError, "unexpected files"):
            self.lab.destroy_state()
        unexpected.unlink()
        certificate = self.lab.directory / "controller-ca.crt"
        certificate.unlink()
        certificate.symlink_to(self.lab.path)
        with self.assertRaisesRegex(RuntimeError, "regular files"):
            self.lab.destroy_state()
        self.assertTrue(self.lab.path.exists())

    def test_protected_directory_rejected(self):
        self.lab.directory = Path.home().resolve()
        with self.assertRaisesRegex(RuntimeError, "protected directory"):
            self.lab.destroy_state()

    def test_cli_dispatches_existing_state(self):
        with patch.object(sys, "argv", ["demo_lab.py", "destroy-state", "--state",
                                       str(self.lab.directory), "--yes"]), \
                patch.object(demo_lab, "DemoLab", return_value=Mock()) as constructor:
            demo_lab.main()
        constructor.assert_called_once_with(self.lab.directory)
        constructor.return_value.destroy_state.assert_called_once_with()

    def test_cli_uses_default_state_directory(self):
        with patch.object(sys, "argv", ["demo_lab.py", "destroy-state", "--yes"]), \
                patch.object(demo_lab, "DEFAULT_STATE", self.lab.directory), \
                patch.object(demo_lab, "DemoLab", return_value=Mock()) as constructor:
            demo_lab.main()
        constructor.assert_called_once_with(self.lab.directory)
        constructor.return_value.destroy_state.assert_called_once_with()

    def test_cli_missing_state_does_not_create_new_plan(self):
        self.lab.path.unlink()
        with patch.object(sys, "argv", ["demo_lab.py", "destroy-state", "--state",
                                       str(self.lab.directory), "--yes"]), \
                patch("sys.stderr", new_callable=io.StringIO) as errors, \
                patch.object(demo_lab, "DemoLab") as constructor:
            with self.assertRaises(SystemExit) as failure:
                demo_lab.main()
        self.assertEqual(failure.exception.code, 2)
        self.assertIn("no demo lab state", errors.getvalue())
        constructor.assert_not_called()
        self.assertFalse(self.lab.path.exists())

    def test_cli_cancellation_preserves_state(self):
        with patch.object(sys, "argv", ["demo_lab.py", "destroy-state", "--state",
                                       str(self.lab.directory)]), \
                patch("builtins.input", return_value="no"), \
                patch.object(demo_lab, "DemoLab") as constructor:
            with self.assertRaisesRegex(SystemExit, "aborted"):
                demo_lab.main()
        constructor.assert_not_called()
        self.assertTrue(self.lab.path.exists())


class ConsoleTests(unittest.TestCase):
    def test_existing_vm_gets_standard_vga_and_tty1_login(self):
        lab = object.__new__(demo_lab.DemoLab)
        vm = {"created": True, "node": "hunsn3", "vmid": 123, "name": "demo-a1-db"}
        lab.state = {"vms": [vm, {"created": False}]}
        lab.vm_config = Mock(return_value={"vga": "std"})
        lab.wait_task = Mock()
        lab.proxmox = Mock()
        lab.proxmox.get.return_value = {"data": {"status": "running"}}
        lab.serial = Mock()
        lab.log = Mock()
        lab.configure_console()
        lab.vm_config.assert_called_once_with(vm)
        lab.proxmox.configure_vm.assert_not_called()
        lab.serial.assert_called_once_with(vm, "sudo -n systemctl enable --now getty@tty1.service")

    def test_running_serial_display_rejected_without_hardware_update(self):
        lab = object.__new__(demo_lab.DemoLab)
        lab.state = {"vms": [{"created": True, "node": "hunsn3", "vmid": 123, "name": "demo"}]}
        lab.vm_config = Mock(return_value={"vga": "serial0"})
        lab.proxmox = Mock()
        lab.proxmox.get.return_value = {"data": {"status": "running"}}
        with self.assertRaisesRegex(RuntimeError, "fully shut down"):
            lab.configure_console()
        lab.proxmox.configure_vm.assert_not_called()

    def test_stopped_vm_display_updated_before_next_start(self):
        lab = object.__new__(demo_lab.DemoLab)
        lab.state = {"vms": [{"created": True, "node": "hunsn3", "vmid": 123, "name": "demo"}]}
        lab.vm_config = Mock(return_value={"vga": "serial0"})
        lab.proxmox = Mock()
        lab.proxmox.get.return_value = {"data": {"status": "stopped"}}
        lab.wait_task = Mock()
        lab.log = Mock()
        lab.configure_console()
        lab.proxmox.configure_vm.assert_called_once_with("hunsn3", 123, vga="std")
        lab.proxmox.post.assert_not_called()

    def test_new_vm_retains_serial_with_standard_vga(self):
        lab = object.__new__(demo_lab.DemoLab)
        vm = {
            "kind": "client", "node": "hunsn3", "vmid": 123, "name": "demo-a1-client1",
            "segment_id": 5000, "address": "10.50.0.101", "gateway": "10.50.0.1", "created": False,
        }
        lab.state = {"run_id": "run", "storage": "VMData", "image_volume": "VMData:import/u.qcow2"}
        lab.proxmox = Mock()
        lab.proxmox.get.return_value = {"data": {"status": "stopped"}}
        lab.storage_lock = threading.Lock()
        lab.existing_vm = Mock(return_value=None)
        lab.wait_task = Mock()
        lab.save = Mock()
        lab.log = Mock()
        lab.create_vm(vm)
        config = lab.proxmox.post.call_args_list[0].kwargs["data"]
        self.assertEqual(config["vga"], "std")
        self.assertEqual(config["serial0"], "socket")
        self.assertEqual(config["cipassword"], "ubuntu")
        self.assertEqual(
            [call.args[0] for call in lab.proxmox.post.call_args_list],
            ["/nodes/hunsn3/qemu", "/nodes/hunsn3/qemu/123/status/start"],
        )
        lab.proxmox.configure_vm.assert_not_called()
        self.assertTrue(vm["created"])

    def test_resume_reuses_complete_vm_and_removes_partial_one(self):
        lab = object.__new__(demo_lab.DemoLab)
        lab.state = {"run_id": "run", "storage": "VMData", "image_volume": "VMData:import/u.qcow2"}
        lab.proxmox = Mock()
        lab.proxmox.get.return_value = {"data": {"status": "running"}}
        lab.storage_lock = threading.Lock()
        lab.wait_task = Mock()
        lab.save = Mock()
        lab.log = Mock()
        base = {"kind": "client", "node": "hunsn3", "segment_id": 5000, "address": "10.50.0.101",
                "gateway": "10.50.0.1", "created": False}

        lab.existing_vm = Mock(return_value={"scsi0": "x", "ide2": "y"})
        lab.create_vm(dict(base, vmid=1, name="complete"))
        lab.proxmox.post.assert_not_called()
        lab.proxmox.delete.assert_not_called()

        lab.existing_vm = Mock(return_value={"name": "partial"})
        lab.create_vm(dict(base, vmid=2, name="partial"))
        lab.proxmox.delete.assert_called_once()
        self.assertEqual(lab.proxmox.post.call_args_list[0].args[0], "/nodes/hunsn3/qemu")

    def test_locked_partial_vm_is_not_forced(self):
        lab = object.__new__(demo_lab.DemoLab)
        lab.state = {"run_id": "run", "storage": "VMData", "image_volume": "VMData:import/u.qcow2"}
        lab.proxmox = Mock()
        lab.existing_vm = Mock(return_value={"lock": "create"})
        vm = {"kind": "client", "node": "hunsn3", "vmid": 7, "name": "p", "segment_id": 5000,
              "address": "10.50.0.101", "gateway": "10.50.0.1", "created": False}
        with self.assertRaisesRegex(RuntimeError, "qm unlock 7"):
            lab.create_vm(vm)
        lab.proxmox.delete.assert_not_called()


class PlanTests(unittest.TestCase):
    def setUp(self):
        self.plan = demo_lab.build_plan(5000, "10.50.0.0/24", "10.0.0.0/8", NODES, "run", "secret")

    def test_segments_are_consecutive_24s(self):
        segments = self.plan["segments"]
        self.assertEqual([segment["id"] for segment in segments], list(range(5000, 5009)))
        self.assertEqual([segment["network"] for segment in segments],
                         [f"10.50.{index}.0/24" for index in (*range(5), *range(4))])
        self.assertTrue(all(segment["gateway_cidr"].endswith(".1/24") for segment in segments))

    def test_second_tenant_replicates_config_a_and_b_without_north_south(self):
        default = [segment for segment in self.plan["segments"] if segment["tenant"] == "default"]
        second = [segment for segment in self.plan["segments"] if segment["tenant"] == "second"]
        self.assertEqual([segment["role"] for segment in default], ["a1", "a2", "b-clients", "b-db", "ns"])
        self.assertEqual([segment["role"] for segment in second], ["a1", "a2", "b-clients", "b-db"])
        for original, replica in zip(default, second):
            self.assertEqual((replica["network"], replica["gateway_cidr"]),
                             (original["network"], original["gateway_cidr"]))
            self.assertNotEqual(replica["name"], original["name"])
        self.assertTrue(all(segment["tenant_id"] == "default" for segment in default))
        self.assertTrue(all("tenant_id" not in segment for segment in second))
        vms = {vm["name"]: vm for vm in self.plan["vms"]}
        for name, vm in vms.items():
            if name.startswith("demo-t2-"):
                original = vms["demo-" + name.removeprefix("demo-t2-")]
                self.assertEqual((vm["kind"], vm["address"], vm.get("servers"), vm.get("allow_networks")),
                                 (original["kind"], original["address"], original.get("servers"),
                                  original.get("allow_networks")))
        self.assertFalse(any(name.startswith("demo-t2-ns") for name in vms))

    def test_vm_counts_and_roles(self):
        counts = {}
        for vm in self.plan["vms"]:
            counts.setdefault((vm["segment_id"], vm["kind"]), 0)
            counts[(vm["segment_id"], vm["kind"])] += 1
        self.assertEqual(counts, {
            (5000, "db"): 1, (5000, "client"): 5, (5001, "db"): 1, (5001, "client"): 5,
            (5002, "client"): 8, (5003, "db"): 2, (5004, "idle"): 3,
            (5005, "db"): 1, (5005, "client"): 5, (5006, "db"): 1, (5006, "client"): 5,
            (5007, "client"): 8, (5008, "db"): 2,
        })
        self.assertEqual(len({vm["name"] for vm in self.plan["vms"]}), 47)
        self.assertEqual(len({vm["address"] for vm in self.plan["vms"]}), 25)

    def test_clients_target_expected_databases(self):
        vms = {vm["name"]: vm for vm in self.plan["vms"]}
        self.assertEqual(vms["demo-a1-client3"]["servers"], [vms["demo-a1-db"]["address"]])
        self.assertEqual(vms["demo-a2-client1"]["servers"], [vms["demo-a2-db"]["address"]])
        self.assertEqual(vms["demo-b-client8"]["servers"],
                         [vms["demo-b-db1"]["address"], vms["demo-b-db2"]["address"]])
        self.assertEqual(vms["demo-b-db1"]["allow_networks"], ["10.50.2.0/24"])
        self.assertEqual(vms["demo-a1-db"]["allow_networks"], ["10.50.0.0/24"])

    def test_every_segment_spans_every_node(self):
        for segment in self.plan["segments"]:
            members = [vm for vm in self.plan["vms"] if vm["segment_id"] == segment["id"]]
            self.assertEqual(len({vm["node"] for vm in members}), min(len(members), len(NODES)))

    def test_addresses_inside_their_segment(self):
        networks = {segment["id"]: ipaddress.ip_network(segment["network"]) for segment in self.plan["segments"]}
        for vm in self.plan["vms"]:
            self.assertIn(ipaddress.ip_address(vm["address"]), networks[vm["segment_id"]])

    def test_rejects_subnets_outside_supernet(self):
        with self.assertRaises(ValueError):
            demo_lab.build_plan(5000, "10.255.254.0/24", "10.0.0.0/8", NODES, "run", "secret")
        with self.assertRaises(ValueError):
            demo_lab.build_plan(5000, "10.50.0.0/23", "10.0.0.0/8", NODES, "run", "secret")

    def test_config_b_acls_scope_postgres_and_icmp(self):
        acls = demo_lab.b_acls(self.plan["segments"])
        self.assertEqual(set(acls), {5002, 5003, 5007, 5008})
        self.assertEqual((acls[5007], acls[5008]), (acls[5002], acls[5003]))
        self.assertEqual(acls[5002]["egress"], acls[5003]["ingress"])
        self.assertEqual(acls[5002]["ingress"], acls[5003]["egress"])
        for rule in acls[5002]["egress"]:
            self.assertEqual((rule["source"], rule["destination"]), ("10.50.2.0/24", "10.50.3.0/24"))
        for rule in acls[5002]["ingress"]:
            self.assertEqual((rule["source"], rule["destination"]), ("10.50.3.0/24", "10.50.2.0/24"))
        ports = lambda rules: {(r["protocol"], r["source_port"], r["destination_port"]) for r in rules}
        self.assertEqual(ports(acls[5002]["egress"]), {("tcp", "any", "5432"), ("icmp", "any", "any")})
        self.assertEqual(ports(acls[5002]["ingress"]), {("tcp", "5432", "any"), ("icmp", "any", "any")})


class LivePlanTests(unittest.TestCase):
    def setUp(self):
        self.lab = object.__new__(demo_lab.DemoLab)
        self.lab.state = {
            **demo_lab.build_plan(5000, "10.50.0.0/24", "10.0.0.0/8", NODES, "run", "secret"),
            "nodes": NODES,
        }
        self.lab.network_inventory = Mock(return_value=([], []))

    def select(self, first_id=5000, start="10.50.0.0/24", pool="10.0.0.0/8"):
        self.lab.select_plan(first_id, start, pool)
        return self.lab.state["segments"]

    def test_selects_free_consecutive_ids_and_subnets(self):
        self.lab.network_inventory.return_value = (
            [{"id": 5002}, {"id": 5006}],
            [ipaddress.ip_network("10.50.2.0/24"), ipaddress.ip_network("10.50.6.0/24")],
        )
        segments = self.select()
        self.assertEqual([segment["id"] for segment in segments], list(range(5007, 5016)))
        self.assertEqual([segment["network"] for segment in segments],
                         [f"10.50.{index}.0/24" for index in (*range(7, 12), *range(7, 11))])
        self.assertEqual(self.lab.state["run_id"], "run")
        self.assertEqual(self.lab.state["db_password"], "secret")
        networks = {segment["id"]: ipaddress.ip_network(segment["network"]) for segment in segments}
        for vm in self.lab.state["vms"]:
            self.assertIn(ipaddress.ip_address(vm["address"]), networks[vm["segment_id"]])

    def test_search_wraps_at_id_and_supernet_bounds(self):
        self.lab.network_inventory.return_value = (
            [{"id": 50000}], [ipaddress.ip_network("10.50.7.0/24")],
        )
        segments = self.select(49996, "10.50.3.0/24", "10.50.0.0/21")
        self.assertEqual(segments[0]["id"], 5000)
        self.assertEqual(segments[0]["network"], "10.50.0.0/24")

    def test_last_valid_id_block_is_accepted(self):
        self.assertEqual(self.select(49992)[-1]["id"], 50000)

    def test_exhaustion_fails_instead_of_overlapping(self):
        self.lab.network_inventory.return_value = (
            [{"id": number} for number in range(5000, 50001)], [],
        )
        with self.assertRaisesRegex(RuntimeError, "unused segment IDs"):
            self.select()
        self.lab.network_inventory.return_value = ([], [ipaddress.ip_network("10.0.0.0/8")])
        with self.assertRaisesRegex(RuntimeError, "non-overlapping /24s"):
            self.select()

    def test_inventory_includes_segment_management_vtep_and_bridge_networks(self):
        del self.lab.network_inventory
        self.lab.config = {
            "ip_range_start": "192.168.10.10", "cidr": 24,
        }
        self.lab.request = Mock(side_effect=[
            [{"id": 5100, "gateway_cidr": "10.50.0.1/24"}], {"cidr": "10.51.0.0/16"},
        ])
        self.lab.proxmox = Mock()
        self.lab.proxmox.get.side_effect = [
            {"data": [{"node": "host"}]},
            {"data": [{"cidr": "10.52.0.1/24"}, {"iface": "no-address"}]},
        ]
        _, reserved = self.lab.network_inventory()
        self.assertEqual({str(network) for network in reserved},
                         {"192.168.10.0/24", "10.50.0.0/24", "10.51.0.0/16", "10.52.0.0/24"})

    def test_new_plan_is_saved_after_validation_and_reused_on_deploy(self):
        config = {**CONFIG, "storage_location": "VMData", "ip_range_start": "192.0.2.10",
                  "cidr": 24, "auto_enroll_host_list": NODES}
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary) / "lab"
            state_file = directory / "state.json"
            lab = Mock()
            lab.network_inventory.return_value = (
                [{"id": 5000}], [ipaddress.ip_network("10.50.0.0/24")],
            )
            select_plan = demo_lab.DemoLab.select_plan
            lab.select_plan.side_effect = lambda *args: select_plan(lab, *args)

            def initialize(staging):
                lab.state = json.loads((staging / "state.json").read_text())
                return lab

            def validate():
                self.assertFalse(state_file.exists())

            lab.preflight.side_effect = validate
            with patch.object(sys, "argv", ["demo_lab.py", "plan", "--state", str(directory)]), \
                    patch.object(demo_lab, "load_deployment_config", return_value=config), \
                    patch.object(demo_lab, "deployer_source", return_value="192.0.2.99"), \
                    patch.object(demo_lab, "DemoLab", side_effect=initialize), \
                    patch("builtins.print"):
                demo_lab.main()
            saved = json.loads(state_file.read_text())
            self.assertEqual(saved, lab.state)
            self.assertEqual([segment["id"] for segment in saved["segments"]], list(range(5001, 5010)))
            self.assertEqual([segment["network"] for segment in saved["segments"]],
                             [f"10.50.{number}.0/24" for number in (*range(1, 6), *range(1, 5))])
            self.assertEqual(saved["tenant"], {
                "name": f"demo-t2-{saved['run_id'][:12]}", "id": None, "create_requested": False,
            })
            self.assertEqual(state_file.stat().st_mode & 0o777, 0o600)
            lab.select_plan.assert_called_once_with(5000, "10.50.0.0/24", "10.0.0.0/8")
            lab.preflight.assert_called_once_with()
            lab.deploy.assert_not_called()
            with patch.object(sys, "argv", ["demo_lab.py", "deploy", "--state", str(directory), "--yes"]), \
                    patch.object(demo_lab, "DemoLab", return_value=lab), \
                    patch("builtins.print"):
                demo_lab.main()
            lab.deploy.assert_called_once_with()
            self.assertEqual(json.loads(state_file.read_text()), saved)
            self.assertEqual(lab.select_plan.call_count, 1)

    def test_failed_validation_does_not_save_plan(self):
        config = {**CONFIG, "storage_location": "VMData", "ip_range_start": "192.0.2.10",
                  "cidr": 24, "auto_enroll_host_list": NODES}
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary) / "lab"
            lab = Mock()
            lab.preflight.side_effect = RuntimeError("image unavailable")
            with patch.object(sys, "argv", ["demo_lab.py", "plan", "--state", str(directory)]), \
                    patch.object(demo_lab, "load_deployment_config", return_value=config), \
                    patch.object(demo_lab, "deployer_source", return_value="192.0.2.99"), \
                    patch.object(demo_lab, "DemoLab", return_value=lab):
                with self.assertRaisesRegex(RuntimeError, "image unavailable"):
                    demo_lab.main()
            self.assertFalse(directory.exists())

    def test_existing_plan_is_validated_without_reallocation(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            (directory / "state.json").write_text(json.dumps(self.lab.state))
            lab = Mock(state={**self.lab.state, "router": {"request": {
                "id": "demo-nsr", "node": NODES[0], "wan_address_cidr": "192.0.2.1/24",
                "wan_gateway": "192.0.2.254", "wan_bridge": "vmbr0",
            }}})
            with patch.object(sys, "argv", ["demo_lab.py", "plan", "--state", str(directory)]), \
                    patch.object(demo_lab, "DemoLab", return_value=lab), \
                    patch("builtins.print"):
                demo_lab.main()
            lab.preflight.assert_called_once_with()
            lab.select_plan.assert_not_called()

    def test_deploy_rejects_new_id_or_subnet_conflict_before_creating_resources(self):
        self.lab.config = {"proxmox_cluster_name": "hunsn"}
        self.lab.request = Mock(return_value=[
            {"node": node, "cluster": "hunsn", "status": "enrolled"} for node in NODES
        ])
        self.lab.start_router = Mock()
        self.lab.create_segments = Mock()
        for inventory, error in (
            (([{"id": 5000}], []), "segment 5000 already exists"),
            (([], [ipaddress.ip_network("10.50.2.0/24")]), "overlaps existing network"),
        ):
            with self.subTest(error=error):
                self.lab.network_inventory.return_value = inventory
                with self.assertRaisesRegex(RuntimeError, error):
                    self.lab.deploy()
                self.lab.start_router.assert_not_called()
                self.lab.create_segments.assert_not_called()


class DeployTests(unittest.TestCase):
    def setUp(self):
        self.lab = object.__new__(demo_lab.DemoLab)
        self.lab.state = {"ready": False, "settle_seconds": 35}
        self.operations = Mock()
        for name in (
            "preflight", "start_router", "create_segments", "create_vms", "wait_router",
            "install_databases", "start_clients", "set_wan_policy", "verify", "save", "status", "log",
        ):
            setattr(self.lab, name, getattr(self.operations, name))

    def test_waits_after_final_policy_before_verifying_even_on_resume(self):
        with patch.object(demo_lab.time, "sleep") as sleep:
            self.operations.attach_mock(sleep, "sleep")
            self.lab.deploy()

        calls = [call[0] for call in self.operations.mock_calls]
        self.assertIn("sleep", calls)
        self.assertLess(calls.index("set_wan_policy"), calls.index("sleep"))
        self.assertLess(calls.index("sleep"), calls.index("verify"))
        self.assertLess(calls.index("verify"), calls.index("save"))
        self.lab.set_wan_policy.assert_called_once_with(demo_lab.EMPTY_WAN_POLICY)
        sleep.assert_called_once_with(35)
        self.assertTrue(self.lab.state["ready"])

    def test_failed_verification_does_not_mark_deployment_ready(self):
        self.lab.verify.side_effect = RuntimeError("No route to host")
        with patch.object(demo_lab.time, "sleep"), \
                self.assertRaisesRegex(RuntimeError, "No route to host"):
            self.lab.deploy()

        self.assertFalse(self.lab.state["ready"])
        self.lab.save.assert_not_called()
        self.lab.status.assert_not_called()


class RouterTests(unittest.TestCase):
    def test_router_from_nsr_config_has_no_wan_policy(self):
        body = demo_lab.router_request(NSR, CONFIG, "demo-nsr", "hunsn3",
                                       "VMData:import/u.qcow2", ["172.16.255.0/24"], None)
        self.assertEqual(body["wan_address_cidr"], NSR["wan_ip"])
        self.assertEqual(body["wan_gateway"], NSR["wan_upstream_router"])
        self.assertEqual((body["wan_bridge"], body["wan_vlan_id"]), ("vmbr0", 4000))
        self.assertEqual((body["vtep_bridge"], body["vtep_vlan_id"]), ("vmbr2", 91))
        self.assertEqual(body["deployment_mode"], "standalone")
        self.assertEqual(body["image_storage"], "VMData")
        for key in demo_lab.WAN_POLICY_KEYS:
            self.assertEqual(body[key], [])
        self.assertNotIn("cloud_init_password", body)
        json.dumps(body)

    def test_rejects_gateway_outside_wan_subnet(self):
        with self.assertRaises(ValueError):
            demo_lab.router_request({**NSR, "wan_upstream_router": "203.0.113.9"}, CONFIG,
                                    "demo-nsr", "hunsn3", "VMData:x", ["10.0.0.0/8"], None)

    def test_allowlist_adds_deployer_once(self):
        merge = demo_lab.merge_allowlist
        self.assertEqual(merge(["172.16.255.0/24"], "192.168.40.142/32"),
                         ["172.16.255.0/24", "192.168.40.142/32"])
        self.assertEqual(merge(["172.16.255.0/24"], "172.16.255.9/32"), ["172.16.255.0/24"])
        self.assertEqual(merge(["172.16.255.0/24", "192.168.40.142/32"], "192.168.40.142/32"),
                         ["172.16.255.0/24", "192.168.40.142/32"])

    def test_deployer_source_uses_route_to_controller(self):
        self.assertEqual(demo_lab.deployer_source("127.0.0.1"), "127.0.0.1")

    def router_lab(self, current):
        lab = object.__new__(demo_lab.DemoLab)
        lab.state = {"router": {"id": "demo-nsr", "request": {
            "id": "demo-nsr", "management_allowlist": ["172.16.255.0/24"], "cloud_init_password": "x"}}}
        lab.config = {"ip_range_start": "172.16.255.2"}
        lab.deployer_cidr = Mock(return_value="192.168.40.142/32")
        lab.save = Mock()
        lab.log = Mock()
        lab.request = Mock(return_value=current)
        return lab

    def test_existing_router_gets_deployer_allowlist_staged(self):
        current = {
            "status": "failed", "vmid": 140, "_version": 31,
            "management_allowlist": ["172.16.255.0/24"],
        }
        lab = self.router_lab(current)
        lab.ensure_router_allowlist(current)
        method, path, body = lab.request.call_args_list[0].args
        self.assertEqual((method, path), ("PUT", "/north-south-routers/demo-nsr"))
        self.assertEqual(body["management_allowlist"], ["172.16.255.0/24", "192.168.40.142/32"])
        self.assertEqual(body["_version"], 31)
        self.assertNotIn("cloud_init_password", body)

    def test_allowlist_already_staged_is_not_resent(self):
        current = {"status": "failed", "vmid": 140, "management_allowlist": ["172.16.255.0/24"],
                   "pending_configuration": {"management_allowlist": ["172.16.255.0/24", "192.168.40.142/32"]}}
        lab = self.router_lab(current)
        lab.state["router"]["request"]["management_allowlist"].append("192.168.40.142/32")
        self.assertIs(lab.ensure_router_allowlist(current), current)
        lab.request.assert_not_called()

    def test_failed_router_is_retried_then_reported(self):
        lab = self.router_lab(None)
        statuses = iter([
            {"status": "failed", "status_message": "watchdog"},
            {"status": "active"},
        ])
        lab.request = Mock(side_effect=lambda method, path, body=None: next(statuses) if method == "GET" else None)
        original = demo_lab.time.sleep
        demo_lab.time.sleep = lambda seconds: None
        try:
            self.assertEqual(lab.wait_router()["status"], "active")
            lab.request.side_effect = lambda method, path, body=None: (
                {"status": "failed", "status_message": "watchdog"} if method == "GET" else None)
            with self.assertRaisesRegex(RuntimeError, "deployment failed: watchdog"):
                lab.wait_router(retries=1)
        finally:
            demo_lab.time.sleep = original
        retries = [call for call in lab.request.call_args_list if call.args[0] == "POST"]
        self.assertEqual(len(retries), 2)
        self.assertEqual(
            [call.args for call in retries],
            [("POST", "/north-south-routers/demo-nsr/retry")] * 2,
        )

    def test_router_deploy_lifecycle_post_has_no_version_body(self):
        lab = self.router_lab({
            "status": "active", "vmid": None,
            "management_allowlist": ["172.16.255.0/24", "192.168.40.142/32"],
        })
        lab.state["router"]["create_requested"] = True
        lab.state["router"]["request"]["node"] = "hunsn3"
        current = lab.request.return_value
        lab.request = Mock(side_effect=lambda method, path: current if method == "GET" else None)

        lab.start_router()

        self.assertEqual(
            [call.args for call in lab.request.call_args_list],
            [
                ("GET", "/north-south-routers/demo-nsr"),
                ("POST", "/north-south-routers/demo-nsr/deploy"),
            ],
        )

    def test_apt_policy_is_scoped(self):
        policy = demo_lab.apt_wan_policy(["10.50.0.0/24", "10.50.3.0/24"])
        self.assertEqual(policy["masquerade_source_cidrs"], ["10.50.0.0/24", "10.50.3.0/24"])
        self.assertEqual(policy["wan_ingress_rules"], [])
        self.assertEqual(policy["inbound_port_mappings"], [])
        rules = {(r["source"], r["destination"], r["protocol"], r["destination_port"]) for r in policy["wan_egress_rules"]}
        self.assertEqual(len(rules), 12)
        self.assertIn(("10.50.3.0/24", "8.8.8.8/32", "udp", "53"), rules)
        self.assertIn(("10.50.0.0/24", "1.1.1.1/32", "tcp", "53"), rules)
        self.assertIn(("10.50.0.0/24", "0.0.0.0/0", "tcp", "443"), rules)
        self.assertFalse({r for r in rules if r[1] == "0.0.0.0/0" and r[3] not in ("80", "443")})
        for rule in policy["wan_egress_rules"]:
            ipaddress.IPv4Network(rule["source"])
            ipaddress.IPv4Network(rule["destination"])

    def test_attached_router(self):
        self.assertEqual(demo_lab.attached_router({"north_south_router": {"id": "r"}}), "r")
        self.assertIsNone(demo_lab.attached_router({"north_south_router": None}))

    def test_wan_policy_uses_its_own_current_version(self):
        lab = self.router_lab({"_version": 4})
        policy_version = 29
        lab.request = Mock(side_effect=lambda method, path, body=None: (
            {"_version": policy_version}
            if method == "GET" and path.endswith("/wan-policy")
            else None
        ))

        lab.set_wan_policy(demo_lab.EMPTY_WAN_POLICY)

        self.assertEqual(
            lab.request.call_args_list[0].args,
            ("GET", "/north-south-routers/demo-nsr/wan-policy"),
        )
        method, path, body = lab.request.call_args_list[1].args
        self.assertEqual((method, path), ("PUT", "/north-south-routers/demo-nsr/wan-policy"))
        self.assertEqual(body["_version"], policy_version)


class SecondTenantTests(unittest.TestCase):
    TENANT_ID = "tenant-00000000-0000-4000-8000-000000000000"

    def setUp(self):
        self.lab = object.__new__(demo_lab.DemoLab)
        self.lab.state = {
            **demo_lab.build_plan(5000, "10.50.0.0/24", "10.0.0.0/8", NODES, "run", "secret"),
            "router": {"id": "demo-nsr", "create_requested": False},
            "tenant": {"name": "demo-t2-run", "id": None, "create_requested": False},
            "router_tenant": "default", "mirror_access": [], "settle_seconds": 30,
        }
        self.lab.save = Mock()
        self.lab.log = Mock()

    def test_tenant_created_with_stable_id_and_segments(self):
        def create_tenant(method, path, body=None):
            self.assertEqual((method, path), ("POST", "/tenants"))
            self.assertEqual(set(body), {"id", "name"})
            self.assertRegex(body["id"], r"^tenant-[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$")
            self.assertEqual(body["name"], "demo-t2-run")
            return {"id": body["id"], "name": body["name"]}

        self.lab.request = Mock(side_effect=create_tenant)
        self.lab.ensure_tenant()
        tenant_id = self.lab.request.call_args.args[2]["id"]
        self.assertEqual(self.lab.state["tenant"]["id"], tenant_id)
        self.assertNotIn("request_id", self.lab.state["tenant"])
        second = [segment for segment in self.lab.state["segments"] if segment["tenant"] == "second"]
        self.assertTrue(all(segment["tenant_id"] == tenant_id for segment in second))

    def test_tenant_create_retry_reuses_id_after_lost_response(self):
        requests = []

        def strict_create(method, path, body=None):
            self.assertEqual((method, path), ("POST", "/tenants"))
            self.assertEqual(set(body), {"id", "name"})
            self.assertRegex(body["id"], r"^tenant-[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$")
            self.assertEqual(body["name"], "demo-t2-run")
            requests.append(dict(body))
            if len(requests) == 1:
                raise TimeoutError("response lost after tenant create")
            self.assertEqual(requests[1], requests[0])
            return {"id": requests[0]["id"], "name": "demo-t2-run"}

        self.lab.request = Mock(side_effect=strict_create)
        with self.assertRaisesRegex(TimeoutError, "response lost"):
            self.lab.ensure_tenant()
        stable_id = self.lab.state["tenant"]["request_id"]
        self.assertEqual(stable_id, requests[0]["id"])
        self.assertTrue(self.lab.state["tenant"]["create_requested"])

        self.lab.ensure_tenant()
        self.assertEqual(self.lab.request.call_count, 2)
        self.assertEqual(self.lab.state["tenant"]["id"], stable_id)
        self.assertNotIn("request_id", self.lab.state["tenant"])

    def test_tenant_create_rejects_mismatched_response_id(self):
        self.lab.request = Mock(return_value={"id": self.TENANT_ID, "name": "demo-t2-run"})
        with self.assertRaisesRegex(RuntimeError, "creation ID mismatch"):
            self.lab.ensure_tenant()
        self.assertEqual(self.lab.state["tenant"]["request_id"], self.lab.request.call_args.args[2]["id"])
        self.assertIsNone(self.lab.state["tenant"]["id"])

    def test_legacy_tenant_creation_recovers_by_name(self):
        self.lab.state["tenant"].update(id=None, create_requested=True)
        self.lab.request = Mock(return_value=[{"id": self.TENANT_ID, "name": "demo-t2-run"}])
        self.lab.ensure_tenant()
        self.lab.request.assert_called_once_with("GET", "/tenants")
        self.assertEqual(self.lab.state["tenant"]["id"], self.TENANT_ID)

    def test_segments_created_in_their_tenant(self):
        self.lab.state["tenant"].update(id=self.TENANT_ID, create_requested=True)
        self.lab.owned_segment = Mock()
        acl_versions = {5002: 17, 5003: 43, 5007: 71, 5008: 89}

        def strict_segment_api(method, path, body=None):
            if (method, path) == ("POST", "/segments"):
                return {}
            if method == "GET" and path.endswith("/acl"):
                segment_id = int(path.split("/")[2])
                return {"_version": acl_versions[segment_id]}
            if method == "PUT" and path.endswith("/acl"):
                segment_id = int(path.split("/")[2])
                self.assertEqual(body["_version"], acl_versions[segment_id])
                return {}
            self.fail(f"unexpected API call: {method} {path}")

        self.lab.request = Mock(side_effect=strict_segment_api)
        self.lab.create_segments()
        bodies = {call.args[2]["id"]: call.args[2] for call in self.lab.request.call_args_list
                  if call.args[:2] == ("POST", "/segments")}
        self.assertEqual({identifier: body["tenant_id"] for identifier, body in bodies.items()}, {
            **{identifier: "default" for identifier in range(5000, 5005)},
            **{identifier: self.TENANT_ID for identifier in range(5005, 5009)},
        })
        self.assertEqual(bodies[5005]["gateway_cidr"], bodies[5000]["gateway_cidr"])
        acl_writes = [
            call.args[2] for call in self.lab.request.call_args_list
            if call.args[:2] and call.args[0] == "PUT" and call.args[1].endswith("/acl")
        ]
        self.assertEqual(len(acl_writes), len(acl_versions))
        self.assertEqual(
            {call.args[1].split("/")[2]: call.args[2]["_version"]
             for call in self.lab.request.call_args_list
             if call.args[0] == "PUT" and call.args[1].endswith("/acl")},
            {str(segment_id): version for segment_id, version in acl_versions.items()},
        )

    def test_router_lent_to_second_tenant_only_while_detached_and_policy_free(self):
        self.lab.state["tenant"].update(id=self.TENANT_ID, create_requested=True)
        for segment in self.lab.state["segments"]:
            if segment["tenant"] == "second":
                segment["tenant_id"] = self.TENANT_ID
        router = {"tenant_id": "default", "_version": 37}
        events = []

        def request(method, path, body=None):
            if path == "/north-south-routers/demo-nsr":
                return dict(router)
            if path.endswith("/tenant"):
                self.assertFalse(attached, "router reassigned while segments attached")
                self.assertEqual(policy[-1], demo_lab.EMPTY_WAN_POLICY)
                self.assertEqual(body["_version"], router["_version"])
                router["tenant_id"] = body["tenant_id"]
                router["_version"] += 1
                events.append(("tenant", body["tenant_id"]))
            return None

        attached, policy = set(), [demo_lab.EMPTY_WAN_POLICY]

        def attach(segment, router_id):
            if router_id:
                self.assertEqual(segment.get("tenant_id"), router["tenant_id"])
                attached.add(segment["id"])
            else:
                attached.discard(segment["id"])

        def guest(vm, arguments, timeout=300):
            events.append(("install", router["tenant_id"], vm["name"]))
            return "ready"

        self.lab.request = Mock(side_effect=request)
        self.lab.attach = Mock(side_effect=attach)
        self.lab.set_wan_policy = Mock(side_effect=policy.append)
        self.lab.guest = Mock(side_effect=guest)
        with patch.object(demo_lab.time, "sleep"):
            self.lab.install_databases()

        installs = {(event[1], event[2]) for event in events if event[0] == "install"}
        self.assertEqual(installs, {
            ("default", "demo-a1-db"), ("default", "demo-a2-db"),
            ("default", "demo-b-db1"), ("default", "demo-b-db2"),
            (self.TENANT_ID, "demo-t2-a1-db"), (self.TENANT_ID, "demo-t2-a2-db"),
            (self.TENANT_ID, "demo-t2-b-db1"), (self.TENANT_ID, "demo-t2-b-db2"),
        })
        self.assertEqual([event for event in events if event[0] == "tenant"],
                         [("tenant", self.TENANT_ID), ("tenant", "default")])
        self.assertEqual(router["tenant_id"], "default")
        self.assertEqual((attached, policy[-1], self.lab.state["mirror_access"]),
                         (set(), demo_lab.EMPTY_WAN_POLICY, []))

    def test_segment_lifecycle_uses_api_metadata_not_saved_plan_or_acl_versions(self):
        self.lab.state["tenant"].update(id=self.TENANT_ID, create_requested=True)
        self.lab.state["vms"] = []
        self.lab.proxmox = Mock()
        self.lab.proxmox.get.return_value = {"data": []}
        self.lab.destroy_tenant = Mock()
        inventory, acl_versions = {}, {}
        mutations = []

        def request(method, path, body=None):
            if (method, path) == ("POST", "/segments"):
                segment_id = body["id"]
                self.assertNotIn("_version", body)
                inventory[segment_id] = {
                    **body, "_version": 17 + segment_id, "createdAt": 1, "updatedAt": 1,
                    "jumbo_frames": False, "mtu": 1500, "port": segment_id,
                    "primary_ip": "192.0.2.10",
                }
                acl_versions[segment_id] = 71 + segment_id
                return dict(inventory[segment_id])
            if (method, path) == ("GET", "/segments"):
                return [dict(item) for item in inventory.values()]
            segment_id = int(path.split("/")[2].split("?")[0])
            if method == "GET" and path.endswith("/acl"):
                return {"egress": [], "ingress": [], "_version": acl_versions[segment_id]}
            if method == "PUT" and path.endswith("/acl"):
                self.assertEqual(body["_version"], acl_versions[segment_id])
                self.assertNotEqual(body["_version"], inventory[segment_id]["_version"])
                acl_versions[segment_id] += 1
                mutations.append("acl")
                return {**body, "_version": acl_versions[segment_id]}
            if method == "PUT" and path.endswith("/north-south-router"):
                self.assertEqual(body["_version"], inventory[segment_id]["_version"])
                inventory[segment_id]["_version"] += 1
                mutations.append("attach" if body["router_id"] else "detach")
                return None
            if method == "DELETE":
                self.assertEqual(path, f"/segments/{segment_id}?_version={inventory[segment_id]['_version']}")
                del inventory[segment_id]
                mutations.append("delete")
                return None
            self.fail(f"unexpected API call: {method} {path}")

        self.lab.request = Mock(side_effect=request)
        self.lab.create_segments()
        for segment in self.lab.state["segments"]:
            self.assertNotIn("_version", segment)
            self.lab.attach(segment, "demo-nsr")
        self.lab.destroy()
        self.assertEqual(inventory, {})
        self.assertEqual({operation: mutations.count(operation) for operation in set(mutations)},
                         {"acl": 4, "attach": 9, "detach": 9, "delete": 9})
        self.assertTrue(all("_version" not in segment for segment in self.lab.state["segments"]))

    def test_failed_second_tenant_install_returns_router_to_default(self):
        self.lab.state["router_tenant"] = self.TENANT_ID
        self.lab.state["mirror_access"] = [5005]
        self.lab.set_wan_policy = Mock()
        self.lab.attach = Mock()
        self.lab.request = Mock(return_value={"tenant_id": self.TENANT_ID, "_version": 53})
        self.lab.revoke_mirror_access()
        self.lab.set_wan_policy.assert_called_once_with(demo_lab.EMPTY_WAN_POLICY)
        self.lab.request.assert_called_with(
            "PUT", "/north-south-routers/demo-nsr/tenant",
            {"tenant_id": "default", "_version": 53})
        self.assertEqual(self.lab.state["router_tenant"], "default")

    def test_destroy_tenant_checks_ownership_and_deletes(self):
        self.lab.state["tenant"].update(id=self.TENANT_ID, create_requested=True)
        self.lab.request = Mock(return_value=[{"id": self.TENANT_ID, "name": "other"}])
        with self.assertRaisesRegex(RuntimeError, "ownership mismatch"):
            self.lab.destroy_tenant()
        self.lab.request = Mock(side_effect=[[
            {"id": self.TENANT_ID, "name": "demo-t2-run", "_version": 3},
        ], None])
        self.lab.destroy_tenant()
        self.lab.request.assert_called_with(
            "DELETE", f"/tenants/{self.TENANT_ID}?_version=3",
        )
        self.assertEqual(self.lab.state["tenant"], {
            "name": "demo-t2-run", "id": None, "create_requested": False,
        })

    def test_destroy_deletes_segment_with_version_refreshed_after_detach(self):
        segment = {"id": 5000, "create_requested": True}
        lab = object.__new__(demo_lab.DemoLab)
        lab.state = {
            "vms": [], "segments": [segment],
            "router": {"id": "demo-nsr", "create_requested": False},
            "mirror_access": [], "router_tenant": "default",
        }
        lab.proxmox = Mock()
        lab.proxmox.get.return_value = {"data": []}
        lab.owned_segment = Mock(side_effect=[
            {"_version": 12}, {"_version": 23}, {"_version": 47},
        ])
        calls = []

        def strict_segment_api(method, path, body=None):
            calls.append((method, path, body))
            if method == "PUT":
                self.assertEqual(path, "/segments/5000/north-south-router")
                self.assertEqual(body, {"router_id": None, "_version": 23})
                return {}
            if method == "DELETE":
                self.assertEqual(path, "/segments/5000?_version=47")
                return {}
            self.fail(f"unexpected API call: {method} {path}")

        lab.request = strict_segment_api
        lab.save = Mock()
        lab.log = Mock()

        lab.destroy()

        self.assertEqual([call[:2] for call in calls], [
            ("PUT", "/segments/5000/north-south-router"),
            ("DELETE", "/segments/5000?_version=47"),
        ])
        self.assertFalse(segment["create_requested"])


if __name__ == "__main__":
    unittest.main()
