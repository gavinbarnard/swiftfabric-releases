# Demo lab packet captures

Capture commands for showing SwiftFabric's overlay on the wire during a demo
of the lab deployed by [demo_lab.py](demo_lab.py). Run them as root on the
Proxmox compute hosts.

## What is on the wire

| Item | Value |
| --- | --- |
| Encapsulation | Geneve, outer UDP destination port **6081** (agent `geneve_port`) |
| VNI | equals the segment ID; tcpdump prints it in hex |
| Capture interface | `sf-vtep` (VTEP VLAN 91 sub-interface of `vmbr2`) |
| Outer IPs | host VTEP addresses from the 172.16.25.0/24 pool |
| Distributed gateway MAC | `02:53:46:00:<id-hi>:<id-lo>`, the same on every host |

| Segment | Role | VNI (tcpdump) | Gateway MAC | Network |
| --- | --- | --- | --- | --- |
| 5000 | Config A replica 1 | `0x1388` | `02:53:46:00:13:88` | 10.50.0.0/24 (DB 10.50.0.10) |
| 5001 | Config A replica 2 | `0x1389` | `02:53:46:00:13:89` | 10.50.1.0/24 (DB 10.50.1.10) |
| 5002 | Config B clients | `0x138a` | `02:53:46:00:13:8a` | 10.50.2.0/24 |
| 5003 | Config B databases | `0x138b` | `02:53:46:00:13:8b` | 10.50.3.0/24 (DBs .10, .11) |

The addresses assume the defaults (`--first-segment-id 5000`, `--subnet-start
10.50.0.0/24`).

## 1. Find the hosts

From the workstation, list where each VM landed:

```sh
python3 demos/demo_lab.py status
```

Pick the DB you want to watch (for example `demo-a1-db`), then SSH to its
`node`. Pick a client on a **different** node: clients that share the DB's host
never leave that host, so they never appear on `sf-vtep`.

On the host, confirm the VTEP device and address:

```sh
ip -4 -br addr show dev sf-vtep      # this host's VTEP, e.g. 172.16.25.10/32
qm list | grep demo-                 # demo VMs running on this host
```

## 2. Load the capture helpers (once per shell)

Paste these into the root shell on each host you capture on:

```sh
GENEVE_PORT=6081
VTEP_DEV=sf-vtep

# BPF for Geneve on the given VNIs, carrying inner IPv4.
# Byte offsets are from the start of the outer UDP header. SwiftFabric
# tunnels carry no Geneve options, so the inner Ethernet frame starts at udp[16].
sf_filter() {
  local vnis="" v
  for v in "$@"; do vnis="${vnis:+$vnis or }(udp[12:4] >> 8) = $v"; done
  echo "udp dst port $GENEVE_PORT and (udp[8] & 0x3f) = 0 and ($vnis) and udp[28:2] = 0x0800"
}
ip2hex() { local IFS=.; set -- $1; printf '0x%02x%02x%02x%02x' "$1" "$2" "$3" "$4"; }
# Inner IPv4 source or destination equals $1.
inner_host() { local h; h=$(ip2hex "$1"); echo "(udp[42:4] = $h or udp[46:4] = $h)"; }
# Inner TCP 5432 (PostgreSQL) in either direction / inner ICMP.
PG="udp[39] = 6 and (udp[50:2] = 5432 or udp[52:2] = 5432)"
ICMP="udp[39] = 1"
```

The tcpdump flags used below:
- `-nn`: no name or port resolution.
- `-e`: print link headers, so the inner Ethernet MACs appear.
- `-v`: print outer and inner IP TTL and length.
- `-l`: line-buffered output.
- `-c` / `timeout`: bound the capture.

## 3. Config A: same-segment L2 over VTEP unicast (5000, reusable for 5001)

Run on the host running `demo-a1-db` (or `demo-a2-db` for 5001):

```sh
SEG=5000                       # 5001 for the second replica
timeout 60 tcpdump -i "$VTEP_DEV" -nn -e -v -l -c 20 "$(sf_filter $SEG) and $PG"
```

Expected output (addresses vary by placement):

```text
... ethertype IPv4 (0x0800), length 1xx: (tos 0x0, ttl 64, ..., proto UDP (17), length ...)
    172.16.25.11.40213 > 172.16.25.10.6081: Geneve, Flags [none], vni 0x1388, proto TEB (0x6558)
	bc:24:11:aa:bb:01 > bc:24:11:aa:bb:10, ethertype IPv4 (0x0800), ...: (... ttl 64, ... proto TCP (6) ...)
    10.50.0.101.51000 > 10.50.0.10.5432: Flags [P.], ...
```

What to point out:
- **Outer header:** unicast UDP from one host VTEP to the other host's VTEP on
  port 6081. There is no multicast group and no flooding; each frame goes
  straight to the host where the destination MAC lives.
- **Geneve VNI:** `0x1388` = segment 5000 (`0x1389` = 5001). The two replicas
  share the underlay but stay isolated by VNI.
- **Inner frame:** VM MAC to VM MAC, both IPs in the same /24, and inner TTL
  still 64. This is pure L2 extension; nothing routed it.

### Show the VTEP change during live migration

On the host currently running `demo-a1-db`, load the helpers above and run:

```sh
SEG=5000
tcpdump -i "$VTEP_DEV" -nn -e -v -l -K "$(sf_filter $SEG) and $PG" | grep -B2 10.50.0.102
```

`10.50.0.102` is `demo-a1-client2` with the default lab addressing. While its
queries are flowing, live-migrate that VM to a different compute host. The
captured Geneve outer source address should change to the new host's VTEP; the
outer destination changes on replies. The inner client/database IPs and
segment VNI stay the same. `grep -B2` keeps the
preceding Geneve and inner-frame lines with each matching client packet.
`-K` disables tcpdump checksum verification, which avoids misleading
checksum warnings when the NIC performs checksum offload. `grep` filters
printed output only; the BPF expression still limits capture to the segment's
PostgreSQL traffic.

Variations:

```sh
# Follow one client only (e.g. demo-a1-client3).
timeout 60 tcpdump -i "$VTEP_DEV" -nn -e -v -l "$(sf_filter $SEG) and $PG and $(inner_host 10.50.0.103)"

# Everything IPv4 on the segment (also shows ICMP from a console ping).
timeout 60 tcpdump -i "$VTEP_DEV" -nn -e -v -l "$(sf_filter $SEG)"

# Watch both Config A replicas side by side; VNIs keep them apart.
timeout 60 tcpdump -i "$VTEP_DEV" -nn -e -l "$(sf_filter 5000 5001) and $PG"

# Save for Wireshark (it decodes Geneve on 6081 natively).
timeout 120 tcpdump -i "$VTEP_DEV" -nn -w /root/sf-seg$SEG.pcap "$(sf_filter $SEG) and $PG"
```

## 4. Config B: East/West distributed routing (5002 -> 5003)

Every host carries the gateway for every routed segment, with the same
gateway MAC everywhere. Traffic from a client in 5002 to a DB in 5003 works
like this:
- The client's own host routes it and applies the ACLs.
- The routed frame is then tunneled straight to the DB's host on the
  **destination** segment's VNI.
- The reply is routed on the DB's host and returns on VNI 5002.

No central router or hairpin is involved.

Run on the host running `demo-b-db1` (use `10.50.3.11` for `demo-b-db2`):

```sh
DB=10.50.3.10
timeout 60 tcpdump -i "$VTEP_DEV" -nn -e -v -l -c 20 "$(sf_filter 5002 5003) and $PG and $(inner_host $DB)"
```

Expected output:

```text
    172.16.25.12.39012 > 172.16.25.10.6081: Geneve, Flags [none], vni 0x138b, proto TEB (0x6558)
	02:53:46:00:13:8b > bc:24:11:aa:bb:10, ethertype IPv4 (0x0800), ...: (... ttl 63, ... proto TCP (6) ...)
    10.50.2.101.52000 > 10.50.3.10.5432: Flags [P.], ...
    172.16.25.10.47781 > 172.16.25.12.6081: Geneve, Flags [none], vni 0x138a, proto TEB (0x6558)
	02:53:46:00:13:8a > bc:24:11:aa:bb:01, ethertype IPv4 (0x0800), ...: (... ttl 63, ... proto TCP (6) ...)
    10.50.3.10.5432 > 10.50.2.101.52000: Flags [P.], ...
```

What to point out:
- **Request:** carried on VNI `0x138b` (5003, the destination segment). The
  inner source MAC is the 5003 gateway MAC `02:53:46:00:13:8b`, and inner TTL
  is 63. The client's host already performed the route.
- **Reply:** carried on VNI `0x138a` (5002) with source MAC
  `02:53:46:00:13:8a`, and TTL 63 again. The DB's host routed it locally.
- **Outer IPs:** VTEP to VTEP between exactly the two hosts holding the client
  and the DB. This is unicast in both directions.
- **Inner IPs:** the real client and DB addresses; there is no NAT.
- **Both databases:** each client queries both DBs. Drop `$(inner_host $DB)`
  to see flows to `.10` and `.11` interleaved:

```sh
timeout 60 tcpdump -i "$VTEP_DEV" -nn -e -l "$(sf_filter 5002 5003) and $PG"
```

### Show the routing hop on the client's host

On the node running the chosen client (e.g. `demo-b-client1`, 10.50.2.101),
run these in two terminals:

```sh
# Before routing: client -> gateway MAC on segment 5002, TTL 64.
timeout 60 tcpdump -i sf-br5002 -nn -e -v -l "host 10.50.2.101 and tcp port 5432"

# After routing: same packet leaves on VNI 5003 toward the DB's host, TTL 63.
timeout 60 tcpdump -i "$VTEP_DEV" -nn -e -v -l "$(sf_filter 5003) and $PG and $(inner_host 10.50.2.101)"
```

The first capture shows destination MAC `02:53:46:00:13:8a` (the local 5002
gateway). The second shows the rewritten frame (source `02:53:46:00:13:8b`)
encapsulated directly to the DB host's VTEP.

### ICMP and ACL checks from a console

The mirrored Config B ACLs permit only TCP 5432 and ICMP between 5002 and 5003. Run these
on a client console (`ubuntu` / `ubuntu`) while capturing on the client's host
with `"$(sf_filter 5002 5003) and $ICMP"`:

```sh
ping -c 3 10.50.3.10      # allowed: echo on VNI 0x138b, reply on 0x138a
ping -c 3 10.50.0.10      # Config A DB: denied by ACL on the client's host
```

The denied ping never reaches `sf-vtep`. It is dropped by the routing ACL on
the client's host, so `$(sf_filter 5000 5002)` shows nothing for it.

## 5. North/South router path and WAN policy

During the demo, attach the NSR to the North/South demo segment (5004 by
default). The `demo-ns-vm` instances are idle Ubuntu VMs, so select one as the
test endpoint and prepare a harmless listener before adding an inbound port
mapping. Keep the mapping and ingress ACL restricted to the known test
client's source address; remove them after the demo. WAN ingress is default
deny, and an inbound mapping does not bypass the WAN ingress ACL.

On the Proxmox compute host where `demo-nsr` is deployed, capture the segment
VNI while the attached VM sends traffic to a controlled external endpoint:

```sh
SEG=5004
tcpdump -i "$VTEP_DEV" -nn -e -v -l "$(sf_filter $SEG) and $(inner_host 10.50.4.10)"
```

The outer Geneve destination is the NSR's VTEP. The inner packet still has
the VM's private source address here: the compute host steers the packet to
the NSR but does not route or NAT it. On the NSR console, compare the segment
and WAN sides:

```sh
sf-cli nsr capture segment:5004 --filter 'host 10.50.4.10'
sf-cli nsr capture wan --filter 'host <controlled-endpoint-ip>'
```

On WAN, the outbound packet should use the NSR's WAN address after
masquerading. To demonstrate policy, start with default deny, add a narrowly
scoped WAN egress rule for the controlled endpoint and protocol/port, and
configure `10.50.4.0/24` as a masquerade source. Show the flow succeed, remove
the egress rule and show a new flow fail, then restore the rule and show the
flow resume. Policy changes govern new flows; use a fresh connection for each
test.

For the ingress/NAT example, add a TCP inbound port mapping from a chosen WAN
port to the test VM's listener, then add a WAN ingress rule for the known
external test-client source and the VM's private address/translated port.
Capture on WAN and `segment:5004` while the external test client connects.
Show the WAN destination translated to the private VM, then remove the
ingress rule to demonstrate default deny even while the mapping exists. Restore
the rule for one final successful connection, then remove the mapping and
policy when finished.

## Notes

- **Different Geneve port:** if `geneve_port` was changed in the host-agent
  config, set `GENEVE_PORT` before defining `sf_filter`.
- **Capturing on `vmbr2`:** to capture on the VLAN-tagged parent instead of
  `sf-vtep`, prefix the filter with `vlan 91 and`. libpcap then adjusts the
  `udp[...]` offsets automatically.
- **Filter assumptions:** the filters assume Geneve without options (enforced
  by `(udp[8] & 0x3f) = 0`) and inner IPv4 without IP options, which is what
  the demo VMs send.
- **ARP and broadcast:** `sf_filter` keeps only inner IPv4, which excludes ARP
  and other broadcast frames. To see head-end replicated ARP for a segment,
  use:
  `tcpdump -i sf-vtep -nn -e -v "udp dst port 6081 and (udp[12:4] >> 8) = 5000 and udp[28:2] = 0x0806"`.
- **Reply path:** the Config B ACLs are mirrored, so the reply routed on the
  DB's host (5003 egress, 5002 ingress) is explicitly allowed, independent of
  that host's conntrack state.
