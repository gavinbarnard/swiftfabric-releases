# SwiftFabric PostgreSQL demo lab

`demo_lab.py` builds a demonstration lab on the enrolled compute hosts. It
reuses the `network-lab` controller client and serial-console automation.

| Segment | Network (default) | VMs | Demonstrates |
| --- | --- | --- | --- |
| 5000 | 10.50.0.0/24 | `demo-a1-db` + `demo-a1-client1..5` | Config A: same-segment L2 over VTEP unicast |
| 5001 | 10.50.1.0/24 | `demo-a2-db` + `demo-a2-client1..5` | Config A (second, isolated copy) |
| 5002 | 10.50.2.0/24 | `demo-b-client1..8` | Config B: clients routed East/West |
| 5003 | 10.50.3.0/24 | `demo-b-db1`, `demo-b-db2` | Config B: ACL-permitted databases |
| 5004 | 10.50.4.0/24 | `demo-ns-vm1..3` (idle) | North/South: attach a router live |
| 5005 | 10.50.0.0/24 | `demo-t2-a1-db` + `demo-t2-a1-client1..5` | Second tenant: Config A replica |
| 5006 | 10.50.1.0/24 | `demo-t2-a2-db` + `demo-t2-a2-client1..5` | Second tenant: Config A replica |
| 5007 | 10.50.2.0/24 | `demo-t2-b-client1..8` | Second tenant: Config B clients replica |
| 5008 | 10.50.3.0/24 | `demo-t2-b-db1`, `demo-t2-b-db2` | Second tenant: Config B databases replica |

Segments 5000-5004 belong to the protected `default` tenant.

- **Second tenant:** `deploy` creates a tenant (`demo-t2-<run id>` by
  default, or `--tenant-name`) holding exact replicas of Config A and Config B.
  It reuses the default tenant's subnets, gateways, and VM addresses, so the two
  tenants overlap and remain isolated. It has no North/South demo segment.
- **Spread across hosts:** each segment's VMs are spread round-robin across
  every lab host, so same-segment traffic crosses the VTEP tunnels.
- **Config B ACLs:** mirrored on both segments. 5002 egress and 5003 ingress
  allow clients -> databases TCP 5432 and ICMP. 5003 egress and 5002 ingress
  allow the return direction (TCP from source port 5432, and ICMP). All other
  cross-segment traffic stays denied. The second tenant gets the same ACLs on
  5007 and 5008.
- **Router:** a standalone router named `demo-nsr` is deployed from
  `nsr.json` (WAN IP, upstream gateway, WAN VLAN and bridge). The VTEP bridge
  and VLAN come from `config.json`. It finishes with an **empty WAN policy and
  no segments attached**, ready to attach to 5004 during the demo.

## Logins

Every workload VM uses standard VGA and the Proxmox noVNC console, with username
`ubuntu` and password `ubuntu`. Serial0 remains available for provisioning
automation. A login banner shows the VM's role, and clients show
these commands:

```sh
journalctl -u sf-demo-client -f              # live randomized query log
sf-demo-query "SELECT count(*) FROM people"  # ad-hoc query against this client's DBs
```

- **Database contents:** each database (`demo`) has a `people` table of 1000
  generated `firstname`, `middlename`, `lastname` rows.
- **Client queries:** every 1–4 seconds, each client selects every person
  whose first or last name starts with a random letter.
- **No client packages:** clients use a built-in, stdlib-only PostgreSQL
  client, so they install nothing.
- **Credentials:** the PostgreSQL password is generated per lab. `status`
  prints it, and the database login banner shows it.

## PostgreSQL install path

The database VMs install `postgresql` from the image's default public Ubuntu
archive (not the local `ubuntu_mirror`). VMs use DNS `8.8.8.8` and `1.1.1.1`.

1. The DB segments are temporarily attached to `demo-nsr`.
2. The router's WAN policy masquerades only those subnets. Egress allows only
   DNS (TCP/UDP 53) to `8.8.8.8` and `1.1.1.1`, plus HTTP/HTTPS (TCP 80/443).
3. When the install finishes or fails, the WAN policy goes back to empty and
   the segments are detached.

The default tenant's databases install first. The router must belong to the
same tenant as attached segments, so the detached, policy-free router is then
reassigned to the second tenant. Steps 1-3 repeat for that tenant's DB segments,
then the router returns to `default`. A failed or interrupted install also
returns it to `default` (on failure, or on the next `deploy`/`destroy`).

Clients and the idle VMs never get WAN access.

## Usage

```sh
python3 demos/demo_lab.py plan       # validate live inventory and save local plan; no deployment
python3 demos/demo_lab.py deploy     # prompts; --yes to skip
python3 demos/demo_lab.py status
python3 demos/demo_lab.py configure-console  # update existing workload VMs to standard VGA
python3 demos/demo_lab.py destroy    # prompts; --yes to skip
python3 demos/demo_lab.py destroy-state  # verify resources are gone, then delete local state
```

New VMs receive standard VGA in their creation request, before initial power-on.
For existing VMs using serial display, fully shut them down first, run
`configure-console`, then start them. The command refuses to change display
hardware while a VM is running. Guests already using standard VGA can have their
tty1 login prompt enabled while running. Use the same `--state` as deployment.
This command does not change the separately managed North/South router.

- **Defaults:** `config.json`, `nsr.json`, and the nodes in
  `proxmox_auto_enroll_host_list`.
- **Proxmox TLS:** live commands retrieve the Proxmox public root CA over
  pinned SSH using `proxmox_ssh_user` and `proxmox_ssh_key` from the saved
  deployment config. Every online node must report the same CA. API certificate
  chains and hostnames remain verified; first-use SSH pins require approval.
- **NSR settings:** copy the sanitized root-level `nsr.example.json` to
  `nsr.json` and set values for your WAN network. Override its path with
  `--nsr-config` (`--edge` remains an alias).
- **Image:** `<storage_location>:import/ubuntu-resolute-server-cloudimg-amd64.qcow2`.
- **Overrides:** `--nodes`, `--subnet-start` (any /24 inside `--supernet`,
  default `10.0.0.0/8`), `--first-segment-id`, `--router-id`,
  `--router-node`, `--router-console-password`, `--image-volume`,
  `--management-allowlist`, and `--tenant-name`.
- **Automatic allocation:** new plans search from `--first-segment-id` and
  `--subnet-start` for nine unused consecutive IDs and five non-overlapping
  consecutive /24s (the second tenant reuses the first four /24s). Searches
  wrap to the start of the ID range or `--supernet` if necessary. Those
  options are preferences, not guaranteed allocations.
  Occupied router IDs and tenant names still require a different
  `--router-id` or `--tenant-name`.
- **Router SSH allowlist:** defaults to the controller management subnet plus
  this machine's source address as a /32. The /32 is the address the kernel
  picks to reach the first controller (for example `192.168.40.142/32`). It
  is also added to `--management-allowlist` values.
  - On resume, a router missing that address gets it through a configuration
    update. A deployed router applies the update at its next deploy or retry.
- **Router failures:** a failed router deployment is retried automatically
  twice (`POST /north-south-routers/<id>/retry`), and on resume.

### Safety checks

New `plan` and `deploy` commands query live inventory and select free segment
IDs and subnets, then check that:

- the segment IDs, router ID, and second-tenant name are unused;
- the subnets don't overlap existing segments, the management network, the
  VTEP pool, or any Proxmox bridge network;
- the image exists and the hosts have enough free memory.

Only a fully validated new plan is saved. `plan` creates local state but no
segments, router, or VMs. It requires controller/Proxmox access, just like
deployment. A saved plan is revalidated, not silently reallocated, by subsequent
`plan` commands. `deploy` uses those exact saved IDs and addresses and checks
again before creating resources. Plans do not reserve live resources; conflicts
introduced afterwards stop deployment.

### State and resuming

VM provisioning, client startup, and VM deletion use up to six concurrent
workers. Proxmox takes a cluster-wide `cfs-lock` on shared storage for disk
imports, resizes, and purges, so those storage tasks run one at a time (with
retries on lock timeouts); VM start, guest bootstrap, and stop overlap them,
and each VM bootstraps as soon as it is created. On resume, an owned VM left
without disks by a failed create is removed and recreated; one still holding a
Proxmox lock is reported for `qm unlock` instead of being forced.
PostgreSQL installs run concurrently across each tenant's four DBs,
while router deployment overlaps VM provisioning. Successful operations save
their state individually. Worker failures are collected and reported after
other workers finish; segment/router cleanup only starts if all VM deletions
succeed. No VMs are automatically restarted to speed up provisioning.

State, including VM IDs and the DB password, is kept in
`~/.local/state/swiftfabric/demo-lab` by default; use `--state` to keep
several labs. Rerunning `deploy` with the same state resumes after a failure
without recreating finished resources.
Second-tenant creation persists a `tenant-<uuid>` request ID before POSTing.
If a create succeeds but its response is lost, resume replays the same ID and
the controller returns the original create result; older saved plans still
recover an already-created tenant by name.

After the final WAN-policy update, deployment waits `--settle-seconds` (default
35, minimum 30; saved with the plan) before verifying database queries. Router
detachment and policy changes converge asynchronously on compute hosts; querying
immediately can otherwise fail transiently with `No route to host`. This wait
also applies on resume, even when every database and client is already set up.
Verification failures still stop deployment without marking the lab ready.

### Destroy

`destroy` deletes only resources this lab created. It checks:

- VMs by ID and current Proxmox node, then by name, run-specific description,
  and segment bridge (so migrated VMs are still found);
- segments by name and gateway;
- the router by ID and WAN address;
- the second tenant by recorded ID and name, deleted after its segments and
  the router.

It refuses to delete the router while a segment from outside the lab is still
attached; detach it first.

### Versioned controller API

Saved plans contain topology, not live mutation versions. The shared
`network-lab` client reloads segment inventory and verifies ownership before
attachment changes, then reloads metadata after detachment before deletion.
ACL and WAN-policy writes use their independent snapshot `_version` values;
router configuration/tenant changes and deletion use router metadata versions.
Tenant deletion uses current tenant inventory. Stale-version conflicts stop
the operation, without guessed versions or overwrite retries.

### Resetting local state

After running `destroy`, run `destroy-state` to remove the default local state
directory, or pass `--state` for another lab. It prompts unless `--yes` is given.
This command does not destroy deployed resources: it checks the controller and
Proxmox for remaining planned segments, the router, the second tenant, and
workload VMs, including
VMs whose IDs were cleared by `destroy`. Remaining resources or failed live
checks preserve the saved state. Controllers and Proxmox must remain reachable.
Unexpected files in the state directory also block cleanup.

Once cleanup succeeds, the next `plan` or `deploy` generates a fresh layout
instead of reusing the old state.

## Packet captures

See [demos_capture_commands.md](demos_capture_commands.md) for `tcpdump`
commands covering L2 unicast, VTEP changes during migration, Config B
East/West routing, and the North/South router path. The
[Session 2 video script](../YT-Session2-L2L3_script.md) follows these demo
steps.

## Tests

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s demos/tests -p 'test_*.py'
```
