"""Guest-side helper for SwiftFabric demo lab VMs (Python standard library only).

Installed by demo_lab.py at /opt/sf-demo/demo_guest.py over the serial console.
Clients speak the PostgreSQL wire protocol directly so they need no packages.
"""

import argparse
import base64
import gzip
import hashlib
import hmac
import json
import os
from pathlib import Path
import random
import re
import secrets
import shlex
import socket
import string
import struct
import subprocess
import sys
import time

INSTALL_PATH = "/opt/sf-demo/demo_guest.py"
ROLE_PATH = Path("/etc/sf-demo/role.json")
CLIENT_UNIT = Path("/etc/systemd/system/sf-demo-client.service")
HBA_BEGIN = "# BEGIN swiftfabric-demo"
HBA_END = "# END swiftfabric-demo"
SAFE = re.compile(r"[A-Za-z0-9._-]{1,63}")

FIRST_NAMES = (
    "Aaron", "Abigail", "Adrian", "Alice", "Amelia", "Benjamin", "Bella", "Caleb", "Charlotte",
    "Chloe", "Daniel", "Delilah", "Elijah", "Ella", "Emma", "Ethan", "Fiona", "Felix", "Gabriel",
    "Grace", "Hannah", "Henry", "Isaac", "Isabella", "Jack", "Julia", "Kai", "Katherine", "Liam",
    "Lucy", "Mason", "Mia", "Nathan", "Nora", "Oliver", "Olivia", "Penelope", "Peter", "Quinn",
    "Riley", "Ruby", "Samuel", "Sophia", "Theodore", "Tessa", "Uma", "Victor", "Violet",
    "William", "Willow", "Xavier", "Yara", "Zachary", "Zoe",
)
MIDDLE_NAMES = (
    "Alexander", "Anne", "Blake", "Claire", "Dean", "Elise", "Francis", "Grey", "Hope", "James",
    "Jane", "Kay", "Lee", "Louise", "Marie", "Michael", "Noel", "Paige", "Quincy", "Rose",
    "Ray", "Scott", "Sage", "Thomas", "Victoria", "Wade",
)
LAST_NAMES = (
    "Anderson", "Adams", "Baker", "Brooks", "Carter", "Collins", "Davis", "Dunn", "Edwards",
    "Ellis", "Fisher", "Foster", "Garcia", "Gray", "Harris", "Hughes", "Irwin", "Jackson",
    "Jenkins", "Kelly", "King", "Lewis", "Lopez", "Martin", "Morgan", "Nelson", "Nguyen",
    "Owens", "Ortiz", "Parker", "Perry", "Quinlan", "Reed", "Roberts", "Sanders", "Smith",
    "Taylor", "Turner", "Underwood", "Vasquez", "Vaughn", "Walker", "Wright", "Young", "Yates",
    "Zimmerman",
)


class PgError(RuntimeError):
    pass


def read_exact(connection, count):
    data = b""
    while len(data) < count:
        chunk = connection.recv(count - len(data))
        if not chunk:
            raise PgError("server closed the connection")
        data += chunk
    return data


def send_message(connection, kind, payload):
    connection.sendall(kind + struct.pack("!I", len(payload) + 4) + payload)


def error_text(body):
    fields = {}
    for part in body.split(b"\0"):
        if part:
            fields[chr(part[0])] = part[1:].decode(errors="replace")
    return f"{fields.get('S', 'ERROR')}: {fields.get('M', 'unknown error')}"


def pg_query(host, port, user, password, database, sql, timeout=5.0):
    """Run one simple query; returns (column names, rows of text values)."""
    with socket.create_connection((host, port), timeout=timeout) as connection:
        params = b"".join(
            key.encode() + b"\0" + value.encode() + b"\0"
            for key, value in (("user", user), ("database", database), ("application_name", "sf-demo"))
        ) + b"\0"
        connection.sendall(struct.pack("!II", len(params) + 8, 196608) + params)
        columns, rows, queried = [], [], False
        scram = None
        while True:
            kind = read_exact(connection, 1)
            body = read_exact(connection, struct.unpack("!I", read_exact(connection, 4))[0] - 4)
            if kind == b"R":
                code = struct.unpack("!I", body[:4])[0]
                if code == 5:
                    inner = hashlib.md5((password + user).encode()).hexdigest().encode()
                    send_message(connection, b"p", b"md5" + hashlib.md5(inner + body[4:8]).hexdigest().encode() + b"\0")
                elif code == 10:
                    if b"SCRAM-SHA-256" not in body[4:].split(b"\0"):
                        raise PgError("server offers no supported SASL mechanism")
                    nonce = base64.b64encode(secrets.token_bytes(18)).decode()
                    scram = {"nonce": nonce, "bare": f"n=,r={nonce}"}
                    first = ("n,," + scram["bare"]).encode()
                    send_message(connection, b"p", b"SCRAM-SHA-256\0" + struct.pack("!I", len(first)) + first)
                elif code == 11 and scram:
                    server_first = body[4:].decode()
                    attributes = dict(item.split("=", 1) for item in server_first.split(","))
                    if not attributes["r"].startswith(scram["nonce"]):
                        raise PgError("SCRAM server nonce mismatch")
                    salted = hashlib.pbkdf2_hmac(
                        "sha256", password.encode(), base64.b64decode(attributes["s"]), int(attributes["i"]),
                    )
                    client_key = hmac.digest(salted, b"Client Key", "sha256")
                    without_proof = f"c=biws,r={attributes['r']}"
                    scram["auth"] = f"{scram['bare']},{server_first},{without_proof}".encode()
                    scram["salted"] = salted
                    signature = hmac.digest(hashlib.sha256(client_key).digest(), scram["auth"], "sha256")
                    proof = bytes(a ^ b for a, b in zip(client_key, signature))
                    send_message(connection, b"p", f"{without_proof},p={base64.b64encode(proof).decode()}".encode())
                elif code == 12 and scram:
                    server_key = hmac.digest(scram["salted"], b"Server Key", "sha256")
                    expected = base64.b64encode(hmac.digest(server_key, scram["auth"], "sha256")).decode()
                    if body[4:].decode() != f"v={expected}":
                        raise PgError("SCRAM server signature mismatch")
                elif code != 0:
                    raise PgError(f"unsupported authentication method {code}")
            elif kind == b"E":
                raise PgError(error_text(body))
            elif kind == b"T":
                count, offset = struct.unpack("!H", body[:2])[0], 2
                for _ in range(count):
                    end = body.index(b"\0", offset)
                    columns.append(body[offset:end].decode())
                    offset = end + 19
            elif kind == b"D":
                count, offset, row = struct.unpack("!H", body[:2])[0], 2, []
                for _ in range(count):
                    size = struct.unpack("!i", body[offset:offset + 4])[0]
                    offset += 4
                    row.append(None if size < 0 else body[offset:offset + size].decode())
                    offset += max(size, 0)
                rows.append(row)
            elif kind == b"Z":
                if queried:
                    send_message(connection, b"X", b"")
                    return columns, rows
                send_message(connection, b"Q", sql.encode() + b"\0")
                queried = True


def run(command, **kwargs):
    print("+ " + shlex.join(command), flush=True)
    return subprocess.run(command, check=True, text=True, **kwargs)


def psql(sql, database="postgres"):
    return run(
        ["runuser", "-u", "postgres", "--", "psql", "-X", "-q", "-v", "ON_ERROR_STOP=1", "-d", database, "-tA"],
        input=sql, capture_output=True,
    ).stdout.strip()


def wait_for_tcp(host, port, seconds):
    deadline = time.monotonic() + seconds
    while True:
        try:
            socket.create_connection((host, port), timeout=5).close()
            return
        except OSError as failure:
            if time.monotonic() > deadline:
                raise SystemExit(f"cannot reach {host}:{port}: {failure}") from failure
            time.sleep(3)


def install_db(args):
    role = json.loads(ROLE_PATH.read_text())
    # Uses the image's default public Ubuntu archive sources, reached via temporary NSR egress.
    wait_for_tcp(args.probe_host, 80, 300)
    apt = ["apt-get", "-o", "Acquire::Retries=3", "-o", "DPkg::Lock::Timeout=600"]
    run([*apt, "update"])
    run([*apt, "install", "-y", "--no-install-recommends", "postgresql"],
        env={**os.environ, "DEBIAN_FRONTEND": "noninteractive"})
    main_dir = sorted(Path("/etc/postgresql").glob("*/main"))[-1]
    conf = main_dir / "postgresql.conf"
    if "include_dir = 'conf.d'" not in conf.read_text():
        conf.write_text(conf.read_text() + "\ninclude_dir = 'conf.d'\n")
    (main_dir / "conf.d").mkdir(exist_ok=True)
    (main_dir / "conf.d" / "swiftfabric-demo.conf").write_text("listen_addresses = '*'\n")
    hba_path = main_dir / "pg_hba.conf"
    hba = re.sub(rf"\n?{HBA_BEGIN}.*?{HBA_END}\n?", "\n", hba_path.read_text(), flags=re.S).rstrip("\n")
    rules = "".join(f"host {role['database']} {role['user']} {network} scram-sha-256\n" for network in role["allow_networks"])
    hba_path.write_text(f"{hba}\n{HBA_BEGIN}\n{rules}{HBA_END}\n")
    run(["systemctl", "enable", "postgresql"])
    run(["systemctl", "restart", "postgresql"])
    for _ in range(60):
        if subprocess.run(["pg_isready", "-q", "-h", "127.0.0.1"], check=False).returncode == 0:
            break
        time.sleep(1)
    user, password, database = role["user"], role["password"], role["database"]
    psql(
        f"DO $$BEGIN IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = '{user}') "
        f"THEN CREATE ROLE {user} LOGIN PASSWORD '{password}'; "
        f"ELSE ALTER ROLE {user} LOGIN PASSWORD '{password}'; END IF; END$$;"
    )
    if psql(f"SELECT 1 FROM pg_database WHERE datname = '{database}'") != "1":
        psql(f"CREATE DATABASE {database} OWNER {user};")
    generator = random.Random(20261026)
    values = ",\n".join(
        f"({index}, '{generator.choice(FIRST_NAMES)}', '{generator.choice(MIDDLE_NAMES)}', '{generator.choice(LAST_NAMES)}')"
        for index in range(1, 1001)
    )
    psql(
        "CREATE TABLE IF NOT EXISTS people (id integer PRIMARY KEY, firstname text NOT NULL, "
        "middlename text NOT NULL, lastname text NOT NULL);\n"
        f"ALTER TABLE people OWNER TO {user};\n"
        "CREATE INDEX IF NOT EXISTS people_firstname ON people (firstname text_pattern_ops);\n"
        "CREATE INDEX IF NOT EXISTS people_lastname ON people (lastname text_pattern_ops);\n"
        f"INSERT INTO people VALUES\n{values}\nON CONFLICT (id) DO NOTHING;\nANALYZE people;\n",
        database,
    )
    count = psql("SELECT count(*) FROM people", database)
    print(f"database ready: {count} rows in {database}.people", flush=True)


def setup(args):
    role = json.loads(gzip.decompress(base64.b64decode(args.role)))
    for key in ("user", "password", "database"):
        if role.get(key) is not None and not SAFE.fullmatch(role[key]):
            raise SystemExit(f"unsafe {key}")
    ROLE_PATH.parent.mkdir(parents=True, exist_ok=True)
    ROLE_PATH.write_text(json.dumps(role, indent=2) + "\n")
    os.chmod(ROLE_PATH, 0o644)
    lines = [
        f"SwiftFabric demo lab | {role['name']} | {role['kind']} | segment {role['segment']} | {role['address']}",
        f"  {role['description']}",
    ]
    if role["kind"] == "client":
        lines += [
            f"  Databases: {', '.join(role['servers'])} (user {role['user']}, db {role['database']}, table people)",
            "  Live query log:  journalctl -u sf-demo-client -f",
            "  Ad-hoc query:    sf-demo-query \"SELECT count(*) FROM people\"",
        ]
        Path("/usr/local/bin/sf-demo-query").write_text(
            f"#!/bin/sh\nexec /usr/bin/python3 {INSTALL_PATH} query \"$@\"\n"
        )
        os.chmod("/usr/local/bin/sf-demo-query", 0o755)
        CLIENT_UNIT.write_text(
            "[Unit]\nDescription=SwiftFabric demo PostgreSQL client\nAfter=network-online.target\n"
            "Wants=network-online.target\n\n[Service]\nDynamicUser=yes\n"
            f"ExecStart=/usr/bin/python3 -u {INSTALL_PATH} client\nRestart=always\nRestartSec=5\n\n"
            "[Install]\nWantedBy=multi-user.target\n"
        )
        run(["systemctl", "daemon-reload"])
    elif role["kind"] == "db":
        lines += [
            f"  PostgreSQL: user {role['user']} / password {role['password']}, database {role['database']}, table people",
            f"  Local shell:     sudo -u postgres psql {role['database']}",
            "  Who's querying:  sudo -u postgres psql -c 'SELECT client_addr, count(*) FROM pg_stat_activity GROUP BY 1'",
        ]
    banner = "\n".join(lines)
    Path("/etc/profile.d/sf-demo.sh").write_text(
        f"[ -n \"$PS1\" ] && cat <<'SFDEMO'\n\n{banner}\n\nSFDEMO\n"
    )
    print(banner)


def start_client(_args):
    run(["systemctl", "enable", "--now", "sf-demo-client.service"])
    run(["systemctl", "is-active", "sf-demo-client.service"])


def client(_args):
    role = json.loads(ROLE_PATH.read_text())
    generator = random.Random()
    while True:
        server = generator.choice(role["servers"])
        column = generator.choice(("firstname", "lastname"))
        letter = generator.choice(string.ascii_uppercase)
        sql = (f"SELECT firstname, middlename, lastname FROM people WHERE {column} LIKE '{letter}%' "
               "ORDER BY lastname, firstname")
        started = time.monotonic()
        try:
            _, rows = pg_query(server, role["port"], role["user"], role["password"], role["database"], sql)
            sample = " ".join(rows[0]) if rows else "-"
            print(f"{server} {column} LIKE '{letter}%' -> {len(rows)} rows in "
                  f"{(time.monotonic() - started) * 1000:.1f} ms (e.g. {sample})", flush=True)
        except (OSError, PgError) as failure:
            print(f"{server} {column} LIKE '{letter}%' FAILED after "
                  f"{(time.monotonic() - started) * 1000:.0f} ms: {failure}", flush=True)
        time.sleep(generator.uniform(role["interval_min"], role["interval_max"]))


def query(args):
    role = json.loads(ROLE_PATH.read_text())
    for server in [args.server] if args.server else role["servers"]:
        columns, rows = pg_query(server, role["port"], role["user"], role["password"], role["database"], args.sql)
        print(f"-- {server}: {len(rows)} rows")
        print(" | ".join(columns))
        for row in rows:
            print(" | ".join("NULL" if value is None else value for value in row))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_subparsers(dest="action", required=True)
    actions.add_parser("setup").add_argument("role", help="base64 JSON role description")
    install = actions.add_parser("install-db")
    install.add_argument("--probe-host", default="archive.ubuntu.com")
    actions.add_parser("start-client")
    actions.add_parser("client")
    ad_hoc = actions.add_parser("query")
    ad_hoc.add_argument("sql")
    ad_hoc.add_argument("--server")
    args = parser.parse_args()
    {"setup": setup, "install-db": install_db, "start-client": start_client,
     "client": client, "query": query}[args.action](args)


if __name__ == "__main__":
    sys.exit(main())
