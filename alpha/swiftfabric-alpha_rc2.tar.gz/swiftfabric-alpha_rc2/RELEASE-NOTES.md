# SwiftFabric release alpha_rc2

Built from supervisor `main` at `a011b84235530473dd59682e24dd4b763dc7da63`.

## Contents

- `install.sh`, `upgrade.sh`, and `python_installer/`: deployment, upgrade, and integration-test tooling.
- `demos/`, `network-lab/`, and `diag/`: demo, acceptance-test, and diagnostic sources.
- `packages/`: prebuilt Debian packages (no local build required).
- `test-report/post-deploy/report.html` and `test-report/post-restore/report.html`: full L2, L3 East/West and L3 North/South tenancy reports after deployment and restore.
- `test-report/nsr-ha/`: separate NSR HA failover and controller-loss HTML reports from the same deployment.
- `RELEASE.json`: versions, commits, checksums and report summary.
- `SHA256SUMS`: checksums for every file in this bundle (verify with `sha256sum -c SHA256SUMS`).

## Packages

- `swiftfabric-api-service_1:0.1.0+20261116105103.292a5bf017a379fd2fcfd1fd030b20aff0b6930a.2397dfd0e4ce0d56b067fa6ec5e50a3ac16ccb9d_amd64.deb` (version `1:0.1.0+20261116105103.292a5bf017a379fd2fcfd1fd030b20aff0b6930a.2397dfd0e4ce0d56b067fa6ec5e50a3ac16ccb9d`)
- `swiftfabric-host-agent_1:0.1.0+20261113202355.2397dfd0e4ce0d56b067fa6ec5e50a3ac16ccb9d_all.deb` (version `1:0.1.0+20261113202355.2397dfd0e4ce0d56b067fa6ec5e50a3ac16ccb9d`)

## Acceptance reports

All ten disaster recovery stages passed, including ordered cleanup.

Upgrade acceptance and ordered cleanup also passed from `alpha_rc1` to this release.
Tenancy reports: `test-report/before-upgrade/report.html` and `test-report/post-upgrade/report.html`. Fresh asynchronous NSR HA deployment is tested after upgrade under `test-report/nsr-ha/after-upgrade/`.
Upgrade compatibility covers retained standalone workloads only. Legacy HA migration is unsupported and requires redeployment; existing asynchronous HA rolling upgrades are not certified by this upgrade acceptance.

### Post-Deploy

**PASS**.
Run `8244024b967946cead4259648b4c2a3c`: tenancy enabled.
- east-west: 2160 traffic assertions passed
- health: 216 traffic assertions passed
- l2: 432 traffic assertions passed
- north-south: 216 traffic assertions passed
- API/RBAC: 384 assertions passed

### Post-Restore

**PASS**.
Run `8244024b967946cead4259648b4c2a3c`: tenancy enabled.
- east-west: 2160 traffic assertions passed
- health: 216 traffic assertions passed
- l2: 432 traffic assertions passed
- north-south: 216 traffic assertions passed
- API/RBAC: 384 assertions passed

### Nsr-Ha/Post-Deploy

**PASS**.
- 5 NSR HA scenarios passed.
- Scenarios: active-crash, controller-path-cut, pair-status, planned-handoff, replication-cut

### Nsr-Ha/Post-Restore

**PASS**.
- 5 NSR HA scenarios passed.
- Scenarios: active-crash, controller-path-cut, pair-status, planned-handoff, replication-cut

### Nsr-Ha/Controller-Loss

**PASS**.
- 6 NSR HA scenarios passed.
- Scenarios: active-crash, controller-cluster-loss, controller-path-cut, pair-status, planned-handoff, replication-cut

### Before-Upgrade

**PASS**.
Run `f8aa27ccdd1141f29c9f8dba19348d4a`: tenancy enabled.
- east-west: 2160 traffic assertions passed
- health: 216 traffic assertions passed
- l2: 432 traffic assertions passed
- north-south: 216 traffic assertions passed
- API/RBAC: 384 assertions passed

### Post-Upgrade

**PASS**.
Run `f8aa27ccdd1141f29c9f8dba19348d4a`: tenancy enabled.
- east-west: 2160 traffic assertions passed
- health: 216 traffic assertions passed
- l2: 432 traffic assertions passed
- north-south: 216 traffic assertions passed
- API/RBAC: 384 assertions passed

### Nsr-Ha/After-Upgrade

**PASS**.
- 5 NSR HA scenarios passed.
- Scenarios: active-crash, controller-path-cut, pair-status, planned-handoff, replication-cut


## Install

Requirements: Python 3 with `venv`, network access to PyPI for the installer dependencies, and SSH/API access to the target Proxmox cluster.

```sh
sha256sum -c SHA256SUMS
./pull-images.sh            # downloads the Ubuntu cloud image into images/generic
cp config.example.json config.json   # then edit for your environment
./install.sh --non-interactive --config config.json
```

## Upgrades

upgrade.sh upgrades the controller packages (and, with --auto-agent-upgrade, compute-host and North/South router agents) of an existing deployment. Releases are not yet guaranteed to be upgrade-compatible: breaking changes may require a full redeployment (./install.sh --destroy, then a fresh install) until a supported upgrade starting release is declared.

```sh
./upgrade.sh --config config.json --token
```

Supported upgrade starting release: `alpha_rc1`.
