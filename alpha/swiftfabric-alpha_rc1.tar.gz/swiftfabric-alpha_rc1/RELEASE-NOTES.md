# SwiftFabric release alpha_rc1

Built from supervisor `main` at `82a647153bfc4a66d493f0539fa99e1efe938643`.

## Contents

- `install.sh`, `upgrade.sh` and `python_installer/`: deployment and upgrade tooling.
- `packages/`: prebuilt Debian packages (no local build required).
- `test-report/post-deploy/report.html` and `test-report/post-restore/report.html`: full L2, L3 East/West and L3 North/South tenancy reports after deployment and restore.
- `RELEASE.json`: versions, commits, checksums and report summary.
- `SHA256SUMS`: checksums for every file in this bundle (verify with `sha256sum -c SHA256SUMS`).

## Packages

- `swiftfabric-api-service_1:0.1.0+20261107211836.990c0725a0f79d123b00a59782d5ac4a27b75370.71b2c131c41ac7cfa97815e02fd234b2978dbb6d_amd64.deb` (version `1:0.1.0+20261107211836.990c0725a0f79d123b00a59782d5ac4a27b75370.71b2c131c41ac7cfa97815e02fd234b2978dbb6d`)
- `swiftfabric-host-agent_1:0.1.0+20261107022250.71b2c131c41ac7cfa97815e02fd234b2978dbb6d_all.deb` (version `1:0.1.0+20261107022250.71b2c131c41ac7cfa97815e02fd234b2978dbb6d`)

## Acceptance reports

All ten disaster recovery stages passed, including ordered cleanup.

Upgrade acceptance and ordered cleanup also passed from `alpha_rc0` to this release.
Reports: `test-report/before-upgrade/report.html` and `test-report/post-upgrade/report.html`.

### Post-Deploy

Run `e91a6e4a457840d0b7f7edb4eab713f0`: **PASS**, tenancy enabled.
- east-west: 2160 traffic assertions passed
- health: 216 traffic assertions passed
- l2: 432 traffic assertions passed
- north-south: 216 traffic assertions passed
- API/RBAC: 384 assertions passed

### Post-Restore

Run `e91a6e4a457840d0b7f7edb4eab713f0`: **PASS**, tenancy enabled.
- east-west: 2160 traffic assertions passed
- health: 216 traffic assertions passed
- l2: 432 traffic assertions passed
- north-south: 216 traffic assertions passed
- API/RBAC: 384 assertions passed

### Before-Upgrade

Run `3c943279e56d4940ba489b7dcbed33cb`: **PASS**, tenancy enabled.
- east-west: 2160 traffic assertions passed
- health: 432 traffic assertions passed
- l2: 432 traffic assertions passed
- north-south: 216 traffic assertions passed
- API/RBAC: 372 assertions passed

### Post-Upgrade

Run `3c943279e56d4940ba489b7dcbed33cb`: **PASS**, tenancy enabled.
- east-west: 2160 traffic assertions passed
- health: 216 traffic assertions passed
- l2: 432 traffic assertions passed
- north-south: 216 traffic assertions passed
- API/RBAC: 384 assertions passed


## Install

Requirements: Python 3 with `venv`, network access to PyPI for the installer dependencies, and SSH/API access to the target Proxmox cluster.

```sh
sha256sum -c SHA256SUMS
./pull-images.sh            # downloads the Ubuntu cloud image into images/generic
cp config.example.json config.json   # then edit for your environment
./install.sh --non-interactive --config config.json
```

## Upgrades

upgrade.sh upgrades the controller packages (and, with --auto-agent-upgrade, compute-host and North/South router agents) of an existing deployment. Releases are not yet guaranteed to be upgrade-compatible: breaking changes may require a full redeployment (./install.sh --destroy, then a fresh install) until a supported upgrade starting release is declared.

```sh
./upgrade.sh --config config.json --token
```

Supported upgrade starting release: `alpha_rc0`.
