"""Validate controller resource versions before client-side mutations."""


def resource_version(record, resource):
    version = record.get("_version") if isinstance(record, dict) else None
    if type(version) is not int or not 1 <= version <= 2**64 - 1:
        raise RuntimeError(f"Controller returned an invalid {resource} version.")
    return version
