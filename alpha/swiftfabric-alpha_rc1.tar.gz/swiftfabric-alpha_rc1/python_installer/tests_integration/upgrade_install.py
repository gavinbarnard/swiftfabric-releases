"""Launch a historical installer with only the current SSH readiness fix."""

from pathlib import Path
import runpy
import sys


def main():
    sys.dont_write_bytecode = True
    root = Path(sys.argv[1]).resolve()
    arguments = sys.argv[2:]
    original_path = sys.path[:]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from deployment.validation import DeploymentValidator

    wait_for_ssh = DeploymentValidator.wait_for_ssh
    # Keep every other installer import historical, including its validation class.
    for name in list(sys.modules):
        if name in ("deployment", "proxmox") or name.startswith(("deployment.", "proxmox.")):
            del sys.modules[name]
    sys.path[:] = [str(root / "python_installer"), str(root), *original_path]
    from deployment.validation import DeploymentValidator as HistoricalValidator

    HistoricalValidator.wait_for_ssh = wait_for_ssh
    print("Historical installer compatibility: using current SSH readiness retries; "
          "host-key approval and verification remain required.", flush=True)
    script = root / "python_installer" / "main.py"
    sys.argv = [str(script), *arguments]
    runpy.run_path(str(script), run_name="__main__")


if __name__ == "__main__":
    main()
