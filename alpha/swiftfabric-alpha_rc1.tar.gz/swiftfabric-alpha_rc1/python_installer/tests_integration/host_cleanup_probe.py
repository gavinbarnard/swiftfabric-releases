"""Read-only check for residual SwiftFabric state on an unenrolled test host."""

import glob
import ipaddress
import json
from pathlib import Path
import re
import subprocess
import sys


def command(*args):
    return subprocess.run(args, check=True, capture_output=True, text=True).stdout


def check(network, tables, zones):
    paths = (
        "/etc/swiftfabric", "/var/lib/swiftfabric", "/usr/lib/swiftfabric-host-agent",
        "/usr/bin/swiftfabric-host-agent", "/usr/bin/sf-cli",
        "/etc/modules-load.d/swiftfabric-host-agent.conf",
    )
    for path in paths:
        if Path(path).exists():
            raise RuntimeError(f"SwiftFabric state remains at {path}")
    if glob.glob("/usr/local/share/ca-certificates/swiftfabric-deployment-ca*.crt"):
        raise RuntimeError("SwiftFabric deployment CA trust remains")
    for unit in ("swiftfabric-host-agent.service", "swiftfabric-neighbors.service"):
        values = dict(line.split("=", 1) for line in command(
            "systemctl", "show", unit, "--property=LoadState", "--property=ActiveState",
        ).splitlines())
        if values.get("LoadState") != "not-found" or values.get("ActiveState") != "inactive":
            raise RuntimeError(f"{unit} remains installed or active")
    packages = command("dpkg-query", "-W", "-f=${binary:Package} ${db:Status-Status}\\n")
    if any(line.startswith("swiftfabric-") and not line.endswith(" not-installed")
           for line in packages.splitlines()):
        raise RuntimeError("SwiftFabric package state remains")
    links = json.loads(command("ip", "-j", "link", "show"))
    if any(link["ifname"].startswith("sf-") for link in links):
        raise RuntimeError("SwiftFabric network devices remain")
    addresses = json.loads(command("ip", "-j", "-4", "address", "show"))
    if any(ipaddress.ip_address(info["local"]) in network
           for link in addresses for info in link.get("addr_info", [])):
        raise RuntimeError("An address in the test VTEP pool remains")
    nft = json.loads(command("nft", "-j", "list", "tables"))
    if any(item.get("table", {}).get("name", "").startswith("swiftfabric")
           for item in nft["nftables"]):
        raise RuntimeError("SwiftFabric nftables state remains")
    for family in ((), ("-6",)):
        routes = json.loads(command("ip", *family, "-j", "route", "show", "table", "all"))
        if any(str(route.get("table")) in tables for route in routes):
            raise RuntimeError("Test tenant routing table remains")
    for zone in zones:
        if command("conntrack", "-L", "--zone", str(zone)).strip():
            raise RuntimeError(f"Test tenant conntrack zone {zone} is not empty")
    for path in ["/etc/network/interfaces", *glob.glob("/etc/network/interfaces.d/*")]:
        if Path(path).is_file() and re.search(
                r"swiftfabric|sf-br\d+|sf-vtep", Path(path).read_text(), re.IGNORECASE):
            raise RuntimeError(f"SwiftFabric network configuration remains in {path}")
    print("SWIFTFABRIC_HOST_CLEAN")


if __name__ == "__main__":
    check(ipaddress.IPv4Network(sys.argv[1]), set(json.loads(sys.argv[2])), json.loads(sys.argv[3]))
