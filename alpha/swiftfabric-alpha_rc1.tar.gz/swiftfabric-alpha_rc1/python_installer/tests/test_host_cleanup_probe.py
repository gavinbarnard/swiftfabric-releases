import contextlib
import importlib.util
import io
import ipaddress
import json
from pathlib import Path
import unittest
from unittest import mock


path = Path(__file__).resolve().parents[1] / "tests_integration/host_cleanup_probe.py"
spec = importlib.util.spec_from_file_location("host_cleanup_probe", path)
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)


class HostCleanupProbeTests(unittest.TestCase):
    def run_probe(self, overrides=None):
        outputs = {
            "systemctl": "LoadState=not-found\nActiveState=inactive\n",
            "dpkg-query": "other installed\n",
            "link": json.dumps([{"ifname": "eth0"}]),
            "address": json.dumps([{"addr_info": [{"local": "192.0.2.1"}]}]),
            "nft": json.dumps({"nftables": []}),
            "route": "[]",
            "conntrack": "",
        }
        outputs.update(overrides or {})

        def command(*args):
            key = next((name for name in outputs if name in args), args[0])
            value = outputs[key]
            if isinstance(value, Exception):
                raise value
            return value

        with mock.patch.object(probe, "command", side_effect=command), \
                mock.patch.object(probe.Path, "exists", return_value=False), \
                mock.patch.object(probe.Path, "is_file", return_value=False), \
                mock.patch.object(probe.glob, "glob", return_value=[]), \
                contextlib.redirect_stdout(io.StringIO()):
            probe.check(ipaddress.IPv4Network("172.16.0.0/24"), {"130000"}, [30000])

    def test_clean_host(self):
        self.run_probe()

    def test_residual_state_or_failed_probe_blocks_cleanup(self):
        cases = [
            {"systemctl": "LoadState=loaded\nActiveState=active\n"},
            {"dpkg-query": "swiftfabric-host-agent installed\n"},
            {"link": '[{"ifname":"sf-sk49100"}]'},
            {"address": '[{"addr_info":[{"local":"172.16.0.2"}]}]'},
            {"nft": '{"nftables":[{"table":{"name":"swiftfabric_routing"}}]}'},
            {"route": '[{"table":130000}]'},
            {"conntrack": "flow\n"},
            {"nft": RuntimeError("inspection failed")},
        ]
        for case in cases:
            with self.subTest(case=case), self.assertRaises(RuntimeError):
                self.run_probe(case)


if __name__ == "__main__":
    unittest.main()
