import json
import hashlib
import os
import re
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path


SOURCE = Path(__file__).resolve().parents[2] / "controller-api/segment-manager/src/neighbor_peers.rs"


class NeighborCertificateMigrationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.source = SOURCE.read_text()
        self.openssl(
            "req", "-x509", "-newkey", "ed25519", "-nodes",
            "-keyout", "ca.key", "-out", "swiftfabric-ca.crt",
            "-subj", "/CN=test CA", "-days", "2",
        )
        self.openssl(
            "req", "-x509", "-newkey", "ed25519", "-nodes",
            "-keyout", "neighbor-identity.key", "-out", "neighbor-identity.crt",
            "-subj", "/CN=swiftfabric-neighbor", "-days", "2",
            "-addext", "basicConstraints=critical,CA:TRUE",
            "-addext", "keyUsage=critical,digitalSignature,keyCertSign",
            "-addext", "extendedKeyUsage=serverAuth,clientAuth",
        )
        (self.directory / "neighbor-identity.key").chmod(0o600)
        (self.directory / "extensions").write_text(
            "basicConstraints=critical,CA:FALSE\n"
            "keyUsage=critical,digitalSignature\n"
            "extendedKeyUsage=serverAuth,clientAuth\n"
            "subjectAltName=IP:192.0.2.10\n"
        )

    def openssl(self, *args, input_data=None, check=True):
        return subprocess.run(
            ["openssl", *args], cwd=self.directory, input=input_data,
            capture_output=True, check=check,
        )

    def script(self, name, request=None):
        match = re.search(rf'const {name}: &str = r#"\n(.*?)\n"#;', self.source, re.S)
        self.assertIsNotNone(match, name)
        script = match.group(1).replace("/etc/swiftfabric", str(self.directory))
        script = script.replace("info.st_uid!=0", f"info.st_uid!={os.getuid()}")
        return subprocess.run(
            [sys.executable, "-c", script],
            input=json.dumps(request or {}).encode(), capture_output=True,
        )

    def fingerprint(self):
        return hashlib.sha256(self.openssl(
            "x509", "-in", "neighbor-identity.crt", "-outform", "DER",
        ).stdout).hexdigest()

    def test_self_signed_identity_is_reissued_and_local_key_preserved(self):
        key = (self.directory / "neighbor-identity.key").read_bytes()
        old = (self.directory / "neighbor-identity.crt").read_bytes()
        self.assertNotEqual(self.openssl(
            "verify", "-CAfile", "swiftfabric-ca.crt", "neighbor-identity.crt", check=False,
        ).returncode, 0)
        request = {"role": "authority", "address": "192.0.2.10"}
        classification = self.script(
            "CLASSIFY_INACTIVE_IDENTITY_SCRIPT", {"address": request["address"]}
        )
        self.assertEqual(classification.returncode, 0, classification.stderr.decode())
        self.assertEqual(json.loads(classification.stdout)["status"], "legacy")
        previous_sha256 = self.fingerprint()
        csr_result = self.script("NEIGHBOR_CSR_SCRIPT", request)
        self.assertEqual(csr_result.returncode, 0, csr_result.stderr.decode())
        csr = json.loads(csr_result.stdout)["csr"]
        signed = self.openssl(
            "x509", "-req", "-CA", "swiftfabric-ca.crt", "-CAkey", "ca.key",
            "-set_serial", "123", "-days", "397", "-extfile", "extensions",
            input_data=csr.encode(),
        ).stdout.decode()
        install = self.script(
            "INSTALL_INACTIVE_CERTIFICATE_SCRIPT",
            {"address": request["address"], "certificate": signed,
             "previous_sha256": previous_sha256},
        )
        self.assertEqual(install.returncode, 0, install.stderr.decode())
        self.assertEqual((self.directory / "neighbor-identity.key").read_bytes(), key)
        self.assertNotEqual((self.directory / "neighbor-identity.crt").read_bytes(), old)
        for purpose in ("sslserver", "sslclient"):
            self.openssl(
                "verify", "-CAfile", "swiftfabric-ca.crt", "-purpose", purpose,
                "-verify_ip", request["address"], "neighbor-identity.crt",
            )
        retry = self.script("NEIGHBOR_CSR_SCRIPT", request)
        self.assertEqual(retry.returncode, 0, retry.stderr.decode())
        self.assertIsNone(json.loads(retry.stdout)["csr"])
        classification = self.script(
            "CLASSIFY_INACTIVE_IDENTITY_SCRIPT", {"address": request["address"]}
        )
        self.assertEqual(classification.returncode, 0, classification.stderr.decode())
        self.assertEqual(json.loads(classification.stdout)["status"], "valid")

    def test_active_membership_blocks_inspection_and_installation(self):
        (self.directory / "neighbor-peers.json").write_text("{}")
        before = (self.directory / "neighbor-identity.crt").read_bytes()
        inspection = self.script("INACTIVE_IDENTITY_SCRIPT")
        self.assertNotEqual(inspection.returncode, 0)
        install = self.script(
            "INSTALL_INACTIVE_CERTIFICATE_SCRIPT",
            {"address": "192.0.2.10", "certificate": "not a certificate",
             "previous_sha256": self.fingerprint()},
        )
        self.assertNotEqual(install.returncode, 0)
        self.assertEqual((self.directory / "neighbor-identity.crt").read_bytes(), before)

    def test_self_signed_certificate_cannot_be_installed(self):
        before = (self.directory / "neighbor-identity.crt").read_bytes()
        install = self.script(
            "INSTALL_INACTIVE_CERTIFICATE_SCRIPT",
            {"address": "192.0.2.10", "certificate": before.decode(),
             "previous_sha256": self.fingerprint()},
        )
        self.assertNotEqual(install.returncode, 0)
        self.assertEqual((self.directory / "neighbor-identity.crt").read_bytes(), before)

    def test_wrong_address_or_key_is_rejected(self):
        before = (self.directory / "neighbor-identity.crt").read_bytes()
        request = {"role": "authority", "address": "192.0.2.10"}
        csr = json.loads(self.script("NEIGHBOR_CSR_SCRIPT", request).stdout)["csr"]
        signed = self.openssl(
            "x509", "-req", "-CA", "swiftfabric-ca.crt", "-CAkey", "ca.key",
            "-set_serial", "124", "-days", "397", "-extfile", "extensions",
            input_data=csr.encode(),
        ).stdout.decode()
        wrong_address = self.script(
            "INSTALL_INACTIVE_CERTIFICATE_SCRIPT",
            {"address": "192.0.2.11", "certificate": signed,
             "previous_sha256": self.fingerprint()},
        )
        self.assertNotEqual(wrong_address.returncode, 0)
        self.assertEqual((self.directory / "neighbor-identity.crt").read_bytes(), before)
        self.openssl("genpkey", "-algorithm", "ED25519", "-out", "neighbor-identity.key")
        (self.directory / "neighbor-identity.key").chmod(0o600)
        wrong_key = self.script(
            "INSTALL_INACTIVE_CERTIFICATE_SCRIPT",
            {"address": request["address"], "certificate": signed,
             "previous_sha256": self.fingerprint()},
        )
        self.assertNotEqual(wrong_key.returncode, 0)
        self.assertEqual((self.directory / "neighbor-identity.crt").read_bytes(), before)

    def test_near_expiry_ca_certificate_is_renewed(self):
        csr = self.openssl(
            "req", "-new", "-key", "neighbor-identity.key",
            "-subj", "/CN=swiftfabric-neighbor",
        ).stdout
        certificate = self.openssl(
            "x509", "-req", "-CA", "swiftfabric-ca.crt", "-CAkey", "ca.key",
            "-set_serial", "125", "-days", "2", "-extfile", "extensions",
            input_data=csr,
        ).stdout
        (self.directory / "neighbor-identity.crt").write_bytes(certificate)
        result = self.script("CLASSIFY_INACTIVE_IDENTITY_SCRIPT", {"address": "192.0.2.10"})
        self.assertEqual(result.returncode, 0, result.stderr.decode())
        self.assertEqual(json.loads(result.stdout)["status"], "renew")
        renewal = self.script("NEIGHBOR_CSR_SCRIPT", {"role": "authority", "address": "192.0.2.10"})
        self.assertEqual(renewal.returncode, 0, renewal.stderr.decode())
        renewal_csr = json.loads(renewal.stdout)["csr"]
        self.assertIsNotNone(renewal_csr)
        renewed_certificate = self.openssl(
            "x509", "-req", "-CA", "swiftfabric-ca.crt", "-CAkey", "ca.key",
            "-set_serial", "127", "-days", "397", "-extfile", "extensions",
            input_data=renewal_csr.encode(),
        ).stdout.decode()
        install = self.script(
            "INSTALL_INACTIVE_CERTIFICATE_SCRIPT",
            {"address": "192.0.2.10", "certificate": renewed_certificate,
             "previous_sha256": self.fingerprint()},
        )
        self.assertEqual(install.returncode, 0, install.stderr.decode())
        result = self.script("CLASSIFY_INACTIVE_IDENTITY_SCRIPT", {"address": "192.0.2.10"})
        self.assertEqual(json.loads(result.stdout)["status"], "valid")

    def test_renewal_window_is_thirty_days(self):
        csr = self.openssl(
            "req", "-new", "-key", "neighbor-identity.key",
            "-subj", "/CN=swiftfabric-neighbor",
        ).stdout
        for days, expected in ((29, "renew"), (31, "valid")):
            with self.subTest(days=days):
                certificate = self.openssl(
                    "x509", "-req", "-CA", "swiftfabric-ca.crt", "-CAkey", "ca.key",
                    "-set_serial", str(days), "-days", str(days), "-extfile", "extensions",
                    input_data=csr,
                ).stdout
                (self.directory / "neighbor-identity.crt").write_bytes(certificate)
                result = self.script(
                    "CLASSIFY_INACTIVE_IDENTITY_SCRIPT", {"address": "192.0.2.10"}
                )
                self.assertEqual(result.returncode, 0, result.stderr.decode())
                self.assertEqual(json.loads(result.stdout)["status"], expected)

    def test_foreign_ca_certificate_is_not_replaced(self):
        self.openssl(
            "req", "-x509", "-newkey", "ed25519", "-nodes", "-keyout", "other.key",
            "-out", "other.crt", "-subj", "/CN=other CA", "-days", "2",
        )
        csr = self.openssl(
            "req", "-new", "-key", "neighbor-identity.key", "-subj", "/CN=swiftfabric-neighbor",
        ).stdout
        certificate = self.openssl(
            "x509", "-req", "-CA", "other.crt", "-CAkey", "other.key",
            "-set_serial", "126", "-days", "397", "-extfile", "extensions", input_data=csr,
        ).stdout
        (self.directory / "neighbor-identity.crt").write_bytes(certificate)
        result = self.script("CLASSIFY_INACTIVE_IDENTITY_SCRIPT", {"address": "192.0.2.10"})
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual((self.directory / "neighbor-identity.crt").read_bytes(), certificate)

    def test_expired_deployment_ca_leaf_is_eligible_for_renewal(self):
        csr = self.openssl(
            "req", "-new", "-key", "neighbor-identity.key",
            "-subj", "/CN=swiftfabric-neighbor",
        ).stdout
        certificate = self.openssl(
            "x509", "-req", "-CA", "swiftfabric-ca.crt", "-CAkey", "ca.key",
            "-set_serial", "128", "-days", "0", "-extfile", "extensions",
            input_data=csr,
        ).stdout
        (self.directory / "neighbor-identity.crt").write_bytes(certificate)
        time.sleep(1.1)
        result = self.script("CLASSIFY_INACTIVE_IDENTITY_SCRIPT", {"address": "192.0.2.10"})
        self.assertEqual(result.returncode, 0, result.stderr.decode())
        self.assertEqual(json.loads(result.stdout)["status"], "renew")

    def test_unrelated_self_signed_certificate_is_not_migrated(self):
        self.openssl(
            "req", "-x509", "-key", "neighbor-identity.key", "-out", "neighbor-identity.crt",
            "-subj", "/CN=unrelated", "-days", "2",
        )
        certificate = (self.directory / "neighbor-identity.crt").read_bytes()
        result = self.script("CLASSIFY_INACTIVE_IDENTITY_SCRIPT", {"address": "192.0.2.10"})
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual((self.directory / "neighbor-identity.crt").read_bytes(), certificate)

    def test_changed_certificate_is_not_replaced(self):
        before = (self.directory / "neighbor-identity.crt").read_bytes()
        result = self.script(
            "INSTALL_INACTIVE_CERTIFICATE_SCRIPT",
            {"address": "192.0.2.10", "certificate": "not a certificate",
             "previous_sha256": "0" * 64},
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual((self.directory / "neighbor-identity.crt").read_bytes(), before)

    def test_absent_identity_is_skipped(self):
        (self.directory / "neighbor-identity.key").unlink()
        (self.directory / "neighbor-identity.crt").unlink()
        result = self.script("INACTIVE_IDENTITY_SCRIPT")
        self.assertEqual(result.returncode, 0, result.stderr.decode())
        self.assertEqual(result.stdout.strip(), b"absent")


if __name__ == "__main__":
    unittest.main()
