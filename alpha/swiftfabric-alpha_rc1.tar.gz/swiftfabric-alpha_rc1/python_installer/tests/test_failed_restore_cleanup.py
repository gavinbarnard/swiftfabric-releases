import copy
import hashlib
import io
import json
from pathlib import Path
import shlex
import sys
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python_installer/tests_integration"))
import failed_restore_cleanup as helper
import disaster_recovery as recovery


class StagedOwnershipTests(unittest.TestCase):
    def setUp(self):
        self.spec = {
            "operation": "probe", "product_version": "version",
            "backup_ca_sha256": hashlib.sha256(b"original-ca").hexdigest(),
            "controller_ips": ["192.0.2.10", "192.0.2.11", "192.0.2.12"],
            "controller_names": ["one", "two", "three"], "api_vip": "192.0.2.13",
            "hosts": [{"host_id": "host1", "node": "n1", "cluster": "pve", "agent_version": "agent"}],
            "router": {"id": "router", "name": "router", "vmid": 200},
            "router_vm_name": "sf-nsr-router", "cluster": {"name": "pve", "proxmox_cluster_ip": "192.0.2.1"},
        }
        host = self.spec["hosts"][0]
        router = {**self.spec["router"], "node": "n1", "vm_owner_token": "a" * 64,
                  "runtime_token": "never-export"}
        cluster = {**self.spec["cluster"], "proxmox_ssh_key": "never-export",
                   "proxmox_apikey": "never-export", "_version": 1}
        self.payload = {
            "manifest": {"product_version": "version"},
            "deployment": {"controller_ips": self.spec["controller_ips"],
                           "controller_names": self.spec["controller_names"], "api_vip": self.spec["api_vip"]},
            "components": {"ca_certificate": "original-ca", "provisioning": {
                "swiftfabric:hosts": {"host1": json.dumps(host)},
                "swiftfabric:north_south_routers": {"router": json.dumps(router)},
                "swiftfabric:proxmox:clusters": {"pve": json.dumps(cluster)},
            }},
        }
        self.path = Path("/staging/" + "b" * 32 + ".json")

    def plan(self, journals=()):
        with mock.patch.object(Path, "exists", return_value=False), \
                mock.patch.object(Path, "glob", side_effect=[journals, [self.path]]), \
                mock.patch.object(helper, "secure_json",
                                  side_effect=lambda path: self.payload if path == self.path else
                                  {"phase": "applying"}), \
                mock.patch.object(Path, "read_bytes", return_value=json.dumps(self.payload).encode()):
            return helper.staged_plan(self.spec)

    def test_only_public_ownership_leaves_controller(self):
        plan, cluster = self.plan()
        self.assertNotIn("never-export", json.dumps(plan))
        self.assertEqual(cluster["proxmox_ssh_key"], "never-export")
        self.assertEqual(plan["router"]["owner_tag"], "swiftfabric_owner_" + "a" * 64)
        self.assertEqual(plan["router"]["description"], "SwiftFabric N/S router router member a")

    def test_mutated_journal_blocks_cleanup(self):
        with self.assertRaisesRegex(RuntimeError, "may have mutated"):
            self.plan([Path("/journals/run/state.json")])

    def test_foreign_host_router_cluster_or_backup_blocks_cleanup(self):
        for change in (
            {"hosts": []}, {"router": {**self.spec["router"], "vmid": 999}},
            {"cluster": {"name": "foreign"}}, {"backup_ca_sha256": "0" * 64},
        ):
            with self.subTest(change=change):
                previous = self.spec
                self.spec = {**self.spec, **change}
                with self.assertRaises(RuntimeError):
                    self.plan()
                self.spec = previous

    def test_registration_uses_existing_api_and_keeps_archived_key_local(self):
        plan, cluster = self.plan()
        config = {"node_ips": self.spec["controller_ips"], "node_names": self.spec["controller_names"],
                  "api_vip": self.spec["api_vip"]}
        responses = [[{"id": "default"}], [], [], [], {}]
        with mock.patch.object(helper, "staged_plan", return_value=(plan, cluster)), \
                mock.patch.object(helper, "secure_json", return_value=config), \
                mock.patch.object(helper.subprocess, "check_output", return_value="version"), \
                mock.patch.object(helper, "api", side_effect=responses) as api:
            result = helper.dispatch({**self.spec, "operation": "register-cluster", "plan": plan})
        self.assertEqual(result, plan)
        self.assertEqual(api.call_args.args[:3], (config, "PUT", "/proxmox/clusters/pve"))
        self.assertNotIn("_version", api.call_args.args[3])

    def test_nonempty_live_inventory_or_wrong_version_blocks_registration(self):
        plan, cluster = self.plan()
        config = {"node_ips": self.spec["controller_ips"], "node_names": self.spec["controller_names"],
                  "api_vip": self.spec["api_vip"]}
        for version, responses in (
            ("wrong", []), ("version", [[{"id": "restored"}]]),
            ("version", [[{"id": "default"}], [{"host_id": "live"}]]),
            ("version", [[{"id": "default"}], [], [{"id": "live-router"}]]),
        ):
            with self.subTest(version=version, responses=responses), \
                    mock.patch.object(helper, "staged_plan", return_value=(plan, cluster)), \
                    mock.patch.object(helper, "secure_json", return_value=config), \
                    mock.patch.object(helper.subprocess, "check_output", return_value=version), \
                    mock.patch.object(helper, "api", side_effect=responses), \
                    self.assertRaises(RuntimeError):
                helper.dispatch({**self.spec, "operation": "register-cluster", "plan": plan})


class OrphanCleanupTests(unittest.TestCase):
    def setUp(self):
        self.run = mock.Mock()
        self.run.directory = Path("/private/run")
        self.run.config = {
            "ip_range_start": "192.0.2.10", "ip_range_end": "192.0.2.13",
            "proxmox_cluster_name": "pve", "proxmox_cluster_ip": "192.0.2.1",
            "proxmox_port": 8006, "proxmox_user": "root@pam", "proxmox_tokenname": "test",
            "proxmox_ssh_user": "root", "proxmox_ssh_key": "/synthetic/key",
            "vtep_ip_range_cidr": "192.0.3.0/24",
        }
        host = {"host_id": "host1", "node": "n1", "cluster": "pve", "agent_version": "agent"}
        router = {"id": "sf-dr-" + "a" * 20 + "-nsr", "name": "sf-dr-" + "a" * 20 + "-nsr", "vmid": 200}
        self.run.state = {
            "status": "failed", "current_stage": "restore",
            "stages": ["install-and-enroll", "create-router", "create-tenancy-lab", "baseline",
                       "backup", "controller-loss", "redeploy"],
            "replacement_controllers": [{"name": name} for name in ("one", "two", "three")],
            "host_identities": [host], "router": router, "backup_product_version": "version",
            "backup_ca_sha256": "b" * 64, "original_ca_der_sha256": "c" * 64,
        }
        self.vm = {"vmid": 100, "node": "n1", "name": "sf-lab-run-vm", "segment_id": 49100}
        self.lab = {
            "run_id": "run", "vms": [self.vm], "tenant_metadata": [
                {"routing_table": 130000, "conntrack_zone": 30000},
                {"routing_table": 130001, "conntrack_zone": 30001}],
        }
        self.evidence = {"run_id": "run", "router": {**router, "proxmox_vm_name": "sf-nsr-owned"}}
        self.plan = {"staging_sha256": "d" * 64, "router": {
            "node": "n1", "vmid": 200, "name": "sf-nsr-owned",
            "description": f"SwiftFabric N/S router {router['id']} member a",
            "owner_tag": "swiftfabric_owner_" + "e" * 64,
        }}
        self.configs = {
            100: {"name": self.vm["name"], "description": "SwiftFabric live network lab run",
                  "net0": "virtio=00:00:00:00:00:01,bridge=sf-br49100"},
            200: {"name": self.plan["router"]["name"], "description": self.plan["router"]["description"],
                  "tags": self.plan["router"]["owner_tag"]},
        }
        self.order = []

        def get(path, **kwargs):
            if path == "/cluster/resources":
                return {"data": [{"vmid": vmid, "node": "n1", "type": "qemu", "name": config["name"]}
                                 for vmid, config in self.configs.items()]}
            vmid = int(path.split("/")[4])
            return {"data": {"status": "stopped"} if path.endswith("/status/current") else self.configs[vmid]}

        def delete(path):
            vmid = int(path.split("/")[4])
            self.order.append(f"vm-{vmid}")
            del self.configs[vmid]
            return {"data": "UPID:delete"}

        self.run.proxmox.get.side_effect = get
        self.run.proxmox.delete.side_effect = delete
        self.run.api.json.return_value = {"results": [{"node": "n1", "result": "cleaned", "message": ""}]}
        self.run.cleanup.side_effect = lambda: self.order.append("controllers")

    def cleanup(self, host_outputs=None, controller_plans=None, preflight_only=False):
        ssh = mock.Mock()
        ssh.run.side_effect = host_outputs or ["OWNED", "OWNED", "SWIFTFABRIC_HOST_CLEAN"]
        responses = []
        for plan in controller_plans or [self.plan] * 3:
            responses.extend(["public-ca", json.dumps(plan)])
        responses.append(json.dumps(self.plan))
        self.run.api.ssh.run.side_effect = responses
        with mock.patch.object(recovery, "read_config_object", side_effect=[self.lab, self.evidence]), \
                mock.patch.object(recovery, "_controller_vip", return_value="192.0.2.13"), \
                mock.patch.object(recovery, "ca_fingerprint", return_value=hashlib.sha256(b"ca").hexdigest()), \
                mock.patch.object(recovery.ssl, "PEM_cert_to_DER_cert", return_value=b"ca"), \
                mock.patch.object(recovery, "SSHCommandRunner", return_value=ssh):
            recovery.cleanup_failed_restore(
                self.run, self.run.directory / "network-lab", preflight_only=preflight_only)
        return ssh

    def test_cleanup_orders_owned_vms_router_hosts_then_controllers(self):
        ssh = self.cleanup()
        self.assertEqual(self.order, ["vm-100", "vm-200", "controllers"])
        self.run.api.json.assert_called_once_with(
            "POST", "/proxmox/clusters/pve/cleanup", {"stale_nodes": ["n1"]})
        self.assertEqual(ssh.run.call_count, 3)
        self.assertEqual(self.run.state["current_stage"], "restore")
        self.assertEqual(self.run.state["orphan_cleanup_plan"], self.plan)

    def test_preflight_does_not_delete_register_or_unenroll(self):
        self.cleanup(host_outputs=["OWNED"], preflight_only=True)
        self.assertEqual(self.order, [])
        self.run.api.json.assert_not_called()
        self.run.cleanup.assert_not_called()

    def test_host_probe_requires_original_anchor_and_os_trust(self):
        ssh = self.cleanup(host_outputs=["OWNED"], preflight_only=True)
        command = ssh.run.call_args.args[1]
        code = shlex.split(command)[-1]
        pem = "original-public-ca"
        spec = json.loads(ssh.run.call_args.kwargs["input_data"])
        spec.update(ca=hashlib.sha256(b"der").hexdigest(),
                    pem_sha256=hashlib.sha256(pem.encode()).hexdigest())
        config = {"host_id": spec["host_id"], "api_url": spec["api_url"]}
        for trusted in ([b"der"], []):
            with self.subTest(trusted=bool(trusted)), \
                    mock.patch.object(Path, "exists", return_value=True), \
                    mock.patch.object(Path, "read_text", side_effect=[json.dumps(config), pem]) as read, \
                    mock.patch.object(recovery.ssl, "PEM_cert_to_DER_cert", return_value=b"der"), \
                    mock.patch.object(recovery.ssl, "create_default_context") as context, \
                    mock.patch.object(sys, "stdin", io.StringIO(json.dumps(spec))), \
                    mock.patch("builtins.print"):
                context.return_value.get_ca_certs.return_value = trusted
                if trusted:
                    exec(code, {})
                else:
                    with self.assertRaisesRegex(RuntimeError, "host ownership differs"):
                        exec(code, {})
                self.assertEqual(read.call_count, 2)
                context.return_value.get_ca_certs.assert_called_once_with(binary_form=True)

    def test_foreign_vm_or_router_blocks_every_deletion(self):
        for vmid in (100, 200):
            original = copy.deepcopy(self.configs[vmid])
            self.configs[vmid]["description"] = "foreign"
            with self.subTest(vmid=vmid), self.assertRaisesRegex(RuntimeError, "ownership"):
                self.cleanup()
            self.configs[vmid] = original
        self.assertEqual(self.order, [])
        self.run.api.json.assert_not_called()

    def test_foreign_host_or_mixed_staging_blocks_every_deletion(self):
        with self.assertRaisesRegex(RuntimeError, "Invalid host"):
            self.cleanup(["FOREIGN"])
        with self.assertRaisesRegex(RuntimeError, "different staged"):
            self.cleanup(controller_plans=[self.plan, {**self.plan, "staging_sha256": "other"}, self.plan])
        self.assertEqual(self.order, [])

    def test_partial_restore_or_upgrade_is_not_eligible(self):
        for change in ({"current_stage": "upgrade"}, {"stages": ["restore"]},
                       {"target_source": {"branch": "main"}}):
            previous = self.run.state.copy()
            self.run.state.update(change)
            with self.subTest(change=change), self.assertRaisesRegex(RuntimeError, "failed restore"):
                self.cleanup()
            self.run.state = previous
        self.assertEqual(self.order, [])

    def test_host_cleanup_failure_forbids_controller_destruction(self):
        self.run.api.json.return_value = {"results": [{"node": "n1", "result": "failed", "message": "blocked"}]}
        with self.assertRaisesRegex(RuntimeError, "host cleanup incomplete"):
            self.cleanup()
        self.run.cleanup.assert_not_called()

    def test_host_ownership_changed_before_teardown_blocks_host_api(self):
        with self.assertRaisesRegex(RuntimeError, "ownership changed before teardown"):
            self.cleanup(["OWNED", "FOREIGN"])
        self.run.api.json.assert_not_called()
        self.run.cleanup.assert_not_called()

    def test_resume_verifies_absent_vms_and_already_clean_hosts(self):
        self.configs.clear()
        self.cleanup(["ABSENT", "SWIFTFABRIC_HOST_CLEAN", "SWIFTFABRIC_HOST_CLEAN"])
        self.assertEqual(self.order, ["controllers"])
        self.run.api.json.assert_not_called()

    def test_missing_host_config_with_residual_state_blocks_cleanup(self):
        with self.assertRaisesRegex(RuntimeError, "Missing host"):
            self.cleanup(["ABSENT", "RESIDUAL"])
        self.assertEqual(self.order, [])


if __name__ == "__main__":
    unittest.main()
