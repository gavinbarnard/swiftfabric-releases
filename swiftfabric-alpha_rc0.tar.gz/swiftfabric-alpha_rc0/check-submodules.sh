#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if (($# == 0)); then
    set -- host-agent demos network-lab controller-api python_installer
fi
# Release bundles ship committed module files without Git metadata.
if [[ -f "$ROOT_DIR/RELEASE.json" && ! -e "$ROOT_DIR/.git" ]]; then
    for module in "$@"; do
        if [[ ! -d "$ROOT_DIR/$module" ]]; then
            echo "ERROR: Release bundle is missing '$module'." >&2
            exit 1
        fi
    done
    exit 0
fi
for module in "$@"; do
    module_root="$(git -C "$ROOT_DIR/$module" rev-parse --show-toplevel 2>/dev/null || true)"
    if [[ "$module_root" != "$ROOT_DIR/$module" ]]; then
        echo "ERROR: Required submodule '$module' is not initialized." >&2
        echo "Run: git -c protocol.file.allow=always submodule update --init --recursive" >&2
        exit 1
    fi
done
