"""Opt-in automated host-agent and North/South router upgrades.

Used by ``upgrade.py --auto-agent-upgrade`` after the controller packages have
been upgraded. Compute hosts are upgraded one at a time: running VMs attached
to SwiftFabric segment bridges are live-migrated to other enrolled hosts, the
controller's per-host upgrade action runs, and the VMs are returned. Routers
use the controller's in-place upgrade or, for state-synchronized HA pairs, the
coordinated rolling runtime upgrade that hands forwarding between members.
"""

import json
import re
import subprocess
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional
from urllib.parse import quote

from rich.console import Console
from rich.table import Table


console = Console()

AGENT_PAYLOAD_PREFIX = "usr/share/swiftfabric/host-agents/"
VERSION_PATTERN = re.compile(r"[A-Za-z0-9._+~:-]{1,128}")
SEGMENT_BRIDGE_PATTERN = re.compile(r"sf-br([1-9][0-9]{0,4})")
MIN_SEGMENT_ID = 5000
MAX_SEGMENT_ID = 50000
HOST_UPGRADE_MAX_TIME = 900
ROUTER_HA_UPGRADE_MAX_TIME = 3600
ROUTER_UPGRADE_TIMEOUT = 1800
ROUTER_POLL_INTERVAL = 5
VM_PLACEMENT_TIMEOUT = 600
API_ATTEMPTS = 3
API_RETRY_DELAY = 5
ROUTER_ACTIVE_STATUS = "active"
ROUTER_BUSY_STATUSES = {"deploying", "starting", "redeploying", "ha-bootstrapping"}


class AgentUpgradeError(RuntimeError):
    """An automated agent upgrade could not be planned or completed."""


@dataclass
class Migration:
    vmid: int
    name: str
    source: str
    target: str
    task_id: Optional[str] = None
    submission_attempted: bool = False
    completed: bool = False
    recovery_record: Optional[dict] = None


@dataclass
class HostPlan:
    host_id: str
    node: str
    cluster: str
    current_version: str
    workloads: List[dict] = field(default_factory=list)


@dataclass
class RouterPlan:
    router_id: str
    name: str
    method: str
    current_version: str
    note: str = ""


@dataclass
class AgentUpgradePlan:
    target_version: str
    hosts: List[HostPlan] = field(default_factory=list)
    routers: List[RouterPlan] = field(default_factory=list)
    target_runtime_version: Optional[str] = None

    @property
    def empty(self):
        return not self.hosts and not self.routers


@dataclass
class AgentUpgradeOptions:
    migrate_back: bool = True
    migrate_local_disks: bool = False
    migration_timeout: int = 3600


def package_agent_version(package_path):
    """Return the single host-agent payload version embedded in the package."""
    try:
        result = subprocess.run(
            ["dpkg-deb", "-c", str(package_path)],
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError as exc:
        raise AgentUpgradeError(
            "dpkg-deb is required to inspect the controller package."
        ) from exc
    if result.returncode != 0:
        raise AgentUpgradeError(
            "Could not list controller package contents: "
            + (result.stderr or result.stdout).strip()
        )
    versions = set()
    for line in result.stdout.splitlines():
        path = line.split()[-1] if line.split() else ""
        path = path.removeprefix("./")
        if not path.startswith(AGENT_PAYLOAD_PREFIX):
            continue
        version = path[len(AGENT_PAYLOAD_PREFIX):].split("/", 1)[0]
        if version:
            versions.add(version)
    if len(versions) != 1:
        raise AgentUpgradeError(
            "The controller package must contain exactly one host-agent payload "
            f"version; found {len(versions)}."
        )
    version = versions.pop()
    if not VERSION_PATTERN.fullmatch(version):
        raise AgentUpgradeError("The packaged host-agent version is invalid.")
    return version


def segment_bridges(vm_config):
    """Return connected SwiftFabric segment bridges in a Proxmox VM config."""
    bridges = set()
    for key, value in vm_config.items():
        if not (key.startswith("net") and key[3:].isdigit()):
            continue
        if not isinstance(value, str):
            raise AgentUpgradeError(f"Proxmox returned invalid network config for {key}.")
        options = value.split(",")
        if any(
            option.partition("=")[0] == "link_down"
            and option.partition("=")[2].lower() in {"1", "on", "true"}
            for option in options
        ):
            continue
        for option in options:
            name, _, bridge = option.partition("=")
            if name != "bridge":
                continue
            match = SEGMENT_BRIDGE_PATTERN.fullmatch(bridge)
            if match and MIN_SEGMENT_ID <= int(match.group(1)) <= MAX_SEGMENT_ID:
                bridges.add(bridge)
    return sorted(bridges)


def _curl_config_string(value):
    if any(character in value for character in "\r\n"):
        raise ValueError("Controller API request values cannot contain line breaks.")
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _shell_quote(value):
    return "'" + value.replace("'", "'\\''") + "'"


class ControllerApi:
    """Authenticated loopback API access on a selected controller.

    Long-running controller actions bypass the HTTPS proxy so they are not
    cut short by its upstream read timeout. The resolver normally selects the
    API VIP owner; callers may select another controller for node-local actions.
    """

    def __init__(self, ssh, token, resolve_controller: Callable[[], dict]):
        self.ssh = ssh
        self.token = token
        self.resolve_controller = resolve_controller
        self._controller = None

    def request(self, method, path, body=None, max_time=30):
        last_error = None
        for attempt in range(API_ATTEMPTS):
            try:
                if self._controller is None:
                    self._controller = self.resolve_controller()
                status, text = self._request_once(method, path, body, max_time)
            except (RuntimeError, TimeoutError) as exc:
                last_error = exc
                # The action may have run; callers re-inspect state instead.
                if method != "GET" and self._controller is not None:
                    self._controller = None
                    break
            else:
                if status == 503 and "API VIP is not active" in text:
                    last_error = AgentUpgradeError(text)
                else:
                    return status, text
            self._controller = None
            if attempt + 1 < API_ATTEMPTS:
                time.sleep(API_RETRY_DELAY)
        raise AgentUpgradeError(
            f"Controller API request {method} {path} failed: {last_error}"
        ) from last_error

    def json(self, method, path, body=None, max_time=30, allowed=()):
        status, text = self.request(method, path, body, max_time)
        if not (200 <= status < 300 or status in allowed):
            raise AgentUpgradeError(
                f"Controller API {method} {path} returned HTTP {status}: "
                + _error_detail(text)
            )
        try:
            return status, json.loads(text) if text else None
        except ValueError as exc:
            raise AgentUpgradeError(
                f"Controller API {method} {path} returned invalid JSON."
            ) from exc

    def _request_once(self, method, path, body, max_time):
        lines = [
            f"header = {_curl_config_string('Authorization: Bearer ' + self.token)}",
            f"request = {_curl_config_string(method)}",
        ]
        if body is not None:
            lines.append(
                f"header = {_curl_config_string('Content-Type: application/json')}"
            )
            lines.append(
                f"data-binary = {_curl_config_string(json.dumps(body, separators=(',', ':')))}"
            )
        command = (
            f"curl --silent --show-error --max-time {int(max_time)} --config - "
            "--write-out '\\n%{http_code}' "
            + _shell_quote(f"http://127.0.0.1:8080{path}")
        )
        output = self.ssh.run(
            self._controller["ip_address"],
            command,
            timeout=int(max_time) + 30,
            input_data=("\n".join(lines) + "\n").encode("utf-8"),
        )
        try:
            text, status = output.rsplit("\n", 1)
            return int(status), text
        except (ValueError, TypeError) as exc:
            raise RuntimeError("Controller returned an invalid local API response.") from exc


class AgentUpgradeRecoveryJournal:
    """Revision-checked evacuation journal stored in controller Valkey 4999."""

    PATH = "/api/v1/system/agent-upgrade-recovery"
    WRITE_ATTEMPTS = 5

    def __init__(self, api):
        self.api = api

    def load(self):
        _, snapshot = self.api.json("GET", self.PATH)
        if (
            not isinstance(snapshot, dict)
            or isinstance(snapshot.get("revision"), bool)
            or not isinstance(snapshot.get("revision"), int)
            or snapshot["revision"] < 0
            or not isinstance(snapshot.get("records"), list)
        ):
            raise AgentUpgradeError("Controller returned invalid agent-upgrade recovery data.")
        return snapshot

    @staticmethod
    def _key(record):
        return record["cluster"], record["vmid"]

    def upsert(self, record):
        key = self._key(record)
        for _ in range(self.WRITE_ATTEMPTS):
            snapshot = self.load()
            records = [item for item in snapshot["records"] if self._key(item) != key]
            records.append(dict(record))
            status, updated = self.api.json(
                "PUT",
                self.PATH,
                {"expected_revision": snapshot["revision"], "records": records},
                allowed=(409,),
            )
            if status == 409:
                continue
            if not isinstance(updated, dict):
                raise AgentUpgradeError("Controller returned invalid updated recovery data.")
            return updated
        raise AgentUpgradeError("Could not update agent-upgrade recovery data after concurrent changes.")

    def remove(self, cluster, vmid):
        key = (cluster, vmid)
        for _ in range(self.WRITE_ATTEMPTS):
            snapshot = self.load()
            records = [item for item in snapshot["records"] if self._key(item) != key]
            if len(records) == len(snapshot["records"]):
                return snapshot
            status, updated = self.api.json(
                "PUT",
                self.PATH,
                {"expected_revision": snapshot["revision"], "records": records},
                allowed=(409,),
            )
            if status == 409:
                continue
            if not isinstance(updated, dict):
                raise AgentUpgradeError("Controller returned invalid updated recovery data.")
            return updated
        raise AgentUpgradeError("Could not remove agent-upgrade recovery data after concurrent changes.")


def _error_detail(text):
    try:
        value = json.loads(text)
    except ValueError:
        return text.strip()[:500] or "no response body"
    if isinstance(value, dict) and isinstance(value.get("error"), str):
        return value["error"][:500]
    return text.strip()[:500]


class ProxmoxWorkloads:
    """Inspect and live-migrate VMs through the installer's Proxmox API token."""

    def __init__(self, client):
        self.client = client

    def _data(self, endpoint, params=None):
        return self.client.get(endpoint, params).get("data")

    def online_nodes(self):
        nodes = self._data("/cluster/resources", {"type": "node"}) or []
        return {
            item["node"]: item
            for item in nodes
            if isinstance(item, dict) and item.get("status") == "online" and item.get("node")
        }

    def vm_location(self, vmid):
        for item in self._data("/cluster/resources", {"type": "vm"}) or []:
            if isinstance(item, dict) and item.get("vmid") == vmid:
                return item
        return None

    def attached_running_vms(self, node):
        vms = []
        for guest in self._data(f"/nodes/{quote(node, safe='')}/qemu") or []:
            if guest.get("status") != "running":
                continue
            vmid = guest.get("vmid")
            if not isinstance(vmid, int):
                raise AgentUpgradeError(f"Proxmox returned a VM without a VMID on {node}.")
            config = self._data(f"/nodes/{quote(node, safe='')}/qemu/{vmid}/config") or {}
            bridges = segment_bridges(config)
            if bridges:
                vms.append({
                    "vmid": vmid,
                    "name": guest.get("name") or "unnamed",
                    "mem": int(guest.get("mem") or 0),
                    "bridges": bridges,
                })
        return vms

    def precondition(self, node, vmid, target):
        return self._data(
            f"/nodes/{quote(node, safe='')}/qemu/{vmid}/migrate", {"target": target}
        ) or {}

    def migrate(self, vmid, source, target, with_local_disks, timeout, on_task=None):
        data = {"target": target, "online": 1}
        if with_local_disks:
            data["with-local-disks"] = 1
        upid = self.client.post(
            f"/nodes/{quote(source, safe='')}/qemu/{vmid}/migrate", data
        ).get("data")
        if isinstance(upid, str) and upid:
            if on_task is not None:
                on_task(upid)
            self.client.wait_for_task(upid, timeout=timeout)
        # HA-managed VMs complete the request task before the move finishes.
        deadline = time.monotonic() + max(timeout, VM_PLACEMENT_TIMEOUT)
        while True:
            location = self.vm_location(vmid)
            if location and location.get("node") == target and location.get("status") == "running":
                return
            if time.monotonic() >= deadline:
                raise AgentUpgradeError(
                    f"VM {vmid} was not running on {target} after migration."
                )
            time.sleep(3)

    def task_status(self, upid):
        parts = upid.split(":")
        if len(parts) < 3 or parts[0] != "UPID" or not parts[1]:
            raise AgentUpgradeError("Proxmox returned an invalid migration task ID.")
        return self._data(
            f"/nodes/{quote(parts[1], safe='')}/tasks/{quote(upid, safe='')}/status"
        ) or {}


def local_disk_blockers(precondition):
    disks = [
        disk for disk in precondition.get("local_disks") or []
        if isinstance(disk, dict) and not disk.get("cdrom") and not disk.get("is_unused")
        and "cloudinit" not in str(disk.get("volid", ""))
    ]
    return disks


def _router_versions(router):
    members = router.get("member_runtime_versions") or {}
    return members if isinstance(members, dict) else {}


def _router_needs_upgrade(router, target, runtime_target=None):
    runtime_target = runtime_target or target
    if router.get("ha_state_sync_enabled"):
        members = _router_versions(router)
        return any(members.get(member) != runtime_target for member in ("a", "b"))
    return (
        router.get("runtime_version") != runtime_target
        or router.get("agent_version") != target
    )


def build_plan(api, proxmox, target_version, cluster_name, options, runtime_target=None):
    """Inspect controller and Proxmox state; raise if any upgrade is blocked."""
    _, hosts = api.json("GET", "/api/v1/hosts")
    _, routers = api.json("GET", "/api/v1/north-south-routers")
    if not isinstance(hosts, list) or not isinstance(routers, list):
        raise AgentUpgradeError("Controller returned an invalid host or router inventory.")
    plan = AgentUpgradePlan(target_version, target_runtime_version=runtime_target)
    blockers = []

    pending_hosts = [
        host for host in hosts
        if isinstance(host, dict) and host.get("agent_version") != target_version
    ]
    online = proxmox.online_nodes() if pending_hosts else {}
    for host in sorted(pending_hosts, key=lambda item: str(item.get("node"))):
        label = f"host {host.get('host_id')} ({host.get('node')})"
        if host.get("status") != "enrolled":
            blockers.append(f"{label} has status {host.get('status')!r}; resolve it first")
            continue
        if host.get("cluster") != cluster_name:
            blockers.append(
                f"{label} belongs to Proxmox cluster {host.get('cluster')!r}, but "
                f"automated upgrades can only manage the configured cluster "
                f"{cluster_name!r}; upgrade it from the Compute page"
            )
            continue
        if host.get("node") not in online:
            blockers.append(f"{label} is not online in Proxmox")
            continue
        workloads = proxmox.attached_running_vms(host["node"])
        candidates = migration_candidates(hosts, host, online)
        reservations = {}
        for vm in workloads:
            try:
                target, _ = _choose_target(
                    proxmox, host["node"], vm, candidates, reservations, options,
                    online=online, baseline=online,
                )
            except AgentUpgradeError as failure:
                blockers.append(f"{label}: VM {vm['name']} ({vm['vmid']}) {failure}")
            else:
                reservations[target] = reservations.get(target, 0) + vm["mem"]
        plan.hosts.append(HostPlan(
            host["host_id"], host["node"], host["cluster"],
            host.get("agent_version") or "legacy", workloads,
        ))

    for router in sorted(
        (item for item in routers if isinstance(item, dict)),
        key=lambda item: str(item.get("name") or item.get("id")),
    ):
        if not _router_needs_upgrade(router, target_version, runtime_target):
            continue
        label = f"router {router.get('name') or router.get('id')}"
        status = router.get("status")
        if router.get("upgrade_in_progress") or status in ROUTER_BUSY_STATUSES:
            blockers.append(f"{label} has another operation in progress ({status})")
            continue
        if status != ROUTER_ACTIVE_STATUS or router.get("vmid") is None:
            blockers.append(f"{label} is {status!r}; only active, deployed routers upgrade")
            continue
        if router.get("pending_configuration"):
            blockers.append(f"{label} has a pending configuration; apply or discard it")
            continue
        if router.get("ha_state_sync_enabled"):
            if router.get("ha_replication_mode", "paired") != "paired":
                blockers.append(
                    f"{label} is in {router.get('ha_replication_mode')} durability; "
                    "restore paired replication before a rolling upgrade"
                )
                continue
            note = ""
            if router.get("agent_version") != target_version:
                note = (
                    "rolling upgrade replaces router runtime; the HA guest host-agent "
                    "has no coordinated upgrade yet"
                )
            plan.routers.append(RouterPlan(
                router["id"], router.get("name") or router["id"], "rolling HA",
                ",".join(
                    f"{member}={_router_versions(router).get(member, 'legacy')}"
                    for member in ("a", "b")
                ),
                note,
            ))
        else:
            if not router.get("ssh_private_key_available", True):
                blockers.append(f"{label} has no retained SSH key; redeploy it")
                continue
            plan.routers.append(RouterPlan(
                router["id"], router.get("name") or router["id"], "in-place",
                f"runtime={router.get('runtime_version', 'legacy')}, "
                f"agent={router.get('agent_version', 'legacy')}",
                "brief forwarding interruption",
            ))

    if blockers:
        raise AgentUpgradeError(
            "Automated agent upgrade preflight failed:\n  - " + "\n  - ".join(blockers)
        )
    return plan


def migration_candidates(hosts, source, online):
    return [
        host["node"] for host in hosts
        if isinstance(host, dict)
        and host.get("cluster") == source.get("cluster")
        and host.get("node") != source.get("node")
        and host.get("status") == "enrolled"
        and host.get("node") in online
    ]


def show_plan(plan):
    runtime_target = plan.target_runtime_version or plan.target_version
    if plan.empty:
        console.print(
            f"[green]All enrolled hosts and routers are current "
            f"(agent {plan.target_version}, router runtime {runtime_target}).[/green]"
        )
        return
    table = Table(
        title=f"Agent target {plan.target_version}; router runtime target {runtime_target}"
    )
    table.add_column("Type")
    table.add_column("Name")
    table.add_column("Method")
    table.add_column("From")
    table.add_column("Workloads / notes")
    for host in plan.hosts:
        workloads = ", ".join(f"{vm['name']} ({vm['vmid']})" for vm in host.workloads)
        table.add_row(
            "compute", host.node, "evacuate, upgrade, return" if host.workloads else "upgrade",
            host.current_version, workloads or "none",
        )
    for router in plan.routers:
        table.add_row("router", router.name, router.method, router.current_version, router.note)
    console.print(table)


def _choose_target(proxmox, source, vm, candidates, reserved, options, online=None, baseline=None):
    online = online if online is not None else proxmox.online_nodes()
    baseline = baseline if baseline is not None else online
    ranked = []
    blockers = []
    for node in candidates:
        info = online.get(node)
        if not info:
            continue
        current_mem = int(info.get("mem") or 0)
        baseline_mem = int((baseline.get(node) or {}).get("mem") or 0)
        reflected_reservations = max(0, current_mem - baseline_mem)
        unreflected_reservations = max(
            0, reserved.get(node, 0) - reflected_reservations
        )
        free = (
            int(info.get("maxmem") or 0)
            - current_mem
            - unreflected_reservations
        )
        ranked.append((free, node))
    ranked.sort(reverse=True)
    for free, node in ranked:
        if free < vm["mem"]:
            continue
        precondition = proxmox.precondition(source, vm["vmid"], node)
        allowed = precondition.get("allowed_nodes")
        if isinstance(allowed, list) and node not in allowed:
            blockers.append(f"{node} is not allowed by Proxmox")
            continue
        local_resources = precondition.get("local_resources")
        if local_resources:
            blockers.append(
                f"{node} has local resources that block live migration: "
                + ", ".join(map(str, local_resources))
            )
            continue
        local_disks = local_disk_blockers(precondition)
        if local_disks and not options.migrate_local_disks:
            blockers.append(
                f"{node} requires --migrate-local-disks to copy local disks"
            )
            continue
        return node, bool(local_disks)
    if blockers:
        raise AgentUpgradeError(
            f"No eligible enrolled host can receive VM {vm['name']} ({vm['vmid']}): "
            + "; ".join(blockers)
        )
    raise AgentUpgradeError(
        f"No enrolled host has capacity to receive VM {vm['name']} ({vm['vmid']})."
    )


def _return_workloads(proxmox, migrations, options, recovery=None):
    stranded = []
    for move in reversed(migrations):
        try:
            if move.submission_attempted and not move.completed and not move.task_id:
                stranded.append(
                    f"{move.name} ({move.vmid}) on {move.target}: "
                    "migration task ID is unavailable; refusing to return while task state is uncertain"
                )
                continue
            if move.task_id:
                task = proxmox.task_status(move.task_id)
                if task.get("status") != "stopped":
                    stranded.append(
                        f"{move.name} ({move.vmid}) on {move.target}: "
                        f"original migration task {move.task_id} is not confirmed stopped"
                    )
                    continue
                if recovery and move.recovery_record:
                    move.recovery_record["phase"] = "evacuated"
                    move.recovery_record["task_id"] = None
                    recovery.upsert(move.recovery_record)
            location = proxmox.vm_location(move.vmid)
            if location is None:
                stranded.append(
                    f"{move.name} ({move.vmid}): Proxmox cannot confirm current placement"
                )
                continue
            current_node = location.get("node")
            if not isinstance(current_node, str) or not current_node:
                stranded.append(
                    f"{move.name} ({move.vmid}): Proxmox returned an invalid current placement"
                )
                continue
            if current_node == move.source:
                if recovery and move.recovery_record:
                    recovery.remove(move.recovery_record["cluster"], move.vmid)
                continue
            if recovery and move.recovery_record:
                move.recovery_record["phase"] = "returning"
                move.recovery_record["task_id"] = None
                recovery.upsert(move.recovery_record)

            def record_return_task(upid):
                move.task_id = upid
                if recovery and move.recovery_record:
                    move.recovery_record["task_id"] = upid
                    recovery.upsert(move.recovery_record)

            console.print(f"  Returning VM {move.name} ({move.vmid}) to {move.source}...")
            precondition = proxmox.precondition(current_node, move.vmid, move.source)
            proxmox.migrate(
                move.vmid, current_node, move.source,
                bool(local_disk_blockers(precondition)) and options.migrate_local_disks,
                options.migration_timeout,
                on_task=record_return_task,
            )
            if recovery and move.recovery_record:
                recovery.remove(move.recovery_record["cluster"], move.vmid)
        except Exception as exc:  # report every VM that could not be returned
            stranded.append(f"{move.name} ({move.vmid}) on {move.target}: {exc}")
    return stranded


def _host_record(api, host_id):
    _, hosts = api.json("GET", "/api/v1/hosts")
    for host in hosts or []:
        if isinstance(host, dict) and host.get("host_id") == host_id:
            return host
    raise AgentUpgradeError(f"Host {host_id} is no longer enrolled.")


def upgrade_host(api, proxmox, host, target_version, options, recovery=None):
    hosts = api.json("GET", "/api/v1/hosts")[1]
    record = _host_record(api, host.host_id)
    if record.get("agent_version") == target_version:
        console.print(f"[green]✓ {host.node} already runs {target_version}.[/green]")
        return
    baseline = {
        node: dict(info) for node, info in proxmox.online_nodes().items()
    }
    candidates = migration_candidates(hosts, record, baseline)
    migrations = []
    reserved = {}
    console.print(f"Upgrading compute host {host.node}...")
    try:
        for vm in proxmox.attached_running_vms(host.node):
            target, local_disks = _choose_target(
                proxmox, host.node, vm, candidates, reserved, options,
                baseline=baseline,
            )
            console.print(f"  Migrating VM {vm['name']} ({vm['vmid']}) to {target}...")
            move = Migration(vm["vmid"], vm["name"], host.node, target)
            if recovery:
                move.recovery_record = {
                    "cluster": host.cluster,
                    "host_id": host.host_id,
                    "source_node": host.node,
                    "target_node": target,
                    "vmid": vm["vmid"],
                    "name": vm["name"],
                    "target_version": target_version,
                    "phase": "moving",
                    "task_id": None,
                    "migrate_back": options.migrate_back,
                    "migrate_local_disks": options.migrate_local_disks,
                }
                recovery.upsert(move.recovery_record)
            migrations.append(move)
            move.submission_attempted = True

            def record_migration_task(upid):
                move.task_id = upid
                if recovery and move.recovery_record:
                    move.recovery_record["task_id"] = upid
                    recovery.upsert(move.recovery_record)

            proxmox.migrate(
                vm["vmid"], host.node, target, local_disks, options.migration_timeout,
                on_task=record_migration_task,
            )
            move.task_id = None
            move.completed = True
            if recovery and move.recovery_record:
                move.recovery_record["phase"] = "evacuated"
                recovery.upsert(move.recovery_record)
            reserved[target] = reserved.get(target, 0) + vm["mem"]
        remaining = proxmox.attached_running_vms(host.node)
        if remaining:
            raise AgentUpgradeError(
                "VMs started on the host during evacuation: "
                + ", ".join(f"{vm['name']} ({vm['vmid']})" for vm in remaining)
            )
        status, upgraded = api.json(
            "POST",
            f"/api/v1/hosts/{quote(host.host_id, safe='')}/upgrade",
            max_time=HOST_UPGRADE_MAX_TIME,
            allowed=(409,),
        )
        if status == 409:
            upgraded = _host_record(api, host.host_id)
        if not isinstance(upgraded, dict) or upgraded.get("agent_version") != target_version:
            raise AgentUpgradeError(
                "the controller did not record the target agent version"
            )
    except Exception as exc:
        stranded = []
        try:
            healthy = _host_record(api, host.host_id).get("status") == "enrolled"
        except Exception:
            healthy = False
        if migrations and healthy:
            stranded = _return_workloads(proxmox, migrations, options, recovery)
        elif migrations:
            stranded = [f"{m.name} ({m.vmid}) on {m.target}" for m in migrations]
        detail = f"Host {host.node} agent upgrade failed: {exc}"
        if stranded:
            detail += "\n  VMs not on their original host:\n    " + "\n    ".join(stranded)
        raise AgentUpgradeError(detail) from exc

    console.print(f"[green]✓ {host.node} host agent is at {target_version}.[/green]")
    if migrations and options.migrate_back:
        stranded = _return_workloads(proxmox, migrations, options, recovery)
        if stranded:
            raise AgentUpgradeError(
                f"{host.node} was upgraded, but some VMs could not be returned:\n    "
                + "\n    ".join(stranded)
            )
    elif migrations:
        for move in migrations:
            if recovery and move.recovery_record:
                move.recovery_record["phase"] = "no_return"
                move.recovery_record["task_id"] = None
                recovery.upsert(move.recovery_record)
            console.print(f"  VM {move.name} ({move.vmid}) remains on {move.target}.")


def _load_router(api, router_id):
    _, routers = api.json("GET", "/api/v1/north-south-routers")
    for router in routers or []:
        if isinstance(router, dict) and router.get("id") == router_id:
            return router
    raise AgentUpgradeError(f"Router {router_id} no longer exists.")


def upgrade_router_in_place(api, router_plan, target_version, runtime_target=None):
    path = f"/api/v1/north-south-routers/{quote(router_plan.router_id, safe='')}"
    router = _load_router(api, router_plan.router_id)
    if not _router_needs_upgrade(router, target_version, runtime_target):
        return
    if not router.get("upgrade_in_progress"):
        api.json("POST", path + "/upgrade", max_time=60)
    deadline = time.monotonic() + ROUTER_UPGRADE_TIMEOUT
    while True:
        time.sleep(ROUTER_POLL_INTERVAL)
        router = _load_router(api, router_plan.router_id)
        if not router.get("upgrade_in_progress"):
            break
        if time.monotonic() >= deadline:
            raise AgentUpgradeError(
                f"Router {router_plan.name} upgrade did not finish in time."
            )
    if _router_needs_upgrade(router, target_version, runtime_target):
        raise AgentUpgradeError(
            f"Router {router_plan.name} upgrade failed: "
            + (router.get("status_message") or f"status {router.get('status')}")
        )


def upgrade_router_rolling(api, router_plan, target_version):
    path = (
        f"/api/v1/north-south-routers/{quote(router_plan.router_id, safe='')}/ha-upgrade"
    )
    deadline = time.monotonic() + ROUTER_HA_UPGRADE_MAX_TIME
    while True:
        _, status = api.json("GET", path)
        pending = status.get("pending")
        if pending:
            request = {
                "source_generation": pending["source_generation"],
                "target_version": pending["target_version"],
            }
        else:
            router = _load_router(api, router_plan.router_id)
            if not _router_needs_upgrade(router, target_version):
                return
            if status.get("available_version") != target_version:
                raise AgentUpgradeError(
                    f"Controller offers router runtime {status.get('available_version')}, "
                    f"expected {target_version}."
                )
            request = {
                "source_generation": status["generation"],
                "target_version": target_version,
            }
        try:
            code, text = api.request(
                "POST", path, request, max_time=ROUTER_HA_UPGRADE_MAX_TIME
            )
        except AgentUpgradeError:
            # The controller-side worker survives a dropped request; resume it.
            if time.monotonic() >= deadline:
                raise
            time.sleep(15)
            continue
        if 200 <= code < 300:
            receipt = json.loads(text)
            if not receipt.get("completed"):
                raise AgentUpgradeError(
                    f"Router {router_plan.name} rolling upgrade did not complete."
                )
            return
        if code == 409 and "already running" in text and time.monotonic() < deadline:
            # A previous request's worker keeps running on the controller.
            time.sleep(15)
            continue
        raise AgentUpgradeError(
            f"Router {router_plan.name} rolling upgrade failed (HTTP {code}): "
            + _error_detail(text)
        )


def _resume_agent_upgrade_recovery(api, proxmox, cluster_name, options, recovery):
    snapshot = recovery.load()
    unresolved = []
    for record in list(snapshot["records"]):
        if record["cluster"] != cluster_name or record["phase"] == "no_return":
            continue
        phase = record["phase"]
        if phase in {"moving", "returning"}:
            if not record["task_id"]:
                unresolved.append(
                    f"VM {record['name']} ({record['vmid']}): {phase} task ID is unavailable"
                )
                continue
            task = proxmox.task_status(record["task_id"])
            if task.get("status") != "stopped":
                unresolved.append(
                    f"VM {record['name']} ({record['vmid']}): task "
                    f"{record['task_id']} is not confirmed stopped"
                )
                continue
            location = proxmox.vm_location(record["vmid"])
            if location is None:
                recovery.remove(cluster_name, record["vmid"])
                continue
            current_node = location.get("node")
            if not isinstance(current_node, str) or not current_node:
                unresolved.append(
                    f"VM {record['name']} ({record['vmid']}): current placement is invalid"
                )
                continue
            if current_node == record["source_node"]:
                recovery.remove(cluster_name, record["vmid"])
                continue
            record["phase"] = "evacuated"
            record["task_id"] = None
            recovery.upsert(record)

        if not record["migrate_back"]:
            try:
                host = _host_record(api, record["host_id"])
            except AgentUpgradeError:
                continue
            if host.get("agent_version") == record["target_version"]:
                record["phase"] = "no_return"
                record["task_id"] = None
                recovery.upsert(record)
            continue

        try:
            host = _host_record(api, record["host_id"])
        except AgentUpgradeError as failure:
            unresolved.append(f"VM {record['name']} ({record['vmid']}): {failure}")
            continue
        if host.get("status") != "enrolled" or host.get("node") != record["source_node"]:
            unresolved.append(
                f"VM {record['name']} ({record['vmid']}): source host is not healthy "
                "at its recorded node"
            )
            continue
        online = proxmox.online_nodes()
        if record["source_node"] not in online:
            unresolved.append(
                f"VM {record['name']} ({record['vmid']}): source node is offline"
            )
            continue
        location = proxmox.vm_location(record["vmid"])
        if location is None:
            recovery.remove(cluster_name, record["vmid"])
            continue
        current_node = location.get("node")
        if not isinstance(current_node, str) or not current_node:
            unresolved.append(
                f"VM {record['name']} ({record['vmid']}): current placement is invalid"
            )
            continue
        if current_node == record["source_node"]:
            recovery.remove(cluster_name, record["vmid"])
            continue
        move = Migration(
            record["vmid"],
            record["name"],
            record["source_node"],
            record["target_node"],
            completed=True,
            recovery_record=record,
        )
        return_options = AgentUpgradeOptions(
            migrate_back=True,
            migrate_local_disks=(
                options.migrate_local_disks or record["migrate_local_disks"]
            ),
            migration_timeout=options.migration_timeout,
        )
        stranded = _return_workloads(proxmox, [move], return_options, recovery)
        unresolved.extend(stranded)
    if unresolved:
        raise AgentUpgradeError(
            "Pending VM migration recovery is incomplete:\n  - "
            + "\n  - ".join(unresolved)
        )


def _finish_no_return_recoveries(recovery, cluster_name, host_id):
    for record in recovery.load()["records"]:
        if (
            record["cluster"] == cluster_name
            and record["host_id"] == host_id
            and not record["migrate_back"]
            and record["phase"] == "evacuated"
        ):
            record["phase"] = "no_return"
            record["task_id"] = None
            recovery.upsert(record)


def run_agent_upgrades(api, proxmox, cluster_name, target_version, options, runtime_target=None):
    """Re-plan against upgraded controllers, then upgrade hosts and routers."""
    recovery = AgentUpgradeRecoveryJournal(api)
    _resume_agent_upgrade_recovery(
        api, proxmox, cluster_name, options, recovery
    )
    runtime_target = runtime_target or target_version
    plan = build_plan(
        api, proxmox, target_version, cluster_name, options, runtime_target=runtime_target
    )
    show_plan(plan)
    completed = []
    for host in plan.hosts:
        try:
            upgrade_host(api, proxmox, host, target_version, options, recovery)
            _finish_no_return_recoveries(recovery, cluster_name, host.host_id)
        except Exception as exc:
            raise AgentUpgradeError(
                f"{exc}\n  Completed agent upgrades: {', '.join(completed) or 'none'}"
            ) from exc
        completed.append(host.node)
    for router in plan.routers:
        console.print(f"Upgrading router {router.name} ({router.method})...")
        try:
            if router.method == "rolling HA":
                upgrade_router_rolling(api, router, runtime_target)
            else:
                upgrade_router_in_place(api, router, target_version, runtime_target)
        except Exception as exc:
            raise AgentUpgradeError(
                f"{exc}\n  Completed agent upgrades: {', '.join(completed) or 'none'}"
            ) from exc
        completed.append(router.name)
        console.print(f"[green]✓ Router {router.name} runs runtime {runtime_target}.[/green]")
        if router.note and router.method == "rolling HA":
            console.print(f"[yellow]  {router.name}: {router.note}.[/yellow]")
    return completed
