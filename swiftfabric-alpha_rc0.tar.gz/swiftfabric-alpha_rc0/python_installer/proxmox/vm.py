"""Proxmox VM creation and configuration."""

import random
import os
import math
import re
import shlex
import subprocess
from typing import Dict, Any, List, Optional


class ProxmoxVM:
    """VM creation and configuration helper."""

    def __init__(self, client, ssh_user: str = None, ssh_key: str = None):
        """
        Initialize ProxmoxVM.

        Args:
            client: ProxmoxClient instance
        """
        self.client = client
        self.ssh_user = ssh_user
        self.ssh_key = ssh_key

    def upload_image(
        self,
        node: str,
        storage: str,
        filename: str,
        content_type: str = "vztmpl",
        file_path: str = None
    ) -> Dict[str, Any]:
        """
        Upload an image file to Proxmox storage.

        Args:
            node: Target node name
            storage: Target storage name
            filename: Name of the file on the server
            content_type: Proxmox upload content type (iso, vztmpl, or import)
            file_path: Path to local file to upload

        Returns:
            Upload result
        """
        if not file_path or not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        url = f"{self.client.base_url}/nodes/{node}/storage/{storage}/upload"
        headers = self.client._get_auth_header()
        with open(file_path, 'rb') as f:
            response = self.client.session.post(
                url,
                headers=headers,
                data={"content": content_type},
                files={"filename": (filename, f, "application/octet-stream")},
                timeout=(30, 300)
            )

        response.raise_for_status()
        result = response.json()
        upid = result.get("data")
        if isinstance(upid, str) and upid.startswith("UPID:"):
            self.client.wait_for_task(upid, timeout=600)
        return result

    def generate_vmid(self, nodes: List[str]) -> int:
        """
        Generate a unique VM ID.

        Args:
            nodes: List of node names to check for existing VMs

        Returns:
            Unique VM ID (100-9999 range)
        """
        used_ids = set()

        # Check existing VMs on all nodes
        for node in nodes:
            try:
                response = self.client.get(f"/nodes/{node}/qemu")
                vm_list = response.get("data", [])
                for vm in vm_list:
                    if "vmid" in vm:
                        used_ids.add(vm["vmid"])
            except Exception:
                continue

        # Generate a random available ID
        while True:
            vmid = random.randint(100, 9999)
            if vmid not in used_ids:
                return vmid

    def find_unused_vmid(self, nodes: List[str]) -> int:
        """Find an unused VM ID."""
        used_ids = set()

        for node in nodes:
            try:
                response = self.client.get(f"/nodes/{node}/qemu")
                vm_list = response.get("data", [])
                for vm in vm_list:
                    if "vmid" in vm:
                        used_ids.add(vm["vmid"])
            except Exception:
                continue

        # Return first available ID
        for vmid in range(100, 10000):
            if vmid not in used_ids:
                return vmid

        raise ValueError("No available VM IDs found")

    def create_cloudinit_vm(
        self,
        node: str,
        vmid: int,
        name: str,
        cores: int = 2,
        memory: int = 2048,
        disk_size: str = "20G",
        storage: str = "local-lvm",
        net0: str = "virtio,bridge=vmbr0,firewall=1",
        scsihw: str = "virtio-scsi-pci",
        vlan_id: int = None,
        ide2: str = "none,media=cdrom",
        boot: str = "order=ide2;scsi0",
        onboot: bool = True,
        serial0: str = "socket",
        ostype: str = "l26"
    ) -> Dict[str, Any]:
        """
        Create a VM with cloudinit support.

        Args:
            node: Target node name
            vmid: VM ID
            name: VM name
            cores: Number of CPU cores
            memory: Memory in MB
            disk_size: Disk size (e.g., "20G")
            storage: Storage location
            net0: Network interface configuration
            scsihw: SCSI controller type
            ide2: CD-ROM configuration for cloudinit
            boot: Boot order
            onboot: Start VM on boot
            serial0: Serial console

        Returns:
            Creation result
        """
        data = {
            "vmid": vmid,
            "name": name,
            "cores": cores,
            "memory": memory,
            "net0": net0,
            "scsihw": scsihw,
            "ide2": ide2,
            "boot": boot,
            "onboot": int(onboot),
            "serial0": serial0,
            "ostype": ostype,
            "ciupgrade": 0
        }

        # Add disk configuration
        data["scsi0"] = f"{storage}:{disk_size}"

        # Add VLAN tag to network interface if specified
        if vlan_id is not None:
            # Append tag to net0 configuration
            if "tag=" not in net0:
                data["net0"] = f"{net0},tag={vlan_id}"
            else:
                # VLAN already in net0, replace it
                import re
                data["net0"] = re.sub(r'tag=\d+', f'tag={vlan_id}', net0)

        return self.client.post(f"/nodes/{node}/qemu", data=data)

    def configure_cloudinit(
        self,
        node: str,
        vmid: int,
        hostname: str,
        ipconfig: Dict[int, str],
        sshkeys: str = None,
        user: str = "ubuntu",
        password: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Configure cloudinit settings for a VM.

        Args:
            node: Target node name
            vmid: VM ID
            hostname: VM hostname
            ipconfig: IP configuration dict {port: "ip=192.168.1.100/24,gw=192.168.1.1"}
            sshkeys: SSH public keys
            user: Cloudinit username
            password: User password (plaintext)

        Returns:
            Configuration result
        """
        data = {
            "hostname": hostname,
            **{f"ipconfig{i}": config for i, config in ipconfig.items()},
            "user": user
        }

        if sshkeys:
            data["sshkeys"] = sshkeys

        if password:
            data["password"] = password

        result = self.client.configure_vm(node, vmid, **data)
        upid = result.get("data")
        if isinstance(upid, str) and upid.startswith("UPID:"):
            self.client.wait_for_task(upid, timeout=1800)
        return result

    def wait_for_vm_start(self, node: str, vmid: int, timeout: int = 60) -> bool:
        """
        Wait for a VM to start.

        Args:
            node: Target node name
            vmid: VM ID
            timeout: Timeout in seconds

        Returns:
            True if started, False otherwise
        """
        import time

        for _ in range(timeout):
            try:
                status = self.client.get_vm_status(node, vmid)
                if status.get("data", {}).get("status") == "running":
                    return True
            except Exception:
                pass
            time.sleep(1)

        return False

    def _wait_for_task_result(
        self, result: Dict[str, Any], timeout: int = 1800
    ) -> Dict[str, Any]:
        upid = result.get("data")
        if isinstance(upid, str) and upid.startswith("UPID:"):
            self.client.wait_for_task(upid, timeout=timeout)
        return result

    def get_vm_ip(self, node: str, vmid: int) -> str:
        """
        Get VM IP address from QEMU agent.

        Args:
            node: Target node name
            vmid: VM ID

        Returns:
            IP address or empty string if not available
        """
        try:
            response = self.client.get(f"/nodes/{node}/qemu/{vmid}/agent/network-get-interfaces")
            interfaces = response.get("data", {}).get("result", [])

            for interface in interfaces:
                if interface.get("name") == "eth0":
                    for ip in interface.get("ip-addresses", []):
                        if ip.get("ip-address-type") == "ipv4":
                            return ip.get("ip-address", "")

            return ""
        except Exception:
            return ""

    def delete_vm(self, node: str, vmid: int) -> Dict[str, Any]:
        """Delete a VM and its unreferenced disks from Proxmox."""
        return self.client.delete(
            f"/nodes/{node}/qemu/{vmid}",
            params={"purge": 1, "destroy-unreferenced-disks": 1},
        )

    def create_vm_no_disk(
        self,
        node: str,
        vmid: int,
        name: str,
        cores: int = 2,
        memory: int = 2048,
        net0: str = "virtio,bridge=vmbr0,firewall=1",
        scsihw: str = "virtio-scsi-pci",
        ide2: str = "none,media=cdrom",
        boot: str = "order=ide2",
        onboot: bool = True,
        serial0: str = "socket"
    ) -> Dict[str, Any]:
        """
        Create a VM without any disk attached.

        Args:
            node: Target node name
            vmid: VM ID
            name: VM name
            cores: Number of CPU cores
            memory: Memory in MB
            net0: Network interface configuration
            scsihw: SCSI controller type
            ide2: CD-ROM configuration
            boot: Boot order
            onboot: Start VM on boot
            serial0: Serial console

        Returns:
            Creation result
        """
        data = {
            "vmid": vmid,
            "name": name,
            "cores": cores,
            "memory": memory,
            "net0": net0,
            "scsihw": scsihw,
            "ide2": ide2,
            "boot": boot,
            "onboot": int(onboot),
            "serial0": serial0,
            "ciupgrade": 0
        }

        return self._wait_for_task_result(
            self.client.post(f"/nodes/{node}/qemu", data=data)
        )

    def attach_disk_image(
        self,
        node: str,
        vmid: int,
        storage: str,
        source: str,
        interface: str = "scsi0"
    ) -> Dict[str, Any]:
        """
        Attach a disk image to an existing VM.

        Args:
            node: Target node name
            vmid: VM ID
            storage: Storage location
            source: Proxmox volume ID or absolute path of the uploaded image
            interface: Disk interface (scsi0, ide0, virtio0, etc.)

        Returns:
            Configuration result
        """
        data = {
            interface: f"{storage}:0,import-from={source}"
        }

        return self._wait_for_task_result(
            self.client.configure_vm(node, vmid, **data)
        )

    def resize_disk(
        self,
        node: str,
        vmid: int,
        disk: str = "scsi0",
        target_size_gib: int = 100,
    ) -> Dict[str, Any]:
        """Grow a VM disk to at least the requested size through Proxmox."""
        if not re.fullmatch(r"(?:scsi|virtio|sata)\d+", disk):
            raise ValueError(f"Unsupported VM disk interface: {disk}.")
        if target_size_gib <= 0:
            raise ValueError("Target disk size must be positive.")

        config = self.client.get_vm_config(node, vmid).get("data", {})
        disk_config = config.get(disk)
        if not isinstance(disk_config, str):
            raise RuntimeError(f"VM {vmid} on {node} has no configured {disk} disk.")
        size_match = re.search(r"(?:^|,)size=(\d+(?:\.\d+)?)([KMGTP])(?:$|,)", disk_config)
        if not size_match:
            raise RuntimeError(
                f"Proxmox did not report the current size for VM {vmid} {disk}: "
                f"{disk_config}"
            )

        unit_bytes = {
            "K": 1024,
            "M": 1024**2,
            "G": 1024**3,
            "T": 1024**4,
            "P": 1024**5,
        }
        current_bytes = float(size_match.group(1)) * unit_bytes[size_match.group(2)]
        target_bytes = target_size_gib * 1024**3
        if current_bytes >= target_bytes:
            return {
                "resized": False,
                "current_size_bytes": int(current_bytes),
                "target_size_bytes": target_bytes,
            }

        delta_mib = math.ceil((target_bytes - current_bytes) / 1024**2)
        try:
            response = self.client.post(
                f"/nodes/{node}/qemu/{vmid}/resize",
                data={"disk": disk, "size": f"+{delta_mib}M"},
            )
        except Exception as failure:
            if getattr(failure, "status_code", None) != 501:
                raise
            self._resize_disk_over_ssh(node, vmid, disk, delta_mib, failure)
        else:
            upid = response.get("data")
            if isinstance(upid, str) and upid.startswith("UPID:"):
                self.client.wait_for_task(upid, timeout=600)
        return {
            "resized": True,
            "current_size_bytes": int(current_bytes),
            "target_size_bytes": target_bytes,
            "increment_mib": delta_mib,
        }

    def _resize_disk_over_ssh(
        self,
        node: str,
        vmid: int,
        disk: str,
        increment_mib: int,
        api_failure: Exception,
    ) -> None:
        """Use qm when a Proxmox-compatible API omits its resize endpoint."""
        # Deployment orchestration imports ProxmoxVM during package initialization.
        from deployment.ssh import integration_ssh_options

        if (
            not self.ssh_user
            or not self.ssh_key
            or not re.fullmatch(r"[a-z_][a-z0-9_-]*[$]?", self.ssh_user)
            or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]*", node)
        ):
            raise RuntimeError(
                f"{api_failure} The API does not implement disk resize, and "
                "Proxmox SSH fallback is not configured."
            ) from api_failure

        remote_command = "sudo -n qm resize " + " ".join(
            shlex.quote(value)
            for value in (str(vmid), disk, f"+{increment_mib}M")
        )
        try:
            result = subprocess.run(
                [
                    "ssh",
                    "-i",
                    self.ssh_key,
                    "-o",
                    "BatchMode=yes",
                    "-o",
                    "IdentitiesOnly=yes",
                    "-o",
                    "ConnectTimeout=15",
                    "-o",
                    "StrictHostKeyChecking=accept-new",
                    *integration_ssh_options(),
                    f"{self.ssh_user}@{node}",
                    remote_command,
                ],
                capture_output=True,
                text=True,
                timeout=600,
                check=False,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired) as failure:
            raise RuntimeError(
                f"Proxmox API does not implement disk resize and the `qm resize` "
                f"SSH fallback failed to run: {failure}"
            ) from failure
        if result.returncode != 0:
            detail = (result.stderr or result.stdout).strip()
            raise RuntimeError(
                "Proxmox API does not implement disk resize and the `qm resize` "
                f"SSH fallback failed on {node}: {detail or 'unknown error'}"
            ) from api_failure
