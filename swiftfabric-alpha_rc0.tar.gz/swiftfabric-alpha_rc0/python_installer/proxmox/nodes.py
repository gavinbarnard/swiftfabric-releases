"""Proxmox node discovery and management."""

from typing import Dict, Any, List


class ProxmoxNodes:
    """Node discovery and management helper."""

    def __init__(self, client):
        """
        Initialize ProxmoxNodes.

        Args:
            client: ProxmoxClient instance
        """
        self.client = client

    def list_nodes(self) -> List[Dict[str, Any]]:
        """List all available nodes."""
        response = self.client.get_nodes()
        return response.get("data", [])

    def get_node_names(self) -> List[str]:
        """Get list of node names."""
        nodes = self.list_nodes()
        return [node.get("node") for node in nodes if node.get("node")]

    def get_node_info(self, node: str) -> Dict[str, Any]:
        """Get detailed information about a node."""
        response = self.client.get(f"/nodes/{node}")
        return response.get("data", {})

    def get_node_status(self, node: str) -> Dict[str, Any]:
        """Get node status (cpu, memory, disk, etc.)."""
        response = self.client.get(f"/nodes/{node}/status")
        return response.get("data", {})

    def find_available_node(self) -> str:
        """Find the first available node."""
        nodes = self.list_nodes()
        for node in nodes:
            if node.get("node") and node.get("type") == "node":
                return node["node"]
        raise ValueError("No available nodes found")

    def check_node_health(self, node: str) -> bool:
        """Check if a node is healthy."""
        try:
            status = self.get_node_status(node)
            return status.get("status") == "online"
        except Exception:
            return False
