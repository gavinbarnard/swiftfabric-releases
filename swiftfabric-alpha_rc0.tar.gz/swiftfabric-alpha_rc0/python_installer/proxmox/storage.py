"""Proxmox storage discovery and management."""

from typing import Dict, Any, List


class ProxmoxStorage:
    """Storage discovery and management helper."""

    def __init__(self, client):
        """
        Initialize ProxmoxStorage.

        Args:
            client: ProxmoxClient instance
        """
        self.client = client

    def list_storage(self) -> List[Dict[str, Any]]:
        """List all available storage."""
        response = self.client.get_storage()
        return response.get("data", [])

    def get_storage_names(self) -> List[str]:
        """Get list of storage names."""
        storage_list = self.list_storage()
        return [storage.get("storage") for storage in storage_list if storage.get("storage")]

    def get_storage_info(self, storage: str) -> Dict[str, Any]:
        """Get detailed information about a storage."""
        response = self.client.get(f"/storage/{storage}")
        return response.get("data", {})

    def get_node_storage(self, node: str) -> List[Dict[str, Any]]:
        """List storage available on a specific node."""
        response = self.client.get_node_storage(node)
        return response.get("data", [])

    def find_storage_with_capacity(
        self,
        min_capacity_gb: int = 20,
        content_types: List[str] = None
    ) -> Dict[str, Any]:
        """
        Find storage with sufficient capacity.

        Args:
            min_capacity_gb: Minimum required capacity in GB
            content_types: Required content types (e.g., ['vztmpl', 'iso'])

        Returns:
            Storage information or raises ValueError if none found
        """
        storage_list = self.list_storage()

        for storage in storage_list:
            if not storage.get("storage"):
                continue

            # Check content types if specified
            if content_types:
                storage_content = storage.get("content", "")
                if not any(ct in storage_content for ct in content_types):
                    continue

            # Check capacity (available in bytes, convert to GB)
            avail_gb = storage.get("avail", 0) / (1024 ** 3)
            if avail_gb >= min_capacity_gb:
                return storage

        raise ValueError(
            f"No storage found with at least {min_capacity_gb}GB "
            f"and content types {content_types}"
        )

    def is_storage_accessible(self, node: str, storage: str) -> bool:
        """Check if a storage is accessible on a specific node."""
        try:
            node_storage = self.get_node_storage(node)
            return any(s.get("storage") == storage for s in node_storage)
        except Exception:
            return False

    def copy_volume(
        self,
        node: str,
        storage: str,
        source_volid: str,
        dest_volid: str
    ) -> Dict[str, Any]:
        """
        Copy a volume within storage.

        Args:
            node: Target node name
            storage: Storage location
            source_volid: Source volume ID (e.g., "local-lvm:vm-100-disk-0.qcow2")
            dest_volid: Destination volume ID (e.g., "local-lvm:vm-101-disk-0.qcow2")

        Returns:
            Copy result
        """
        data = {
            "storage": storage,
            "source": source_volid,
            "dest": dest_volid
        }

        return self.client.post(f"/nodes/{node}/storage/{storage}/copy", data=data)
