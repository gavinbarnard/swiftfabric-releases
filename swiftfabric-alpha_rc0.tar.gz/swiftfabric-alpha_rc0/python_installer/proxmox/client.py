"""Core Proxmox API client class."""

import requests
import time
from pathlib import Path
from typing import Dict, Any, Optional, Union
from urllib.parse import quote


class ProxmoxAPIError(Exception):
    """Proxmox API request failure with its HTTP status code."""

    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code


class ProxmoxClient:
    """Proxmox API client with authentication."""

    def __init__(
        self,
        host: str,
        port: int = 8006,
        user: str = "root@pam",
        token_name: str = None,
        api_key: str = None,
        verify_ssl: Union[bool, str] = True,
    ):
        """
        Initialize Proxmox API client.

        Args:
            host: Proxmox cluster IP address or hostname
            port: Proxmox API port (default: 8006)
            user: Proxmox user (e.g., root@pam)
            token_name: API token name
            api_key: API token key
            verify_ssl: Verify system CA certificates or use the supplied CA bundle.
        """
        if verify_ssl is False:
            raise ValueError("Proxmox TLS certificate and hostname verification cannot be disabled.")
        if isinstance(verify_ssl, str) and not Path(verify_ssl).is_file():
            raise ValueError("Proxmox TLS CA bundle must point to an existing file.")
        if verify_ssl is not True and not isinstance(verify_ssl, str):
            raise ValueError("Proxmox TLS verification must use system roots or a CA bundle.")

        self.host = host
        self.port = port
        self.base_url = f"https://{host}:{port}/api2/json"
        self.user = user
        self.token_name = token_name
        self.api_key = api_key
        self.verify_ssl = verify_ssl
        self.session = requests.Session()
        self.session.verify = verify_ssl
        self._ticket = None

    def _get_auth_header(self) -> Dict[str, str]:
        """Generate authentication header."""
        if self.token_name and self.api_key:
            return {
                "Authorization": f"PVEAPIToken={self.user}!{self.token_name}={self.api_key}"
            }
        raise ValueError("API token name and key must be provided for authentication")

    def _make_request(
        self,
        method: str,
        endpoint: str,
        params: Dict[str, Any] = None,
        data: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Make a request to the Proxmox API.

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            params: Query parameters
            data: Request body data

        Returns:
            JSON response from API

        Raises:
            requests.exceptions.RequestException: If request fails
        """
        url = f"{self.base_url}{endpoint}"
        headers = self._get_auth_header()

        try:
            response = self.session.request(
                method=method.upper(),
                url=url,
                headers=headers,
                params=params,
                data=data,
                timeout=30
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            details = ""
            response = getattr(e, "response", None)
            if response is not None:
                try:
                    error_data = response.json()
                except ValueError:
                    error_data = {}
                field_errors = error_data.get("errors", {})
                if isinstance(field_errors, dict) and field_errors:
                    details = "; ".join(
                        f"{field}: {message}"
                        for field, message in field_errors.items()
                    )
                elif isinstance(error_data.get("message"), str):
                    details = error_data["message"]
            detail_suffix = f" Details: {details}" if details else ""
            raise ProxmoxAPIError(
                f"Proxmox API error ({method} {endpoint}): {e}.{detail_suffix}",
                status_code=response.status_code if response is not None else None,
            ) from e

    def get(self, endpoint: str, params: Dict[str, Any] = None) -> Dict[str, Any]:
        """Make a GET request."""
        return self._make_request("GET", endpoint, params)

    def post(self, endpoint: str, data: Dict[str, Any] = None) -> Dict[str, Any]:
        """Make a POST request."""
        return self._make_request("POST", endpoint, data=data)

    def delete(self, endpoint: str, params: Dict[str, Any] = None) -> Dict[str, Any]:
        """Make a DELETE request."""
        return self._make_request("DELETE", endpoint, params=params)

    def get_nodes(self) -> Dict[str, Any]:
        """Get list of available nodes."""
        return self.get("/nodes")

    def get_storage(self) -> Dict[str, Any]:
        """Get list of available storage."""
        return self.get("/storage")

    def get_node_storage(self, node: str) -> Dict[str, Any]:
        """Get storage for a specific node."""
        return self.get(f"/nodes/{node}/storage")

    def wait_for_task(self, upid: str, timeout: int = 300) -> Dict[str, Any]:
        """Wait for a Proxmox task to finish and raise if it failed."""
        parts = upid.split(":")
        if len(parts) < 3 or parts[0] != "UPID" or not parts[1]:
            raise ValueError(f"Invalid Proxmox task ID: {upid}")

        node = parts[1]
        endpoint = f"/nodes/{node}/tasks/{quote(upid, safe='')}/status"
        deadline = time.monotonic() + timeout

        while True:
            task = self.get(endpoint).get("data", {})
            if task.get("status") == "stopped":
                if task.get("exitstatus") != "OK":
                    raise RuntimeError(
                        f"Proxmox task failed: {task.get('exitstatus', 'unknown status')}"
                    )
                return task

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError(
                    f"Proxmox task did not finish within {timeout} seconds."
                )
            time.sleep(min(1, remaining))

    def upload_image(
        self,
        node: str,
        storage: str,
        filename: str,
        content_type: str = "vztmpl",
        file_path: str = None,
        file_content: bytes = None
    ) -> Dict[str, Any]:
        """
        Upload an image file to Proxmox storage.

        Args:
            node: Target node name
            storage: Target storage name
            filename: Name of the file on the server
            content_type: Type of content (vztmpl, iso, backup, container)
            file_path: Path to local file (alternative to file_content)
            file_content: Raw bytes of file to upload

        Returns:
            Upload result
        """
        # For now, use a placeholder implementation
        # Actual implementation would use multipart/form-data upload
        data = {
            "filename": filename,
            "content": content_type,
            "storage": storage
        }
        return self.post(f"/nodes/{node}/storage/{storage}/upload", data=data)

    def create_vm(
        self,
        node: str,
        vmid: int,
        name: str,
        cores: int = 2,
        memory: int = 2048,
        disk_size: str = "20G",
        storage: str = "local-lvm",
        net0: str = "virtio,bridge=vmbr0,firewall=1",
        ide0: str = None,
        boot: str = "order=ide0",
        onboot: bool = True
    ) -> Dict[str, Any]:
        """
        Create a new VM.

        Args:
            node: Target node name
            vmid: VM ID (unique)
            name: VM name
            cores: Number of CPU cores
            memory: Memory in MB
            disk_size: Disk size (e.g., "20G")
            storage: Storage location
            net0: Network interface configuration
            ide0: IDE disk configuration (for cloudinit)
            boot: Boot order
            onboot: Start VM on boot

        Returns:
            Creation result
        """
        data = {
            "vmid": vmid,
            "name": name,
            "cores": cores,
            "memory": memory,
            "net0": net0,
            "onboot": int(onboot),
            "boot": boot
        }

        if ide0:
            data["ide0"] = ide0

        # Add disk configuration
        data[f"scsi0"] = f"{storage}:{disk_size}"

        return self.post(f"/nodes/{node}/qemu", data=data)

    def configure_vm(
        self,
        node: str,
        vmid: int,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Configure an existing VM.

        Args:
            node: Target node name
            vmid: VM ID
            **kwargs: Configuration parameters

        Returns:
            Configuration result
        """
        return self.post(f"/nodes/{node}/qemu/{vmid}/config", data=kwargs)

    def start_vm(self, node: str, vmid: int) -> Dict[str, Any]:
        """Start a VM."""
        return self.post(f"/nodes/{node}/qemu/{vmid}/status/start")

    def get_vm_status(self, node: str, vmid: int) -> Dict[str, Any]:
        """Get VM status."""
        return self.get(f"/nodes/{node}/qemu/{vmid}/status/current")

    def get_vm_config(self, node: str, vmid: int) -> Dict[str, Any]:
        """Get VM configuration."""
        return self.get(f"/nodes/{node}/qemu/{vmid}/config")

    def close(self):
        """Close the session."""
        self.session.close()
