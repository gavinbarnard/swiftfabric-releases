"""Argument handling shared by installer and upgrade entry points."""

import re
import sys


def token_arguments(argv=None):
    """Bind dash-prefixed token values without consuming long-option flags."""
    arguments = list(sys.argv[1:] if argv is None else argv)
    result = []
    index = 0
    while index < len(arguments):
        argument = arguments[index]
        if argument == "--token" and index + 1 < len(arguments):
            value = arguments[index + 1]
            # token_urlsafe(48) produces 64 URL-safe characters, possibly "--...".
            generated_token = re.fullmatch(r"[A-Za-z0-9_-]{64}", value) is not None
            if value.startswith("-") and (
                not value.startswith("--") or generated_token
            ):
                result.append(f"--token={value}")
                index += 2
                continue
        result.append(argument)
        index += 1
    return result
