"""Cloudinit image location and management."""

import os
from pathlib import Path
from typing import Dict, Any, Optional


class CloudInitImages:
    """Cloudinit image discovery and management."""

    def __init__(self, base_path: str = None):
        """
        Initialize CloudInitImages.

        Args:
            base_path: Base path to search for images (default: workspace root)
        """
        if base_path is None:
            # Assume we're running from the workspace root
            self.base_path = Path(__file__).parent.parent.parent
        else:
            self.base_path = Path(base_path)

        self.image_dirs = {
            "proxmox": self.base_path / "images" / "generic",
            "azure": self.base_path / "images" / "vhd",
            "gcp": self.base_path / "images" / "gcp"
        }

    def find_image(self, platform: str = "proxmox") -> Optional[Path]:
        """
        Find cloudinit image for a platform.

        Args:
            platform: Platform name (proxmox, azure, gcp)

        Returns:
            Path to image file or None if not found
        """
        image_dir = self.image_dirs.get(platform)
        if not image_dir or not image_dir.exists():
            return None

        disk_images = sorted(
            path
            for pattern in ("*.qcow2", "*.img")
            for path in image_dir.glob(pattern)
        )
        ubuntu_images = [
            image_file for image_file in disk_images
            if "ubuntu" in image_file.name.lower()
        ]
        img_images = [image_file for image_file in disk_images if image_file.suffix == ".img"]
        preferred_images = ubuntu_images or img_images
        if preferred_images:
            return preferred_images[0]

        # Prefer BIOS cloud-init images when multiple Proxmox images are present.
        qcow2_images = [image_file for image_file in disk_images if image_file.suffix == ".qcow2"]
        bios_images = [
            image_file for image_file in qcow2_images
            if "bios" in image_file.name.lower()
        ]
        if bios_images:
            return bios_images[0]
        if qcow2_images:
            return qcow2_images[0]

        # Look for raw images
        for image_file in image_dir.glob("*.raw"):
            return image_file

        # Look for vhd images
        for image_file in image_dir.glob("*.vhd"):
            return image_file

        return None

    def get_image_info(self, platform: str = "proxmox") -> Dict[str, Any]:
        """
        Get information about the cloudinit image.

        Args:
            platform: Platform name

        Returns:
            Image information dict
        """
        image_path = self.find_image(platform)

        if not image_path:
            return {"error": f"No image found for platform: {platform}"}

        return {
            "path": str(image_path),
            "name": image_path.name,
            "size": image_path.stat().st_size,
            "platform": platform
        }

    def list_available_images(self) -> Dict[str, Optional[Path]]:
        """List all available images across platforms."""
        return {
            platform: self.find_image(platform)
            for platform in self.image_dirs.keys()
        }

    def get_default_image_path(self) -> str:
        """Get the default image path for Proxmox."""
        image = self.find_image("proxmox")
        if image:
            return str(image)
        raise FileNotFoundError(
            "No cloudinit disk image found. Please ensure images/generic contains "
            "a .qcow2 or .img image."
        )
