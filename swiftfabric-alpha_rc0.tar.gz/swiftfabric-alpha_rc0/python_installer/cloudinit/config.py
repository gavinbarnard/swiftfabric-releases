"""Cloudinit configuration generation."""

import json
from typing import Dict, Any, Optional


class CloudInitConfig:
    """Generate cloudinit configuration for VMs."""

    def __init__(self):
        """Initialize CloudInitConfig."""
        self.config = {}

    def generate_network_config(
        self,
        vlan_id: int,
        ip_start: str,
        ip_end: str,
        cidr: int,
        interface: str = "eth0"
    ) -> Dict[str, Any]:
        """
        Generate network configuration.

        Args:
            vlan_id: VLAN ID
            ip_start: Starting IP address
            ip_end: Ending IP address
            cidr: CIDR notation
            interface: Network interface name

        Returns:
            Network configuration dict
        """
        # Parse IPs
        start_parts = ip_start.split('.')
        end_parts = ip_end.split('.')

        # Generate IP range
        ips = []
        for i in range(int(start_parts[3]), int(end_parts[3]) + 1):
            ips.append(f"{start_parts[0]}.{start_parts[1]}.{start_parts[2]}.{i}")

        return {
            "version": 2,
            "ethernets": {
                interface: {
                    "dhcp4": False,
                    "addresses": [f"{ip}/{cidr}" for ip in ips],
                    "gateway4": f"{start_parts[0]}.{start_parts[1]}.{start_parts[2]}.1",
                    "nameservers": {
                        "addresses": ["8.8.8.8", "1.1.1.1"]
                    }
                }
            }
        }

    def generate_user_config(
        self,
        username: str = "ubuntu",
        password: Optional[str] = None,
        ssh_keys: list = None,
        ssh_password_auth: bool = True
    ) -> Dict[str, Any]:
        """
        Generate user configuration.

        Args:
            username: Default username
            password: User password (plaintext)
            ssh_keys: List of SSH public keys
            ssh_password_auth: Enable SSH password authentication

        Returns:
            User configuration dict
        """
        users = [
            {
                "name": username,
                "sudo": ["ALL=(ALL) NOPASSWD:ALL"],
                "ssh_authorized_keys": ssh_keys or [],
                "shell": "/bin/bash"
            }
        ]

        if password:
            users[0]["passwd"] = password

        return {
            "chpasswd": {
                "list": [f"{username}:{password}"] if password else [],
                "expire": False
            },
            "ssh_pwauth": ssh_password_auth,
            "users": users
        }

    def generate_vendor_user_data(
        self,
        password: Optional[str] = None,
        dns_ip: str = "8.8.8.8",
        ubuntu_mirror: str = "",
    ) -> str:
        """Generate vendor data with password or key-only SSH authentication."""
        apt_config = ""
        if ubuntu_mirror:
            mirror = json.dumps(ubuntu_mirror)
            apt_config = (
                "apt:\n"
                "  primary:\n"
                "    - arches: [default]\n"
                f"      uri: {mirror}\n"
                "  security:\n"
                "    - arches: [default]\n"
                f"      uri: {mirror}\n"
            )
        password_config = ""
        if password:
            password_config = (
                "disable_root: false\n"
                "ssh_pwauth: true\n"
                "chpasswd:\n"
                "  expire: false\n"
                "  users:\n"
                "    - name: root\n"
                f"      password: {json.dumps(password)}\n"
                "      type: text\n"
                "    - name: ubuntu\n"
                f"      password: {json.dumps(password)}\n"
                "      type: text\n"
            )
        else:
            password_config = "disable_root: true\nssh_pwauth: false\n"

        return (
            "#cloud-config\n"
            f"{password_config}"
            f"{apt_config}"
            "package_update: true\n"
            "packages:\n"
            "  - valkey-server\n"
            "  - nftables\n"
            "  - cloud-guest-utils\n"
            "users:\n"
            "  - default\n"
            "write_files:\n"
            "  - path: /etc/resolv.conf\n"
            "    permissions: '0644'\n"
            "    owner: root:root\n"
            "    content: |\n"
            f"      nameserver {dns_ip}\n"
        )

    def generate_hostname_config(self, hostname: str) -> Dict[str, Any]:
        """
        Generate hostname configuration.

        Args:
            hostname: VM hostname

        Returns:
            Hostname configuration dict
        """
        return {
            "hostname": hostname
        }

    def generate_full_config(
        self,
        hostname: str,
        username: str = "ubuntu",
        password: str = None,
        vlan_id: int = None,
        ip_start: str = None,
        ip_end: str = None,
        cidr: int = 24,
        interface: str = "eth0",
        ssh_keys: list = None
    ) -> Dict[str, Any]:
        """
        Generate complete cloudinit configuration.

        Args:
            hostname: VM hostname
            username: Default username
            password: User password
            vlan_id: VLAN ID (optional)
            ip_start: Starting IP address
            ip_end: Ending IP address
            cidr: CIDR notation
            interface: Network interface name
            ssh_keys: List of SSH public keys

        Returns:
            Complete cloudinit configuration dict
        """
        config = {
            "hostname": hostname,
            "users": [
                {
                    "name": username,
                    "sudo": ["ALL=(ALL) NOPASSWD:ALL"],
                    "ssh_authorized_keys": ssh_keys or [],
                    "shell": "/bin/bash",
                    "passwd": password
                }
            ],
            "chpasswd": {
                "list": [f"{username}:{password}"] if password else [],
                "expire": False
            },
            "ssh_pwauth": True,
            "ssh_authorized_keys": ssh_keys or []
        }

        # Add network configuration if IP info provided
        if vlan_id and ip_start and ip_end:
            config["network"] = {
                "version": 2,
                "ethernets": {
                    interface: {
                        "dhcp4": False,
                        "addresses": [f"{ip}/{cidr}" for ip in self._generate_ip_range(ip_start, ip_end)],
                        "gateway4": f"{ip_start.rsplit('.', 1)[0]}.1",
                        "nameservers": {
                            "addresses": ["8.8.8.8", "1.1.1.1"]
                        }
                    }
                }
            }

        return config

    def _generate_ip_range(self, start: str, end: str) -> list:
        """Generate IP range from start to end."""
        start_parts = start.split('.')
        end_parts = end.split('.')

        ips = []
        for i in range(int(start_parts[3]), int(end_parts[3]) + 1):
            ips.append(f"{start_parts[0]}.{start_parts[1]}.{start_parts[2]}.{i}")

        return ips

    def to_yaml(self, config: Dict[str, Any]) -> str:
        """Convert config dict to YAML format."""
        # Simple YAML conversion
        lines = []

        for key, value in config.items():
            if isinstance(value, dict):
                lines.append(f"{key}:")
                lines.extend(self._dict_to_yaml(value, indent=2))
            elif isinstance(value, list):
                lines.append(f"{key}:")
                for item in value:
                    if isinstance(item, str):
                        lines.append(f"  - {item}")
                    elif isinstance(item, dict):
                        lines.append("  -")
                        lines.extend(self._dict_to_yaml(item, indent=4))
            else:
                lines.append(f"{key}: {value}")

        return "\n".join(lines)

    def _dict_to_yaml(self, data: dict, indent: int = 0) -> list:
        """Convert dict to YAML lines."""
        lines = []
        prefix = " " * indent

        for key, value in data.items():
            if isinstance(value, dict):
                lines.append(f"{prefix}{key}:")
                lines.extend(self._dict_to_yaml(value, indent + 2))
            elif isinstance(value, list):
                lines.append(f"{prefix}{key}:")
                for item in value:
                    if isinstance(item, str):
                        lines.append(f"{prefix}  - {item}")
                    elif isinstance(item, dict):
                        lines.append(f"{prefix}  -")
                        lines.extend(self._dict_to_yaml(item, indent + 4))
            else:
                lines.append(f"{prefix}{key}: {value}")

        return lines
