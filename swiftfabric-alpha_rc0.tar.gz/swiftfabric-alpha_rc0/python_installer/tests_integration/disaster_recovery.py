#!/usr/bin/env python3
"""Opt-in controller-loss recovery test with retained overlapping-tenant workloads."""

import argparse
import concurrent.futures
import fcntl
import hashlib
import importlib
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import shlex
import shutil
import ssl
import stat
import subprocess
import sys
import time
import uuid
from urllib.parse import quote

import requests

sys.path.insert(0, str(Path(__file__).resolve().parent))
from integration_common import ROOT, automated_ssh_tofu, integration_ssh_options, read_config_object
from non_interactive import preflight as install_preflight, run_lifecycle

sys.path.insert(0, str(ROOT / "python_installer"))
from deployment.proxmox_ca import ProxmoxCATrust
from deployment.bootstrap import wait_for_api
from deployment.api_retry import request_with_retry
from deployment.restore import ControllerRestore
from deployment.ssh import SSHCommandRunner
from main import _controller_vip, load_deployment_config
from proxmox.client import ProxmoxAPIError, ProxmoxClient


FORWARDING_SNAPSHOT = """
import json,subprocess,sys
ports=json.loads(sys.argv[1])
def read(args):
    return json.loads(subprocess.check_output(args,text=True))
links=read(['ip','-j','link','show'])
tables=read(['nft','-j','list','tables'])
segments={str(segment):{
    'remote':read(['tc','-j','filter','show','dev','sf-tq'+str(segment),'ingress']),
    'fdb':read(['bridge','-j','fdb','show','br','sf-br'+str(segment)]),
    'ports':{port:read(['tc','-j','filter','show','dev',port,'ingress']) for port in selected}
} for segment,selected in ports.items()}
print(json.dumps({'links':links,'tables':tables,'segments':segments}))
"""
DIAGNOSTIC_CAPTURE_SECONDS = 15
DIAGNOSTIC_CAPTURE_MAX_BYTES = 8 * 1024 * 1024
DIAGNOSTIC_LOG_MAX_BYTES = 1024 * 1024
DIAGNOSTIC_REMOTE_FILES = (
    "capture.pcap", "tcpdump.log", "capture.json",
    "host-agent.log", "journalctl.log", "journal.json",
)
DIAGNOSTIC_PROBE_FIELDS = (
    "plane", "phase", "expected", "source", "destination", "source_node", "destination_node",
    "source_tenant", "destination_tenant", "source_segment", "destination_segment", "gateway",
    "isolation_probe", "protocol", "dns", "source_port", "endpoint_identity", "destination_port",
)


def failure_capture_filter(probes):
    """Build a bounded BPF filter from validated failed probe tuples."""
    clauses = set()
    for probe in probes:
        source = str(ipaddress.IPv4Address(probe["source"]))
        destination = str(ipaddress.IPv4Address(probe["destination"]))
        protocol = probe["protocol"]
        hosts = (
            f"((src host {source} and dst host {destination}) or "
            f"(src host {destination} and dst host {source}))"
        )
        if protocol == "icmp":
            transport = "icmp"
        elif protocol in ("tcp", "udp"):
            ports = (probe["source_port"], probe["destination_port"])
            if any(type(port) is not int or not 1 <= port <= 65535 for port in ports):
                raise ValueError("Diagnostic probe contains an invalid transport port.")
            transport = f"{protocol} and (port {ports[0]} or port {ports[1]})"
        else:
            raise ValueError("Diagnostic probe contains an unsupported transport protocol.")
        clauses.add(f"({hosts} and ({transport}))")
    if not clauses or len(clauses) > 64:
        raise ValueError("Failure capture requires 1-64 distinct probe filters.")
    return " or ".join(sorted(clauses))


def forwarding_blockers(snapshot, expected, node):
    """Check observed kernel readiness; this is not a replacement for traffic acceptance."""
    blockers = []
    links = {link["ifname"]: link for link in snapshot["links"]}
    if any(item.get("table", {}).get("name") == "swiftfabric_guard"
           for item in snapshot["tables"]["nftables"]):
        blockers.append("distributed routing remains fenced")
    for segment_id, guests in expected.items():
        segment = snapshot["segments"][str(segment_id)]
        for guest in guests:
            if guest["node"] == node:
                port = guest["port"]
                if links.get(port, {}).get("master") != f"sf-br{segment_id}":
                    blockers.append(f"segment {segment_id}: VM port {port} is detached")
                if any(rule.get("pref") in (49135, 49136)
                       and rule.get("options", {}).get("actions")
                       for rule in segment["ports"][port]):
                    blockers.append(f"segment {segment_id}: VM port {port} remains fenced")
                continue
            if not any(
                rule.get("options", {}).get("keys", {}).get("dst_mac") == guest["mac"]
                and any(action.get("kind") == "tunnel_key" and action.get("dst_ip") == guest["vtep"]
                        and action.get("key_id") == segment_id
                        for action in rule.get("options", {}).get("actions", []))
                for rule in segment["remote"]
            ):
                blockers.append(f"segment {segment_id}: remote tunnel binding is missing")
            if not any(record.get("mac") == guest["mac"]
                       and record.get("ifname") == f"sf-tp{segment_id}"
                       and record.get("state") == "static" for record in segment["fdb"]):
                blockers.append(f"segment {segment_id}: remote static FDB entry is missing")
    return blockers


def private_write(path, content):
    temporary = path.with_suffix(path.suffix + ".tmp")
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(content if isinstance(content, bytes) else json.dumps(content, indent=2).encode())
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def fingerprint(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def ca_fingerprint(path):
    return hashlib.sha256(ssl.PEM_cert_to_DER_cert(path.read_text(encoding="ascii"))).hexdigest()


def read_passphrase(path, directory):
    path = path.expanduser().absolute()
    if (path == ROOT or ROOT in path.resolve().parents
            or path.resolve() == directory or directory in path.resolve().parents):
        raise ValueError("Keep the passphrase outside the checkout and recovery state directory.")
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, "rb") as stream:
        metadata = os.fstat(stream.fileno())
        if (not stat.S_ISREG(metadata.st_mode) or metadata.st_uid != os.getuid()
                or stat.S_IMODE(metadata.st_mode) & 0o077):
            raise ValueError("Recovery passphrase file must be owner-only and owned by the current user.")
        raw = stream.read(1027)
    if len(raw) > 1026:
        raise ValueError("Recovery passphrase file exceeds 1024 bytes plus line ending.")
    raw = raw.removesuffix(b"\n").removesuffix(b"\r")
    if not 12 <= len(raw) <= 1024 or any(byte < 32 or byte > 126 for byte in raw):
        raise ValueError("Recovery passphrase must contain 12-1024 printable ASCII bytes.")
    return raw.decode("utf-8")


def controller_configuration(configuration):
    return {key: value for key, value in configuration.items() if key != "digest"}


def validate_router_request(request, nodes):
    required = (
        "node", "image_storage", "image_volume", "wan_bridge", "wan_address_cidr",
        "wan_gateway", "vtep_bridge",
    )
    if any(not isinstance(request.get(key), str) or not request[key] for key in required):
        raise ValueError("Router request lacks required image, node, WAN, or VTEP settings.")
    if request["node"] not in nodes:
        raise ValueError("Disposable router must use one of the selected enrolled lab nodes.")
    allowlist = request.get("management_allowlist")
    if not isinstance(allowlist, list) or not 1 <= len(allowlist) <= 128:
        raise ValueError("Router management_allowlist requires 1-128 SSH source IPv4 CIDRs.")
    for cidr in allowlist:
        if not isinstance(cidr, str) or "/" not in cidr:
            raise ValueError("Router management_allowlist entries must be IPv4 CIDRs.")
        try:
            ipaddress.IPv4Network(cidr, strict=False)
        except ValueError as exc:
            raise ValueError("Router management_allowlist entries must be IPv4 CIDRs.") from exc
    if (request.get("deployment_mode", "standalone") != "standalone"
            or request.get("synchronous_ha") or request.get("ha_shared_vtep")
            or any(request.get(key) for key in (
                "wan_ingress_rules", "wan_egress_rules", "inbound_port_mappings",
                "outbound_port_mappings", "masquerade_source_cidrs",
            ))):
        raise ValueError("Recovery test requires a standalone router with empty WAN policy.")
    wan = ipaddress.IPv4Interface(request["wan_address_cidr"])
    gateway = ipaddress.IPv4Address(request["wan_gateway"])
    if wan.ip in (wan.network.network_address, wan.network.broadcast_address) or gateway not in wan.network:
        raise ValueError("Router WAN address and gateway must be usable addresses in the same subnet.")


def controller_inventory(client, prefix):
    resources = client.get("/cluster/resources", params={"type": "vm"})["data"]
    controllers = []
    for index in range(3):
        name = f"{prefix}-swiftfabric-controller-{index}"
        matches = [vm for vm in resources if vm.get("name") == name and vm.get("type") == "qemu"]
        if len(matches) != 1:
            raise RuntimeError(f"Expected exactly one owned controller named {name}.")
        vm = matches[0]
        node, vmid = vm["node"], vm["vmid"]
        if (not isinstance(node, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]*", node)
                or type(vmid) is not int or vmid <= 0):
            raise RuntimeError("Invalid owned controller identity.")
        configuration = client.get(f"/nodes/{node}/qemu/{vmid}/config")["data"]
        if configuration.get("name") != name or "swiftfabric" not in configuration.get("cicustom", ""):
            raise RuntimeError(f"Controller {name} has unexpected cloud-init ownership.")
        controllers.append({
            "node": node, "vmid": vmid, "name": name,
            "configuration": controller_configuration(configuration),
        })
    return controllers


def wait_task(client, response):
    task = response.get("data")
    if not isinstance(task, str) or not task.startswith("UPID:"):
        raise RuntimeError("Proxmox mutation did not return a task identifier.")
    client.wait_for_task(task, timeout=1800)


def delete_owned_controllers(client, prefix, expected):
    """Deliberate fault injection, never the production destroy/unenroll path."""
    if controller_inventory(client, prefix) != expected:
        raise RuntimeError("Controller identity/configuration changed; refusing fault injection.")
    for vm in expected:
        path = f"/nodes/{vm['node']}/qemu/{vm['vmid']}"
        status = client.get(path + "/status/current")["data"]["status"]
        if status != "stopped":
            wait_task(client, client.post(path + "/status/stop"))
        if client.get(path + "/status/current")["data"]["status"] != "stopped":
            raise RuntimeError("Controller did not stop; refusing deletion.")
    for vm in expected:
        path = f"/nodes/{vm['node']}/qemu/{vm['vmid']}"
        if controller_configuration(client.get(path + "/config")["data"]) != vm["configuration"]:
            raise RuntimeError("Stopped controller configuration changed; refusing deletion.")
        wait_task(client, client.delete(path, params={"purge": 1, "destroy-unreferenced-disks": 1}))
    remaining = client.get("/cluster/resources", params={"type": "vm"})["data"]
    if any(vm.get("vmid") in {item["vmid"] for item in expected} for vm in remaining):
        raise RuntimeError("Controller deletion did not remove every recorded VM.")


class ControllerAPI:
    def __init__(self, config, directory):
        self.config = config
        self.directory = directory
        self.ssh = SSHCommandRunner(config["controller_priv_key"], "ubuntu", "disaster recovery test")
        self.session = requests.Session()
        self.session.trust_env = False
        self.base_url = f"https://{_controller_vip(config)}/api/v1"
        self.refresh()

    def refresh(self):
        self.session.close()
        self.session = requests.Session()
        self.session.trust_env = False
        certificate = self.ssh.run(
            self.config["ip_range_start"], "sudo -n cat /etc/swiftfabric/swiftfabric-ca.crt",
        )
        certificate_path = self.directory / "controller-ca.crt"
        private_write(certificate_path, certificate.encode("ascii"))
        token = self.ssh.run(
            self.config["ip_range_start"], "sudo -n cat /etc/swiftfabric/segment-manager.token",
        ).strip()
        if not token or "\n" in token:
            raise RuntimeError("Controller returned an invalid bootstrap credential.")
        self.session.verify = str(certificate_path)
        self.session.headers["Authorization"] = f"Bearer {token}"

    def request(self, method, path, *, body=None, archive=None, passphrase=None):
        headers = {}
        if passphrase is not None:
            headers["X-SwiftFabric-Recovery-Passphrase"] = passphrase
        if archive is not None:
            headers["Content-Type"] = "application/octet-stream"
        response = request_with_retry(
            self.session,
            method, self.base_url + path, json=body, data=archive,
            headers=headers, timeout=(10, 1800),
        )
        if not response.ok:
            raise RuntimeError(f"{method} {path} failed (HTTP {response.status_code}); response body withheld.")
        return response

    def json(self, method, path, body=None):
        response = self.request(method, path, body=body)
        return response.json() if response.content else None

    def close(self):
        self.session.close()


def verify_acceptance(directory):
    acceptance = read_config_object(directory / "acceptance.json")
    results = json.loads((directory / "results.json").read_text())
    api_results = json.loads((directory / "api-results.json").read_text())
    api_count = acceptance.get("api_assertions")
    if (acceptance.get("complete") is not True or acceptance.get("traffic_assertions") != 3240
            or not isinstance(results, list) or len(results) != 3240
            or any(result.get("passed") is not True for result in results)
            or not isinstance(api_results, list) or not api_results
            or type(api_count) is not int or not 0 < api_count <= len(api_results)
            or any(result.get("passed") is not True for result in api_results)):
        raise RuntimeError("Tenancy acceptance requires all 3,240 passing traffic assertions and API checks.")


class RecoveryRun:
    def __init__(self, args):
        self.args = args
        self.directory = args.state
        self.config = load_deployment_config(args.config)
        self.state = {
            "prefix": f"sf-dr-{uuid.uuid4().hex[:20]}", "config": str(args.config),
            "config_sha256": fingerprint(args.config), "status": "incomplete", "stages": [],
        }
        self.api = None
        self.proxmox = None
        self.proxmox_ca = None
        self.lab = None
        self.network_lab = None
        self.lab_lock = None
        self.restorer = ControllerRestore(self.config)

    def save(self):
        private_write(self.directory / "recovery.json", self.state)

    def stage(self, name, operation):
        self.state["current_stage"] = name
        self.save()
        print(f"Recovery integration: {name}", flush=True)
        operation()
        self.state["stages"].append(name)
        self.save()

    def command(self, command, **kwargs):
        name = f"{len(self.state['stages']):02d}-{self.state['current_stage']}.log"
        descriptor = os.open(self.directory / name, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        with os.fdopen(descriptor, "ab") as output:
            return subprocess.run(command, **kwargs, stdout=output, stderr=subprocess.STDOUT)

    def installer(self, *options):
        if fingerprint(self.args.config) != self.state["config_sha256"]:
            raise RuntimeError("Deployment configuration changed during the recovery test.")
        result = self.command([
            str(ROOT / "install.sh"), "--non-interactive", "--config", str(self.args.config),
            "--prefix", self.state["prefix"], *options,
        ], cwd=ROOT, check=False)
        if result.returncode:
            raise RuntimeError(f"Installer failed with exit status {result.returncode}; inspect private stage log.")

    def install(self):
        if fingerprint(self.args.config) != self.state["config_sha256"]:
            raise RuntimeError("Deployment configuration changed before installation.")
        status = run_lifecycle(
            self.args.config, runner=self.command, keep_deployment=True, prefix=self.state["prefix"],
        )
        if status == 130:
            raise KeyboardInterrupt
        if status:
            raise RuntimeError(f"Non-interactive integration test failed with exit status {status}.")
        self.connect_proxmox()
        self.state["controllers"] = controller_inventory(self.proxmox, self.state["prefix"])
        self.api = ControllerAPI(self.config, self.directory)
        self.restorer.capabilities()

    def connect_proxmox(self):
        self.proxmox_ca = ProxmoxCATrust(
            self.config["proxmox_cluster_ip"], self.config["proxmox_ssh_user"], self.config["proxmox_ssh_key"],
        )
        self.proxmox = ProxmoxClient(
            self.config["proxmox_cluster_ip"], self.config["proxmox_port"], self.config["proxmox_user"],
            self.config["proxmox_tokenname"], self.config["proxmox_apikey"], self.proxmox_ca.ca_path,
        )
        self.proxmox_ca.verify_cluster_nodes(self.proxmox)

    def create_router(self):
        request = read_config_object(self.args.router_config)
        validate_router_request(request, self.args.nodes)
        identifier = self.state["prefix"] + "-nsr"
        request.update({
            "id": identifier, "name": identifier, "tenant_id": "default",
            "cluster": self.config["proxmox_cluster_name"],
            "deployment_mode": "standalone", "synchronous_ha": False,
        })
        self.state["router_requested"] = identifier
        self.save()
        router = self.api.json("POST", "/north-south-routers", request)
        self.state["router"] = {key: router.get(key) for key in ("id", "name", "vmid")}
        self.save()
        if router.get("id") != identifier or router.get("name") != identifier:
            raise RuntimeError("Controller returned a different disposable router identity.")
        self.api.json("POST", f"/north-south-routers/{identifier}/deploy")
        deadline = time.monotonic() + 1800
        while time.monotonic() < deadline:
            router = self.api.json("GET", f"/north-south-routers/{identifier}")
            if router.get("id") != identifier or router.get("name") != identifier:
                raise RuntimeError("Disposable router identity changed during deployment.")
            if router.get("status") == "active":
                if type(router.get("vmid")) is not int or router["vmid"] <= 0:
                    raise RuntimeError("Active router has no valid VM identity.")
                self.state["router"] = {key: router[key] for key in ("id", "name", "vmid")}
                return
            if router.get("status") == "failed":
                raise RuntimeError("Disposable router deployment failed; inspect controller status.")
            time.sleep(5)
        raise TimeoutError("Disposable router did not become active within 1800 seconds.")

    def create_lab(self):
        sys.path.insert(0, str(ROOT / "network-lab"))
        self.network_lab = importlib.import_module("lab")
        TenantLab = importlib.import_module("tenancy").TenantLab

        directory = self.directory / "network-lab"
        directory.mkdir(mode=0o700)
        self.lab_lock = os.open(directory / "run.lock", os.O_WRONLY | os.O_CREAT, 0o600)
        fcntl.flock(self.lab_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        private_write(directory / "state.json", {
            "run_id": uuid.uuid4().hex, "config": str(self.args.config),
            "nodes": self.args.nodes, "tenancy": True, "segments": [], "vms": [],
            "router": self.state["router"]["id"], "image_volume": self.args.image_volume,
            "storage": self.args.image_volume.split(":", 1)[0], "dns_address": self.args.dns_address,
            "console_password": secrets.token_urlsafe(32),
            "settle_seconds": self.args.settle_seconds, "results": [], "ready": False,
        })
        self.lab = TenantLab(directory)
        self.lab.select_segments(self.args.first_segment_id, self.args.subnet_start, self.args.supernet)
        self.lab.create()

    def acceptance(self, name):
        if getattr(self.args, "workflow", "recovery") == "recovery":
            self.lab.phase_recovery = self.recover_interrupted_phase
        try:
            self.lab.acceptance_test()
        except self.network_lab.TrafficPhaseFailure:
            failures = [
                result for result in self.lab.state["results"] if not result.get("passed")
            ]
            if getattr(self.args, "capture_failed_traffic", False) and failures:
                try:
                    self.capture_failure_diagnostics(failures)
                except (OSError, RuntimeError, TimeoutError, ValueError) as diagnostic_error:
                    print(
                        f"Failure diagnostics incomplete ({type(diagnostic_error).__name__}): "
                        f"{diagnostic_error}",
                        file=sys.stderr,
                    )
            raise
        verify_acceptance(self.lab.directory)
        destination = self.directory / name
        destination.mkdir(mode=0o700)
        for filename in (
            "acceptance.json", "results.json", "api-results.json", "evidence.json",
            "report-data.json", "report.html",
        ):
            shutil.copyfile(self.lab.directory / filename, destination / filename)
            os.chmod(destination / filename, 0o600)

    def _diagnostic_cases(self, failures):
        phases = {(failure["plane"], failure["phase"]) for failure in failures}
        if len(phases) != 1:
            raise ValueError("Failure diagnostics require one failed traffic phase.")
        plane, phase = next(iter(phases))
        vms = {vm["vmid"]: vm for vm in self.lab.state["vms"]}
        grouped = {}
        probes = []
        for failure in failures:
            source = vms.get(failure.get("source_vmid"))
            if source is None or source["name"] != failure.get("source_vm"):
                raise ValueError("Failed probe source no longer matches an owned lab VM.")
            if failure.get("expected") not in ("allow", "drop"):
                raise ValueError("Failed probe has an invalid expectation.")
            case = {key: failure[key] for key in DIAGNOSTIC_PROBE_FIELDS}
            port = source.get("next_source_port", 20000)
            if type(port) is not int or port > 65000:
                raise ValueError("No fresh source port remains for failure diagnostics.")
            case["source_port"] = port
            source["next_source_port"] = port + 1
            grouped.setdefault(source["vmid"], (source, []))[1].append(case)
            probes.append(case)
        return plane, phase, list(grouped.values()), probes

    @staticmethod
    def _scp_diagnostic_files(ssh, node, remote_directory, filenames, local_directory):
        ssh.ensure_host_key(node)
        command = [
            "scp", "-q", "-i", ssh.private_key,
            "-o", "BatchMode=yes", "-o", "IdentitiesOnly=yes",
            "-o", "ConnectTimeout=5",
            "-o", f"UserKnownHostsFile={ssh.known_hosts_file}",
            "-o", "StrictHostKeyChecking=yes", *integration_ssh_options(),
            *[f"{ssh.username}@{node}:{remote_directory}/{name}" for name in filenames],
            str(local_directory),
        ]
        result = subprocess.run(command, capture_output=True, text=True, timeout=60, check=False)
        if result.returncode:
            detail = (result.stderr or result.stdout or "").strip()[-2000:]
            raise RuntimeError(f"SCP diagnostics from {node} failed (exit {result.returncode}): {detail}")
        copied = {}
        for name in filenames:
            path = local_directory / name
            if not path.is_file():
                raise RuntimeError(f"SCP did not create expected diagnostic file for {node}: {name}")
            os.chmod(path, 0o600)
            copied[name] = path
        return copied

    def _capture_failure_packets(self, ssh, node, packet_filter, remote_directory, local_directory):
        remote_pcap = f"{remote_directory}/capture.pcap"
        remote_log = f"{remote_directory}/tcpdump.log"
        remote_result = f"{remote_directory}/capture.json"
        remote_program = "\n".join((
            "import json, os, subprocess",
            f"pcap = {remote_pcap!r}",
            f"log = {remote_log!r}",
            f"result_path = {remote_result!r}",
            f"packet_filter = {packet_filter!r}",
            f"capture_limit = {DIAGNOSTIC_CAPTURE_MAX_BYTES}",
            f"log_limit = {DIAGNOSTIC_LOG_MAX_BYTES}",
            f"seconds = {DIAGNOSTIC_CAPTURE_SECONDS}",
            "result = {'complete': False}",
            "open(pcap, 'wb').close()",
            "try:",
            "    command = [",
            '        "sudo", "-n", "timeout", "--signal=INT", "--kill-after=5s",',
            '        f"{seconds}s", "tcpdump", "-U", "-nn", "-i", "any", "-s", "256",',
            '        "-c", "5000", "-w", pcap, packet_filter,',
            "    ]",
            "    with open(log, 'wb') as errors:",
            "        try:",
            "            capture = subprocess.run(command, stdout=subprocess.DEVNULL, stderr=errors,",
            "                                     timeout=seconds + 10, check=False)",
            "            result['returncode'] = capture.returncode",
            "        except subprocess.TimeoutExpired:",
            "            result['error'] = 'tcpdump exceeded capture deadline'",
            "    size = os.path.getsize(pcap)",
            "    if size > capture_limit:",
            "        result['error'] = 'pcap exceeded capture size limit'",
            "    elif size < 24:",
            "        result['error'] = 'tcpdump returned incomplete pcap'",
            "    elif result.get('returncode') not in (0, 124):",
            "        result['error'] = f'tcpdump exited {result[\"returncode\"]}'",
            "    result['bytes'] = size",
            "    subprocess.run(['sudo', '-n', 'chown', f'{os.getuid()}:{os.getgid()}', pcap],",
            "                   check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)",
            "    os.chmod(pcap, 0o600)",
            "    if os.path.getsize(log) > log_limit:",
            "        with open(log, 'r+b') as errors:",
            "            errors.truncate(log_limit)",
            "    result['log_bytes'] = os.path.getsize(log)",
            "    result['complete'] = 'error' not in result",
            "except Exception as failure:",
            "    result['error'] = f'{type(failure).__name__}: {failure}'",
            "with open(result_path, 'w', encoding='utf-8') as output:",
            "    json.dump(result, output)",
        ))
        ssh.run(
            node, "python3 -c " + shlex.quote(remote_program),
            timeout=DIAGNOSTIC_CAPTURE_SECONDS + 30,
        )
        files = self._scp_diagnostic_files(
            ssh, node, remote_directory, ("capture.pcap", "tcpdump.log", "capture.json"),
            local_directory,
        )
        capture = json.loads(files["capture.json"].read_text(encoding="utf-8"))
        size = files["capture.pcap"].stat().st_size
        if size > DIAGNOSTIC_CAPTURE_MAX_BYTES:
            raise ValueError(f"Remote packet capture from {node} exceeded its size limit.")
        return {
            "file": f"{node}/capture.pcap",
            "log": f"{node}/tcpdump.log",
            "bytes": size,
            "packets": (
                self.network_lab.pcap_packet_count(files["capture.pcap"])
                if size >= 24 else 0
            ),
            "complete": capture.get("complete") is True,
            "error": capture.get("error"),
        }

    def _collect_failure_host_log(self, ssh, node, remote_directory, local_directory, since, until):
        remote_log = f"{remote_directory}/host-agent.log"
        remote_error = f"{remote_directory}/journalctl.log"
        remote_result = f"{remote_directory}/journal.json"
        remote_program = "\n".join((
            "import json, os, subprocess",
            f"log = {remote_log!r}",
            f"error_log = {remote_error!r}",
            f"result_path = {remote_result!r}",
            f"log_limit = {DIAGNOSTIC_LOG_MAX_BYTES}",
            "command = [",
            '    "sudo", "-n", "journalctl", "-u", "swiftfabric-host-agent",',
            f"    '--since', '@{since}', '--until', '@{until}',",
            "    '--no-pager', '-o', 'short-iso', '-n', '500',",
            "]",
            "with open(log, 'wb') as output, open(error_log, 'wb') as errors:",
            "    result = subprocess.run(command, stdout=output, stderr=errors, check=False)",
            "for path in (log, error_log):",
            "    if os.path.getsize(path) > log_limit:",
            "        with open(path, 'r+b') as output:",
            "            output.truncate(log_limit)",
            "report = {'returncode': result.returncode, 'bytes': os.path.getsize(log)}",
            "with open(result_path, 'w', encoding='utf-8') as output:",
            "    json.dump(report, output)",
        ))
        ssh.run(node, "python3 -c " + shlex.quote(remote_program), timeout=60)
        files = self._scp_diagnostic_files(
            ssh, node, remote_directory,
            ("host-agent.log", "journalctl.log", "journal.json"), local_directory,
        )
        report = json.loads(files["journal.json"].read_text(encoding="utf-8"))
        return {
            "file": f"{node}/host-agent.log",
            "log": f"{node}/journalctl.log",
            "bytes": files["host-agent.log"].stat().st_size,
            "complete": report.get("returncode") == 0,
        }

    @staticmethod
    def _cleanup_remote_diagnostics(ssh, node, remote_directory):
        files = " ".join(shlex.quote(f"{remote_directory}/{name}") for name in DIAGNOSTIC_REMOTE_FILES)
        ssh.run(node, f"rm -f -- {files} && rmdir -- {shlex.quote(remote_directory)}", timeout=30)

    def _replay_failed_probes(self, grouped, plane, phase):
        original_results = list(self.lab.state["results"])
        had_original_output = "assertion_output" in self.lab.state
        original_output = list(self.lab.state.get("assertion_output", []))
        previous_recovery = getattr(self.lab, "phase_recovery", None)
        self.lab.phase_recovery = None
        failure_message = None
        replay_results = []
        try:
            try:
                self.lab.execute_probes(grouped, plane, phase)
            except self.network_lab.TrafficPhaseFailure as failure:
                failure_message = str(failure)
            replay_results = self.lab.state["results"][len(original_results):]
        finally:
            self.lab.state["results"] = original_results
            if had_original_output:
                self.lab.state["assertion_output"] = original_output
            else:
                self.lab.state.pop("assertion_output", None)
            self.lab.phase_recovery = previous_recovery
            self.lab.save()
            private_write(self.lab.directory / "results.json", original_results)
        return {
            "passed": failure_message is None,
            "failure": failure_message,
            "results": replay_results,
        }

    def capture_failure_diagnostics(self, failures):
        directory = self.directory / "failure-diagnostics" / uuid.uuid4().hex
        directory.mkdir(mode=0o700, parents=True, exist_ok=False)
        private_write(directory / "failed-probes.json", failures)
        report = {
            "capture_seconds": DIAGNOSTIC_CAPTURE_SECONDS,
            "started_epoch": time.time(),
            "probe_count": len(failures),
            "captures": {},
            "host_logs": {},
            "errors": [],
        }
        plane, phase, grouped, probes = self._diagnostic_cases(failures)
        nodes = sorted({
            probe[key] for probe in probes for key in ("source_node", "destination_node")
            if probe[key] in self.lab.state["nodes"]
        })
        if not nodes:
            raise ValueError("Failed traffic probes identify no owned lab nodes.")
        packet_filter = failure_capture_filter(probes)
        report.update(plane=plane, phase=phase, nodes=nodes, packet_filter=packet_filter)
        ssh = SSHCommandRunner(
            self.config["proxmox_ssh_key"], self.config["proxmox_ssh_user"],
            "capture failed recovery traffic diagnostics",
        )
        remote_directory = f"/tmp/swiftfabric-recovery-diagnostics-{uuid.uuid4().hex}"
        local_directories = {}
        for node in nodes:
            local = directory / node
            local.mkdir(mode=0o700)
            local_directories[node] = local
            ssh.run(node, f"umask 077 && mkdir -- {shlex.quote(remote_directory)}", timeout=30)
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(nodes)) as executor:
            captures = {
                node: executor.submit(
                    self._capture_failure_packets, ssh, node, packet_filter,
                    remote_directory, local_directories[node],
                )
                for node in nodes
            }
            time.sleep(2)
            try:
                report["replay"] = self._replay_failed_probes(grouped, plane, phase)
            except (OSError, RuntimeError, TimeoutError, ValueError) as replay_error:
                report["errors"].append(
                    f"probe replay ({type(replay_error).__name__}): {replay_error}"
                )
            for node, future in captures.items():
                try:
                    report["captures"][node] = future.result()
                    if not report["captures"][node]["complete"]:
                        report["errors"].append(
                            f"{node} packet capture incomplete: "
                            f"{report['captures'][node].get('error') or 'unknown reason'}"
                        )
                except (OSError, RuntimeError, TimeoutError, ValueError) as capture_error:
                    report["errors"].append(
                        f"{node} packet capture ({type(capture_error).__name__}): {capture_error}"
                    )
        end_epoch = time.time()
        since = int(min(probe["started_epoch"] for probe in failures)) - 60
        until = int(end_epoch) + 1
        for node in nodes:
            try:
                report["host_logs"][node] = self._collect_failure_host_log(
                    ssh, node, remote_directory, local_directories[node], since, until,
                )
                if not report["host_logs"][node]["complete"]:
                    report["errors"].append(f"{node} host-agent journal command failed.")
            except (OSError, RuntimeError, TimeoutError, ValueError) as log_error:
                report["errors"].append(
                    f"{node} host log ({type(log_error).__name__}): {log_error}"
                )
            try:
                self._cleanup_remote_diagnostics(ssh, node, remote_directory)
            except (OSError, RuntimeError, TimeoutError, ValueError) as cleanup_error:
                report["errors"].append(
                    f"{node} temporary-file cleanup ({type(cleanup_error).__name__}): {cleanup_error}"
                )
        report["completed_epoch"] = time.time()
        private_write(directory / "diagnostics.json", report)
        print(f"Failure diagnostics retained at {directory}", flush=True)

    def backup(self, passphrase):
        response = self.api.request("POST", "/backup-restore/backup", body={
            "recovery_passphrase": passphrase, "include_ca_private_key": True,
            "include_external_credentials": True, "installer_config": read_config_object(self.args.config),
        })
        archive = response.content
        if not archive.startswith(b"SWFTBAK1"):
            raise RuntimeError("Backup endpoint did not return a SwiftFabric archive.")
        private_write(self.directory / "backup.sfbak", archive)
        self.state["backup_sha256"] = fingerprint(self.directory / "backup.sfbak")
        report = self.api.request(
            "POST", "/backup-restore/validate", archive=archive, passphrase=passphrase,
        ).json()
        private_write(self.directory / "backup-validation.json", report)
        required = (
            "valid", "product_version_matches", "controller_ips_match", "api_vip_matches",
            "host_agent_payloads_available", "external_credentials_included", "operator_config_included",
            "recovery_credentials_included",
        )
        failed = [key for key in required if report.get(key) is not True]
        if failed:
            raise RuntimeError(
                f"Encrypted backup failed validation gates: {', '.join(failed)}; fault injection forbidden."
            )
        staged = self.restorer.stage(archive, passphrase)
        private_write(self.directory / "backup-staged.json", staged)
        self.state["backup_ca_sha256"] = staged["ca_sha256_fingerprint"]
        self.state["original_ca_der_sha256"] = ca_fingerprint(self.directory / "controller-ca.crt")
        self.state["backup_product_version"] = staged["product_version"]
        self.state["host_identities"] = [
            {key: host.get(key) for key in ("host_id", "cluster", "node", "agent_version")}
            for host in self.api.json("GET", "/hosts")
        ]

    def fault(self):
        verify_acceptance(self.directory / "before")
        if fingerprint(self.directory / "backup.sfbak") != self.state.get("backup_sha256"):
            raise RuntimeError("Verified backup changed; fault injection forbidden.")
        if fingerprint(self.args.config) != self.state["config_sha256"]:
            raise RuntimeError("Deployment configuration changed; fault injection forbidden.")
        if fingerprint(self.state_package) != self.state["package_sha256"]:
            raise RuntimeError("Recovery package changed; fault injection forbidden.")
        delete_owned_controllers(self.proxmox, self.state["prefix"], self.state["controllers"])
        self.api.ssh.forget_host_keys([
            *[str(ipaddress.IPv4Address(self.config["ip_range_start"]) + index)
              for index in range(3)],
            _controller_vip(self.config),
        ])

    def redeploy(self):
        if fingerprint(self.state_package) != self.state["package_sha256"]:
            raise RuntimeError("API package changed; exact-version recovery required.")
        self.installer("--restore-target")
        self.api.refresh()
        self.state["replacement_controllers"] = controller_inventory(self.proxmox, self.state["prefix"])

    def restore(self, passphrase):
        archive_path = self.directory / "backup.sfbak"
        if fingerprint(archive_path) != self.state["backup_sha256"]:
            raise RuntimeError("Backup changed after validation.")
        self.restorer = ControllerRestore(self.config)
        self.restorer.capabilities()
        self.restorer.stage(archive_path.read_bytes(), passphrase)
        if self.restorer.staged[self.restorer.nodes[0]]["ca_sha256_fingerprint"] != self.state["backup_ca_sha256"]:
            raise RuntimeError("Staged recovery CA differs from original validated backup.")
        result = self.restorer.restore()
        private_write(self.directory / "restore.json", result)
        self.api.refresh()
        if ca_fingerprint(self.directory / "controller-ca.crt") != self.state["original_ca_der_sha256"]:
            raise RuntimeError("Recovered controller public CA differs from the original backup CA.")
        version = wait_for_api(self.api.session, self.api.base_url + "/version").json()
        if version.get("version") != self.state["backup_product_version"]:
            raise RuntimeError("Restored cluster version differs from the backup.")
        self.verify_recovered_agents()
        self.lab.api.close()
        self.lab.proxmox.session.close()
        self.lab.proxmox_ca.close()
        self.lab = type(self.lab)(self.lab.directory)
        self.verify_recovered_forwarding()

    def recover_interrupted_phase(self, plane, phase, results, attempt, deadline):
        failed = [result for result in results if not result["passed"]]
        # A security boundary violation is never an inconclusive outage.
        if any(
            result["expected"] != "allow"
            or (
                result["outcome"] != "drop"
                and not (
                    result["outcome"] == "error"
                    and result.get("protocol") == "icmp"
                    and result.get("stage") == "icmp"
                    and re.search(
                        r"\b\d+ packets transmitted,\s*0 received,\s*100% packet loss\b",
                        result.get("detail", ""),
                    )
                )
            )
            for result in failed
        ):
            return False
        start = min(result["started_epoch"] for result in results)
        end = max(result["started_epoch"] + result["elapsed_ms"] / 1000 for result in results)
        ssh = SSHCommandRunner(
            self.config["proxmox_ssh_key"], self.config["proxmox_ssh_user"],
            "confirm API outage interrupted owned traffic phase",
        )
        affected = {result[key] for result in failed for key in ("source_node", "destination_node")}
        affected &= {vm["node"] for vm in self.lab.state["vms"]}
        logs = {}
        interrupted = set()
        for node in sorted(affected):
            raw = ssh.run(
                node, "sudo -n journalctl -u swiftfabric-host-agent"
                f" --since @{int(start) - 1800} --until @{int(end) + 1} --no-pager -o json",
                timeout=60,
            )
            entries = [json.loads(line) for line in raw.splitlines()]
            logs[node] = entries
            unavailable = False
            for entry in entries:
                message = entry.get("MESSAGE", "")
                epoch = int(entry["__REALTIME_TIMESTAMP"]) / 1e6
                if "controller routing recovery complete; validated forwarding guards released" in message:
                    unavailable = False
                elif ("controller routing transport unavailable; forwarding recovery pending" in message
                      and epoch <= end):
                    unavailable = True
                if epoch >= start and unavailable:
                    interrupted.add(node)
            if unavailable:
                interrupted.add(node)
        if not interrupted or any(
            result["source_node"] not in interrupted and result["destination_node"] not in interrupted
            for result in failed
        ):
            return False
        evidence = self.directory / "interrupted-phases"
        evidence.mkdir(mode=0o700, exist_ok=True)
        private_write(evidence / f"{plane}-{phase}-{uuid.uuid4().hex}.json", {
            "inconclusive": True, "reason": "confirmed controller API outage",
            "retry": attempt, "results": results, "agent_logs": logs,
            "interrupted_nodes": sorted(interrupted),
        })
        if time.monotonic() + 60 >= deadline:
            raise TimeoutError("Interrupted traffic phase exhausted its thirty-minute recovery window.")
        print(f"{plane} phase {phase}: confirmed API outage; preserving evidence and recovering.", flush=True)
        time.sleep(60)
        self.verify_recovered_forwarding(deadline=deadline)
        return True

    def verify_recovered_forwarding(self, deadline=None):
        hosts = {host["node"]: host for host in self.api.json("GET", "/hosts")}
        identities = {host["node"]: host for host in self.state["host_identities"]}
        expected = {}
        for vm in self.lab.state["vms"]:
            host = hosts[vm["node"]]
            if any(host.get(key) != value for key, value in identities[vm["node"]].items()):
                raise RuntimeError("Compute identity changed before forwarding recovery.")
            config = self.lab.vm_config(vm)
            fields = dict(part.split("=", 1) for part in config["net0"].split(",") if "=" in part)
            expected.setdefault(vm["segment_id"], []).append({
                "node": vm["node"], "host_id": host["host_id"], "vtep": host["vtep_ip"],
                "mac": fields["virtio"].lower(), "ip": vm["address"],
                "port": f"fwpr{vm['vmid']}p0",
            })
        if len(expected) != 6 or sum(map(len, expected.values())) != 18:
            raise RuntimeError("Forwarding recovery requires the complete owned tenancy lab.")
        ssh = SSHCommandRunner(
            self.config["proxmox_ssh_key"], self.config["proxmox_ssh_user"],
            "verify recovered owned VM forwarding",
        )
        deadline = time.monotonic() + 1800 if deadline is None else deadline
        ready_samples = 0
        report = {"passed": False, "observations": []}
        while time.monotonic() < deadline:
            blockers = []
            for segment_id, guests in expected.items():
                entries = self.api.json("GET", f"/segments/{segment_id}/macs")["entries"]
                catalog = {entry["mac"]: entry for entry in entries}
                for guest in guests:
                    entry = catalog.get(guest["mac"], {})
                    if any(entry.get(key) != guest[value] for key, value in (
                        ("host_id", "host_id"), ("vtep_ip", "vtep"), ("ip", "ip"),
                    )):
                        blockers.append(f"segment {segment_id}: authoritative guest binding not recovered")
            for node in sorted(identities):
                ports = {
                    str(segment_id): [guest["port"] for guest in guests if guest["node"] == node]
                    for segment_id, guests in expected.items()
                }
                snapshot = json.loads(ssh.run(
                    node, "sudo -n python3 -c " + shlex.quote(FORWARDING_SNAPSHOT)
                    + " " + shlex.quote(json.dumps(ports)), timeout=60,
                ))
                blockers.extend(f"{node}: {item}" for item in forwarding_blockers(snapshot, expected, node))
            report["observations"].append({"epoch": time.time(), "blockers": blockers})
            ready_samples = ready_samples + 1 if not blockers else 0
            report["passed"] = ready_samples >= 2
            private_write(self.directory / "forwarding-readiness.json", report)
            if report["passed"]:
                return
            print(f"Recovered forwarding readiness: {len(blockers)} pending checks.", flush=True)
            time.sleep(60)
        raise TimeoutError("Restored agents did not recover authoritative MACs and unfenced kernel forwarding.")

    def verify_recovered_agents(self):
        expected = self.state["host_identities"]
        deadline = time.monotonic() + 1800
        initial = None
        while time.monotonic() < deadline:
            hosts = self.api.json("GET", "/hosts")
            identities = [
                {key: host.get(key) for key in ("host_id", "cluster", "node", "agent_version")}
                for host in hosts
            ]
            if sorted(identities, key=lambda host: host["host_id"]) != sorted(expected, key=lambda host: host["host_id"]):
                raise RuntimeError("Restored compute identities/versions differ from the backed-up deployment.")
            router = self.api.json("GET", f"/north-south-routers/{self.state['router']['id']}/status")
            current = router.get("router", {})
            if any(current.get(key) != value for key, value in self.state["router"].items()):
                raise RuntimeError("Restored NSR no longer identifies the original workload VM.")
            observed = {host["host_id"]: host.get("last_seen_at") for host in hosts}
            observed["nsr:" + current["id"]] = (router.get("agent_health") or {}).get("last_seen_at")
            if hosts and router.get("health") == "healthy" and all(host.get("status") == "enrolled" for host in hosts):
                if initial is None:
                    initial = {
                        identity: value if type(value) is int else 0
                        for identity, value in observed.items()
                    }
                elif all(
                    type(value) is int and value > initial[identity]
                    for identity, value in observed.items()
                ):
                    return
            time.sleep(60)
        raise TimeoutError("Original compute/router agents did not produce fresh recovery heartbeats.")

    def cleanup(self):
        if self.lab is not None:
            self.lab.destroy()
        router_id = self.state.get("router", {}).get("id") or self.state.get("router_requested")
        if router_id:
            routers = self.api.json("GET", "/north-south-routers")
            if (not isinstance(routers, list)
                    or any(not isinstance(router, dict) for router in routers)):
                raise RuntimeError("Controller returned an invalid router inventory; refusing teardown.")
            matches = [router for router in routers if router.get("id") == router_id]
            if len(matches) > 1:
                raise RuntimeError("Router identity is ambiguous; refusing teardown.")
            if matches:
                router = matches[0]
                expected = self.state.get("router", {})
                if (router.get("name") != router_id
                        or any(router.get(key) != value for key, value in expected.items())):
                    raise RuntimeError("Router ownership changed; refusing teardown.")
                self.api.json("DELETE", f"/north-south-routers/{router_id}")
                remaining = self.api.json("GET", "/north-south-routers")
                if not isinstance(remaining, list) or any(item.get("id") == router_id for item in remaining):
                    raise RuntimeError("Disposable router teardown did not complete; refusing host cleanup.")
        name = self.config["proxmox_cluster_name"]
        hosts = self.api.json("GET", "/hosts")
        if (not isinstance(hosts, list)
                or any(not isinstance(host, dict) for host in hosts)):
            raise RuntimeError("Controller returned an invalid host inventory; refusing teardown.")
        if hosts:
            result = self.api.json(
                "POST", f"/proxmox/clusters/{quote(name, safe='')}/cleanup", {"enrolled_only": True},
            )
            results = result.get("results") if isinstance(result, dict) else None
            if (not isinstance(results, list) or any(
                    not isinstance(item, dict) or item.get("result") != "cleaned" or item.get("message")
                    for item in results)):
                raise RuntimeError("Host unenrollment incomplete; controller destruction forbidden.")
        remaining_hosts = self.api.json("GET", "/hosts")
        if not isinstance(remaining_hosts, list) or remaining_hosts:
            raise RuntimeError("Enrolled hosts remain; controller destruction forbidden.")
        clusters = self.api.json("GET", "/proxmox/clusters")
        if (not isinstance(clusters, list)
                or any(not isinstance(cluster, dict) for cluster in clusters)):
            raise RuntimeError("Controller returned an invalid cluster inventory; refusing teardown.")
        if any(cluster.get("name") == name for cluster in clusters):
            self.api.json("DELETE", f"/proxmox/clusters/{quote(name, safe='')}")
        remaining_clusters = self.api.json("GET", "/proxmox/clusters")
        if (not isinstance(remaining_clusters, list)
                or any(not isinstance(cluster, dict) for cluster in remaining_clusters)):
            raise RuntimeError("Controller returned an invalid cluster inventory; refusing teardown.")
        if any(cluster.get("name") == name for cluster in remaining_clusters):
            raise RuntimeError("Cluster registration remains; controller destruction forbidden.")
        self.installer("--destroy", "--yes")

    def print_failure_cleanup_command(self):
        workflow = getattr(self.args, "workflow", "recovery")
        script = "recovery.py" if workflow == "recovery" else "network_tenancy.py"
        command = [
            sys.executable, str(ROOT / "python_installer" / "tests_integration" / script),
            "--cleanup", "--state", str(self.directory),
        ]
        print(
            "After reviewing the failed run, remove its lab, NSR, enrollment, and controllers with:\n"
            + shlex.join(command),
            file=sys.stderr,
        )

    def run(self, passphrase):
        self.state_package = next((ROOT / "packages").glob("swiftfabric-api-service_*_amd64.deb"))
        self.state["package"] = str(self.state_package)
        self.state["package_sha256"] = fingerprint(self.state_package)
        try:
            stages = [
                ("install-and-enroll", self.install), ("create-router", self.create_router),
                ("create-tenancy-lab", self.create_lab), ("baseline", lambda: self.acceptance("before")),
            ]
            if getattr(self.args, "workflow", "recovery") == "recovery":
                stages.extend([
                    ("backup", lambda: self.backup(passphrase)), ("controller-loss", self.fault),
                    ("redeploy", self.redeploy), ("restore", lambda: self.restore(passphrase)),
                    ("revalidate", lambda: self.acceptance("after")),
                ])
            stages.append(("cleanup", self.cleanup))
            for name, operation in stages:
                self.stage(name, operation)
            self.state["status"] = "passed"
        except (Exception, KeyboardInterrupt) as exc:
            self.state["status"] = "interrupted" if isinstance(exc, KeyboardInterrupt) else "failed"
            print(
                f"Recovery test stopped at {self.state['current_stage']}: {type(exc).__name__}. "
                f"Resources and evidence retained at {self.directory}.",
                file=sys.stderr,
            )
            self.print_failure_cleanup_command()
            raise
        finally:
            self.save()
            self.close()

    def close(self):
        if self.api:
            self.api.close()
        if self.lab:
            self.lab.api.close()
            self.lab.proxmox.session.close()
            self.lab.proxmox_ca.close()
        if self.proxmox:
            self.proxmox.session.close()
        if self.proxmox_ca:
            self.proxmox_ca.close()
        if self.lab_lock is not None:
            os.close(self.lab_lock)


def cleanup_saved_run(directory):
    directory = directory.expanduser().resolve()
    if directory == ROOT or ROOT in directory.parents:
        raise ValueError("Cleanup state must be outside the checkout.")
    state = read_config_object(directory / "recovery.json")
    prefix = state.get("prefix")
    config_path = state.get("config")
    if (not isinstance(prefix, str) or not re.fullmatch(r"sf-dr-[0-9a-f]{20}", prefix)
            or not isinstance(config_path, str) or not Path(config_path).is_absolute()):
        raise ValueError("Invalid saved deployment ownership/configuration; refusing cleanup.")
    if fingerprint(Path(config_path)) != state.get("config_sha256"):
        raise ValueError("Deployment configuration changed since this run; refusing cleanup.")
    router = state.get("router", {})
    if (not isinstance(router, dict)
            or state.get("router_requested", prefix + "-nsr") != prefix + "-nsr"
            or (router and (
                router.get("id") != prefix + "-nsr" or router.get("name") != prefix + "-nsr"
                or type(router.get("vmid")) is not int or router["vmid"] <= 0
            ))):
        raise ValueError("Saved NSR does not belong to this run; refusing cleanup.")
    run = RecoveryRun(argparse.Namespace(state=directory, config=Path(config_path)))
    run.state = state
    failed_stage = state.get("current_stage")
    try:
        # Lock saved lab state before opening clients or changing resources.
        lab_directory = directory / "network-lab"
        if lab_directory.exists():
            run.lab_lock = os.open(lab_directory / "run.lock", os.O_WRONLY | os.O_CREAT, 0o600)
            fcntl.flock(run.lab_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            lab_state = read_config_object(lab_directory / "state.json")
            if (lab_state.get("config") != config_path
                    or lab_state.get("router") != prefix + "-nsr"
                    or lab_state.get("tenancy") is not True):
                raise ValueError("Saved lab ownership/configuration differs from this run.")
        run.connect_proxmox()
        controllers = controller_inventory(run.proxmox, prefix)
        expected = state.get("replacement_controllers") or state.get("controllers")
        if expected is not None and controllers != expected:
            raise RuntimeError("Controller ownership/configuration changed; refusing cleanup.")
        run.api = ControllerAPI(run.config, directory)
        if (state.get("original_ca_der_sha256")
                and ca_fingerprint(directory / "controller-ca.crt") != state["original_ca_der_sha256"]):
            raise RuntimeError("Controller CA differs from this run; refusing cleanup.")
        if lab_directory.exists():
            sys.path.insert(0, str(ROOT / "network-lab"))
            run.lab = importlib.import_module("tenancy").TenantLab(lab_directory)
        run.stage("post-failure-cleanup", run.cleanup)
        run.state["cleanup_status"] = "complete"
        print(f"Lab, NSR, enrollment, and controller cleanup completed. Evidence retained: {directory}")
    except (Exception, KeyboardInterrupt) as exc:
        run.state["cleanup_status"] = "incomplete"
        print(
            f"Cleanup stopped ({type(exc).__name__}); remaining resources and evidence retained. "
            "Do not destroy controllers before the NSR and enrollment are removed.",
            file=sys.stderr,
        )
        raise
    finally:
        if failed_stage is not None:
            run.state["current_stage"] = failed_stage
        run.save()
        run.close()


def main(argv=None, *, workflow="recovery"):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--yes", action="store_true", help="authorize permanent loss of this run's controller VMs")
    parser.add_argument("--config", type=Path, default=ROOT / "config.json")
    parser.add_argument("--state", type=Path, required=True, help="new private directory outside the checkout")
    parser.add_argument("--recovery-passphrase-file", type=Path, required=workflow == "recovery")
    parser.add_argument("--router-config", type=Path, required=True, help="disposable standalone NSR creation request")
    parser.add_argument("--nodes", nargs=3, required=True)
    parser.add_argument("--image-volume", required=True)
    parser.add_argument("--dns-address", default="1.1.1.1")
    parser.add_argument("--settle-seconds", type=int, default=35)
    parser.add_argument("--first-segment-id", type=int, default=49100)
    parser.add_argument("--subnet-start", default="10.253.244.0/24")
    parser.add_argument("--supernet", default="10.0.0.0/8")
    parser.add_argument(
        "--capture-failed-traffic", action="store_true",
        help="on traffic failure, capture bounded packet traces and host-agent logs",
    )
    args = parser.parse_args(argv)
    args.workflow = workflow
    if not args.yes:
        parser.error("this destructive live test requires explicit --yes")
    args.config = args.config.expanduser().resolve()
    args.state = args.state.expanduser().resolve()
    if args.state == ROOT or ROOT in args.state.parents or args.state.exists():
        parser.error("--state must be a new directory outside the checkout")
    if (len(set(args.nodes)) != 3 or not all(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]*", n) for n in args.nodes)
            or args.settle_seconds < 30):
        parser.error("select three distinct valid hosts and at least 30 settling seconds")
    try:
        args.dns_address = str(ipaddress.IPv4Address(args.dns_address))
        if ":" not in args.image_volume or not all(args.image_volume.split(":", 1)):
            raise ValueError("--image-volume must identify an existing storage:volume.")
        passphrase = (
            read_passphrase(args.recovery_passphrase_file, args.state)
            if workflow == "recovery" else None
        )
        args.router_config = args.router_config.expanduser().resolve()
        validate_router_request(read_config_object(args.router_config), args.nodes)
        with automated_ssh_tofu():
            install_preflight(args.config)
            config = load_deployment_config(args.config)
            selection = config["auto_enroll_host_list"]
            if selection != "all" and not set(args.nodes).issubset(selection):
                raise ValueError("Every lab node must be selected for automatic enrollment.")
            args.state.mkdir(mode=0o700, parents=True, exist_ok=False)
            RecoveryRun(args).run(passphrase)
    except KeyboardInterrupt:
        return 130
    except (
        OSError, ValueError, RuntimeError, ProxmoxAPIError,
        subprocess.CalledProcessError, requests.RequestException,
    ) as exc:
        print(f"Recovery integration failed: {exc}", file=sys.stderr)
        return 1
    label = "Disaster recovery" if workflow == "recovery" else "Fresh-install tenancy acceptance"
    print(f"{label} and ordered cleanup passed. Evidence: {args.state}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
