#!/usr/bin/env python3
"""Install a fresh disposable deployment, run full tenancy acceptance, and clean up."""

from automation import main


if __name__ == "__main__":
    raise SystemExit(main("tenancy"))
