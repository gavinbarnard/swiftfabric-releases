"""Local configuration for unattended disposable integration workflows."""

import argparse
from pathlib import Path
import sys
import uuid

from integration_common import ROOT, read_config_object
import disaster_recovery


def command_arguments(path, workflow):
    settings = read_config_object(path)
    allowed = {
        "allow_destructive", "config", "router_config", "nodes", "image_volume",
        "state_root", "recovery_passphrase_file", "dns_address",
    }
    if set(settings) - allowed:
        raise ValueError("Unknown integration test settings: " + ", ".join(sorted(set(settings) - allowed)))
    if settings.get("allow_destructive") is not True:
        raise ValueError("Set allow_destructive to true only for an authorized empty disposable target.")
    nodes = settings.get("nodes")
    if not isinstance(nodes, list) or len(nodes) != 3 or any(not isinstance(node, str) for node in nodes):
        raise ValueError("nodes must contain exactly three Proxmox node names.")

    def value(key):
        item = settings.get(key)
        if not isinstance(item, str) or not item.strip():
            raise ValueError(f"Missing or invalid integration setting: {key}")
        return item

    def local_path(key):
        result = Path(value(key)).expanduser()
        return (path.parent / result).resolve() if not result.is_absolute() else result.resolve()

    state_root = local_path("state_root")
    if state_root == ROOT or ROOT in state_root.parents:
        raise ValueError("state_root must be outside the checkout.")
    state = state_root / f"{workflow}-{uuid.uuid4().hex}"
    arguments = [
        "--yes", "--config", str(local_path("config")),
        "--state", str(state), "--router-config", str(local_path("router_config")),
        "--nodes", *nodes, "--image-volume", value("image_volume"),
    ]
    if workflow == "recovery":
        arguments.extend(["--recovery-passphrase-file", str(local_path("recovery_passphrase_file"))])
    if "dns_address" in settings:
        arguments.extend(["--dns-address", value("dns_address")])
    return arguments


def main(workflow, argv=None):
    parser = argparse.ArgumentParser(
        description="Install, run disposable tenancy tests, and clean up; recovery also deletes/restores controllers.",
    )
    parser.add_argument("--test-config", type=Path, default=ROOT / "integration-test.json")
    parser.add_argument(
        "--capture-failed-traffic", action="store_true",
        help="on recovery traffic failure, retain scoped packet captures and host-agent logs",
    )
    parser.add_argument("--cleanup", action="store_true",
                        help="delete a saved run's lab, NSR, enrollment, and controllers after review")
    parser.add_argument("--state", type=Path, help="existing run directory; requires --cleanup")
    args = parser.parse_args(argv)
    if args.cleanup != (args.state is not None):
        parser.error("--cleanup and --state must be supplied together")
    if args.capture_failed_traffic and (workflow != "recovery" or args.cleanup):
        parser.error("--capture-failed-traffic applies only to recovery test runs")
    try:
        if args.cleanup:
            with disaster_recovery.automated_ssh_tofu():
                disaster_recovery.cleanup_saved_run(args.state)
            return 0
        arguments = command_arguments(args.test_config.expanduser().resolve(), workflow)
        if args.capture_failed_traffic:
            arguments.append("--capture-failed-traffic")
    except KeyboardInterrupt:
        return 130
    except (
        OSError, ValueError, RuntimeError, disaster_recovery.ProxmoxAPIError,
        disaster_recovery.subprocess.CalledProcessError,
        disaster_recovery.requests.RequestException,
    ) as failure:
        print(f"Integration {'cleanup' if args.cleanup else 'automation configuration'} failed: {failure}",
              file=sys.stderr)
        return 1
    return disaster_recovery.main(arguments, workflow=workflow)
