#!/usr/bin/env python3
"""Run the full controller-loss disaster-recovery workflow from local test settings."""

from automation import main


if __name__ == "__main__":
    raise SystemExit(main("recovery"))
