"""Shared helpers for the live SwiftFabric installer integration tests."""

import ipaddress
import fcntl
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tempfile
from contextlib import contextmanager
from urllib.parse import quote


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python_installer"))
from proxmox.client import ProxmoxAPIError, ProxmoxClient  # noqa: E402
from deployment.proxmox_ca import ProxmoxCATrust  # noqa: E402
from deployment.ssh import SSHCommandRunner, SSHHostKeyError, integration_ssh_options  # noqa: E402


API_PACKAGE_PATTERN = "swiftfabric-api-service_*_amd64.deb"
EMPTY_TARGET_MESSAGE = (
    "Point the test kit at a system with no SwiftFabric installation active "
    "and no enrolled hosts."
)


@contextmanager
def automated_ssh_tofu():
    """Reset test pins at session boundaries, retaining them throughout the run."""
    directory = Path.home() / ".ssh"
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    path = directory / "swiftfabric-integration-known-hosts"
    variables = {
        "SWIFTFABRIC_INTEGRATION_TOFU": "1",
        "SWIFTFABRIC_INTEGRATION_KNOWN_HOSTS": str(path),
    }
    previous = {name: os.environ.get(name) for name in variables}
    with (directory / "swiftfabric-integration-known-hosts.lock").open("a") as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise ValueError("Another integration test owns the SSH trust session.") from exc
        path.unlink(missing_ok=True)
        path.touch(mode=0o600)
        print("Cleared previous integration SSH keys; starting a new trust session.",
              file=sys.stderr)
        os.environ.update(variables)
        try:
            yield
        finally:
            try:
                path.unlink(missing_ok=True)
                print("Removed integration session SSH keys.", file=sys.stderr)
            finally:
                for name, value in previous.items():
                    if value is None:
                        os.environ.pop(name, None)
                    else:
                        os.environ[name] = value


def management_addresses(config):
    """Return the three controller addresses and API VIP from a test config."""
    start = config.get("mgmt_ip_range_start", config.get("ip_range_start"))
    end = config.get("mgmt_ip_range_end", config.get("ip_range_end"))
    first = ipaddress.IPv4Address(start)
    return [str(first + offset) for offset in range(3)] + [str(ipaddress.IPv4Address(end))]


def forget_stale_controller_host_keys(config, ssh_runner=None):
    """Drop pins left by earlier test controllers once the target is proven empty."""
    if os.environ.get("SWIFTFABRIC_INTEGRATION_KNOWN_HOSTS"):
        return []
    runner = ssh_runner or SSHCommandRunner(None, "ubuntu", "integration host-key cleanup")
    try:
        removed = runner.forget_host_keys(management_addresses(config))
    except SSHHostKeyError as exc:
        raise ValueError(f"Could not remove stale controller SSH host keys: {exc}") from exc
    if removed:
        print(
            "Removed stale SSH host keys for unused test controller addresses: "
            + ", ".join(removed),
            file=sys.stderr,
        )
    return removed


def require_empty_target(config, config_dir, client=None, runner=None):
    """Fail closed on existing deployments or host state, regardless of test prefix."""
    runner = runner or subprocess.run
    owned_client = client is None
    proxmox_ca = None
    try:
        required = (
            "proxmox_cluster_ip", "proxmox_user", "proxmox_tokenname",
            "proxmox_apikey", "proxmox_ssh_user", "proxmox_ssh_key",
        )
        if any(not isinstance(config.get(key), str) or not config[key] for key in required):
            raise ValueError("Proxmox API and SSH access settings are required.")
        key = Path(os.path.expanduser(config["proxmox_ssh_key"]))
        if not key.is_absolute():
            key = config_dir / key
        if not key.is_file():
            raise ValueError("Proxmox SSH private key file is missing.")
        if not re.fullmatch(r"[a-z_][a-z0-9_-]*[$]?", config["proxmox_ssh_user"]):
            raise ValueError("Proxmox SSH user must be a valid Unix account name.")
        addresses = set(management_addresses(config))
        if owned_client:
            proxmox_ca = ProxmoxCATrust(
                config["proxmox_cluster_ip"],
                config["proxmox_ssh_user"],
                str(key),
            )
            client = ProxmoxClient(
                config["proxmox_cluster_ip"], config.get("proxmox_port", 8006),
                config["proxmox_user"], config["proxmox_tokenname"],
                config["proxmox_apikey"],
                verify_ssl=proxmox_ca.ca_path,
            )
            proxmox_ca.verify_cluster_nodes(client)

        def inventory(endpoint):
            response = client.get(endpoint)
            data = response.get("data") if isinstance(response, dict) else None
            if not isinstance(data, list) or any(not isinstance(item, dict) for item in data):
                raise ValueError(f"Invalid Proxmox inventory from {endpoint}.")
            return data

        nodes = inventory("/nodes")
        if not nodes:
            raise ValueError("Proxmox returned no nodes to inspect.")
        node_names = set()
        for node in nodes:
            name = node.get("node")
            if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]*", name):
                raise ValueError("Invalid node name in Proxmox inventory.")
            if node.get("status") != "online":
                raise ValueError(f"Cannot inspect offline Proxmox host {name}.")
            node_names.add(name)
        resources = inventory("/cluster/resources")
        for resource in resources:
            if resource.get("type") not in ("qemu", "lxc"):
                continue
            name = resource.get("name", "")
            if not isinstance(name, str):
                raise ValueError("Invalid VM name in Proxmox inventory.")
            if "swiftfabric" in name.lower() or re.search(r"(?:^|-)controller-[123]$", name):
                raise ValueError(f"Existing SwiftFabric controller/deployment VM: {name}.")
            node = resource.get("node")
            vmid = resource.get("vmid")
            if not isinstance(node, str) or not node or type(vmid) is not int or vmid <= 0:
                raise ValueError("Incomplete VM identity in Proxmox inventory.")
            endpoint = f"/nodes/{quote(node, safe='')}/{resource['type']}/{vmid}/config"
            response = client.get(endpoint)
            vm_config = response.get("data") if isinstance(response, dict) else None
            if not isinstance(vm_config, dict):
                raise ValueError(f"Invalid VM configuration from {endpoint}.")
            if "swiftfabric" in str(vm_config.get("cicustom", "")).lower():
                raise ValueError(f"Existing SwiftFabric deployment VM: {name or vmid}.")
            for field, value in vm_config.items():
                if field.startswith(("ipconfig", "net")) and isinstance(value, str):
                    match = re.search(r"(?:^|,)ip=([^/,]+)", value)
                    if match and match[1] in addresses:
                        raise ValueError(
                            f"VM {name or vmid} already uses test management address {match[1]}."
                        )

        # Root-side inventory also catches VMs hidden by API-token ACLs.
        guest_check = (
            "from pathlib import Path\n"
            "import re\n"
            "root = Path('/etc/pve/nodes')\n"
            "if not root.is_dir():\n"
            "    raise RuntimeError('Proxmox VM configuration directory is missing')\n"
            f"if {{path.name for path in root.iterdir() if path.is_dir()}} != {node_names!r}:\n"
            "    raise RuntimeError('Proxmox node inventory is incomplete or inconsistent')\n"
            "for kind in ('qemu-server', 'lxc'):\n"
            "    for path in root.glob('*/' + kind + '/*.conf'):\n"
            "        text = path.read_text()\n"
            "        names = re.findall(r'^name:\\s*(.*)$', text, re.M)\n"
            "        if ('swiftfabric' in text.lower()\n"
            "                or any(re.search(r'(?:^|-)controller-[123]$', name) for name in names)\n"
            f"                or set(re.findall(r'(?:^|[,\\s])ip=([^/,\\s]+)', text)) & {addresses!r}):\n"
            "            print('existing deployment or occupied management address: ' + str(path))\n"
            "print('SWIFTFABRIC_TARGET_CHECK_COMPLETE')\n"
        )
        remote = (
            "set -eu; "
            "for state_path in /etc/swiftfabric /var/lib/swiftfabric; do "
            "if [ -e \"$state_path\" ]; then "
            "printf 'existing SwiftFabric configuration or state: %s\\n' \"$state_path\"; "
            "find \"$state_path\" -maxdepth 2 -print; exit 0; fi; done; "
            "packages=$(dpkg-query -W -f='${binary:Package} ${db:Status-Status}\\n'); "
            "printf '%s\\n' \"$packages\" "
            "| awk '$1 ~ /^swiftfabric-/ && $2 != \"not-installed\" {print}'; "
            f"python3 -c {shlex.quote(guest_check)}"
        )
        for node in nodes:
            name = node["node"]
            if os.environ.get("SWIFTFABRIC_INTEGRATION_TOFU") == "1":
                SSHCommandRunner(
                    str(key), config["proxmox_ssh_user"], "integration target check",
                ).ensure_host_key(name)
            result = runner(
                [
                    "ssh", "-i", str(key),
                    "-o", "BatchMode=yes", "-o", "IdentitiesOnly=yes",
                    "-o", "ConnectTimeout=5", "-o", "StrictHostKeyChecking=accept-new",
                    *integration_ssh_options(),
                    f"{config['proxmox_ssh_user']}@{name}",
                    remote if config["proxmox_ssh_user"] == "root" else f"sudo -n sh -c {shlex.quote(remote)}",
                ],
                capture_output=True, text=True, timeout=60, check=False,
            )
            if result.returncode != 0:
                raise ValueError(f"Cannot inspect Proxmox host {name} over SSH.")
            if result.stdout.strip() != "SWIFTFABRIC_TARGET_CHECK_COMPLETE":
                details = result.stdout.strip() or result.stderr.strip()
                raise ValueError(
                    f"Proxmox host {name} has an existing SwiftFabric installation, "
                    "enrollment state, or an incomplete safety check."
                    + (f" Remote check output: {details}" if details else "")
                )
    except (OSError, ValueError, ProxmoxAPIError, subprocess.TimeoutExpired) as exc:
        raise ValueError(f"Target safety check failed: {exc} {EMPTY_TARGET_MESSAGE}") from exc
    finally:
        if owned_client and client is not None:
            client.session.close()
        if proxmox_ca is not None:
            proxmox_ca.close()


def validate_package_fingerprint(package, root):
    """Use the package builder's source manifest to reject stale artifacts."""
    python = root / "venv" / "bin" / "python"
    fingerprint = subprocess.run(
        [
            str(python) if python.is_file() else sys.executable,
            str(root / "python_installer" / "build_api_service.py"),
            "--fingerprint",
        ],
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()
    if len(fingerprint) != 64 or any(char not in "0123456789abcdef" for char in fingerprint):
        raise ValueError("Package builder returned an invalid source fingerprint.")
    with tempfile.TemporaryDirectory(prefix="swiftfabric-integration-package-") as directory:
        subprocess.run(
            ["dpkg-deb", "-x", str(package), directory],
            capture_output=True,
            text=True,
            check=True,
        )
        marker = Path(directory) / "usr/share/doc/swiftfabric-api-service/source-fingerprint"
        if not marker.is_file() or marker.read_text(encoding="ascii").strip() != fingerprint:
            raise ValueError(
                "API-service package is stale or lacks a source fingerprint. "
                "Commit intended changes, then run ./build-packages.sh --force "
                "on the configured buildbox before retrying."
            )


def validate_api_package(root, fingerprint_check=None):
    """Require exactly one current API-service package in packages/."""
    packages = list((root / "packages").glob(API_PACKAGE_PATTERN))
    if len(packages) != 1:
        raise ValueError(
            "Expected exactly one SwiftFabric API-service package in "
            f"'{root / 'packages'}'; found {len(packages)}."
        )
    (fingerprint_check or validate_package_fingerprint)(packages[0], root)


def read_config_object(config_path):
    """Read a deployment config file that must contain a JSON object."""
    try:
        with config_path.open(encoding="utf-8") as config_file:
            config = json.load(config_file)
    except OSError as exc:
        raise ValueError(f"Cannot read configuration file '{config_path}': {exc}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"Invalid JSON in configuration file '{config_path}' "
            f"at line {exc.lineno}, column {exc.colno}: {exc.msg}"
        ) from exc
    if not isinstance(config, dict):
        raise ValueError("Configuration file must contain a JSON object.")
    return config


CONTROLLER_CONFIG_PATH = "/etc/swiftfabric/config.json"


def controller_access(config, config_dir):
    """Return (controller IPs, controller private key) from a deployment config."""
    start = config.get("mgmt_ip_range_start", config.get("ip_range_start"))
    key = config.get("mgmt_priv_key", config.get("controller_priv_key"))
    if not isinstance(start, str) or not isinstance(key, str) or not key:
        raise ValueError("Configuration lacks the management range start or controller key.")
    first = ipaddress.IPv4Address(start)
    key_path = Path(os.path.expanduser(key))
    if not key_path.is_absolute():
        key_path = config_dir / key_path
    return [str(first + offset) for offset in range(3)], str(key_path)


def verify_controller_configs(config, config_dir, expected, runner=None):
    """Return problems unless every controller holds a root-only exact copy."""
    if runner is None:
        runner = subprocess.run
    try:
        nodes, key = controller_access(config, config_dir)
    except ValueError as exc:
        return [str(exc)]
    problems = []
    remote = (
        f"sudo cmp -s /dev/stdin {CONTROLLER_CONFIG_PATH} && "
        f"sudo stat -c '%a %U %G' {CONTROLLER_CONFIG_PATH}"
    )
    for node in nodes:
        if os.environ.get("SWIFTFABRIC_INTEGRATION_TOFU") == "1":
            SSHCommandRunner(
                key, "ubuntu", "integration controller config check",
            ).ensure_host_key(node)
        command = [
            "ssh", "-i", key,
            "-o", "BatchMode=yes",
            "-o", "IdentitiesOnly=yes",
            "-o", "ConnectTimeout=5",
            "-o", "StrictHostKeyChecking=accept-new",
            *integration_ssh_options(),
            f"ubuntu@{node}", remote,
        ]
        try:
            result = runner(command, input=expected, capture_output=True, timeout=60, check=False)
        except (OSError, subprocess.TimeoutExpired) as exc:
            problems.append(f"{node}: cannot check {CONTROLLER_CONFIG_PATH}: {exc}")
            continue
        output = result.stdout.decode("utf-8", "replace").strip()
        if result.returncode != 0:
            problems.append(f"{node}: {CONTROLLER_CONFIG_PATH} is missing or differs")
        elif output != "600 root root":
            problems.append(f"{node}: {CONTROLLER_CONFIG_PATH} has mode/owner '{output}'")
    return problems
