#!/usr/bin/env python3
"""Run a disposable non-interactive controller-install, host-enrollment, and destroy test."""

import argparse
from pathlib import Path
import shlex
import subprocess
import sys
import uuid


sys.path.insert(0, str(Path(__file__).resolve().parent))
from integration_common import (  # noqa: E402
    ROOT,
    automated_ssh_tofu,
    forget_stale_controller_host_keys,
    read_config_object,
    require_empty_target,
    validate_api_package,
    validate_package_fingerprint,
    verify_controller_configs,
)


def preflight(config_path, root=ROOT):
    """Reject configurations that cannot exercise automatic host enrollment."""
    config = read_config_object(config_path)

    host_selection = config.get(
        "auto_enroll_host_list",
        config.get("proxmox_auto_enroll_host_list"),
    )
    if not host_selection:
        raise ValueError(
            "Automatic host enrollment is not configured; set "
            "'auto_enroll_host_list' to one or more hosts."
        )

    required_enrollment_fields = (
        "proxmox_cluster_name",
        "vtep_vlan_id",
        "vtep_ip_range_cidr",
        "vtep_mtu",
        "vtep_interface",
    )
    missing = [
        key for key in required_enrollment_fields
        if config.get(key) is None or config.get(key) == ""
    ]
    if missing:
        raise ValueError(
            "Automatic host enrollment requires configured VTEP and cluster "
            f"settings; missing: {', '.join(missing)}."
        )

    validate_api_package(root, validate_package_fingerprint)
    require_empty_target(config, config_path.parent)
    forget_stale_controller_host_keys(config)


def run_lifecycle(
    config_path, root=ROOT, runner=None, verifier=None, *,
    keep_deployment=False, prefix=None,
):
    """Install and enroll, optionally retaining controllers for recovery tests."""
    if runner is None:
        runner = subprocess.run
    if verifier is None:
        verifier = verify_controller_configs
    config_bytes = config_path.read_bytes()

    prefix = prefix or f"sf-it-{uuid.uuid4().hex[:28]}"
    install_command = [
        str(root / "install.sh"),
        "--non-interactive",
        "--config",
        str(config_path),
        "--prefix",
        prefix,
    ]
    destroy_command = [
        str(root / "install.sh"),
        "--destroy",
        "--non-interactive",
        "--config",
        str(config_path),
        "--prefix",
        prefix,
        "--auto-unenroll",
        "--yes",
    ]

    print(f"Starting full install and host-enrollment test ({prefix}).", flush=True)
    install_attempted = False
    install_status = 1
    cleanup_status = 0
    interrupted = False
    problems = []
    try:
        install_attempted = True
        install_status = runner(install_command, cwd=root, check=False).returncode
        if install_status == 0:
            try:
                problems = verifier(
                    read_config_object(config_path), config_path.parent, config_bytes,
                )
            except (OSError, ValueError) as exc:
                problems = [f"cannot check controller config copies: {exc}"]
    except KeyboardInterrupt:
        interrupted = True
        install_status = 130
    finally:
        if install_attempted and not keep_deployment:
            print(f"Removing test deployment ({prefix}).", flush=True)
            try:
                cleanup_status = runner(destroy_command, cwd=root, check=False).returncode
            except KeyboardInterrupt:
                cleanup_status = 130
        elif install_attempted:
            print(
                f"Retained test deployment ({prefix}). Teardown only:\n"
                + shlex.join(destroy_command),
                flush=True,
            )

    if install_status != 0:
        print(f"Install/enrollment failed with exit status {install_status}.", file=sys.stderr)
    for problem in problems:
        print(f"Controller config check failed: {problem}.", file=sys.stderr)
    if cleanup_status != 0:
        print(
            f"Cleanup failed with exit status {cleanup_status}; "
            f"test deployment prefix '{prefix}' may remain.",
            file=sys.stderr,
        )
        print(
            "After resolving the cleanup failure, retry only teardown:\n"
            + shlex.join(destroy_command),
            file=sys.stderr,
        )
    if interrupted:
        return 130
    if install_status != 0:
        return install_status
    if cleanup_status != 0:
        return cleanup_status
    if problems:
        return 1
    if keep_deployment:
        print("Install, host enrollment, and controller config copy passed; deployment retained.")
    else:
        print("Full install, host enrollment, controller config copy, and cleanup passed.")
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--yes",
        action="store_true",
        help="confirm creation of temporary controllers and destructive cleanup",
    )
    parser.add_argument(
        "--keep-deployment",
        action="store_true",
        help="retain the deployment, including on failure; print its teardown command",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=ROOT / "config.json",
        help="deployment configuration (default: config.json in repository root)",
    )
    args = parser.parse_args(argv)
    if not args.yes:
        parser.error("this live integration test requires explicit --yes confirmation")
    config_path = args.config.expanduser().resolve()

    with automated_ssh_tofu():
        try:
            preflight(config_path)
        except (OSError, ValueError, subprocess.CalledProcessError) as exc:
            print(f"Integration test preflight failed: {exc}", file=sys.stderr)
            return 1
        try:
            return run_lifecycle(config_path, keep_deployment=args.keep_deployment)
        except OSError as exc:
            print(f"Integration test could not run installer: {exc}", file=sys.stderr)
            return 1


if __name__ == "__main__":
    raise SystemExit(main())
