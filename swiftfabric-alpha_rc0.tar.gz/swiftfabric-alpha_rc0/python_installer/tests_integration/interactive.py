#!/usr/bin/env python3
"""Run a disposable interactive controller-install and destroy test.

The installer TUI is driven through a pseudo-terminal using answers taken from
an existing deployment config (``config.json`` by default). The config file the
TUI saves is then used, unchanged, for the non-interactive destroy.
"""

import argparse
import errno
import fcntl
import json
import os
from pathlib import Path
import re
import secrets
import select
import shlex
import shutil
import signal
import stat
import struct
import subprocess
import sys
import tempfile
import termios
import time
import uuid


sys.path.insert(0, str(Path(__file__).resolve().parent))
from integration_common import (  # noqa: E402
    ROOT,
    automated_ssh_tofu,
    forget_stale_controller_host_keys,
    read_config_object,
    require_empty_target,
    validate_api_package,
    validate_package_fingerprint,
    verify_controller_configs,
)


DEFAULT_CONTROLLER_NAME = "swiftfabric-controller"
KEY_ALIASES = {
    "mgmt_priv_key": "controller_priv_key",
    "mgmt_pub_key": "controller_pub_key",
    "mgmt_vlan_id": "vlan_id",
    "mgmt_gateway_ip": "gateway_ip",
    "mgmt_dns_ip": "dns_ip",
    "mgmt_cidr": "cidr",
    "mgmt_interface": "interface",
    "ip_range_start": "mgmt_ip_range_start",
    "ip_range_end": "mgmt_ip_range_end",
}
ANSWER_DEFAULTS = {
    "proxmox_port": 8006,
    "vlan_id": 100,
    "cidr": 24,
    "ubuntu_mirror": "http://archive.ubuntu.com/ubuntu",
    "interface": "vmbr0",
    "storage_location": "local-lvm",
    "controller_pub_key": "",
}
REQUIRED_ANSWERS = (
    "proxmox_cluster_ip",
    "proxmox_user",
    "proxmox_tokenname",
    "proxmox_apikey",
    "proxmox_ssh_user",
    "proxmox_ssh_key",
    "controller_priv_key",
    "mgmt_ip_range_start",
    "mgmt_ip_range_end",
    "gateway_ip",
    "dns_ip",
)
# Values the saved config must reproduce from the answers that were typed.
ROUND_TRIP_KEYS = (
    "proxmox_cluster_ip",
    "proxmox_port",
    "proxmox_user",
    "proxmox_tokenname",
    "proxmox_apikey",
    "proxmox_ssh_user",
    "vlan_id",
    "mgmt_ip_range_start",
    "mgmt_ip_range_end",
    "gateway_ip",
    "dns_ip",
    "ubuntu_mirror",
    "cidr",
    "interface",
    "storage_location",
)
SAVE_PROMPT = "Save reusable deployment config to"
FAILURE_MARKERS = ("✗", "Invalid selection", "Passwords do not match")
ANSI_PATTERN = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b\][^\x07]*\x07|\x1b[()][A-Za-z0-9]")


class InteractiveError(RuntimeError):
    """The installer TUI did not behave as the scripted answers expect."""


def normalize_answer_config(config, config_dir):
    """Resolve aliases and defaults into the values typed at each prompt."""
    answers = dict(ANSWER_DEFAULTS)
    for key, value in config.items():
        answers[KEY_ALIASES.get(key, key)] = value
    missing = [
        key for key in REQUIRED_ANSWERS
        if not isinstance(answers.get(key), (str, int)) or answers.get(key) == ""
    ]
    if missing:
        raise ValueError(
            "Configuration cannot answer the interactive installer; missing: "
            f"{', '.join(missing)}."
        )
    vlan = answers["vlan_id"]
    if vlan is not None and (isinstance(vlan, bool) or not isinstance(vlan, int)):
        raise ValueError("'vlan_id' must be null or an integer.")
    for key in ("proxmox_port", "cidr"):
        if isinstance(answers[key], bool) or not isinstance(answers[key], int):
            raise ValueError(f"'{key}' must be an integer.")

    # Match non-interactive resolution: controller keys are relative to the config.
    private_key = Path(os.path.expanduser(answers["controller_priv_key"]))
    if not private_key.is_absolute():
        private_key = config_dir / private_key
    answers["controller_priv_key"] = str(private_key)
    public_key = answers["controller_pub_key"]
    if not public_key:
        public_key = f"{private_key}.pub"
    elif not public_key.lstrip().startswith(("ssh-", "ecdsa-", "sk-")):
        public_path = Path(os.path.expanduser(public_key))
        if not public_path.is_absolute():
            public_path = config_dir / public_path
        public_key = str(public_path)
    answers["controller_pub_key"] = public_key
    answers["ubuntu_mirror"] = str(answers["ubuntu_mirror"]).strip().rstrip("/")
    return answers


def prompt_script(answers, admin_password):
    """Return pre-deployment (prompt label, typed value, is_secret) in TUI order."""
    vlan = answers["vlan_id"]
    return [
        ("Proxmox Cluster IP Address", answers["proxmox_cluster_ip"], False),
        ("Proxmox Port", str(answers["proxmox_port"]), False),
        ("Proxmox User (e.g., root@pam)", answers["proxmox_user"], False),
        ("Proxmox API Token Name", answers["proxmox_tokenname"], False),
        ("Proxmox API Key", answers["proxmox_apikey"], True),
        ("Proxmox SSH User for cloud-init snippets", answers["proxmox_ssh_user"], False),
        ("Path to Proxmox SSH private key", answers["proxmox_ssh_key"], False),
        ("Path to controller SSH private key", answers["controller_priv_key"], False),
        ("Path to matching controller SSH public key", answers["controller_pub_key"], False),
        ("VLAN ID (or 'none' for no VLAN)", "none" if vlan is None else str(vlan), False),
        ("Management pool start", answers["mgmt_ip_range_start"], False),
        ("Management pool end", answers["mgmt_ip_range_end"], False),
        ("Default Gateway IP", answers["gateway_ip"], False),
        ("DNS Server IP", answers["dns_ip"], False),
        ("Ubuntu mirror URL", answers["ubuntu_mirror"], False),
        ("CIDR Notation", str(answers["cidr"]), False),
        ("Network Interface Name", answers["interface"], False),
        ("Storage Location", answers["storage_location"], False),
        ("Ubuntu Account Password", admin_password, True),
        ("Confirm Ubuntu Account Password", admin_password, True),
        ("Do you want to proceed with this configuration?", "y", False),
    ]


def prompt_is_waiting(text, label):
    """Return whether the latest output ends at the input point for label."""
    index = text.rfind(label)
    if index < 0:
        return False
    return re.fullmatch(r"[^\n]*[:?]\s*", text[index + len(label):]) is not None


class PtySession:
    """Minimal expect-style driver for a child process on a pseudo-terminal."""

    echo_off_timeout = 15

    def __init__(self, command, cwd, env=None, output=None):
        self.output = output if output is not None else sys.stdout.buffer
        self.text = ""
        self.exit_status = None
        child_env = dict(os.environ if env is None else env)
        child_env.update({"COLUMNS": "220", "LINES": "60", "NO_COLOR": "1"})
        child_env.setdefault("TERM", "xterm")
        pid, fd = os.forkpty()
        if pid == 0:
            try:
                os.chdir(cwd)
                os.execvpe(command[0], command, child_env)
            finally:
                os._exit(127)
        self.pid = pid
        self.fd = fd
        fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", 60, 220, 0, 0))

    def _read(self, timeout):
        """Read available output; return False at EOF."""
        ready, _, _ = select.select([self.fd], [], [], timeout)
        if not ready:
            return True
        try:
            data = os.read(self.fd, 65536)
        except OSError as exc:
            if exc.errno != errno.EIO:
                raise
            data = b""
        if not data:
            return False
        self.output.write(data)
        self.output.flush()
        text = ANSI_PATTERN.sub("", data.decode("utf-8", "replace")).replace("\r", "")
        self.text += text
        return True

    def expect_prompt(self, label, timeout, check_failures=True):
        deadline = time.monotonic() + timeout
        while True:
            for marker in FAILURE_MARKERS if check_failures else ():
                if marker in self.text:
                    raise InteractiveError(
                        f"Installer reported an error before prompt '{label}'."
                    )
            if prompt_is_waiting(self.text, label):
                return
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise InteractiveError(f"Timed out waiting for prompt '{label}'.")
            if not self._read(min(remaining, 1.0)):
                raise InteractiveError(f"Installer exited before prompt '{label}'.")

    def _wait_for_echo_off(self, label):
        deadline = time.monotonic() + self.echo_off_timeout
        while termios.tcgetattr(self.fd)[3] & termios.ECHO:
            if time.monotonic() >= deadline:
                raise InteractiveError(
                    f"Prompt '{label}' did not disable terminal echo; refusing to "
                    "type a secret that would be displayed."
                )
            self._read(0.05)

    def send(self, label, value, secret=False):
        if secret:
            self._wait_for_echo_off(label)
        self.text = ""
        os.write(self.fd, value.encode("utf-8") + b"\n")

    def wait(self, timeout=None):
        deadline = None if timeout is None else time.monotonic() + timeout
        while self._read(1.0):
            if deadline is not None and time.monotonic() >= deadline:
                raise InteractiveError("Timed out waiting for the installer to finish.")
        return self._reap()

    def _reap(self, blocking=True):
        if self.exit_status is None:
            pid, status = os.waitpid(self.pid, 0 if blocking else os.WNOHANG)
            if pid == 0:
                return None
            self.exit_status = os.waitstatus_to_exitcode(status)
            os.close(self.fd)
        return self.exit_status

    def terminate(self):
        """Stop the installer's whole session, escalating if it ignores SIGINT."""
        if self.exit_status is not None:
            return self.exit_status
        for sig, grace in ((signal.SIGINT, 30), (signal.SIGTERM, 10), (signal.SIGKILL, 5)):
            try:
                os.killpg(self.pid, sig)
            except ProcessLookupError:
                pass
            deadline = time.monotonic() + grace
            while time.monotonic() < deadline:
                try:
                    self._read(0.2)
                except OSError:
                    pass
                if self._reap(blocking=False) is not None:
                    return self.exit_status
        return self._reap()


def drive_install(session, script, saved_config_path, prompt_timeout, install_timeout):
    """Answer the questions, then save the config offered after deployment.

    The installer offers the save after success and also after a deployment
    failure, so errors printed while deploying do not abort the driver.
    """
    for label, value, secret in script:
        session.expect_prompt(label, prompt_timeout)
        session.send(label, value, secret)
    session.expect_prompt(SAVE_PROMPT, install_timeout, check_failures=False)
    session.send(SAVE_PROMPT, str(saved_config_path))
    return session.wait(prompt_timeout)


def verify_saved_config(path, answers, admin_password):
    """Check the TUI-written config is private, password-free, and faithful."""
    problems = []
    try:
        mode = stat.S_IMODE(path.stat().st_mode)
        raw = path.read_text(encoding="utf-8")
        saved = json.loads(raw)
    except (OSError, json.JSONDecodeError) as exc:
        return [f"cannot read saved config '{path}': {exc}"]
    if mode != 0o600:
        problems.append(f"saved config mode is {mode:o}, expected 600")
    if not isinstance(saved, dict):
        return problems + ["saved config is not a JSON object"]
    if saved.get("admin_password") is not None or admin_password in raw:
        problems.append("saved config contains the Ubuntu account password")
    for key in ROUND_TRIP_KEYS:
        if saved.get(key) != answers[key]:
            problems.append(f"saved config '{key}' does not match the answer typed")
    return problems


def preflight(config_path, root=ROOT):
    """Validate scripted answers and the API package before creating VMs."""
    config = read_config_object(config_path)
    answers = normalize_answer_config(config, config_path.parent)
    validate_api_package(root, validate_package_fingerprint)
    require_empty_target(config, config_path.parent)
    forget_stale_controller_host_keys(config)
    return answers


def run_lifecycle(
    config_path,
    answers,
    root=ROOT,
    runner=None,
    session_factory=PtySession,
    prompt_timeout=900,
    install_timeout=4 * 3600,
    verifier=None,
):
    """Install through the TUI, then always destroy using the config it saved."""
    if runner is None:
        runner = subprocess.run
    if verifier is None:
        verifier = verify_controller_configs

    prefix = f"sf-iit-{uuid.uuid4().hex[:27]}"
    workdir = Path(tempfile.mkdtemp(prefix="swiftfabric-interactive-it-"))
    saved_config = workdir / f"config-{prefix}.json"
    admin_password = secrets.token_urlsafe(24)
    script = prompt_script(answers, admin_password)
    install_command = [str(root / "install.sh"), "--prefix", prefix]

    print(f"Starting interactive install test ({prefix}).", flush=True)
    install_status = 1
    install_attempted = False
    interrupted = False
    session = None
    try:
        install_attempted = True
        session = session_factory(install_command, cwd=root)
        install_status = drive_install(
            session, script, saved_config, prompt_timeout, install_timeout,
        )
    except KeyboardInterrupt:
        interrupted = True
        install_status = 130
    except (InteractiveError, OSError) as exc:
        print(f"\nInteractive install failed: {exc}", file=sys.stderr, flush=True)
        install_status = 1
    finally:
        if session is not None and session.exit_status is None:
            session.terminate()

    problems = []
    if install_attempted and saved_config.is_file():
        problems = verify_saved_config(saved_config, answers, admin_password)
        if install_status == 0 and not problems:
            try:
                problems += verifier(
                    read_config_object(saved_config), saved_config.parent,
                    saved_config.read_bytes(),
                )
            except (OSError, ValueError) as exc:
                problems.append(f"cannot check controller config copies: {exc}")
        destroy_config = saved_config
    else:
        if install_attempted:
            problems.append("interactive installer did not save a deployment config")
        # Still sweep anything created under this prefix.
        destroy_config = config_path

    destroy_command = [
        str(root / "install.sh"),
        "--destroy",
        "--non-interactive",
        "--config",
        str(destroy_config),
        "--prefix",
        prefix,
        "--auto-unenroll",
        "--yes",
    ]
    cleanup_status = 0
    if install_attempted:
        print(f"Removing test deployment ({prefix}) using {destroy_config}.", flush=True)
        try:
            cleanup_status = runner(destroy_command, cwd=root, check=False).returncode
        except KeyboardInterrupt:
            cleanup_status = 130

    if install_status != 0:
        print(f"Interactive install failed with exit status {install_status}.", file=sys.stderr)
    for problem in problems:
        print(f"Saved config check failed: {problem}.", file=sys.stderr)
    if cleanup_status != 0:
        print(
            f"Cleanup failed with exit status {cleanup_status}; "
            f"test deployment prefix '{prefix}' may remain.",
            file=sys.stderr,
        )
        print(
            "After resolving the cleanup failure, retry only teardown:\n"
            + shlex.join(destroy_command),
            file=sys.stderr,
        )

    passed = not interrupted and install_status == 0 and not problems and cleanup_status == 0
    if passed:
        shutil.rmtree(workdir, ignore_errors=True)
        print(
            "Interactive install, controller config copy, saved-config destroy, "
            "and cleanup passed."
        )
        return 0
    print(
        f"Kept '{workdir}' for diagnosis; its saved config contains the "
        "Proxmox API token key. Delete it when finished.",
        file=sys.stderr,
    )
    if interrupted:
        return 130
    if install_status != 0:
        return install_status
    if cleanup_status != 0:
        return cleanup_status
    return 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--yes",
        action="store_true",
        help="confirm creation of temporary controllers and destructive cleanup",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=ROOT / "config.json",
        help="config supplying the TUI answers (default: config.json in repository root)",
    )
    parser.add_argument(
        "--prompt-timeout",
        type=int,
        default=900,
        help="seconds to wait for each installer prompt (default: 900)",
    )
    parser.add_argument(
        "--install-timeout",
        type=int,
        default=4 * 3600,
        help="seconds to wait for deployment to reach the save-config prompt (default: 14400)",
    )
    args = parser.parse_args(argv)
    if not args.yes:
        parser.error("this live integration test requires explicit --yes confirmation")
    config_path = args.config.expanduser().resolve()

    with automated_ssh_tofu():
        try:
            answers = preflight(config_path)
        except (OSError, ValueError, subprocess.CalledProcessError) as exc:
            print(f"Integration test preflight failed: {exc}", file=sys.stderr)
            return 1
        try:
            return run_lifecycle(
                config_path,
                answers,
                prompt_timeout=args.prompt_timeout,
                install_timeout=args.install_timeout,
            )
        except OSError as exc:
            print(f"Integration test could not run installer: {exc}", file=sys.stderr)
            return 1


if __name__ == "__main__":
    raise SystemExit(main())
