"""Build the SwiftFabric host-agent Debian package on the configured buildbox."""

import sys
from pathlib import Path

from deployment.api_service import ApiServiceDeployment


def main() -> int:
    if len(sys.argv) != 4:
        print(
            "usage: build_host_agent.py OUTPUT_DIR SOURCE_FINGERPRINT VERSION",
            file=sys.stderr,
        )
        return 2
    output_dir = Path(sys.argv[1])
    fingerprint = sys.argv[2]
    version = sys.argv[3]
    output_dir.mkdir(parents=True, exist_ok=True)
    deployment = ApiServiceDeployment(private_key="")
    package = deployment.build_host_agent(output_dir, fingerprint, version)
    print(f"Built host-agent package on buildbox and copied to {package}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
