"""Configuration collection form using Rich."""

from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich.table import Table
from rich.panel import Panel
from rich.text import Text

console = Console()


class ConfigForm:
    """Interactive form for collecting deployment configuration."""

    def __init__(self):
        self.config = {}
        self.console = Console()
        self.available_options = {}  # Store available options for dynamic prompts

    def _display_options(self, prompt_text: str, options: list, default: str = None) -> str:
        """Display available options and get user input."""
        # Show a preview of options (first 3)
        if len(options) > 3:
            preview = options[:3]
            remaining = len(options) - 3
            self.console.print(f"\n[bold]Available options:[/bold]")
            for i, opt in enumerate(preview):
                marker = " *" if opt == default else ""
                self.console.print(f"  {i+1}. {opt}{marker}")
            self.console.print(f"  ... and {remaining} more")
            self.console.print()
        else:
            self.console.print(f"\n[bold]Available options:[/bold]")
            for i, opt in enumerate(options):
                marker = " *" if opt == default else ""
                self.console.print(f"  {i+1}. {opt}{marker}")
            self.console.print()

        # If there are more than 3 options, show help text
        if len(options) > 3:
            self.console.print("[dim]Type '?' to see all options or enter your selection.[/dim]")
            self.console.print()

        return Prompt.ask(prompt_text)

    def _show_all_options(self, options: list, default: str = None) -> None:
        """Display full list of all available options."""
        table = Table(title="All Available Options")
        table.add_column("#", style="cyan")
        table.add_column("Option", style="magenta")

        for i, opt in enumerate(options):
            marker = " *" if opt == default else ""
            table.add_row(str(i+1), f"{opt}{marker}")

        self.console.print(table)
        self.console.print()

    def _get_selection_from_options(self, prompt_text: str, options: list, default: str = None) -> str:
        """Get user selection from available options with help support."""
        while True:
            # Display preview first
            if len(options) > 3:
                preview = options[:3]
                remaining = len(options) - 3
                self.console.print(f"\n[bold]Available options:[/bold]")
                for i, opt in enumerate(preview):
                    marker = " *" if opt == default else ""
                    self.console.print(f"  {i+1}. {opt}{marker}")
                self.console.print(f"  ... and {remaining} more")
                self.console.print()
                self.console.print("[dim]Type '?' to see all options or enter your selection.[/dim]")
            else:
                self.console.print(f"\n[bold]Available options:[/bold]")
                for i, opt in enumerate(options):
                    marker = " *" if opt == default else ""
                    self.console.print(f"  {i+1}. {opt}{marker}")
                self.console.print()

            user_input = Prompt.ask(prompt_text)

            # Handle help request (strip whitespace)
            if user_input.strip() == "?":
                self._show_all_options(options, default)
                # Loop continues to prompt again
                continue

            # Handle empty input (use default)
            if not user_input.strip():
                return default

            # Try to parse as number or name
            try:
                idx = int(user_input) - 1
                if 0 <= idx < len(options):
                    return options[idx]
            except ValueError:
                pass

            # Check if input matches a name (case-insensitive)
            for opt in options:
                if opt.lower() == user_input.lower():
                    return opt

            self.console.print("[red]Invalid selection. Please try again.[/red]")
            self.console.print()

    def collect_proxmox_config(self, require_ssh: bool = True) -> dict:
        """Collect Proxmox cluster configuration."""
        self.console.print(Panel(
            "[bold blue]Proxmox Cluster Configuration[/bold blue]",
            title="Step 1/2",
            border_style="blue"
        ))

        self.config["proxmox_cluster_ip"] = Prompt.ask(
            "Proxmox Cluster IP Address",
            default="192.168.1.100"
        )

        self.config["proxmox_port"] = int(Prompt.ask(
            "Proxmox Port",
            default="8006"
        ))

        self.config["proxmox_user"] = Prompt.ask(
            "Proxmox User (e.g., root@pam)",
            default="root@pam"
        )

        self.config["proxmox_tokenname"] = Prompt.ask(
            "Proxmox API Token Name",
            default="swiftinstaller"
        )

        self.config["proxmox_apikey"] = Prompt.ask(
            "Proxmox API Key",
            password=True
        )

        if require_ssh:
            self.config["proxmox_ssh_user"] = Prompt.ask(
                "Proxmox SSH User for cloud-init snippets",
                default="root"
            )
            self.config["proxmox_ssh_key"] = Prompt.ask(
                "Path to Proxmox SSH private key",
                default="~/.ssh/id_ed25519"
            )

        return self.config

    def collect_controller_ssh_config(self) -> dict:
        """Collect the guest controller's public and private SSH key paths."""
        self.console.print(Panel(
            "[bold blue]Controller SSH Configuration[/bold blue]",
            title="Controller access",
            border_style="blue",
        ))
        private_key = Prompt.ask(
            "Path to controller SSH private key",
            default="~/.ssh/controller",
        )
        public_key = Prompt.ask(
            "Path to matching controller SSH public key",
            default=f"{private_key}.pub",
        )
        self.config["controller_priv_key"] = private_key
        self.config["controller_pub_key"] = public_key
        return self.config

    def collect_network_config(self) -> dict:
        """Collect network configuration."""
        self.console.print(Panel(
            "[bold blue]Network Configuration[/bold blue]",
            title="Step 2/2",
            border_style="blue"
        ))

        vlan_input = Prompt.ask(
            "VLAN ID (or 'none' for no VLAN)",
            default="100"
        )
        if vlan_input.lower() == "none" or vlan_input.strip() == "":
            self.config["vlan_id"] = None
        else:
            self.config["vlan_id"] = int(vlan_input)

        self.config["mgmt_ip_range_start"] = Prompt.ask(
            "Management pool start (first three IPs are controllers; fourth is the fixed VIP)",
            default="172.16.255.50"
        )

        self.config["mgmt_ip_range_end"] = Prompt.ask(
            "Management pool end (remaining IPs are reserved for edge VMs)",
            default="172.16.255.80"
        )
        self.config["ip_range_start"] = self.config["mgmt_ip_range_start"]
        self.config["ip_range_end"] = self.config["mgmt_ip_range_end"]

        self.config["gateway_ip"] = Prompt.ask(
            "Default Gateway IP",
            default="172.16.255.1"
        )

        self.config["dns_ip"] = Prompt.ask(
            "DNS Server IP",
            default="8.8.8.8"
        )

        self.config["ubuntu_mirror"] = Prompt.ask(
            "Ubuntu mirror URL",
            default=self.config.get("ubuntu_mirror")
            or "http://archive.ubuntu.com/ubuntu"
        ).strip().rstrip("/")

        self.config["cidr"] = int(Prompt.ask(
            "CIDR Notation",
            default="24"
        ))

        # Get available interfaces if provided, otherwise use default prompt
        if "available_interfaces" in self.available_options:
            options = self.available_options["available_interfaces"]
            self.config["interface"] = self._get_selection_from_options(
                "Network Interface Name",
                options,
                default="vmbr0"
            )
        else:
            self.config["interface"] = Prompt.ask(
                "Network Interface Name",
                default="vmbr0"
            )

        return self.config

    def collect_storage_config(self) -> dict:
        """Collect storage configuration."""
        self.console.print(Panel(
            "[bold blue]Storage Configuration[/bold blue]",
            title="Step 3/3",
            border_style="blue"
        ))

        # Get available storage if provided, otherwise use default prompt
        if "available_storage" in self.available_options:
            options = self.available_options["available_storage"]
            self.config["storage_location"] = self._get_selection_from_options(
                "Storage Location",
                options,
                default="local-lvm"
            )
        else:
            self.config["storage_location"] = Prompt.ask(
                "Storage Location",
                default="local-lvm"
            )

        # Fixed defaults - no need to ask for these
        self.config["vm_memory"] = 8192
        self.config["vm_cores"] = 4

        return self.config

    def collect_admin_password(self) -> dict:
        """Collect the Ubuntu account password for cloud-init."""
        self.console.print(Panel(
            "[bold blue]Ubuntu Account Configuration[/bold blue]",
            title="Step 4/4",
            border_style="blue"
        ))

        # Prompt for password twice to ensure it's entered correctly
        password1 = Prompt.ask(
            "Ubuntu Account Password",
            password=True
        )
        password2 = Prompt.ask(
            "Confirm Ubuntu Account Password",
            password=True
        )

        if password1 != password2:
            self.console.print("[red]✗ Passwords do not match. Please try again.[/red]")
            return self.collect_admin_password()

        self.config["admin_password"] = password1


        return self.config

    def show_summary(self) -> bool:
        """Display configuration summary and ask for confirmation."""
        table = Table(title="Deployment Configuration Summary")

        table.add_column("Setting", style="cyan")
        table.add_column("Value", style="magenta")

        summary_items = [
            ("Deployment API", self.config.get("deploy_api", "proxmox")),
            ("Proxmox Cluster IP", self.config.get("proxmox_cluster_ip", "N/A")),
            ("Proxmox Port", str(self.config.get("proxmox_port", "N/A"))),
            ("Proxmox User", self.config.get("proxmox_user", "N/A")),
            ("Proxmox Token Name", self.config.get("proxmox_tokenname", "N/A")),
            ("Proxmox SSH User", self.config.get("proxmox_ssh_user", "N/A")),
            ("Proxmox SSH Key", "configured" if self.config.get("proxmox_ssh_key") else "N/A"),
            ("Controller SSH Key", "configured" if self.config.get("controller_priv_key") else "N/A"),
            ("Controller Public Key", "configured" if self.config.get("controller_pub_key") else "N/A"),
            ("VLAN ID", "none" if self.config.get("vlan_id") is None else str(self.config.get("vlan_id", "N/A"))),
            ("Management pool", f"{self.config.get('ip_range_start', 'N/A')} - {self.config.get('ip_range_end', 'N/A')}"),
            ("Default Gateway", self.config.get("gateway_ip", "N/A")),
            ("DNS Server", self.config.get("dns_ip", "N/A")),
            ("Ubuntu Mirror", self.config.get("ubuntu_mirror", "N/A")),
            ("CIDR", f"/{self.config.get('cidr', 'N/A')}"),
            ("Interface", self.config.get("interface", "N/A")),
            ("Storage Location", self.config.get("storage_location", "N/A")),
            ("VM Memory", "8192 MB (fixed)"),
            ("VM Cores", "4 (fixed)"),
        ]

        for label, value in summary_items:
            table.add_row(label, value)

        self.console.print(table)
        self.console.print()

        return Confirm.ask(
            "[bold]Do you want to proceed with this configuration?[/bold]",
            default=True
        )
