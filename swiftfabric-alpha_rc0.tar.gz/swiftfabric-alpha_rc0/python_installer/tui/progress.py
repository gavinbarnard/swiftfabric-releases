"""Progress indicators for deployment stages."""

from rich.console import Console
from rich.progress import Progress, TaskID, SpinnerColumn, TextColumn, BarColumn, TimeRemainingColumn
from rich.panel import Panel
from rich.text import Text

console = Console()


class ProgressIndicator:
    """Progress tracking for deployment operations."""

    def __init__(self):
        self.console = console
        self.progress = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TimeRemainingColumn(),
            console=console,
            transient=True
        )
        self.tasks = {}

    def __enter__(self):
        self.progress.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.progress.stop()

    def create_task(self, description: str) -> TaskID:
        """Create a new progress task."""
        task_id = self.progress.add_task(description, total=None)
        self.tasks[description] = task_id
        return task_id

    def update_task(self, task_id: TaskID, description: str = None, completed: int = None):
        """Update a progress task."""
        if description:
            self.progress.update(task_id, description=description)
        if completed is not None:
            self.progress.update(task_id, completed=completed)

    def complete_task(self, task_id: TaskID, message: str = None):
        """Mark a task as complete."""
        self.progress.update(task_id, completed=self.progress.tasks[task_id].total or 100)
        if message:
            self.console.print(Panel(
                f"[green]{message}[/green]",
                border_style="green"
            ))

    def print_step(self, step: int, total: int, description: str):
        """Print a step indicator."""
        console.print()
        console.print(Panel(
            f"[bold blue]Step {step}/{total}:[/bold blue] {description}",
            border_style="blue"
        ))

    def show_success(self, message: str):
        """Show a success message."""
        self.console.print(Panel(
            f"[green]{message}[/green]",
            border_style="green",
            title="Success",
            title_align="left"
        ))

    def show_error(self, message: str):
        """Show an error message."""
        self.console.print(Panel(
            f"[red]{message}[/red]",
            border_style="red",
            title="Error",
            title_align="left"
        ))
