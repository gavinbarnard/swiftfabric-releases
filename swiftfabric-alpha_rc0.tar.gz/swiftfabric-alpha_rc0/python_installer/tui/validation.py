"""Input validation helpers."""

import re
from typing import Optional


class InputValidator:
    """Validation helpers for user input."""

    @staticmethod
    def is_valid_ip(ip: str) -> bool:
        """Validate IPv4 address."""
        pattern = r'^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$'
        match = re.match(pattern, ip)
        if not match:
            return False
        return all(0 <= int(group) <= 255 for group in match.groups())

    @staticmethod
    def is_valid_port(port: int) -> bool:
        """Validate port number."""
        return 1 <= port <= 65535

    @staticmethod
    def is_valid_cidr(cidr: int) -> bool:
        """Validate CIDR notation."""
        return 0 <= cidr <= 32

    @staticmethod
    def is_valid_hostname(hostname: str) -> bool:
        """Validate hostname."""
        if len(hostname) > 253:
            return False
        pattern = r'^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$'
        return bool(re.match(pattern, hostname))

    @staticmethod
    def is_valid_interface(interface: str) -> bool:
        """Validate network interface name."""
        pattern = r'^[a-zA-Z0-9\-]+$'
        return bool(re.match(pattern, interface))

    @staticmethod
    def validate_ip_range(start: str, end: str) -> bool:
        """Validate IP range."""
        # Extract the first 3 octets from start IP
        start_parts = start.split('.')
        if len(start_parts) != 4:
            return False

        # Check that end IP has same first 3 octets
        end_parts = end.split('.')
        if len(end_parts) != 4:
            return False

        return start_parts[:3] == end_parts[:3]

    @staticmethod
    def validate_api_key(api_key: str) -> bool:
        """Validate API key format (UUID)."""
        pattern = r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
        return bool(re.match(pattern, api_key, re.IGNORECASE))

    @staticmethod
    def get_input_with_validation(
        prompt: str,
        validator,
        error_message: str,
        default: Optional[str] = None,
        password: bool = False
    ) -> str:
        """Get input with validation."""
        from rich.prompt import Prompt

        while True:
            if password:
                value = Prompt.ask(prompt, password=True)
            else:
                value = Prompt.ask(prompt, default=default)

            if not value and default:
                return default

            if validator(value):
                return value

            print(error_message)


def validate_ip_range(start: str, end: str) -> bool:
    """Validate IP range - standalone function."""
    start_parts = start.split('.')
    if len(start_parts) != 4:
        return False

    end_parts = end.split('.')
    if len(end_parts) != 4:
        return False

    return start_parts[:3] == end_parts[:3]


def validate_api_key(api_key: str) -> bool:
    """Validate API key format - standalone function."""
    pattern = r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    return bool(re.match(pattern, api_key, re.IGNORECASE))
