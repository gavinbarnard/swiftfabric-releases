"""SwiftFabric TUI Installer Package.

This package provides a Terminal User Interface (TUI) installer for deploying
SwiftFabric controller VMs on Proxmox.
"""

__version__ = "1.0.0"
