#!/usr/bin/env python3
"""SwiftFabric TUI Installer - Main Entry Point."""

import sys
import argparse
import base64
import getpass
import ipaddress
import json
import re
import shlex
import ssl
import tempfile
from pathlib import Path
from urllib.parse import quote, urlparse

import requests
from rich.console import Console
from rich.markup import escape
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Confirm

import sys
import os

# Add parent directory to path for imports
script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir not in sys.path:
    sys.path.insert(0, script_dir)

from tui.config_form import ConfigForm
from tui.progress import ProgressIndicator
from deployment.controller import ControllerDeployment
from tui.validation import InputValidator
from cli_args import token_arguments


console = Console()
SUPPORTED_DEPLOY_APIS = ("proxmox",)


def show_banner(
    message="Deploy 3 controller VMs on Proxmox for SwiftFabric",
    title="[green]✓[/green]",
):
    """Display the installer banner for the selected action."""
    console.print(Panel(
        f"[bold blue]SwiftFabric TUI Installer[/bold blue]\n{message}",
        border_style="blue",
        title=title,
        title_align="left"
    ))
    console.print()


def parse_args():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="SwiftFabric TUI Installer - Deploy controller VMs on Proxmox"
    )
    parser.add_argument(
        "--non-interactive",
        action="store_true",
        help="Run in non-interactive mode (requires config file)"
    )
    parser.add_argument(
        "--restore-target",
        action="store_true",
        help="Deploy clean controllers for backup restore; skip pools, cluster registration, and host enrollment",
    )
    parser.add_argument(
        "--config",
        type=str,
        help="Path to JSON configuration file (used with --non-interactive)"
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug mode"
    )
    parser.add_argument(
        "--prefix",
        default="",
        help="Optional prefix for controller VM names (default: empty)"
    )
    parser.add_argument(
        "--controllername",
        "--controller-name",
        dest="controllername",
        default="swiftfabric-controller",
        help="Controller VM name stem (default: swiftfabric-controller)"
    )
    parser.add_argument(
        "--destroy",
        "--delete",
        dest="destroy",
        action="store_true",
        help="Delete the three controller VMs matching --prefix and --controllername"
    )
    parser.add_argument(
        "--yes",
        action="store_true",
        help="Confirm deletion without prompting (required for non-interactive deletion)"
    )
    parser.add_argument(
        "--auto-unenroll",
        action="store_true",
        help="For --destroy only, clean and unenroll registered Proxmox hosts and clusters first"
    )
    parser.add_argument(
        "--token",
        nargs="?",
        const="",
        metavar="VALUE",
        help="Controller API bearer token for --destroy; omit VALUE to enter it securely. "
             "Use --token=VALUE to unambiguously pass any dash-prefixed value."
    )
    parser.add_argument(
        "--ca-cert",
        help="Deployment CA certificate PEM for --destroy (otherwise fetched over controller SSH)",
    )

    args = parser.parse_args(token_arguments())
    if args.restore_target and (not args.non_interactive or args.destroy):
        parser.error("--restore-target requires a non-interactive install, not --destroy.")
    if args.auto_unenroll and not args.destroy:
        parser.error("--auto-unenroll can only be used with --destroy or --delete.")
    if args.token is not None and not args.destroy:
        parser.error("--token can only be used with --destroy or --delete.")
    if args.ca_cert is not None and not args.destroy:
        parser.error("--ca-cert can only be used with --destroy or --delete.")
    name_pattern = r"[A-Za-z0-9][A-Za-z0-9-]*"
    if args.prefix and not re.fullmatch(name_pattern, args.prefix):
        parser.error("--prefix may contain only letters, numbers, and hyphens.")
    if not re.fullmatch(name_pattern, args.controllername):
        parser.error(
            "--controllername must be non-empty and contain only letters, "
            "numbers, and hyphens."
        )
    stem = f"{args.prefix}-{args.controllername}" if args.prefix else args.controllername
    if len(stem) + len("-2") > 63:
        parser.error("The generated controller VM names must be 63 characters or fewer.")
    return args


def interactive_install(prefix="", controllername="swiftfabric-controller"):
    """Run the interactive installation process."""
    show_banner()

    # Collect configuration
    config_form = ConfigForm()
    config_form.config["deploy_api"] = "proxmox"

    console.print("[bold]Starting SwiftFabric Installer...[/bold]\n")
    console.print("[cyan]Deployment API: Proxmox (currently the only supported backend)[/cyan]\n")

    # Collect Proxmox configuration first
    config_form.collect_proxmox_config()
    config_form.collect_controller_ssh_config()
    config_form.config["controller_priv_key"] = _resolve_private_key(
        config_form.config["controller_priv_key"],
        Path.cwd(),
    )
    config_form.config["controller_pub_key"] = _resolve_public_key(
        config_form.config["controller_pub_key"],
        Path.cwd(),
    )

    console.print()

    # Get deployment parameters from config
    proxmox_config = {
        "host": config_form.config["proxmox_cluster_ip"],
        "port": config_form.config["proxmox_port"],
        "user": config_form.config["proxmox_user"],
        "token_name": config_form.config["proxmox_tokenname"],
        "api_key": config_form.config["proxmox_apikey"],
        "ssh_user": config_form.config["proxmox_ssh_user"],
        "ssh_key": config_form.config["proxmox_ssh_key"],
    }

    # Initialize deployment
    deployment = _create_deployment(config_form.config["deploy_api"], proxmox_config)
    _ensure_controller_names_available(deployment, prefix, controllername)

    # Get cloudinit image path
    qcow2_image_path = deployment.cloudinit_images.get_default_image_path()

    # Discover resources to get available options
    with ProgressIndicator() as progress:
        progress.print_step(1, 4, "Discovering Proxmox resources")

        try:
            resources = deployment.discover_resources()
            nodes = [n.get("node") for n in resources["nodes"]]
            storage_list = [s.get("storage") for s in resources["storage"]]
            available_interfaces = resources.get("available_interfaces", ["vmbr0"])

            console.print(f"\n[green]✓ Found {len(nodes)} nodes: {', '.join(nodes)}[/green]")
            console.print(f"[green]✓ Found {len(storage_list)} storage locations: {', '.join(storage_list)}[/green]")
            console.print(f"[green]✓ Found {len(available_interfaces)} network interfaces: {', '.join(available_interfaces[:3])}{'...' if len(available_interfaces) > 3 else ''}[/green]\n")

            # Pass available options to config form BEFORE network/storage collection
            config_form.available_options["available_storage"] = storage_list
            config_form.available_options["available_interfaces"] = available_interfaces
        except Exception as e:
            console.print(f"\n[red]✗ Error discovering resources: {e}[/red]")
            sys.exit(1)

    # Collect network configuration
    config_form.collect_network_config()
    api_vip = _controller_vip(config_form.config)

    # Collect storage configuration
    config_form.collect_storage_config()

    # Collect admin password
    config_form.collect_admin_password()

    # Show summary and confirm
    if not config_form.show_summary():
        console.print("\n[bold]Installation cancelled by user.[/bold]")
        sys.exit(0)

    try:
        api_summary = _deploy_interactive(
            config_form, deployment, nodes, prefix, controllername,
            qcow2_image_path, api_vip, progress,
        )
    except KeyboardInterrupt:
        raise
    except BaseException as exc:
        if isinstance(exc, SystemExit) and exc.code in (0, None):
            raise
        if not isinstance(exc, SystemExit):
            console.print(f"\n[red]✗ Deployment failed: {escape(str(exc))}[/red]")
        _offer_saved_deployment_config(
            config_form.config, prefix, controllername, failed=True,
        )
        raise
    saved_path = _offer_saved_deployment_config(config_form.config, prefix, controllername)
    if saved_path is not None:
        content = Path(saved_path).read_bytes()
    else:
        content = _saved_deployment_config_bytes(config_form.config)
    publish_controller_config(config_form.config, api_summary, content)
    console.print()


def _deploy_interactive(
    config_form, deployment, nodes, prefix, controllername,
    qcow2_image_path, api_vip, progress,
):
    """Deploy and bootstrap controllers from confirmed interactive answers."""
    from deployment.api_service import ApiServiceDeployment

    api_service = ApiServiceDeployment(
        config_form.config["controller_priv_key"],
        package_path=ApiServiceDeployment.find_package(
            Path(__file__).resolve().parents[1] / "packages"
        ),
    )

    # Deploy controllers
    progress.print_step(2, 4, "Deploying 3 controller VMs")

    try:
        ip_range_start = config_form.config["ip_range_start"]
        ip_range_end = config_form.config["ip_range_end"]
        admin_password = config_form.config["admin_password"]
        vlan_id = config_form.config.get("vlan_id")  # None if "none" selected

        results = deployment.deploy_multiple_controllers(
            node=nodes[0],  # Use first available node
            base_vmid=100,
            count=3,
            prefix=prefix,
            controller_name=controllername,
            cores=config_form.config["vm_cores"],
            memory=config_form.config["vm_memory"],
            storage=config_form.config["storage_location"],
            cidr=config_form.config["cidr"],
            interface=config_form.config["interface"],
            gateway_ip=config_form.config["gateway_ip"],
            dns_ip=config_form.config["dns_ip"],
            ubuntu_mirror=config_form.config.get("ubuntu_mirror", ""),
            controller_pub_key=config_form.config["controller_pub_key"],
            ip_range_start=ip_range_start,
            ip_range_end=ip_range_end,
            admin_password=admin_password,
            vlan_id=vlan_id,
            qcow2_image_path=qcow2_image_path
        )

        console.print(f"\n[green]✓ Deployed {len(results)} controller VMs successfully![/green]\n")

    except Exception as e:
        console.print(f"\n[red]✗ Error deploying controllers: {e}[/red]")
        sys.exit(1)

    progress.print_step(3, 4, "Preparing authenticated compute bootstrap")
    console.print(
        "[yellow]ℹ Proxmox API credentials are not placed in cloud-init. "
        "Declared compute registration is applied through the authenticated API after controller readiness.[/yellow]\n"
    )

    progress.print_step(
        4, 4, "Configuring the cluster and API service"
    )
    api_summary = _verify_and_configure_corosync(
        deployment,
        results,
        config_form.config["controller_priv_key"],
        api_service,
        api_vip,
        config_form.config["cidr"],
        config_form.config["gateway_ip"],
    )
    from deployment.bootstrap import bootstrap_deployment
    bootstrap_deployment(config_form.config, api_summary)

    # Show success
    progress = ProgressIndicator()
    progress.show_success("SwiftFabric deployment completed successfully!")

    console.print("\n[bold]Next steps:[/bold]")
    console.print("1. Corosync cluster is running and quorate across all three controllers")
    console.print("2. Pacemaker is active; fencing and automatic failover are not configured")
    console.print("3. Use the segment API from a controller to create and delete Geneve segments")
    return api_summary


CONTROLLER_CONFIG_PATH = "/etc/swiftfabric/config.json"


def _read_config_snapshot(config_path):
    """Capture the deployed config before changing infrastructure."""
    try:
        return Path(config_path).expanduser().read_bytes()
    except OSError as exc:
        raise ValueError(f"Cannot read configuration file '{config_path}': {exc}") from exc


def publish_controller_config(config, api_summary, content):
    """Install the deployment config root-only on every controller."""
    from deployment.ssh import SSHCommandRunner

    nodes = api_summary.get("nodes") or []
    if len(nodes) != 3:
        raise RuntimeError(
            "Cannot copy the deployment config: expected three controller addresses."
        )
    ssh = SSHCommandRunner(
        config["controller_priv_key"], "ubuntu", "the controller deployment config",
    )
    for ip_address in nodes:
        ssh.run(
            ip_address,
            "sudo install -D -o root -g root -m 0600 /dev/stdin "
            + CONTROLLER_CONFIG_PATH,
            timeout=120,
            input_data=content,
        )
    console.print(
        f"[green]✓ Copied deployment config to {CONTROLLER_CONFIG_PATH} "
        f"(root-only) on {', '.join(nodes)}[/green]"
    )


CONFIG_DEFAULTS = {
    "deploy_api": "proxmox",
    "proxmox_port": 8006,
    "vlan_id": 100,
    "cidr": 24,
    "admin_password": None,
    "gateway_ip": "172.16.255.1",
    "dns_ip": "8.8.8.8",
    "ubuntu_mirror": "http://archive.ubuntu.com/ubuntu",
    "controller_pub_key": "",
    "interface": "vmbr0",
    "storage_location": "local-lvm",
    "vm_memory": 8192,
    "vm_cores": 4,
    "proxmox_cluster_name": "",
    "vtep_vlan_id": None,
    "vtep_ip_range_cidr": "",
    "vtep_interface": "",
    "auto_enroll_host_list": [],
}
CONFIG_KEY_ALIASES = {
    "mgmt_priv_key": "controller_priv_key",
    "mgmt_pub_key": "controller_pub_key",
    "mgmt_vlan_id": "vlan_id",
    "mgmt_gateway_ip": "gateway_ip",
    "mgmt_dns_ip": "dns_ip",
    "mgmt_vm_password": "admin_password",
    "mgmt_cidr": "cidr",
    "mgmt_interface": "interface",
    "proxmox_auto_enroll_host_list": "auto_enroll_host_list",
}
CONFIG_REQUIRED = {
    "proxmox_cluster_ip",
    "proxmox_user",
    "proxmox_tokenname",
    "proxmox_apikey",
    "proxmox_ssh_user",
    "proxmox_ssh_key",
    "controller_priv_key",
    "ip_range_start",
    "ip_range_end",
    "gateway_ip",
    "dns_ip",
}
CONFIG_KEYS = CONFIG_REQUIRED | set(CONFIG_DEFAULTS) | {
    "mgmt_ip_range_start", "mgmt_ip_range_end", "vtep_mtu",
} | set(CONFIG_KEY_ALIASES)


def validate_ubuntu_mirror(value):
    """Return a normalized Ubuntu mirror URL, or raise ValueError."""
    if not isinstance(value, str):
        raise ValueError("'ubuntu_mirror' must be a string.")
    mirror = value.strip().rstrip("/")
    parsed = urlparse(mirror)
    if (
        parsed.scheme not in ("http", "https")
        or not parsed.netloc
        or any(char.isspace() or char in "\"'\\" for char in mirror)
    ):
        raise ValueError(
            "'ubuntu_mirror' must be an http:// or https:// URL, "
            "for example http://archive.ubuntu.com/ubuntu."
        )
    return mirror


def load_deployment_config(config_path):
    """Load and validate non-interactive deployment configuration."""
    try:
        with open(config_path, encoding="utf-8") as config_file:
            config = json.load(config_file)
    except OSError as exc:
        raise ValueError(f"Cannot read configuration file '{config_path}': {exc}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"Invalid JSON in configuration file '{config_path}' "
            f"at line {exc.lineno}, column {exc.colno}: {exc.msg}"
        ) from exc

    if not isinstance(config, dict):
        raise ValueError("Configuration file must contain a JSON object.")

    for new_key, old_key in CONFIG_KEY_ALIASES.items():
        if new_key in config:
            if old_key in config and config[old_key] != config[new_key]:
                raise ValueError(f"'{old_key}' conflicts with '{new_key}'.")
            config[old_key] = config[new_key]

    for suffix in ("start", "end"):
        new_key = f"mgmt_ip_range_{suffix}"
        old_key = f"ip_range_{suffix}"
        if new_key in config:
            if old_key in config and config[old_key] != config[new_key]:
                raise ValueError(f"'{old_key}' conflicts with '{new_key}'.")
            config[old_key] = config[new_key]
    if ("mgmt_ip_range_start" in config) != ("mgmt_ip_range_end" in config):
        raise ValueError("Specify both 'mgmt_ip_range_start' and 'mgmt_ip_range_end'.")

    missing = sorted(CONFIG_REQUIRED - config.keys())
    if missing:
        raise ValueError(f"Missing required configuration keys: {', '.join(missing)}")

    unknown = sorted(config.keys() - CONFIG_KEYS)
    if unknown:
        raise ValueError(f"Unknown configuration keys: {', '.join(unknown)}")

    config = {**CONFIG_DEFAULTS, **config}
    if not isinstance(config["deploy_api"], str) or not config["deploy_api"].strip():
        raise ValueError("'deploy_api' must be a non-empty string.")
    config["deploy_api"] = config["deploy_api"].strip().lower()
    if config["deploy_api"] not in SUPPORTED_DEPLOY_APIS:
        supported = ", ".join(SUPPORTED_DEPLOY_APIS)
        raise ValueError(
            f"Unsupported deployment API '{config['deploy_api']}'. "
            f"Currently supported: {supported}."
        )

    for key in ("proxmox_cluster_ip", "proxmox_user", "proxmox_tokenname",
                "proxmox_ssh_user", "proxmox_ssh_key", "controller_priv_key",
                "proxmox_apikey", "ip_range_start", "ip_range_end", "gateway_ip",
                "dns_ip", "interface", "storage_location"):
        if not isinstance(config[key], str) or not config[key].strip():
            raise ValueError(f"'{key}' must be a non-empty string.")
        config[key] = config[key].strip()

    if config["admin_password"] is not None and (
        not isinstance(config["admin_password"], str)
        or not config["admin_password"].strip()
    ):
        raise ValueError("'mgmt_vm_password' must be null or a non-empty string.")

    if not isinstance(config["controller_pub_key"], str):
        raise ValueError("'controller_pub_key' must be a string.")
    config["controller_pub_key"] = _resolve_public_key(
        config["controller_pub_key"],
        Path(config_path).expanduser().parent,
    )

    for key in ("proxmox_port", "cidr", "vm_memory", "vm_cores"):
        value = config[key]
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError(f"'{key}' must be an integer.")

    if not 1 <= config["proxmox_port"] <= 65535:
        raise ValueError("'proxmox_port' must be between 1 and 65535.")
    if not InputValidator.is_valid_cidr(config["cidr"]):
        raise ValueError("'cidr' must be between 0 and 32.")
    if config["vm_memory"] < 1 or config["vm_cores"] < 1:
        raise ValueError("'vm_memory' and 'vm_cores' must be positive integers.")
    if config["vlan_id"] is not None and (
        isinstance(config["vlan_id"], bool)
        or not isinstance(config["vlan_id"], int)
        or not 1 <= config["vlan_id"] <= 4094
    ):
        raise ValueError("'vlan_id' must be null or an integer between 1 and 4094.")
    if not InputValidator.is_valid_interface(config["interface"]):
        raise ValueError("'interface' contains invalid characters.")
    if not InputValidator.validate_api_key(config["proxmox_apikey"]):
        raise ValueError("'proxmox_apikey' must be a UUID-formatted Proxmox API token key.")
    if not re.fullmatch(r"[a-z_][a-z0-9_-]*[$]?", config["proxmox_ssh_user"]):
        raise ValueError("'proxmox_ssh_user' must be a valid Unix account name.")
    ssh_key_path = os.path.expanduser(config["proxmox_ssh_key"])
    if not os.path.isfile(ssh_key_path):
        raise ValueError("'proxmox_ssh_key' must point to an existing private key file.")
    config["proxmox_ssh_key"] = ssh_key_path
    config["controller_priv_key"] = _resolve_private_key(
        config["controller_priv_key"],
        Path(config_path).expanduser().parent,
    )

    _controller_vip(config)
    from deployment.bootstrap import validate_bootstrap_config
    validate_bootstrap_config(config)
    try:
        ipaddress.IPv4Address(config["dns_ip"])
    except ipaddress.AddressValueError as exc:
        raise ValueError(f"Invalid DNS IPv4 address: {exc}") from exc
    config["ubuntu_mirror"] = validate_ubuntu_mirror(config["ubuntu_mirror"])

    return config


SAVED_CONFIG_KEYS = (
    "deploy_api",
    "proxmox_cluster_ip",
    "proxmox_cluster_name",
    "proxmox_port",
    "proxmox_user",
    "proxmox_tokenname",
    "proxmox_apikey",
    "proxmox_ssh_user",
    "proxmox_ssh_key",
    "controller_priv_key",
    "controller_pub_key",
    "vlan_id",
    "mgmt_ip_range_start",
    "mgmt_ip_range_end",
    "gateway_ip",
    "dns_ip",
    "ubuntu_mirror",
    "admin_password",
    "cidr",
    "interface",
    "vtep_vlan_id",
    "vtep_ip_range_cidr",
    "vtep_interface",
    "auto_enroll_host_list",
    "storage_location",
    "vm_memory",
    "vm_cores",
)


def build_saved_deployment_config(config):
    """Return a reusable install/upgrade config from interactive answers.

    The Ubuntu account password is never persisted.
    """
    merged = {**CONFIG_DEFAULTS, **config}
    merged.setdefault("mgmt_ip_range_start", merged["ip_range_start"])
    merged.setdefault("mgmt_ip_range_end", merged["ip_range_end"])
    merged["proxmox_ssh_key"] = os.path.abspath(
        os.path.expanduser(merged["proxmox_ssh_key"])
    )
    saved = {key: merged[key] for key in SAVED_CONFIG_KEYS}
    saved["admin_password"] = None
    if "vtep_mtu" in merged:
        saved["vtep_mtu"] = merged["vtep_mtu"]
    return saved


def _saved_deployment_config_bytes(config):
    """Serialize the reusable deployment config exactly as it is saved."""
    saved = build_saved_deployment_config(config)
    return (json.dumps(saved, indent=2) + "\n").encode("utf-8")


def save_deployment_config(config, path, *, overwrite=False):
    """Atomically write a validated, owner-only deployment config file."""
    target = Path(path).expanduser().resolve()
    if target.exists() and not overwrite:
        raise FileExistsError(f"'{target}' already exists.")
    if not target.parent.is_dir():
        raise ValueError(f"Directory '{target.parent}' does not exist.")
    fd, temp_path = tempfile.mkstemp(
        prefix=f".{target.name}.", suffix=".tmp", dir=target.parent
    )
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "wb") as handle:
            handle.write(_saved_deployment_config_bytes(config))
            handle.flush()
            os.fsync(handle.fileno())
        load_deployment_config(temp_path)
        os.replace(temp_path, target)
    except BaseException:
        try:
            os.unlink(temp_path)
        except FileNotFoundError:
            pass
        raise
    return target


DEFAULT_CONTROLLER_NAME = "swiftfabric-controller"


def _default_saved_config_path(
    directory=None, prefix="", controllername=DEFAULT_CONTROLLER_NAME, now=None,
):
    """Return config-[<prefix>-][<controllername>-]<UTC YYYYMMDDHHMMSS>.json."""
    from datetime import datetime, timezone
    directory = Path(directory or Path.cwd())
    stamp = (now or datetime.now(timezone.utc)).strftime("%Y%m%d%H%M%S")
    parts = ["config"]
    if prefix:
        parts.append(prefix)
    if controllername and controllername != DEFAULT_CONTROLLER_NAME:
        parts.append(controllername)
    parts.append(stamp)
    return directory / f"{'-'.join(parts)}.json"


def _offer_saved_deployment_config(
    config, prefix="", controllername="swiftfabric-controller", failed=False,
):
    """Save interactive answers as a config reusable by upgrade.sh and destroy."""
    from rich.prompt import Prompt

    destroy = "./install.sh --destroy --non-interactive --config PATH"
    if prefix:
        destroy += f" --prefix {shlex.quote(prefix)}"
    if controllername != DEFAULT_CONTROLLER_NAME:
        destroy += f" --controllername {shlex.quote(controllername)}"
    if failed:
        console.print(
            "\n[yellow]Save the deployment configuration so partially deployed "
            f"controllers can be removed with: {escape(destroy)} --yes[/yellow]"
        )
    else:
        console.print(
            "\n[cyan]The controller upgrade workflow (./upgrade.sh --config PATH) "
            "requires the deployment configuration.[/cyan]"
        )
    console.print(
        "[yellow]The file contains the Proxmox API token key and is written "
        "with owner-only (0600) permissions. The Ubuntu account password is "
        "not saved.[/yellow]"
    )
    while True:
        path = Prompt.ask(
            "Save reusable deployment config to",
            default=str(_default_saved_config_path(
                prefix=prefix, controllername=controllername,
            )),
        ).strip()
        if not path:
            continue
        target = Path(path).expanduser().resolve()
        overwrite = False
        if target.exists():
            if not Confirm.ask(f"'{target}' exists. Overwrite it?", default=False):
                continue
            overwrite = True
        try:
            saved_path = save_deployment_config(config, target, overwrite=overwrite)
        except (OSError, ValueError) as exc:
            console.print(f"[red]Could not save deployment config: {escape(str(exc))}[/red]")
            if Confirm.ask("Try a different path?", default=True):
                continue
            console.print(
                "[yellow]Deployment config was not saved; recreate it before "
                "using ./upgrade.sh or --destroy --config.[/yellow]"
            )
            return None
        console.print(f"[green]✓ Saved deployment config to {escape(str(saved_path))}[/green]")
        quoted = shlex.quote(str(saved_path))
        if failed:
            console.print(
                "[cyan]Remove the partial deployment with: "
                f"{escape(destroy.replace('PATH', quoted, 1))} --yes[/cyan]"
            )
            return saved_path
        command = f"./upgrade.sh --config {quoted} --token"
        if prefix:
            command += f" --prefix {shlex.quote(prefix)}"
        if controllername != DEFAULT_CONTROLLER_NAME:
            command += f" --controllername {shlex.quote(controllername)}"
        console.print(f"[cyan]Upgrade later with: {escape(command)}[/cyan]")
        return saved_path

def _controller_vip(config):
    """Keep the fourth management address fixed when the pool expands."""
    return _validate_controller_ip_range(
        config["ip_range_start"], config["ip_range_end"],
        config["gateway_ip"], config["cidr"],
        allow_expansion="mgmt_ip_range_start" in config,
    )


def _validate_controller_ip_range(start, end, gateway, cidr, *, allow_expansion=False):
    """Validate controller reservations within a legacy range or management pool."""
    if isinstance(cidr, bool) or not isinstance(cidr, int) or not 1 <= cidr <= 32:
        raise ValueError("'cidr' must be an integer between 1 and 32.")
    try:
        start_ip = ipaddress.IPv4Address(start)
        end_ip = ipaddress.IPv4Address(end)
        gateway_ip = ipaddress.IPv4Address(gateway)
        network = ipaddress.ip_network(f"{start_ip}/{cidr}", strict=False)
        end_network = ipaddress.ip_network(f"{end_ip}/{cidr}", strict=False)
    except (ipaddress.AddressValueError, ipaddress.NetmaskValueError) as exc:
        raise ValueError(f"Invalid IPv4 network configuration: {exc}") from exc
    if network != end_network:
        raise ValueError("The IP range must remain within the configured CIDR subnet.")
    if gateway_ip not in network:
        raise ValueError("'gateway_ip' must be within the configured CIDR subnet.")
    size = int(end_ip) - int(start_ip)
    if (allow_expansion and size < 3) or (not allow_expansion and size != 3):
        raise ValueError(
            "IP range must contain " + ("at least" if allow_expansion else "exactly") +
            " four consecutive addresses: "
            "three controller IPs followed by the API VIP."
        )
    vip_ip = ipaddress.IPv4Address(int(start_ip) + 3)
    if vip_ip == gateway_ip or gateway_ip in (start_ip, start_ip + 1, start_ip + 2):
        raise ValueError("The gateway must not overlap a controller address or API VIP.")
    reserved = (network.network_address, network.broadcast_address)
    if start_ip in reserved or end_ip in reserved or gateway_ip in reserved:
        raise ValueError("Management range endpoints and gateway must be usable host addresses.")
    return str(vip_ip)


def _resolve_private_key(value, base_directory):
    """Resolve a controller private-key path against a config directory."""
    private_key = Path(value).expanduser()
    if not private_key.is_absolute():
        private_key = Path(base_directory) / private_key
    if not private_key.is_file():
        raise ValueError(
            "'controller_priv_key' must point to an existing private key file."
        )
    return str(private_key.resolve())


def _resolve_public_key(value, base_directory):
    """Read and validate an OpenSSH public key or a path to one."""
    public_key = value.strip()
    if not public_key:
        raise ValueError("'controller_pub_key' is required for controller SSH access.")
    key_path = Path(public_key).expanduser()
    if not key_path.is_absolute() and not key_path.is_file():
        relative_path = Path(base_directory) / key_path
        if relative_path.is_file():
            key_path = relative_path
    if key_path.is_file():
        try:
            public_key = key_path.read_text(encoding="utf-8").strip()
        except OSError as exc:
            raise ValueError(
                f"Cannot read controller public key file '{key_path}': {exc}"
            ) from exc

    if "\n" in public_key or "\r" in public_key:
        raise ValueError("'controller_pub_key' must contain a single public key line.")
    key_parts = public_key.split()
    if len(key_parts) < 2:
        raise ValueError(
            "'controller_pub_key' must be an OpenSSH public key or a path to one."
        )
    try:
        key_blob = base64.b64decode(key_parts[1], validate=True)
        algorithm_length = int.from_bytes(key_blob[:4], "big")
        embedded_algorithm = key_blob[4:4 + algorithm_length].decode("ascii")
    except (ValueError, UnicodeDecodeError) as exc:
        raise ValueError("'controller_pub_key' is not a valid OpenSSH public key.") from exc
    if not algorithm_length or embedded_algorithm != key_parts[0]:
        raise ValueError("'controller_pub_key' is not a valid OpenSSH public key.")
    return " ".join(key_parts)


def non_interactive_install(
    config_path,
    prefix="",
    controllername="swiftfabric-controller",
    *,
    restore_target=False,
):
    """Run the deployment using validated JSON settings without prompting."""
    show_banner()
    config = load_deployment_config(config_path)
    config_snapshot = _read_config_snapshot(config_path)

    proxmox_config = {
        "host": config["proxmox_cluster_ip"],
        "port": config["proxmox_port"],
        "user": config["proxmox_user"],
        "token_name": config["proxmox_tokenname"],
        "api_key": config["proxmox_apikey"],
        "ssh_user": config.get("proxmox_ssh_user"),
        "ssh_key": config.get("proxmox_ssh_key"),
    }
    deployment = _create_deployment(config["deploy_api"], proxmox_config)
    _ensure_controller_names_available(deployment, prefix, controllername)
    qcow2_image_path = deployment.cloudinit_images.get_default_image_path()

    progress = ProgressIndicator()
    progress.print_step(1, 4, "Discovering Proxmox resources")
    resources = deployment.discover_resources()
    nodes = [item.get("node") for item in resources["nodes"] if item.get("node")]
    storages = [item.get("storage") for item in resources["storage"] if item.get("storage")]
    interfaces = resources.get("available_interfaces", [])
    if not nodes:
        raise RuntimeError("No Proxmox nodes are available.")
    if config["storage_location"] not in storages:
        raise ValueError(
            f"Storage '{config['storage_location']}' is unavailable. "
            f"Available storage: {', '.join(storages) or 'none'}."
        )
    if config["interface"] not in interfaces:
        raise ValueError(
            f"Network interface '{config['interface']}' is unavailable. "
            f"Available interfaces: {', '.join(interfaces)}."
        )

    console.print(
        f"[green]✓ Using node {nodes[0]}, storage {config['storage_location']}, "
        f"and interface {config['interface']}[/green]"
    )

    from deployment.api_service import ApiServiceDeployment

    api_service = ApiServiceDeployment(
        config["controller_priv_key"],
        package_path=ApiServiceDeployment.find_package(
            Path(__file__).resolve().parents[1] / "packages"
        ),
    )
    api_vip = _controller_vip(config)

    progress.print_step(2, 4, "Deploying 3 controller VMs")
    results = deployment.deploy_multiple_controllers(
        node=nodes[0],
        base_vmid=100,
        count=3,
        prefix=prefix,
        controller_name=controllername,
        cores=config["vm_cores"],
        memory=config["vm_memory"],
        storage=config["storage_location"],
        cidr=config["cidr"],
        interface=config["interface"],
        gateway_ip=config["gateway_ip"],
        dns_ip=config["dns_ip"],
        ubuntu_mirror=config["ubuntu_mirror"],
        controller_pub_key=config["controller_pub_key"],
        ip_range_start=config["ip_range_start"],
        ip_range_end=config["ip_range_end"],
        admin_password=config["admin_password"],
        vlan_id=config["vlan_id"],
        qcow2_image_path=qcow2_image_path,
        placement_node_allowlist=(
            config["auto_enroll_host_list"]
            if isinstance(config["auto_enroll_host_list"], list)
            else None
        ),
    )

    progress.print_step(3, 4, "Preparing authenticated compute bootstrap")
    console.print(
        "[yellow]ℹ Proxmox API credentials are not placed in cloud-init. "
        "Declared compute registration is applied through the authenticated API after controller readiness.[/yellow]"
    )

    progress.print_step(
        4, 4, "Configuring the cluster and API service"
    )
    from deployment.ssh import automated_tofu_for_hosts
    controller_addresses = [
        vm.get("ip_address") for vm in results if vm.get("ip_address")
    ]
    with automated_tofu_for_hosts(controller_addresses):
        api_summary = _verify_and_configure_corosync(
            deployment,
            results,
            config["controller_priv_key"],
            api_service,
            api_vip,
            config["cidr"],
            config["gateway_ip"],
        )
        from deployment.bootstrap import bootstrap_deployment
        if restore_target:
            console.print(
                "[yellow]Restore target: skipping pools, cluster registration, and host enrollment. "
                "Restore the backup before managing existing workloads.[/yellow]"
            )
        else:
            bootstrap_deployment(config, api_summary)
        publish_controller_config(config, api_summary, config_snapshot)
    progress.show_success("SwiftFabric deployment completed successfully!")


def _deployment_from_config(config):
    """Build the Proxmox deployment options from validated configuration."""
    proxmox_config = {
        "host": config["proxmox_cluster_ip"],
        "port": config["proxmox_port"],
        "user": config["proxmox_user"],
        "token_name": config["proxmox_tokenname"],
        "api_key": config["proxmox_apikey"],
        "ssh_user": config.get("proxmox_ssh_user"),
        "ssh_key": config.get("proxmox_ssh_key"),
    }
    return _create_deployment(config["deploy_api"], proxmox_config)


def _verify_and_configure_corosync(
    deployment,
    results,
    private_key,
    api_service=None,
    api_vip=None,
    cidr=None,
    gateway_ip=None,
):
    """Wait for guests, then configure and verify Corosync and Pacemaker."""
    from deployment.corosync import CorosyncCluster
    from deployment.validation import DeploymentValidator

    validator = DeploymentValidator(deployment.client)
    validation = validator.validate_deployment(results)
    console.print(
        f"[green]✓ Validation complete: {validation['successful']}/"
        f"{validation['total']} VMs running[/green]"
    )
    if validation["failed"]:
        raise RuntimeError(f"{validation['failed']} controller VM(s) did not start.")
    if len(results) != 3:
        raise RuntimeError(
            f"Corosync setup requires exactly 3 controller VMs; got {len(results)}."
        )

    for vm in results:
        ip_address = vm.get("ip_address")
        if not ip_address:
            raise RuntimeError(
                f"Controller VM {vm.get('vmid')} has no IP address for readiness checks."
            )
        console.print(f"Waiting for {vm['name']} ({ip_address}) to respond to ping...")
        validator.wait_for_ping(ip_address)
        console.print(f"Checking SSH key login to ubuntu@{ip_address}...")
        validator.wait_for_ssh(ip_address, private_key, username="ubuntu")
        console.print(f"[green]✓ {vm['name']} is reachable over ping and SSH.[/green]")

    from deployment.preparation import ControllerPreparation

    ControllerPreparation(deployment, private_key).prepare(results)

    cluster = CorosyncCluster(private_key)
    summary = cluster.configure_and_verify(results)
    console.print(
        f"[green]✓ Corosync cluster '{summary['cluster_name']}' is quorate "
        f"across {len(summary['nodes'])} nodes.[/green]"
    )

    from deployment.pacemaker import PacemakerCluster

    pacemaker = PacemakerCluster(private_key)
    pacemaker_summary = pacemaker.configure_and_verify(results)
    console.print(
        f"[green]✓ Pacemaker is active and sees all "
        f"{len(pacemaker_summary['nodes'])} Corosync nodes.[/green]"
    )

    if api_service is None:
        from deployment.api_service import ApiServiceDeployment
        api_service = ApiServiceDeployment(
            private_key,
            package_path=ApiServiceDeployment.find_package(
                Path(__file__).resolve().parents[1] / "packages"
            ),
        )
    api_summary = api_service.build_and_deploy(
        results,
        pacemaker_summary["node_names"],
        api_vip,
    )
    pacemaker.configure_api_vip(
        api_vip,
        cidr,
        gateway_ip,
        pacemaker_summary["nodes"],
    )
    console.print(
        f"[green]✓ SwiftFabric API service is active at "
        f"{api_summary['api_url']}.[/green]"
    )
    console.print(
        f"[yellow]ℹ Authorized nodes: {', '.join(api_summary['nodes'])}; "
        f"token also saved at {api_summary['token_path']} on each controller. "
        "Automatic promotion assumes failed nodes are fully inaccessible; "
        "STONITH is disabled, so network partitions are not protected.[/yellow]"
    )
    console.print(
        "[bold yellow]Save this API bearer token for testing and future UI "
        f"authentication; anyone with it can manage segments:[/bold yellow]\n"
        f"{api_summary['api_token']}"
    )
    console.print(
        "[dim]Test with: curl -H 'Authorization: Bearer "
        f"{api_summary['api_token']}' {api_summary['api_url']}[/dim]"
    )
    return api_summary


def _ensure_controller_names_available(
    deployment,
    prefix="",
    controllername="swiftfabric-controller",
):
    """Stop before deployment if any requested controller VM name is occupied."""
    plan = deployment.find_controllers_to_destroy(prefix, controllername)
    if not plan["matches"]:
        return

    existing = ", ".join(
        f"{vm['name']} (VMID {vm['vmid']} on {vm['node']})"
        for vm in plan["matches"]
    )
    destroy_command = "./install.sh --destroy"
    if prefix:
        destroy_command += f" --prefix {prefix}"
    if controllername != "swiftfabric-controller":
        destroy_command += f" --controllername {controllername}"
    raise RuntimeError(
        "Controller VM name collision; no VMs were changed. Existing VM(s): "
        f"{existing}. Destroy the existing controller VM(s) and redeploy with "
        f"'{destroy_command}', or choose a different --prefix or --controllername."
    )


def _create_deployment(deploy_api, proxmox_config):
    """Create a deployment backend, rejecting APIs that are not implemented."""
    if deploy_api != "proxmox":
        supported = ", ".join(SUPPORTED_DEPLOY_APIS)
        raise ValueError(
            f"Unsupported deployment API '{deploy_api}'. Currently supported: {supported}."
        )
    return ControllerDeployment(**proxmox_config)


def non_interactive_destroy(
    config_path,
    prefix="",
    controllername="swiftfabric-controller",
    assume_yes=False,
    auto_unenroll=False,
    api_token=None,
    ca_cert=None,
):
    """Preview and optionally delete the named VMs using JSON configuration."""
    show_banner("Delete controller VMs from Proxmox", title="[red]Delete[/red]")
    config = load_deployment_config(config_path)
    deployment = _deployment_from_config(config)
    plan = deployment.find_controllers_to_destroy(prefix, controllername)
    _print_destroy_plan(plan)
    if not plan["matches"]:
        console.print("[yellow]No matching controller VMs were found.[/yellow]")
        return
    api_token = _resolve_api_token(api_token)
    api_vip = _controller_vip(config)
    with tempfile.TemporaryDirectory(prefix="swiftfabric-destroy-ca-") as ca_dir:
        management = _prepare_controller_cleanup(
            deployment, plan, config["controller_priv_key"], auto_unenroll, api_vip,
            api_token, ca_cert, ca_dir,
        )
        if not assume_yes:
            raise ValueError(
                "Deletion was not confirmed. Re-run with --yes after reviewing the VM list."
            )
        _destroy_confirmed(deployment, plan, management, api_vip)


def interactive_destroy(
    prefix="",
    controllername="swiftfabric-controller",
    config_path=None,
    auto_unenroll=False,
    api_token=None,
    ca_cert=None,
):
    """Prompt only for Proxmox access, then delete the named controllers."""
    show_banner("Delete controller VMs from Proxmox", title="[red]Delete[/red]")
    if config_path:
        config = load_deployment_config(config_path)
    else:
        config_form = ConfigForm()
        console.print("[bold]Connect to Proxmox to delete controller VMs.[/bold]\n")
        config_form.collect_proxmox_config()
        config = config_form.config
    deployment = _deployment_from_config({
        "deploy_api": config.get("deploy_api", "proxmox"),
        "proxmox_cluster_ip": config["proxmox_cluster_ip"],
        "proxmox_port": config["proxmox_port"],
        "proxmox_user": config["proxmox_user"],
        "proxmox_tokenname": config["proxmox_tokenname"],
        "proxmox_apikey": config["proxmox_apikey"],
        "proxmox_ssh_user": config.get("proxmox_ssh_user"),
        "proxmox_ssh_key": config.get("proxmox_ssh_key"),
    })
    plan = deployment.find_controllers_to_destroy(prefix, controllername)
    _print_destroy_plan(plan)
    if not plan["matches"]:
        console.print("[yellow]No matching controller VMs were found.[/yellow]")
        return
    if not config_path:
        config_form.collect_controller_ssh_config()
    api_token = _resolve_api_token(api_token)
    private_key = _resolve_private_key(
        config["controller_priv_key"],
        Path.cwd(),
    )
    api_vip = None
    if all(key in config for key in ("ip_range_start", "ip_range_end", "gateway_ip", "cidr")):
        api_vip = _controller_vip(config)
    with tempfile.TemporaryDirectory(prefix="swiftfabric-destroy-ca-") as ca_dir:
        management = _prepare_controller_cleanup(
            deployment, plan, private_key, auto_unenroll, api_vip, api_token,
            ca_cert, ca_dir,
        )
        if not Confirm.ask(
            "[bold red]Permanently delete the listed controller VMs?[/bold red]",
            default=False,
        ):
            console.print("[yellow]Deletion cancelled; no VMs were changed.[/yellow]")
            return
        _destroy_confirmed(deployment, plan, management, api_vip)


def _resolve_api_token(api_token):
    if api_token is None:
        return None
    if api_token == "":
        if not sys.stdin.isatty():
            raise RuntimeError("--token without a value requires an interactive terminal.")
        api_token = getpass.getpass("Controller API bearer token: ")
    api_token = api_token.strip()
    if not api_token:
        raise RuntimeError("The controller API token is empty; refusing to destroy.")
    return api_token


def _print_destroy_plan(plan):
    """Display the exact VM targets before a deletion confirmation."""
    table = Table(title="Controller VMs selected for deletion")
    table.add_column("Name")
    table.add_column("Node")
    table.add_column("VMID")
    table.add_column("Status")
    for controller in plan["matches"]:
        table.add_row(
            controller["name"],
            controller["node"],
            str(controller["vmid"]),
            controller["status"],
        )
    console.print(table)
    if plan["not_found"]:
        console.print(
            "[yellow]Not found: " + ", ".join(plan["not_found"]) + "[/yellow]"
        )


def _controller_vm_ip(deployment, controller):
    config = deployment.client.get(
        f"/nodes/{controller['node']}/qemu/{controller['vmid']}/config"
    ).get("data", {})
    ipconfig = config.get("ipconfig0", "")
    match = re.search(r"(?:^|,)ip=([^,]+)", ipconfig)
    if not match:
        raise RuntimeError(
            f"Could not determine the management IP for controller VM "
            f"'{controller['name']}'; refusing to destroy without checking host enrollment."
        )
    address = match.group(1).split("/", 1)[0]
    try:
        ipaddress.IPv4Address(address)
    except ipaddress.AddressValueError as failure:
        raise RuntimeError(
            f"Controller VM '{controller['name']}' has an invalid configured IPv4 address."
        ) from failure
    return address


def _controller_api_access(
    deployment, plan, private_key, configured_api_vip=None, api_token=None,
    ca_cert=None, ca_dir=None
):
    """Resolve API access and session-scoped trust for the controller CA."""
    from deployment.ssh import SSHCommandRunner

    controllers = sorted(
        plan["matches"],
        key=lambda item: int(re.search(r"-(\d+)$", item["name"]).group(1))
        if re.search(r"-(\d+)$", item["name"])
        else 99,
    )
    selected = None
    api_vip = None
    if configured_api_vip is not None:
        try:
            api_vip = ipaddress.IPv4Address(configured_api_vip)
        except ipaddress.AddressValueError as failure:
            raise RuntimeError("The configured API VIP is not a valid IPv4 address.") from failure
    else:
        indices = set()
        for controller in controllers:
            match = re.search(r"-(\d+)$", controller["name"])
            if match:
                indices.add(int(match.group(1)))
        if indices == {0, 1, 2}:
            vip_offset = 3
        elif indices == {1, 2, 3}:
            vip_offset = 4
        else:
            raise RuntimeError(
                "Cannot determine the API VIP from controller VM names; "
                "provide the deployment config or a supported controller set."
            )
        for controller in controllers:
            index = int(re.search(r"-(\d+)$", controller["name"]).group(1))
            candidate_vip = ipaddress.IPv4Address(
                _controller_vm_ip(deployment, controller)
            ) + vip_offset - index
            if api_vip is None:
                api_vip = candidate_vip
            elif api_vip != candidate_vip:
                raise RuntimeError(
                    "Controller VM IP configuration is inconsistent; refusing to destroy "
                    "without checking host enrollment."
                )
    if api_token is not None and ca_cert is not None:
        if api_vip is None:
            raise RuntimeError(
                "Could not determine the controller API VIP; refusing to destroy "
                "without checking host enrollment."
            )
        return f"https://{api_vip}", api_token.strip(), ca_cert

    for controller in controllers:
        if selected is None and controller["status"] == "running":
            selected = _controller_vm_ip(deployment, controller)

    if selected is None or api_vip is None:
        raise RuntimeError(
            "No running controller is available to verify the API CA; refusing to destroy."
        )
    ssh = SSHCommandRunner(
        private_key,
        username="ubuntu",
        purpose="SwiftFabric enrollment checks",
    )
    if api_token is None:
        api_token = ssh.run(
            selected,
            "sudo cat /etc/swiftfabric/segment-manager.token",
            timeout=15,
        ).strip()
        if not api_token:
            raise RuntimeError(
                "The controller API token is empty; refusing to destroy "
                "without an enrollment check."
            )

    if ca_cert is None:
        if ca_dir is None:
            raise RuntimeError("A temporary directory is required to trust the controller CA.")
        certificate = ssh.run(
            selected,
            "sudo cat /etc/swiftfabric/swiftfabric-ca.crt",
            timeout=15,
        ).strip()
        if not certificate:
            raise RuntimeError("Could not read the controller CA certificate over SSH.")
        try:
            ssl.create_default_context(cadata=certificate)
        except (ssl.SSLError, ValueError) as failure:
            raise RuntimeError(
                "Controller returned an invalid CA certificate."
            ) from failure
        ca_path = Path(ca_dir) / "swiftfabric-ca.crt"
        ca_path.write_text(certificate + "\n", encoding="ascii")
        ca_cert = str(ca_path)
    return f"https://{api_vip}", api_token.strip(), ca_cert


def _controller_api_request(management, method, path, json_body=None):
    base_url, token, ca_cert = management
    try:
        response = requests.request(
            method,
            f"{base_url}{path}",
            headers={"Authorization": f"Bearer {token}"},
            timeout=(3, 15),
            verify=ca_cert or True,
            json=json_body,
        )
        response.raise_for_status()
    except requests.RequestException as failure:
        raise RuntimeError(
            f"Could not complete the controller enrollment check ({method} {path}): {failure}"
        ) from failure
    if response.status_code == 204 or not response.content:
        return None
    try:
        return response.json()
    except ValueError as failure:
        raise RuntimeError(
            f"Controller returned invalid JSON for {method} {path}."
        ) from failure


def _controller_enrollment_state(management):
    clusters = _controller_api_request(
        management, "GET", "/api/v1/proxmox/clusters"
    )
    hosts = _controller_api_request(management, "GET", "/api/v1/hosts")
    if (
        not isinstance(clusters, list)
        or any(not isinstance(item, dict) or not isinstance(item.get("name"), str) for item in clusters)
        or not isinstance(hosts, list)
        or any(not isinstance(item, dict) or not isinstance(item.get("host_id"), str) for item in hosts)
    ):
        raise RuntimeError("Controller returned an invalid enrollment inventory.")
    return clusters, hosts


def _prepare_controller_cleanup(
    deployment, plan, private_key, auto_unenroll, configured_api_vip=None,
    api_token=None, ca_cert=None, ca_dir=None
):
    """Refuse unsafe destroy, or return the API access needed for confirmed cleanup."""
    management = _controller_api_access(
        deployment, plan, private_key, configured_api_vip, api_token, ca_cert,
        ca_dir,
    )
    identity = _controller_api_request(management, "GET", "/api/v1/system/me")
    if not isinstance(identity, dict) or identity.get("is_admin") is not True:
        raise RuntimeError(
            "Destroy requires an active admin API key; use --token to supply "
            "the current key after revoking the deployment key."
        )
    clusters, hosts = _controller_enrollment_state(management)
    if (clusters or hosts) and not auto_unenroll:
        cluster_names = ", ".join(
            item.get("name", "<unnamed>") for item in clusters
        )
        host_names = ", ".join(
            item.get("host_id", "<unnamed>") for item in hosts
        )
        details = []
        if clusters:
            details.append(f"registered Proxmox clusters: {cluster_names}")
        if hosts:
            details.append(f"enrolled hosts: {host_names}")
        raise RuntimeError(
            "Destroy refused because " + "; ".join(details) + ". Unenroll them "
            "from the SwiftFabric Compute UI, or rerun with --destroy --auto-unenroll."
        )
    return management if auto_unenroll else None


def _auto_unenroll(management):
    """Remove host state first, then cluster registrations; fail if cleanup is incomplete."""
    clusters, hosts = _controller_enrollment_state(management)
    if not clusters and not hosts:
        console.print("[green]No enrolled hosts or registered Proxmox clusters.[/green]")
        return

    for cluster in clusters:
        name = cluster.get("name")
        if not isinstance(name, str) or not name:
            raise RuntimeError("Controller returned a cluster without a valid name.")
        result = _controller_api_request(
            management,
            "POST",
            f"/api/v1/proxmox/clusters/{quote(name, safe='')}/cleanup",
            json_body={"enrolled_only": True},
        )
        node_results = result.get("results") if isinstance(result, dict) else None
        if not isinstance(node_results, list):
            raise RuntimeError(f"Cleanup returned an invalid result for cluster '{name}'.")
        incomplete = [
            f"{item.get('node', '<unknown>')}: {item.get('result', 'unknown')}"
            + (f" ({item['message']})" if item.get("message") else "")
            for item in node_results
            if not isinstance(item, dict)
            or item.get("result") != "cleaned"
            or item.get("message")
        ]
        if incomplete:
            raise RuntimeError(
                f"Automatic unenrollment of cluster '{name}' was incomplete; "
                "controller VMs were not destroyed: " + "; ".join(incomplete)
            )
        _controller_api_request(
            management,
            "DELETE",
            f"/api/v1/proxmox/clusters/{quote(name, safe='')}",
        )

    remaining_clusters, remaining_hosts = _controller_enrollment_state(management)
    if remaining_clusters or remaining_hosts:
        raise RuntimeError(
            "Automatic unenrollment did not clear all host and cluster registrations; "
            "controller VMs were not destroyed."
        )
    console.print("[green]✓ All registered Proxmox hosts and clusters were unenrolled.[/green]")


def _destroy_confirmed(deployment, plan, management=None, api_vip=None):
    """Unenroll when requested, then delete a confirmed plan."""
    if management is not None:
        _auto_unenroll(management)
    controller_ips = {}
    for controller in plan["matches"]:
        try:
            controller_ips[controller["name"]] = _controller_vm_ip(deployment, controller)
        except Exception:
            continue
    results = deployment.destroy_controllers(plan["matches"])
    console.print(
        f"[green]✓ Deleted and verified {len(results['verified'])} controller VM(s): "
        f"{', '.join(results['verified'])}[/green]"
    )
    all_deleted = set(results["verified"]) >= {item["name"] for item in plan["matches"]}
    _forget_destroyed_host_keys(
        [controller_ips[name] for name in results["verified"] if name in controller_ips]
        + ([str(api_vip)] if api_vip is not None and all_deleted else [])
    )


def _forget_destroyed_host_keys(addresses):
    """Drop SSH pins for deleted controllers so redeployed addresses can be re-pinned."""
    from deployment.ssh import SSHCommandRunner, SSHHostKeyError

    if not addresses:
        return
    try:
        removed = SSHCommandRunner(
            None, "ubuntu", "controller host-key cleanup",
        ).forget_host_keys(addresses)
    except SSHHostKeyError as failure:
        console.print(
            f"[yellow]Could not remove stale SSH host keys for deleted controllers: "
            f"{failure}[/yellow]"
        )
        return
    if removed:
        console.print(
            "[green]✓ Removed stale SSH host keys for deleted controller addresses: "
            f"{', '.join(removed)}[/green]"
        )


def main():
    """Main entry point."""
    args = parse_args()

    try:
        if args.yes and not args.destroy:
            raise ValueError("--yes can only be used with --destroy or --delete.")
        if args.destroy:
            if args.non_interactive:
                if not args.config:
                    raise ValueError("--non-interactive requires --config PATH.")
                non_interactive_destroy(
                    args.config,
                    args.prefix,
                    args.controllername,
                    args.yes,
                    args.auto_unenroll,
                    args.token,
                    args.ca_cert,
                )
            elif args.config:
                interactive_destroy(
                    args.prefix,
                    args.controllername,
                    config_path=args.config,
                    auto_unenroll=args.auto_unenroll,
                    api_token=args.token,
                    ca_cert=args.ca_cert,
                )
            else:
                interactive_destroy(
                    args.prefix,
                    args.controllername,
                    auto_unenroll=args.auto_unenroll,
                    api_token=args.token,
                    ca_cert=args.ca_cert,
                )
        elif args.non_interactive:
            if not args.config:
                raise ValueError("--non-interactive requires --config PATH.")
            non_interactive_install(
                args.config,
                args.prefix,
                args.controllername,
                restore_target=args.restore_target,
            )
        else:
            if args.config:
                raise ValueError("--config can only be used with --non-interactive.")
            interactive_install(args.prefix, args.controllername)
    except KeyboardInterrupt:
        console.print("\n\n[yellow]Installation cancelled by user.[/yellow]")
        sys.exit(130)
    except Exception as e:
        if args.debug:
            import traceback
            console.print(f"\n[red]✗ Unexpected error:[/red]")
            console.print(traceback.format_exc())
        else:
            console.print(f"\n[red]✗ Unexpected error: {e}[/red]")
            console.print("\n[bold]Run with --debug for more information.[/bold]")
        sys.exit(1)


if __name__ == "__main__":
    main()
