"""Build the SwiftFabric API service Debian package on the configured buildbox."""

import shutil
import sys
import os
import subprocess
from pathlib import Path

from deployment.api_service import ApiServiceDeployment


def main() -> int:
    project_root = Path(__file__).resolve().parents[1]
    if sys.argv[1:] == ["--fingerprint"]:
        print(ApiServiceDeployment._source_fingerprint(
            project_root / "controller-api" / "segment-manager"
        ))
        return 0
    if sys.argv[1:] and (len(sys.argv) != 3 or sys.argv[1] != "--version"):
        print("usage: build_api_service.py [--fingerprint] | [--version PACKAGE_VERSION]", file=sys.stderr)
        return 2
    version_script = str(project_root / "build-version.sh")
    subprocess.run([version_script, "--check"], check=True)
    version = sys.argv[2] if sys.argv[1:] else subprocess.check_output(
        [version_script, "controller-api"], text=True
    ).strip()
    os.environ["SWIFTFABRIC_AGENT_VERSION"] = subprocess.check_output(
        [version_script, "host-agent"], text=True
    ).strip()
    os.environ["SWIFTFABRIC_SOURCE_DATE_EPOCH"] = subprocess.check_output(
        [version_script, "--epoch", "controller-api"], text=True
    ).strip()
    package_dir = Path(os.environ.get("SWIFTFABRIC_PACKAGES_DIR", project_root / "packages"))
    package_dir.mkdir(exist_ok=True)

    deployment = ApiServiceDeployment(private_key="")
    built_package = deployment.build(version)

    for previous_package in package_dir.glob(
        "swiftfabric-api-service_*_amd64.deb"
    ):
        previous_package.unlink()
    destination = package_dir / built_package.name
    shutil.copy2(built_package, destination)
    print(f"Built and copied package to {destination}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
