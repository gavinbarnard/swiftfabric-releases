"""SSH command execution for deployed controller VMs."""

import base64
from contextlib import contextmanager
from contextvars import ContextVar
import fcntl
import hashlib
import os
from pathlib import Path
import subprocess
import sys


class SSHHostKeyError(RuntimeError):
    """Raised when an SSH server identity is not explicitly trusted."""


_AUTOMATED_TOFU_HOSTS = ContextVar("automated_tofu_hosts", default=frozenset())


@contextmanager
def automated_tofu_for_hosts(hosts):
    """Automatically pin first-use keys only for explicitly scoped hosts."""
    token = _AUTOMATED_TOFU_HOSTS.set(
        _AUTOMATED_TOFU_HOSTS.get()
        | frozenset(host for host in hosts if isinstance(host, str) and host)
    )
    try:
        yield
    finally:
        _AUTOMATED_TOFU_HOSTS.reset(token)


def integration_ssh_options() -> list[str]:
    """Share the integration session trust store with direct SSH/SCP commands."""
    path = os.environ.get("SWIFTFABRIC_INTEGRATION_KNOWN_HOSTS")
    if os.environ.get("SWIFTFABRIC_INTEGRATION_TOFU") == "1" and path:
        return [
            "-o", f"UserKnownHostsFile={path}",
            "-o", "GlobalKnownHostsFile=/dev/null",
        ]
    return []


class SSHCommandRunner:
    """Run SSH commands after persisting explicit host-key approval."""

    def __init__(
        self,
        private_key: str,
        username: str,
        purpose: str,
        known_hosts_file: str = None,
    ):
        self.private_key = private_key
        self.username = username
        self.purpose = purpose
        self.known_hosts_file = Path(
            known_hosts_file
            or (
                os.environ.get("SWIFTFABRIC_INTEGRATION_KNOWN_HOSTS")
                if os.environ.get("SWIFTFABRIC_INTEGRATION_TOFU") == "1"
                else None
            )
            or Path.home() / ".ssh" / "known_hosts"
        ).expanduser()

    def ensure_host_key(self, ip_address: str) -> None:
        """Pin first-use keys; unattended trust must be explicitly scoped."""
        integration_tofu = os.environ.get("SWIFTFABRIC_INTEGRATION_TOFU") == "1"
        automated_tofu = (
            integration_tofu or ip_address in _AUTOMATED_TOFU_HOSTS.get()
        )
        self.known_hosts_file.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        try:
            with self.known_hosts_file.open("a+", encoding="ascii") as known_hosts:
                os.chmod(self.known_hosts_file, 0o600)
                fcntl.flock(known_hosts.fileno(), fcntl.LOCK_EX)
                if self._host_is_pinned(ip_address):
                    return

                keys = self._scan_host_keys(ip_address)
                fingerprints = sorted({
                    self._fingerprint(key.split()[2])
                    for key in keys
                })
                print(
                    f"\nFirst-use SSH host key for {ip_address}:\n"
                    + "\n".join(f"  {fingerprint}" for fingerprint in fingerprints)
                    + "\nTOFU cannot detect interception on this first connection."
                    + (
                        " Verify fingerprint through an independent trusted channel "
                        "before accepting."
                        if not automated_tofu else ""
                    ),
                    file=sys.stderr,
                    flush=True,
                )
                if integration_tofu:
                    print(
                        f"Integration test: automatically trusting first-use SSH "
                        f"keys for {ip_address}.",
                        file=sys.stderr,
                        flush=True,
                    )
                elif ip_address in _AUTOMATED_TOFU_HOSTS.get():
                    print(
                        f"Non-interactive install: automatically trusting first-use "
                        f"SSH key for newly deployed controller {ip_address}.",
                        file=sys.stderr,
                        flush=True,
                    )
                elif not automated_tofu and not sys.stdin.isatty():
                    raise SSHHostKeyError(
                        f"SSH host {ip_address} has no saved trust pin and no "
                        "interactive terminal is available."
                    )
                elif not automated_tofu:
                    try:
                        accepted = input(
                            f"Trust this SSH host key for {ip_address}? Type 'yes': "
                        )
                    except EOFError as failure:
                        raise SSHHostKeyError(
                            f"SSH host-key approval for {ip_address} was not provided."
                        ) from failure
                    if accepted.strip().lower() != "yes":
                        raise SSHHostKeyError(
                            f"SSH host key for {ip_address} was not accepted."
                        )

                known_hosts.seek(0, os.SEEK_END)
                for key in keys:
                    known_hosts.write(key + "\n")
                known_hosts.flush()
                os.fsync(known_hosts.fileno())
        except OSError as failure:
            raise SSHHostKeyError(
                f"Could not persist SSH host-key trust for {ip_address}: {failure}"
            ) from failure

    def forget_host_keys(self, addresses) -> list:
        """Remove saved pins for addresses whose previous machines are verified gone."""
        removed = []
        if not self.known_hosts_file.exists():
            return removed
        try:
            with self.known_hosts_file.open("a+", encoding="ascii") as known_hosts:
                fcntl.flock(known_hosts.fileno(), fcntl.LOCK_EX)
                for address in dict.fromkeys(addresses):
                    if not self._host_is_pinned(address):
                        continue
                    try:
                        result = subprocess.run(
                            [
                                "ssh-keygen",
                                "-R", address,
                                "-f", str(self.known_hosts_file),
                            ],
                            capture_output=True,
                            text=True,
                            timeout=5,
                            check=False,
                        )
                    except FileNotFoundError as failure:
                        raise SSHHostKeyError(
                            "The ssh-keygen client is required to remove stale host pins."
                        ) from failure
                    except subprocess.TimeoutExpired as failure:
                        raise SSHHostKeyError(
                            f"Timed out removing the saved SSH host key for {address}."
                        ) from failure
                    if result.returncode != 0:
                        raise SSHHostKeyError(
                            f"Could not remove the saved SSH host key for {address}: "
                            f"{(result.stderr or result.stdout).strip()}"
                        )
                    removed.append(address)
        except OSError as failure:
            raise SSHHostKeyError(
                f"Could not update SSH host-key trust: {failure}"
            ) from failure
        return removed

    def _host_is_pinned(self, ip_address: str) -> bool:
        try:
            result = subprocess.run(
                [
                    "ssh-keygen",
                    "-F", ip_address,
                    "-f", str(self.known_hosts_file),
                ],
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
        except FileNotFoundError as failure:
            raise SSHHostKeyError("The ssh-keygen client is required for host pinning.") from failure
        except subprocess.TimeoutExpired as failure:
            raise SSHHostKeyError(
                f"Timed out checking the saved SSH host key for {ip_address}."
            ) from failure

        if result.returncode == 0:
            return True
        if result.returncode == 1:
            return False
        raise SSHHostKeyError(
            f"Could not check the saved SSH host key for {ip_address}: "
            f"{(result.stderr or result.stdout).strip()}"
        )

    @staticmethod
    def _scan_host_keys(ip_address: str) -> list:
        try:
            result = subprocess.run(
                [
                    "ssh-keyscan",
                    "-T", "5",
                    "-t", "ed25519,ecdsa,rsa",
                    ip_address,
                ],
                capture_output=True,
                text=True,
                timeout=10,
                check=False,
            )
        except FileNotFoundError as failure:
            raise SSHHostKeyError("The ssh-keyscan client is required for host pinning.") from failure
        except subprocess.TimeoutExpired as failure:
            raise SSHHostKeyError(
                f"Timed out retrieving the SSH host key for {ip_address}."
            ) from failure

        keys = []
        for line in result.stdout.splitlines():
            fields = line.split()
            if len(fields) >= 3 and fields[0] == ip_address:
                try:
                    base64.b64decode(fields[2], validate=True)
                except ValueError:
                    continue
                keys.append(" ".join(fields[:3]))
        if result.returncode != 0 or not keys:
            detail = (result.stderr or "").strip()
            raise SSHHostKeyError(
                f"Could not retrieve an SSH host key for {ip_address}"
                + (f": {detail}" if detail else ".")
            )
        return list(dict.fromkeys(keys))

    @staticmethod
    def _fingerprint(key_data: str) -> str:
        raw_key = base64.b64decode(key_data, validate=True)
        digest = base64.b64encode(hashlib.sha256(raw_key).digest())
        return "SHA256:" + digest.decode("ascii").rstrip("=")

    def run(
        self,
        ip_address: str,
        remote_command: str,
        timeout: int = 15,
        input_data: bytes = None,
        stream_output: bool = False,
    ) -> str:
        """Run one command on a VM, optionally streaming bytes to its stdin."""
        self.ensure_host_key(ip_address)
        command = [
            "ssh",
            "-i", self.private_key,
            "-o", "BatchMode=yes",
            "-o", "IdentitiesOnly=yes",
            "-o", "ConnectTimeout=5",
            "-o", "ConnectionAttempts=1",
            "-o", f"UserKnownHostsFile={self.known_hosts_file}",
            "-o", "StrictHostKeyChecking=yes",
            *integration_ssh_options(),
            f"{self.username}@{ip_address}",
            remote_command,
        ]
        try:
            result = subprocess.run(
                command,
                input=input_data,
                capture_output=not stream_output,
                text=input_data is None,
                timeout=timeout,
                check=False,
            )
        except FileNotFoundError as exc:
            raise RuntimeError(
                f"The ssh client is required to configure {self.purpose}."
            ) from exc
        except subprocess.TimeoutExpired as exc:
            raise TimeoutError(
                f"Timed out running '{remote_command}' on {ip_address}."
            ) from exc

        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "") if not stream_output else ""
            if isinstance(detail, bytes):
                detail = detail.decode("utf-8", errors="replace")
            detail = detail.strip()
            raise RuntimeError(
                f"SSH command '{remote_command}' failed on {ip_address}"
                + (f": {detail}" if detail else ".")
            )
        output = result.stdout if not stream_output else ""
        return output.decode("utf-8", errors="replace") if isinstance(output, bytes) else output
