"""Controller VM orchestration."""

import json
import ipaddress
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Dict, Any, List, Optional
from urllib.parse import quote

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from proxmox.client import ProxmoxClient
from proxmox.nodes import ProxmoxNodes
from proxmox.storage import ProxmoxStorage
from proxmox.vm import ProxmoxVM
from cloudinit.images import CloudInitImages
from cloudinit.config import CloudInitConfig
from deployment.proxmox_ca import ProxmoxCATrust
from deployment.ssh import integration_ssh_options


class ControllerDeployment:
    """Deploy and configure controller VMs on Proxmox."""

    def __init__(
        self,
        host: str,
        port: int = 8006,
        user: str = "root@pam",
        token_name: str = None,
        api_key: str = None,
        ssh_user: str = None,
        ssh_key: str = None
    ):
        """
        Initialize ControllerDeployment.

        Args:
            host: Proxmox cluster IP address
            port: Proxmox API port
            user: Proxmox user
            token_name: API token name
            api_key: API token key
            ssh_user: SSH user with write access to Proxmox snippets storage
            ssh_key: Path to the SSH private key
        """
        from rich.console import Console

        self.ssh_user = ssh_user
        self.ssh_key = str(Path(ssh_key).expanduser()) if ssh_key else None
        self.proxmox_ca = ProxmoxCATrust(host, self.ssh_user, self.ssh_key)
        self.client = ProxmoxClient(
            host,
            port,
            user,
            token_name,
            api_key,
            verify_ssl=self.proxmox_ca.ca_path,
        )
        self.proxmox_ca.verify_cluster_nodes(self.client)
        self.nodes = ProxmoxNodes(self.client)
        self.storage = ProxmoxStorage(self.client)
        self.vm = ProxmoxVM(self.client, self.ssh_user, self.ssh_key)
        self.cloudinit_images = CloudInitImages()
        self.cloudinit_config = CloudInitConfig()
        self.console = Console()

    def _install_cloudinit_vendor_data(
        self,
        node: str,
        storage: str,
        vmid: int,
        password: Optional[str],
        dns_ip: str,
        ubuntu_mirror: str = "",
    ) -> str:
        """Copy a per-VM cloud-init vendor-data snippet to Proxmox storage."""
        if not self.ssh_user or not self.ssh_key:
            raise ValueError("Proxmox SSH user and private key are required for cloud-init snippets.")
        if not re.fullmatch(r"[a-z_][a-z0-9_-]*[$]?", self.ssh_user):
            raise ValueError("Proxmox SSH user must be a valid Unix account name.")
        if not Path(self.ssh_key).is_file():
            raise FileNotFoundError(f"Proxmox SSH private key not found: {self.ssh_key}")

        storage_info = self.client.get(f"/storage/{storage}").get("data", {})
        content_types = (storage_info.get("content") or "").split(",")
        if "snippets" not in content_types:
            raise ValueError(
                f"Storage '{storage}' must have the snippets content type enabled."
            )

        storage_path = storage_info.get("path")
        if not storage_path or not Path(storage_path).is_absolute():
            raise RuntimeError(
                f"Proxmox did not provide a valid filesystem path for storage '{storage}'."
            )

        snippet_name = f"swiftfabric-vm-{vmid}-vendor.yaml"
        remote_directory = str(Path(storage_path) / "snippets")
        remote_path = str(Path(remote_directory) / snippet_name)
        destination = f"{self.ssh_user}@{node}"
        ssh_options = [
            "-i", self.ssh_key,
            "-o", "BatchMode=yes",
            "-o", "IdentitiesOnly=yes",
            "-o", "ConnectTimeout=15",
            "-o", "StrictHostKeyChecking=accept-new",
            *integration_ssh_options(),
        ]

        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            suffix=".yaml",
            prefix="swiftfabric-vendor-",
        ) as snippet_file:
            snippet_file.write(
                self.cloudinit_config.generate_vendor_user_data(
                    password, dns_ip, ubuntu_mirror
                )
            )
            snippet_file.flush()

            commands = [
                (
                    "ssh",
                    [
                        *ssh_options,
                        destination,
                        f"mkdir -p -- {shlex.quote(remote_directory)}",
                    ],
                    60,
                    "create the Proxmox snippets directory",
                ),
                (
                    "scp",
                    [
                        *ssh_options,
                        "--",
                        snippet_file.name,
                        f"{destination}:{remote_path}",
                    ],
                    120,
                    "copy cloud-init vendor data to Proxmox",
                ),
                (
                    "ssh",
                    [
                        *ssh_options,
                        destination,
                        f"chmod 600 -- {shlex.quote(remote_path)}",
                    ],
                    60,
                    "restrict access to the cloud-init vendor data",
                ),
            ]
            for executable, arguments, timeout, action in commands:
                try:
                    subprocess.run(
                        [executable, *arguments],
                        check=True,
                        capture_output=True,
                        text=True,
                        timeout=timeout,
                    )
                except subprocess.CalledProcessError as exc:
                    detail = exc.stderr.strip() or str(exc)
                    raise RuntimeError(f"Failed to {action}: {detail}") from exc
                except subprocess.TimeoutExpired as exc:
                    raise TimeoutError(f"Timed out trying to {action}.") from exc

        return f"{storage}:snippets/{snippet_name}"

    def discover_resources(self) -> Dict[str, Any]:
        """Discover available Proxmox resources."""
        nodes = self.nodes.list_nodes()
        storage = self.storage.list_storage()

        # Get available network interfaces from first node
        available_interfaces = []
        if nodes:
            first_node = nodes[0].get("node")
            try:
                # Get interface list from Proxmox
                response = self.client.get(f"/nodes/{first_node}/network")
                interfaces_data = response.get("data", [])
                for iface in interfaces_data:
                    if iface.get("iface") and iface.get("type") in ["bridge", "ethernet"]:
                        available_interfaces.append(iface["iface"])
            except Exception:
                # Fallback to common interface names
                available_interfaces = ["vmbr0", "vmbr1", "eth0"]

        return {
            "nodes": nodes,
            "storage": storage,
            "available_interfaces": available_interfaces
        }

    def deploy_controller(
        self,
        node: str,
        vmid: int,
        name: str,
        cores: int = 2,
        memory: int = 2048,
        storage: str = "local-lvm",
        ip_address: str = None,
        hostname: str = None,
        admin_password: Optional[str] = None,
        vlan_id: int = None,
        qcow2_image_path: str = None,
        cidr: int = 24,
        interface: str = "vmbr0",
        gateway_ip: str = "172.16.255.1",
        dns_ip: str = "8.8.8.8",
        ubuntu_mirror: str = "",
        controller_pub_key: str = "",
    ) -> Dict[str, Any]:
        """
        Deploy a single controller VM.

        Args:
            node: Target node name
            vmid: VM ID
            name: VM name
            cores: CPU cores
            memory: Memory in MB
            storage: Storage location
            ip_address: Static IP address
            hostname: VM hostname
            admin_password: Admin user password
            vlan_id: VLAN ID (None for no VLAN)
            qcow2_image_path: Path to cloudinit qcow2 image

        Returns:
            Deployment result
        """
        # Keep source names versioned so an updated local image does not reuse
        # an older Proxmox import volume with the generic base-image name.
        base_image_name = Path(qcow2_image_path).name if qcow2_image_path else None

        if qcow2_image_path:
            content = self.client.get(
                f"/nodes/{node}/storage/{storage}/content",
                params={"content": "import"}
            ).get("data", [])
            base_image_volid = next(
                (
                    item.get("volid")
                    for item in content
                    if item.get("volid", "").endswith(f"/{base_image_name}")
                ),
                None
            )
            if base_image_volid:
                self.console.print(f"[bold]Base cloudinit image already exists, skipping upload...[/bold]")
            else:
                self.console.print(f"[bold]Uploading base cloudinit image to {node}...[/bold]")
                self.vm.upload_image(
                    node=node,
                    storage=storage,
                    filename=base_image_name,
                    content_type="import",
                    file_path=qcow2_image_path
                )
                content = self.client.get(
                    f"/nodes/{node}/storage/{storage}/content",
                    params={"content": "import"}
                ).get("data", [])
                base_image_volid = next(
                    (
                        item.get("volid")
                        for item in content
                        if item.get("volid", "").endswith(f"/{base_image_name}")
                    ),
                    None
                )
                if not base_image_volid:
                    raise RuntimeError(
                        f"Uploaded image {base_image_name} was not found in "
                        f"storage {storage}."
                    )
                self.console.print(f"[green]✓ Base image uploaded successfully as {base_image_name}[/green]\n")

        else:
            raise ValueError("A qcow2 cloudinit image path is required.")

        # Create VM without disk
        vendor_data_volume = self._install_cloudinit_vendor_data(
            node=node,
            storage=storage,
            vmid=vmid,
            dns_ip=dns_ip,
            ubuntu_mirror=ubuntu_mirror,
            password=admin_password,
        )
        result = self.vm.create_vm_no_disk(
            node=node,
            vmid=vmid,
            name=name,
            cores=cores,
            memory=memory,
            net0=f"virtio,bridge={interface},firewall=1"
            + (f",tag={vlan_id}" if vlan_id is not None else ""),
            ide2=f"{storage}:cloudinit,media=cdrom",
            boot="order=scsi0"
        )

        # Import a separate copy of the base image into this VM's disk.
        attach_result = self.vm.attach_disk_image(
            node=node,
            vmid=vmid,
            storage=storage,
            source=base_image_volid,
            interface="scsi0"
        )

        # Configure cloud-init even without a password so static networking and SSH keys apply.
        if ip_address and hostname:
            config_data = {
                "ipconfig0": f"ip={ip_address}/{cidr},gw={gateway_ip}",
                "nameserver": dns_ip,
                "cicustom": f"vendor={vendor_data_volume}",
            }
            if controller_pub_key:
                # Proxmox expects sshkeys to be URL-encoded within its form value.
                config_data["sshkeys"] = quote(controller_pub_key, safe="")

            config_result = self.client.configure_vm(node, vmid, **config_data)
            config_upid = config_result.get("data")
            if isinstance(config_upid, str) and config_upid.startswith("UPID:"):
                self.client.wait_for_task(config_upid, timeout=1800)

        # Start the VM
        start_result = self.client.start_vm(node, vmid)
        start_upid = start_result.get("data")
        if isinstance(start_upid, str) and start_upid.startswith("UPID:"):
            self.client.wait_for_task(start_upid, timeout=300)
        if not self.vm.wait_for_vm_start(node, vmid):
            raise TimeoutError(f"VM {vmid} on node {node} did not start within 60 seconds.")

        return {
            **result,
            "node": node,
            "vmid": vmid,
            "name": name,
            "ip_address": ip_address,
        }

    def deploy_multiple_controllers(
        self,
        node: str,
        base_vmid: int,
        count: int,
        prefix: str = "",
        controller_name: str = "swiftfabric-controller",
        cores: int = 2,
        memory: int = 2048,
        storage: str = "local-lvm",
        ip_range_start: str = None,
        ip_range_end: str = None,
        admin_password: Optional[str] = None,
        vlan_id: int = None,
        qcow2_image_path: str = None,
        cidr: int = 24,
        interface: str = "vmbr0",
        gateway_ip: str = "172.16.255.1",
        dns_ip: str = "8.8.8.8",
        ubuntu_mirror: str = "",
        controller_pub_key: str = "",
        placement_node_allowlist: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Deploy multiple controller VMs.

        Args:
            node: Target node name
            base_vmid: Starting VM ID
            count: Number of VMs to deploy
            prefix: Optional prefix prepended to controller names
            controller_name: Base controller VM name
            cores: CPU cores per VM
            memory: Memory per VM in MB
            storage: Storage location
            ip_range_start: Starting IP address
            ip_range_end: Ending IP address
            admin_password: Admin user password
            vlan_id: VLAN ID (None for no VLAN)
            qcow2_image_path: Path to cloudinit qcow2 image

        Returns:
            List of deployment results
        """
        results = []
        cluster_nodes = self.nodes.list_nodes()
        online_nodes = list(dict.fromkeys(
            item["node"]
            for item in cluster_nodes
            if item.get("node") and item.get("status", "online") == "online"
        ))
        if placement_node_allowlist:
            allowed_nodes = set(placement_node_allowlist)
            online_nodes = [
                candidate for candidate in online_nodes if candidate in allowed_nodes
            ]
        if node in online_nodes:
            online_nodes.remove(node)
            online_nodes.insert(0, node)

        eligible_nodes = []
        for candidate in online_nodes:
            node_storages = self.storage.get_node_storage(candidate)
            for node_storage in node_storages:
                if node_storage.get("storage") != storage:
                    continue
                if node_storage.get("active", 1) in (0, False):
                    continue
                if node_storage.get("enabled", 1) in (0, False):
                    continue
                eligible_nodes.append(candidate)
                break

        if not eligible_nodes:
            raise ValueError(
                f"Storage '{storage}' is not active on any online Proxmox node."
            )

        node_loads = []
        for candidate in eligible_nodes:
            status = self.nodes.get_node_status(candidate)
            cpu_usage = status.get("cpu")
            memory_stats = status.get("memory", {})
            memory_used = memory_stats.get("used")
            memory_total = memory_stats.get("total")
            if (
                not isinstance(cpu_usage, (int, float))
                or isinstance(cpu_usage, bool)
                or not 0 <= cpu_usage <= 1
                or not isinstance(memory_used, (int, float))
                or isinstance(memory_used, bool)
                or not isinstance(memory_total, (int, float))
                or isinstance(memory_total, bool)
                or memory_total <= 0
                or not 0 <= memory_used <= memory_total
            ):
                raise RuntimeError(
                    f"Proxmox returned invalid CPU or memory utilization for node "
                    f"'{candidate}'; cannot rank deployment placement."
                )
            memory_usage = memory_used / memory_total
            node_loads.append(
                {
                    "node": candidate,
                    "cpu": cpu_usage,
                    "memory": memory_usage,
                    "score": (cpu_usage + memory_usage) / 2,
                }
            )

        node_loads.sort(key=lambda item: item["score"])
        eligible_nodes = [item["node"] for item in node_loads]
        placement = [
            eligible_nodes[index % len(eligible_nodes)]
            for index in range(count)
        ]
        self.console.print(
            "[bold]Controller VM placement by current CPU/memory utilization: "
            + ", ".join(placement)
            + "[/bold]"
        )
        for load in node_loads:
            self.console.print(
                f"  {load['node']}: CPU {load['cpu']:.1%}, "
                f"memory {load['memory']:.1%}"
            )

        # VM IDs are cluster-wide and disk volumes can remain after a VM is
        # removed, so avoid both registered guests and existing target-storage
        # volumes when choosing a contiguous range.
        cluster_vms = self.client.get(
            "/cluster/resources",
            params={"type": "vm"}
        ).get("data", [])
        storage_volumes = []
        for eligible_node in eligible_nodes:
            storage_volumes.extend(
                self.client.get(
                    f"/nodes/{eligible_node}/storage/{storage}/content"
                ).get("data", [])
            )
        used_vmids = {
            int(item["vmid"])
            for item in [*cluster_vms, *storage_volumes]
            if item.get("vmid") is not None
        }
        while any(base_vmid + offset in used_vmids for offset in range(count)):
            base_vmid += 1

        # Parse IP range
        if ip_range_start and ip_range_end:
            start_address = ipaddress.IPv4Address(ip_range_start)
            end_address = ipaddress.IPv4Address(ip_range_end)
            if int(end_address) - int(start_address) < count:
                raise ValueError(
                    f"IP range must provide {count} controller addresses and "
                    "one additional address for the API VIP."
                )

            for i in range(count):
                vmid = base_vmid + i
                name = self._controller_vm_name(prefix, controller_name, i)
                target_node = placement[i]

                # Calculate IP
                ip = str(ipaddress.IPv4Address(int(start_address) + i))
                hostname = name

                result = self.deploy_controller(
                    node=target_node,
                    vmid=vmid,
                    name=name,
                    cores=cores,
                    memory=memory,
                    storage=storage,
                    ip_address=ip,
                    hostname=hostname,
                    admin_password=admin_password,
                    vlan_id=vlan_id,
                    qcow2_image_path=qcow2_image_path,
                    cidr=cidr,
                    interface=interface,
                    gateway_ip=gateway_ip,
                    dns_ip=dns_ip,
                    ubuntu_mirror=ubuntu_mirror,
                    controller_pub_key=controller_pub_key,
                )
                results.append(result)

        else:
            for i in range(count):
                vmid = base_vmid + i
                name = self._controller_vm_name(prefix, controller_name, i)
                target_node = placement[i]

                result = self.deploy_controller(
                    node=target_node,
                    vmid=vmid,
                    name=name,
                    cores=cores,
                    memory=memory,
                    storage=storage,
                    admin_password=admin_password,
                    qcow2_image_path=qcow2_image_path,
                    cidr=cidr,
                    interface=interface,
                    gateway_ip=gateway_ip,
                    dns_ip=dns_ip,
                    ubuntu_mirror=ubuntu_mirror,
                    controller_pub_key=controller_pub_key,
                )
                results.append(result)

        return results

    @staticmethod
    def _controller_vm_name(prefix: str, controller_name: str, index: int) -> str:
        """Return the CLI-defined name for a controller VM."""
        stem = f"{prefix}-{controller_name}" if prefix else controller_name
        return f"{stem}-{index}"

    def find_controllers_to_destroy(
        self,
        prefix: str = "",
        controller_name: str = "swiftfabric-controller",
        count: int = 3,
    ) -> Dict[str, List[Any]]:
        """Find unique controller VM matches before deletion."""
        vm_resources = self.client.get(
            "/cluster/resources",
            params={"type": "vm"},
        ).get("data", [])
        names = [
            self._controller_vm_name(prefix, controller_name, index)
            for index in range(count)
        ]
        if (
            not prefix
            and controller_name == "swiftfabric-controller"
            and not any(vm.get("name") in names for vm in vm_resources)
        ):
            names = [f"controller-{index}" for index in range(1, count + 1)]

        matches_by_name = {
            name: [vm for vm in vm_resources if vm.get("name") == name]
            for name in names
        }
        for name, matches in matches_by_name.items():
            if len(matches) > 1:
                raise RuntimeError(
                    f"Multiple Proxmox VMs are named '{name}'; refusing to delete ambiguously."
                )

        return {
            "matches": [
                {
                    "name": name,
                    "node": matches[0]["node"],
                    "vmid": int(matches[0]["vmid"]),
                    "status": matches[0].get("status", "unknown"),
                }
                for name, matches in matches_by_name.items()
                if matches
            ],
            "not_found": [
                name for name, matches in matches_by_name.items() if not matches
            ],
        }

    def destroy_controllers(
        self,
        controllers: List[Dict[str, Any]],
    ) -> Dict[str, List[str]]:
        """Delete a confirmed controller selection and verify removal."""
        current_vms = self.client.get(
            "/cluster/resources",
            params={"type": "vm"},
        ).get("data", [])
        for controller in controllers:
            matches = [
                vm for vm in current_vms
                if int(vm.get("vmid", -1)) == controller["vmid"]
                and vm.get("node") == controller["node"]
                and vm.get("name") == controller["name"]
            ]
            if len(matches) != 1:
                raise RuntimeError(
                    f"Controller VM '{controller['name']}' changed after confirmation; "
                    "no VMs were deleted."
                )

        deleted = []
        for controller in controllers:
            name = controller["name"]
            node = controller["node"]
            vmid = controller["vmid"]
            if controller["status"] != "stopped":
                stop_result = self.client.post(
                    f"/nodes/{node}/qemu/{vmid}/status/stop"
                )
                stop_upid = stop_result.get("data")
                if isinstance(stop_upid, str) and stop_upid.startswith("UPID:"):
                    self.client.wait_for_task(stop_upid, timeout=300)

            delete_result = self.vm.delete_vm(node, vmid)
            delete_upid = delete_result.get("data")
            if isinstance(delete_upid, str) and delete_upid.startswith("UPID:"):
                self.client.wait_for_task(delete_upid, timeout=1800)
            deleted.append(name)

        deadline = time.monotonic() + 30
        remaining = [controller["name"] for controller in controllers]
        while remaining and time.monotonic() < deadline:
            remaining_vmids = {
                int(vm["vmid"])
                for vm in self.client.get(
                    "/cluster/resources",
                    params={"type": "vm"},
                ).get("data", [])
                if vm.get("vmid") is not None
            }
            remaining = [
                controller["name"]
                for controller in controllers
                if controller["vmid"] in remaining_vmids
            ]
            if remaining:
                time.sleep(1)
        if remaining:
            raise RuntimeError(
                "Proxmox still reports these controller VMs after deletion: "
                + ", ".join(remaining)
            )

        return {"deleted": deleted, "verified": deleted}

    def save_connection_config(
        self,
        node: str,
        vmid: int,
        host: str,
        port: int,
        user: str,
        token_name: str,
        api_key: str
    ) -> Dict[str, Any]:
        """
        Save connection configuration to a VM.

        Args:
            node: Target node name
            vmid: VM ID
            host: Proxmox cluster IP
            port: Proxmox API port
            user: Proxmox user
            token_name: API token name
            api_key: API token key

        Returns:
            Configuration result
        """
        config = {
            "proxmox_cluster_ip": host,
            "proxmox_port": port,
            "proxmox_user": user,
            "proxmox_tokenname": token_name,
            "proxmox_apikey": api_key
        }

        # Generate cloudinit config to write file
        config_content = json.dumps(config, indent=2)
        user_data = f"""#cloud-config
runcmd:
  - mkdir -p /etc/swiftfabric/proxmox
  - echo '{config_content}' > /etc/swiftfabric/proxmox/connection.json
"""

        return self.client.configure_vm(node, vmid, **{"user": user_data})
