"""Post-deployment validation."""

import subprocess
import time
from typing import Dict, Any, List

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from proxmox.client import ProxmoxClient
from deployment.ssh import SSHCommandRunner, integration_ssh_options


class DeploymentValidator:
    """Validate deployment success and VM status."""

    READINESS_TIMEOUT = 300
    RETRY_INTERVAL = 5

    def __init__(self, client):
        """
        Initialize DeploymentValidator.

        Args:
            client: ProxmoxClient instance
        """
        self.client = client

    def validate_vm_running(self, node: str, vmid: int) -> bool:
        """
        Check if a VM is running.

        Args:
            node: Target node name
            vmid: VM ID

        Returns:
            True if running, False otherwise
        """
        try:
            status = self.client.get_vm_status(node, vmid)
            return status.get("data", {}).get("status") == "running"
        except Exception:
            return False

    def validate_vm_config(self, node: str, vmid: int) -> Dict[str, Any]:
        """
        Validate VM configuration.

        Args:
            node: Target node name
            vmid: VM ID

        Returns:
            Validation results dict
        """
        try:
            config = self.client.get_vm_config(node, vmid)
            data = config.get("data", {})

            return {
                "status": "valid",
                "vmid": data.get("vmid"),
                "name": data.get("name"),
                "cores": data.get("cores"),
                "memory": data.get("memory"),
                "onboot": data.get("onboot")
            }
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }

    def validate_deployment(
        self,
        deployments: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Validate entire deployment.

        Args:
            deployments: List of deployment results

        Returns:
            Validation summary
        """
        results = {
            "total": len(deployments),
            "successful": 0,
            "failed": 0,
            "details": []
        }

        for deployment in deployments:
            node = deployment.get("node")
            vmid = deployment.get("vmid")

            if self.validate_vm_running(node, vmid):
                results["successful"] += 1
                results["details"].append({
                    "node": node,
                    "vmid": vmid,
                    "status": "running",
                    "valid": True
                })
            else:
                results["failed"] += 1
                results["details"].append({
                    "node": node,
                    "vmid": vmid,
                    "status": "not_running",
                    "valid": False
                })

        return results

    def check_network_connectivity(self, node: str, vmid: int) -> bool:
        """
        Check if VM has network connectivity.

        Args:
            node: Target node name
            vmid: VM ID

        Returns:
            True if network is configured, False otherwise
        """
        try:
            config = self.client.get_vm_config(node, vmid)
            data = config.get("data", {})

            # Check if network interface is configured
            for key in data.keys():
                if key.startswith("net"):
                    return True

            return False
        except Exception:
            return False

    def wait_for_ping(
        self,
        ip_address: str,
        timeout: int = READINESS_TIMEOUT,
    ) -> None:
        """Wait until the guest responds to ICMP echo requests."""
        deadline = time.monotonic() + timeout
        last_output = ""
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                detail = f" Last ping output: {last_output}" if last_output else ""
                raise TimeoutError(
                    f"Controller at {ip_address} did not respond to ping within "
                    f"{timeout} seconds.{detail}"
                )
            try:
                result = subprocess.run(
                    ["ping", "-c", "1", "-W", "2", ip_address],
                    capture_output=True,
                    text=True,
                    timeout=min(3, remaining),
                    check=False,
                )
            except FileNotFoundError as exc:
                raise RuntimeError("The ping utility is required for guest readiness checks.") from exc
            except subprocess.TimeoutExpired:
                result = None

            if result is not None and result.returncode == 0:
                return
            if result is not None:
                last_output = (result.stderr or result.stdout).strip()
            time.sleep(min(self.RETRY_INTERVAL, max(0, deadline - time.monotonic())))

    def wait_for_ssh(
        self,
        ip_address: str,
        private_key: str,
        username: str = "ubuntu",
        timeout: int = READINESS_TIMEOUT,
    ) -> None:
        """Wait until key-based SSH can run a harmless remote command."""
        ssh = SSHCommandRunner(
            private_key,
            username,
            "controller readiness checks",
        )
        ssh.ensure_host_key(ip_address)
        deadline = time.monotonic() + timeout
        last_output = ""
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                detail = f" Last SSH error: {last_output}" if last_output else ""
                raise TimeoutError(
                    f"Could not connect to {username}@{ip_address} with the configured "
                    f"SSH key within {timeout} seconds.{detail}"
                )
            try:
                result = subprocess.run(
                    [
                        "ssh",
                        "-i", private_key,
                        "-o", "BatchMode=yes",
                        "-o", "IdentitiesOnly=yes",
                        "-o", "ConnectTimeout=5",
                        "-o", "ConnectionAttempts=1",
                        "-o", f"UserKnownHostsFile={ssh.known_hosts_file}",
                        "-o", "StrictHostKeyChecking=yes",
                        *integration_ssh_options(),
                        f"{username}@{ip_address}",
                        "true",
                    ],
                    capture_output=True,
                    text=True,
                    timeout=min(8, remaining),
                    check=False,
                )
            except FileNotFoundError as exc:
                raise RuntimeError("The ssh client is required for guest readiness checks.") from exc
            except subprocess.TimeoutExpired:
                result = None

            if result is not None and result.returncode == 0:
                return
            if result is not None:
                last_output = (result.stderr or result.stdout).strip()
                if "REMOTE HOST IDENTIFICATION HAS CHANGED" in last_output:
                    raise RuntimeError(
                        f"SSH host key for {ip_address} does not match the saved pin in "
                        f"{ssh.known_hosts_file}. If a previous controller at this address "
                        "was destroyed, remove only the stale entry with "
                        f"'ssh-keygen -R {ip_address} -f {ssh.known_hosts_file}' and retry; "
                        "otherwise investigate possible interception."
                    )
            time.sleep(min(self.RETRY_INTERVAL, max(0, deadline - time.monotonic())))

    def wait_for_ssh_disconnect(
        self,
        ip_address: str,
        private_key: str,
        username: str = "ubuntu",
        timeout: int = 120,
    ) -> None:
        """Wait until SSH goes offline, confirming a requested reboot occurred."""
        ssh = SSHCommandRunner(
            private_key,
            username,
            "controller reboot monitoring",
        )
        ssh.ensure_host_key(ip_address)
        deadline = time.monotonic() + timeout
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError(
                    f"Controller at {ip_address} did not disconnect for reboot "
                    f"within {timeout} seconds."
                )
            try:
                result = subprocess.run(
                    [
                        "ssh",
                        "-i", private_key,
                        "-o", "BatchMode=yes",
                        "-o", "IdentitiesOnly=yes",
                        "-o", "ConnectTimeout=5",
                        "-o", "ConnectionAttempts=1",
                        "-o", f"UserKnownHostsFile={ssh.known_hosts_file}",
                        "-o", "StrictHostKeyChecking=yes",
                        *integration_ssh_options(),
                        f"{username}@{ip_address}",
                        "true",
                    ],
                    capture_output=True,
                    text=True,
                    timeout=min(8, remaining),
                    check=False,
                )
            except FileNotFoundError as exc:
                raise RuntimeError(
                    "The ssh client is required to monitor controller reboots."
                ) from exc
            except subprocess.TimeoutExpired:
                result = None

            if result is None or result.returncode != 0:
                return
            time.sleep(min(2, max(0, deadline - time.monotonic())))
