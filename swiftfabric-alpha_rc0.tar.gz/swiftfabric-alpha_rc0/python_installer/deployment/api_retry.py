"""Bounded transport retries; ambiguous mutations are never replayed."""

import logging
import time

import requests

log = logging.getLogger(__name__)
READ_METHODS = frozenset(("GET", "HEAD", "OPTIONS"))
RETRY_DELAYS = (1, 3, 5, 10, 20, 40, 60)


def request_with_retry(session, method, url, *, timeout, **kwargs):
    deadline = time.monotonic() + 1800
    attempt = 0
    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            log.error("API recovery exhausted after %d retries: %s", attempt, method)
            raise TimeoutError("API recovery exceeded 30 minutes")
        response = None
        failure = None
        try:
            response = session.request(
                method, url, timeout=(
                    min(timeout[0], remaining / 2),
                    min(timeout[1], remaining - min(timeout[0], remaining / 2)),
                ),
                **kwargs,
            )
            if time.monotonic() >= deadline:
                response.close()
                raise TimeoutError("API recovery exceeded 30 minutes")
            retryable = method.upper() in READ_METHODS and response.status_code in (502, 503, 504)
            if not retryable:
                return response
        except requests.exceptions.SSLError:
            raise
        except requests.exceptions.ConnectTimeout as exc:
            # Requests guarantees this failure occurred before a request was sent.
            failure = exc
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as exc:
            if method.upper() not in READ_METHODS:
                raise
            failure = exc
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            log.error("API recovery exhausted after %d retries: %s", attempt, method)
            if failure is not None:
                raise failure
            return response
        if response is not None:
            response.close()
        delay = min(RETRY_DELAYS[min(attempt, len(RETRY_DELAYS) - 1)], remaining)
        log.warning("API transport unavailable: %s; retry %d in %g seconds", method, attempt + 1, delay)
        time.sleep(delay)
        attempt += 1
