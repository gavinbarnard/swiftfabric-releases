"""Apply declarative management/VTEP pools and compute enrollment after installation."""

import ipaddress
import re
import tempfile
import time
from pathlib import Path

import requests
from rich.console import Console


def _has_vtep_configuration(config):
    return all(
        key in config and config[key] is not None and config[key] != ""
        for key in ("vtep_vlan_id", "vtep_ip_range_cidr", "vtep_mtu", "vtep_interface")
    )


def validate_bootstrap_config(config):
    """Validate optional bootstrap settings before changing infrastructure."""
    name = config.get("proxmox_cluster_name", "")
    if not isinstance(name, str) or (name and not re.fullmatch(r"[A-Za-z0-9._-]{1,128}", name)):
        raise ValueError("'proxmox_cluster_name' must be a valid cluster name.")
    interface = config.get("vtep_interface", "")
    if not isinstance(interface, str) or (
        interface and not re.fullmatch(r"[A-Za-z0-9._-]{1,15}", interface)
    ):
        raise ValueError("'vtep_interface' must be a valid network interface name.")
    vlan = config.get("vtep_vlan_id")
    if vlan is not None and (
        isinstance(vlan, bool) or not isinstance(vlan, int) or not 1 <= vlan <= 4094
    ):
        raise ValueError("'vtep_vlan_id' must be null or an integer between 1 and 4094.")
    mtu = config.get("vtep_mtu", 9000)
    if isinstance(mtu, bool) or not isinstance(mtu, int) or not 1600 <= mtu <= 9000:
        raise ValueError("'vtep_mtu' must be an integer between 1600 and 9000.")
    cidr = config.get("vtep_ip_range_cidr", "")
    if not isinstance(cidr, str):
        raise ValueError("'vtep_ip_range_cidr' must be an IPv4 CIDR string.")
    if cidr:
        try:
            network = ipaddress.IPv4Network(cidr, strict=False)
        except ValueError as exc:
            raise ValueError("'vtep_ip_range_cidr' must be a valid IPv4 subnet.") from exc
        if not 1 <= network.prefixlen <= 30:
            raise ValueError("'vtep_ip_range_cidr' must have usable host addresses.")
        management = ipaddress.IPv4Network(
            f"{config['ip_range_start']}/{config['cidr']}", strict=False,
        )
        if network.overlaps(management):
            raise ValueError("VTEP and management subnets must not overlap.")
        config["vtep_ip_range_cidr"] = str(network)
    vtep_configured = _has_vtep_configuration(config)
    hosts = config.get("auto_enroll_host_list", [])
    if isinstance(hosts, str):
        hosts = "all" if hosts == "all" else [hosts]
    if hosts != "all" and (
        not isinstance(hosts, list)
        or any(not isinstance(node, str) or not re.fullmatch(r"[A-Za-z0-9._-]{1,64}", node) or node == "all" for node in hosts)
        or len(set(hosts)) != len(hosts)
    ):
        raise ValueError("'auto_enroll_host_list' must be 'all', one node name, or a unique list of node names.")
    if hosts and vtep_configured and not name:
        raise ValueError("Automatic enrollment requires 'proxmox_cluster_name', 'vtep_ip_range_cidr', and 'vtep_interface'.")
    if not vtep_configured:
        hosts = []
    config["auto_enroll_host_list"] = hosts


def _selected_nodes(nodes, selection):
    if not isinstance(nodes, list) or any(
        not isinstance(node, dict) or not isinstance(node.get("node"), str)
        or not isinstance(node.get("status"), str) for node in nodes
    ):
        raise RuntimeError("Controller returned an invalid compute-node inventory.")
    inventory = {node["node"]: node for node in nodes}
    if len(inventory) != len(nodes):
        raise RuntimeError("Controller returned duplicate compute-node names.")
    selected = list(inventory) if selection == "all" else selection
    if selection == "all" and not selected:
        raise RuntimeError("No compute nodes were discovered for automatic enrollment.")
    for name in selected:
        if name not in inventory:
            raise RuntimeError(f"Requested compute node '{name}' was not found.")
        if inventory[name]["status"] != "online":
            raise RuntimeError(f"Requested compute node '{name}' is not online.")
    return selected


def wait_for_api(session, url):
    """Wait for a read-only API endpoint without retrying TLS or authorization failures."""
    for attempt in range(30):
        try:
            response = session.get(url, timeout=(3, 5))
        except requests.exceptions.SSLError as exc:
            raise RuntimeError("Deployment API TLS verification failed.") from exc
        except (requests.ConnectionError, requests.Timeout):
            if attempt == 29:
                raise RuntimeError("Deployment API VIP did not become reachable.")
            reason = "connection unavailable"
        else:
            if response.ok:
                return response
            if response.status_code not in (502, 503, 504) or attempt == 29:
                raise RuntimeError(f"Deployment API VIP readiness failed (HTTP {response.status_code}).")
            reason = f"HTTP {response.status_code}"
        Console().print(f"[yellow]Deployment API not ready ({reason}); retrying.[/yellow]")
        time.sleep(2)


def bootstrap_deployment(config, api_summary):
    """Configure the installed API, using its deployment CA rather than insecure TLS."""
    validate_bootstrap_config(config)
    certificate = api_summary.get("ca_certificate")
    if not isinstance(certificate, str) or not certificate.startswith("-----BEGIN CERTIFICATE-----"):
        raise RuntimeError("Deployment CA certificate is required for API bootstrap.")
    vip = str(ipaddress.IPv4Address(int(ipaddress.IPv4Address(config["ip_range_start"])) + 3))
    base_url = f"https://{vip}"
    with tempfile.NamedTemporaryFile(mode="w", encoding="ascii", suffix=".pem") as ca_file:
        ca_file.write(certificate)
        ca_file.flush()
        with requests.Session() as session:
            session.verify = ca_file.name
            session.headers["Authorization"] = f"Bearer {api_summary['api_token']}"

            def request(method, path, body=None):
                try:
                    response = session.request(
                        method, base_url + path, json=body, timeout=(5, 1800),
                    )
                    response.raise_for_status()
                except requests.RequestException as exc:
                    status = getattr(getattr(exc, "response", None), "status_code", None)
                    raise RuntimeError(f"Deployment bootstrap failed at {method} {path} (HTTP {status or 'unavailable'}).") from exc
                try:
                    return response.json()
                except ValueError as exc:
                    raise RuntimeError(f"Controller returned invalid JSON for {path}.") from exc

            wait_for_api(session, base_url + "/api/v1/health")

            management_pool = request("PUT", "/api/v1/management/pool", {
                "start_ip": config["ip_range_start"],
                "end_ip": config["ip_range_end"],
                "prefix_len": config["cidr"],
                "gateway": config["gateway_ip"],
                "dns": [config["dns_ip"]],
                "bridge": config["interface"],
                "vlan_id": config.get("vlan_id"),
            })
            if not isinstance(management_pool, dict):
                raise RuntimeError("Controller returned an invalid management pool.")
            if management_pool.get("exhausted"):
                Console().print("[yellow]Management pool exhausted; expand it before deploying edge routers.[/yellow]")
            if _has_vtep_configuration(config):
                request("PUT", "/api/v1/vteps/pool", {
                    "cidr": config["vtep_ip_range_cidr"],
                    "vtep_mtu": config.get("vtep_mtu", 9000),
                })
            name = config.get("proxmox_cluster_name")
            if not name:
                return
            cluster = {key: config[key] for key in (
                "proxmox_cluster_ip", "proxmox_port", "proxmox_user",
                "proxmox_tokenname", "proxmox_apikey", "proxmox_ssh_user",
            )}
            cluster["proxmox_ssh_key"] = Path(config["proxmox_ssh_key"]).read_text(encoding="ascii")
            request("PUT", f"/api/v1/proxmox/clusters/{name}", cluster)
            selection = config["auto_enroll_host_list"]
            if not selection:
                return
            nodes = request("GET", f"/api/v1/proxmox/clusters/{name}/nodes")
            selected = _selected_nodes(nodes, selection)
            completed = []
            for node in selected:
                host_id = f"{name}-{node}"
                if len(host_id) > 128:
                    raise RuntimeError(f"Compute host ID '{host_id}' exceeds 128 characters.")
            for node in selected:
                try:
                    request("PUT", f"/api/v1/hosts/{name}-{node}", {
                        "cluster": name, "node": node,
                        "interface": config["vtep_interface"],
                        "vlan_id": config.get("vtep_vlan_id"),
                    })
                except RuntimeError as exc:
                    raise RuntimeError(
                        f"Automatic compute enrollment stopped at '{node}'; completed: "
                        f"{', '.join(completed) or 'none'}. Controller deployment and pool configuration were retained."
                    ) from exc
                completed.append(node)
