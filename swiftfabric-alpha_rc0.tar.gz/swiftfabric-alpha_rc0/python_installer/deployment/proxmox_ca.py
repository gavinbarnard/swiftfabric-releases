"""Bootstrap and verify the Proxmox API trust anchor."""

import base64
import hashlib
import re
import ssl
import tempfile

from deployment.ssh import SSHCommandRunner


class ProxmoxCATrust:
    """Load Proxmox's root CA over pinned SSH and verify cluster consistency."""

    CA_PATH = "/etc/pve/pve-root-ca.pem"
    READ_CA_COMMAND = f"cat {CA_PATH}"

    def __init__(self, host: str, username: str, private_key: str):
        if not host or not username or not private_key:
            raise ValueError("Proxmox host and SSH access settings are required for TLS trust.")

        self.ssh = SSHCommandRunner(
            private_key,
            username,
            "Proxmox CA bootstrap",
        )
        certificate = self._read_ca(host)
        self.fingerprint = self._fingerprint(certificate, host)
        self._ca_file = tempfile.NamedTemporaryFile(
            mode="w",
            encoding="ascii",
            suffix=".pem",
        )
        self._ca_file.write(certificate)
        self._ca_file.flush()
        self.ca_path = self._ca_file.name

    def _read_ca(self, host: str) -> str:
        certificate = self.ssh.run(host, self.READ_CA_COMMAND, timeout=15).strip()
        return certificate + "\n"

    @staticmethod
    def _fingerprint(certificate: str, host: str) -> str:
        pem = certificate.strip()
        if (
            pem.count("-----BEGIN CERTIFICATE-----") != 1
            or pem.count("-----END CERTIFICATE-----") != 1
            or not re.fullmatch(
                r"-----BEGIN CERTIFICATE-----\s+.+?\s+-----END CERTIFICATE-----",
                pem,
                re.DOTALL,
            )
        ):
            raise ValueError(
                f"Invalid Proxmox root CA certificate retrieved from {host}."
            )
        try:
            context = ssl.create_default_context(cadata=pem)
            certificate_der = ssl.PEM_cert_to_DER_cert(pem)
            if isinstance(certificate_der, str):
                certificate_der = base64.b64decode(
                    "".join(certificate_der.split()),
                    validate=True,
                )
        except (ssl.SSLError, ValueError) as exc:
            raise ValueError(
                f"Invalid Proxmox root CA certificate retrieved from {host}: {exc}"
            ) from exc
        if certificate_der not in context.get_ca_certs(binary_form=True):
            raise ValueError(
                f"Proxmox root CA certificate from {host} could not be loaded."
            )
        return hashlib.sha256(certificate_der).hexdigest()

    def verify_cluster_nodes(self, client) -> None:
        """Require every online node to publish the same root CA certificate."""
        response = client.get_nodes()
        nodes = response.get("data") if isinstance(response, dict) else None
        if not isinstance(nodes, list) or not nodes:
            raise ValueError("Proxmox returned an invalid or empty node inventory.")

        online_nodes = []
        seen = set()
        for node in nodes:
            if not isinstance(node, dict):
                raise ValueError("Proxmox returned an invalid node inventory.")
            name = node.get("node")
            status = node.get("status")
            if (
                not isinstance(name, str)
                or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]*", name)
                or name in seen
                or status not in ("online", "offline")
            ):
                raise ValueError("Proxmox returned an invalid node identity or status.")
            seen.add(name)
            if status == "online":
                online_nodes.append(name)

        if not online_nodes:
            raise ValueError("Proxmox has no online nodes for CA verification.")

        for node in online_nodes:
            certificate = self.ssh.run(
                node,
                self.READ_CA_COMMAND,
                timeout=15,
            )
            fingerprint = self._fingerprint(certificate, node)
            if fingerprint != self.fingerprint:
                raise ValueError(
                    f"Proxmox root CA fingerprint mismatch on node {node}: "
                    f"expected {self.fingerprint}, got {fingerprint}."
                )

    def close(self) -> None:
        """Remove temporary local copy of the public CA certificate."""
        self._ca_file.close()
