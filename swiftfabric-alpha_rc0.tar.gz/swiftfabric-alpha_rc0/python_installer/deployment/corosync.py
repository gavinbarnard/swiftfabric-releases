"""Configure and verify a Corosync cluster on deployed controller VMs."""

import ipaddress
import re
import secrets
import time
from typing import Any, Dict, List

from rich.console import Console

from deployment.ssh import SSHCommandRunner


class CorosyncCluster:
    """Install a shared Corosync configuration on a three-node controller set."""

    USERNAME = "ubuntu"
    CLUSTER_NAME = "swiftfabric"
    RETRY_INTERVAL = 5
    VERIFY_TIMEOUT = 120

    def __init__(self, private_key: str):
        self.private_key = private_key
        self.console = Console()
        self.ssh = SSHCommandRunner(
            private_key,
            self.USERNAME,
            "the Corosync cluster",
        )

    def configure_and_verify(
        self,
        deployments: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Configure a three-node cluster and require quorum on every node."""
        if len(deployments) != 3:
            raise ValueError(
                f"Corosync setup requires exactly 3 controller VMs; got {len(deployments)}."
            )

        nodes = []
        seen_ips = set()
        for nodeid, deployment in enumerate(deployments, start=1):
            ip_address = deployment.get("ip_address")
            if not ip_address:
                raise ValueError(
                    f"Controller VM {deployment.get('vmid')} has no IP address."
                )
            try:
                normalized_ip = str(ipaddress.ip_address(ip_address))
            except ValueError as exc:
                raise ValueError(
                    f"Controller VM {deployment.get('vmid')} has invalid IP "
                    f"address '{ip_address}'."
                ) from exc
            if normalized_ip in seen_ips:
                raise ValueError(f"Duplicate controller IP address: {normalized_ip}.")
            seen_ips.add(normalized_ip)
            nodes.append({"nodeid": nodeid, "ip": normalized_ip})

        config = self._render_config(nodes)
        authkey = secrets.token_bytes(128)

        for node in nodes:
            self.console.print(
                f"Waiting for cloud-init package setup on {node['ip']}..."
            )
            self._run_ssh(
                node["ip"],
                "sudo cloud-init status --wait",
                timeout=1800,
            )
            self._run_ssh(
                node["ip"],
                "command -v corosync && command -v corosync-quorumtool "
                "&& command -v corosync-cfgtool",
            )

        for node in nodes:
            self.console.print(
                f"Installing shared Corosync authentication and configuration on "
                f"{node['ip']}..."
            )
            self._run_ssh(
                node["ip"],
                "sudo install -D -o root -g root -m 0400 /dev/stdin "
                "/etc/corosync/authkey",
                input_data=authkey,
            )
            self._run_ssh(
                node["ip"],
                "sudo install -D -o root -g root -m 0644 /dev/stdin "
                "/etc/corosync/corosync.conf",
                input_data=config.encode("utf-8"),
            )

        for node in nodes:
            self.console.print(f"Enabling Corosync on {node['ip']}...")
            self._run_ssh(
                node["ip"],
                "sudo systemctl enable corosync && sudo systemctl restart corosync",
                timeout=60,
            )

        self._wait_for_cluster(nodes)
        return {
            "cluster_name": self.CLUSTER_NAME,
            "nodes": [node["ip"] for node in nodes],
            "quorate": True,
        }

    @classmethod
    def _render_config(cls, nodes: List[Dict[str, Any]]) -> str:
        """Build a Corosync 3 KNET configuration for the supplied nodes."""
        node_config = "\n".join(
            "    node {\n"
            f"        ring0_addr: {node['ip']}\n"
            f"        nodeid: {node['nodeid']}\n"
            "    }"
            for node in nodes
        )
        return (
            "totem {\n"
            "    version: 2\n"
            f"    cluster_name: {cls.CLUSTER_NAME}\n"
            "    transport: knet\n"
            "}\n"
            "nodelist {\n"
            f"{node_config}\n"
            "}\n"
            "quorum {\n"
            "    provider: corosync_votequorum\n"
            f"    expected_votes: {len(nodes)}\n"
            "}\n"
        )

    def _wait_for_cluster(self, nodes: List[Dict[str, Any]]) -> None:
        deadline = time.monotonic() + self.VERIFY_TIMEOUT
        last_errors = {}
        while True:
            pending = []
            for node in nodes:
                try:
                    self._verify_node(node, len(nodes))
                except (RuntimeError, TimeoutError) as exc:
                    pending.append(node["ip"])
                    last_errors[node["ip"]] = str(exc)

            if not pending:
                return

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                details = "; ".join(
                    f"{ip}: {last_errors[ip]}" for ip in pending
                )
                raise TimeoutError(
                    f"Corosync did not reach a healthy three-node quorum within "
                    f"{self.VERIFY_TIMEOUT} seconds. {details}"
                )
            time.sleep(min(self.RETRY_INTERVAL, remaining))

    def _verify_node(self, node: Dict[str, Any], expected_nodes: int) -> None:
        ip_address = node["ip"]
        self._run_ssh(ip_address, "systemctl is-active --quiet corosync")
        status = self._run_ssh(ip_address, "sudo -n corosync-quorumtool -s")
        if not re.search(r"(?m)^\s*Quorate:\s*Yes\s*$", status, re.IGNORECASE):
            raise RuntimeError(f"Corosync on {ip_address} is not quorate.")
        if not re.search(
            rf"(?m)^\s*Expected votes:\s*{expected_nodes}\s*$",
            status,
        ):
            raise RuntimeError(
                f"Corosync on {ip_address} does not expect {expected_nodes} votes."
            )
        if not re.search(
            rf"(?m)^\s*Total votes:\s*{expected_nodes}\s*$",
            status,
        ):
            raise RuntimeError(
                f"Corosync on {ip_address} does not see all {expected_nodes} votes."
            )

        membership = self._run_ssh(ip_address, "sudo -n corosync-quorumtool -l")
        member_ids = {
            int(line.split()[0])
            for line in membership.splitlines()
            if line.split() and line.split()[0].isdigit()
        }
        expected_ids = set(range(1, expected_nodes + 1))
        if not expected_ids.issubset(member_ids):
            raise RuntimeError(
                f"Corosync on {ip_address} sees node IDs {sorted(member_ids)}, "
                f"expected {sorted(expected_ids)}."
            )

        link_status = self._run_ssh(ip_address, "sudo -n corosync-cfgtool -s")
        if "connected" not in link_status.lower():
            raise RuntimeError(f"Corosync KNET link on {ip_address} is not connected.")

    def _run_ssh(
        self,
        ip_address: str,
        remote_command: str,
        timeout: int = 15,
        input_data: bytes = None,
    ) -> str:
        """Run an SSH command without using or updating known-hosts files."""
        return self.ssh.run(
            ip_address,
            remote_command,
            timeout=timeout,
            input_data=input_data,
        )
