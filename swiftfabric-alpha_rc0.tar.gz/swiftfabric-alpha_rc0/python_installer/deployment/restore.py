"""Coordinated offline restore into three clean replacement controllers."""

import hashlib
import ipaddress
import json
import re
import time
import uuid
import xml.etree.ElementTree as ET

from deployment.ssh import SSHCommandRunner


WORKER = "/usr/libexec/swiftfabric-restore-controller"
API_SERVICE = "swiftfabric-api-service.service"
VALKEY_SERVICE = "swiftfabric-valkey@4999.service"


class ControllerRestore:
    """Keep decrypted backup and CA private material on controllers."""

    def __init__(self, config, ssh=None):
        self.config = config
        self.ssh = ssh or SSHCommandRunner(
            config["controller_priv_key"], "ubuntu", "SwiftFabric offline disaster recovery",
        )
        first = ipaddress.IPv4Address(config["ip_range_start"])
        self.nodes = [str(first + index) for index in range(3)]
        self.run_id = uuid.uuid4().hex
        self.staged = {}

    def worker(self, node, operation, **options):
        request = {"operation": operation}
        if operation != "capabilities":
            request.update(run_id=self.run_id, primary_ip=self.nodes[0])
        request.update(options)
        if operation == "plan" and node in self.staged:
            request["staging_id"] = self.staged[node]["staging_id"]
        output = self.ssh.run(
            node, f"sudo -n {WORKER}", input_data=json.dumps(request).encode(), timeout=1800,
        )
        result = json.loads(output)
        if not isinstance(result, dict) or result.get("complete") is not True:
            raise RuntimeError(f"Controller {node} did not complete offline restore operation {operation}.")
        return result

    def capabilities(self):
        for node in self.nodes:
            result = self.worker(node, "capabilities")
            if result.get("protocol_version") != 1 or result.get("supported_schema") != 3:
                raise RuntimeError(f"Controller {node} lacks the supported offline restore worker.")

    def stage(self, archive, passphrase):
        """Rust validates authenticated archive; no decrypted payload crosses SSH."""
        if not archive.startswith(b"SWFTBAK1") or len(archive) > 64 * 1024 * 1024:
            raise ValueError("Invalid or oversized SwiftFabric backup.")
        expected = hashlib.sha256(archive).hexdigest()
        remote = f"/var/lib/swiftfabric/restore-inputs/{self.run_id}.sfbak"
        for node in self.nodes:
            self.ssh.run(
                node,
                "sudo -n install -d -o root -g root -m 0700 /var/lib/swiftfabric/restore-inputs && "
                f"sudo -n install -o root -g root -m 0600 /dev/stdin {remote}",
                input_data=archive, timeout=120,
            )
            checksum = self.ssh.run(node, f"sudo -n sha256sum {remote}").split()
            if not checksum or checksum[0] != expected:
                raise RuntimeError(f"Controller {node} received a changed recovery archive.")
            output = self.ssh.run(
                node,
                "sudo -n /usr/bin/swiftfabric-api-service "
                "--config /etc/swiftfabric/api-service.json "
                f"--restore-stage-archive {remote}",
                input_data=passphrase.encode("utf-8") + b"\n", timeout=1800,
            )
            report = json.loads(output)
            if (not isinstance(report, dict) or report.get("status") != "staged"
                    or report.get("schema_version") != 3
                    or not isinstance(report.get("staging_id"), str)
                    or not re.fullmatch(r"[a-f0-9]{32}", report.get("staging_id", ""))
                    or not isinstance(report.get("ca_sha256_fingerprint"), str)
                    or not re.fullmatch(r"[a-f0-9]{64}", report.get("ca_sha256_fingerprint", ""))
                    or report.get("controller_ips") != self.nodes):
                raise RuntimeError(f"Controller {node} did not validate a schema-3 recovery archive.")
            self.staged[node] = report
        fingerprints = {report.get("ca_sha256_fingerprint") for report in self.staged.values()}
        if len(fingerprints) != 1:
            raise RuntimeError("Controllers did not stage one consistent backup CA.")
        return self.staged[self.nodes[0]]

    def maintenance(self, enabled):
        value = "true" if enabled else "false"
        self.ssh.run(self.nodes[0], f"sudo -n pcs property set maintenance-mode={value}", timeout=60)
        for node in self.nodes:
            deadline = time.monotonic() + 60
            while True:
                observed = self.ssh.run(node, "sudo -n cibadmin --query", timeout=60)
                try:
                    properties = ET.fromstring(observed).findall(".//cluster_property_set/nvpair")
                except ET.ParseError as exc:
                    raise RuntimeError(f"Controller {node} returned invalid Pacemaker configuration.") from exc
                values = [item.get("value") for item in properties if item.get("name") == "maintenance-mode"]
                if values == [value]:
                    break
                if time.monotonic() >= deadline:
                    raise RuntimeError(f"Controller {node} did not converge to maintenance-mode={value}.")
                time.sleep(1)

    def stop(self):
        for node in self.nodes:
            self.ssh.run(
                node,
                "sudo -n systemctl stop swiftfabric-tls-renew.timer swiftfabric-tls-renew.service nginx.service "
                f"{API_SERVICE} {VALKEY_SERVICE} && "
                f"! systemctl is-active --quiet {API_SERVICE} && "
                f"! systemctl is-active --quiet {VALKEY_SERVICE} && "
                "! systemctl is-active --quiet swiftfabric-tls-renew.service",
                timeout=120,
            )

    def start(self):
        for node in self.nodes:
            self.ssh.run(
                node, f"sudo -n systemctl start {VALKEY_SERVICE} && "
                f"systemctl is-active --quiet {VALKEY_SERVICE}", timeout=120,
            )
        for node in self.nodes:
            self.ssh.run(
                node,
                f"sudo -n systemctl start {API_SERVICE} && "
                "sudo -n nginx -t && sudo -n systemctl start nginx.service swiftfabric-tls-renew.timer && "
                f"systemctl is-active --quiet {API_SERVICE} && systemctl is-active --quiet nginx.service",
                timeout=180,
            )

    def restore(self):
        if set(self.staged) != set(self.nodes):
            raise RuntimeError("Stage and validate the backup on all three controllers before restore.")
        for node in self.nodes:
            self.worker(node, "plan")
        fenced = False
        mutated = False
        try:
            fenced = True
            self.maintenance(True)
            self.stop()
            for node in self.nodes:
                # Record possible mutation before SSH: connection loss may hide committed writes.
                mutated = True
                self.worker(node, "apply")
            self.worker(self.nodes[0], "cib")
            self.start()
            for node in self.nodes:
                self.worker(node, "verify")
            self.maintenance(False)
            fenced = False
        except (OSError, ValueError, RuntimeError) as failure:
            rollback_problems = []
            if fenced:
                try:
                    # The failed operation may have cleared maintenance before SSH lost its reply.
                    self.maintenance(True)
                    self.stop()
                except (OSError, RuntimeError) as exc:
                    rollback_problems.append(f"fencing: {type(exc).__name__}")
                if not rollback_problems:
                    if mutated:
                        for node in self.nodes:
                            try:
                                self.worker(node, "rollback")
                            except (OSError, ValueError, RuntimeError) as exc:
                                rollback_problems.append(f"{node}: {type(exc).__name__}")
                    if not rollback_problems:
                        try:
                            if mutated:
                                self.worker(self.nodes[0], "rollback-cib")
                            self.start()
                            self.maintenance(False)
                            fenced = False
                        except (OSError, ValueError, RuntimeError) as exc:
                            rollback_problems.append(f"restart: {type(exc).__name__}")
            state = "controllers remain fenced; manual recovery required" if fenced else "fresh target restored"
            detail = "; ".join(rollback_problems)
            raise RuntimeError(
                f"Offline restore failed ({type(failure).__name__}); {state}."
                + (f" Rollback errors: {detail}." if detail else "")
            ) from failure
        return {
            "complete": True, "run_id": self.run_id, "controllers": self.nodes,
            "ca_sha256_fingerprint": self.staged[self.nodes[0]]["ca_sha256_fingerprint"],
            "scope": "controller state and CA restored; fresh agent heartbeats and traffic acceptance still required",
        }
