"""Prepare controller disks and update Ubuntu before cluster setup."""

from typing import Any, Dict, List

from rich.console import Console

from deployment.ssh import SSHCommandRunner
from deployment.validation import DeploymentValidator


class ControllerPreparation:
    """Grow controller disks, apply OS upgrades, and install cluster packages."""

    TARGET_DISK_SIZE_GIB = 100

    def __init__(self, deployment, private_key: str):
        self.deployment = deployment
        self.private_key = private_key
        self.ssh = SSHCommandRunner(
            private_key,
            "ubuntu",
            "controller disk and package preparation",
        )
        self.validator = DeploymentValidator(deployment.client)
        self.console = Console()

    def prepare(self, controllers: List[Dict[str, Any]]) -> None:
        """Prepare each guest completely before any cluster services are set up."""
        if len(controllers) != 3:
            raise ValueError(
                f"Controller preparation requires exactly 3 VMs; got {len(controllers)}."
            )

        validated_controllers = []
        for controller in controllers:
            ip_address = controller.get("ip_address")
            node = controller.get("node")
            vmid = controller.get("vmid")
            if not ip_address or not node or vmid is None:
                raise ValueError(
                    f"Controller deployment details are incomplete: {controller}."
                )
            validated_controllers.append((ip_address, node, vmid))

        for ip_address, node, vmid in validated_controllers:
            self.console.print(
                f"Resizing VM {vmid} on {node} to at least "
                f"{self.TARGET_DISK_SIZE_GIB} GiB through Proxmox..."
            )
            self.deployment.vm.resize_disk(
                node,
                vmid,
                disk="scsi0",
                target_size_gib=self.TARGET_DISK_SIZE_GIB,
            )

            self.console.print(
                f"Growing the root partition and filesystem on {ip_address}..."
            )
            self.ssh.run(
                ip_address,
                "sudo cloud-init status --wait",
                timeout=1800,
            )
            self.ssh.run(
                ip_address,
                "sudo growpart /dev/sda 1 && "
                "sudo resize2fs /dev/sda1",
                timeout=300,
            )

            self.console.print(f"Updating Ubuntu packages on {ip_address}...")
            self.ssh.run(
                ip_address,
                "sudo apt-get update && "
                "sudo DEBIAN_FRONTEND=noninteractive apt-get -y upgrade",
                timeout=3600,
            )
            reboot_status = self.ssh.run(
                ip_address,
                "if [ -f /var/run/reboot-required ]; then "
                "printf REBOOT_REQUIRED; else printf NO_REBOOT_REQUIRED; fi",
            )
            if reboot_status.strip() == "REBOOT_REQUIRED":
                self.console.print(
                    f"Rebooting {ip_address} to finish package upgrades..."
                )
                self.ssh.run(
                    ip_address,
                    "sudo systemd-run --unit=swiftfabric-post-upgrade-reboot "
                    "--collect --on-active=2s /usr/bin/systemctl reboot",
                )
                self.validator.wait_for_ssh_disconnect(
                    ip_address,
                    self.private_key,
                )
                self.validator.wait_for_ping(ip_address)
                self.validator.wait_for_ssh(
                    ip_address,
                    self.private_key,
                    username="ubuntu",
                )

        for ip_address, node, vmid in validated_controllers:
            self.console.print(
                f"Installing Corosync, Pacemaker, and pcs from Ubuntu packages "
                f"on {ip_address}..."
            )
            self.ssh.run(
                ip_address,
                "sudo DEBIAN_FRONTEND=noninteractive apt-get install -y "
                "corosync pacemaker pcs iputils-ping iputils-arping",
                timeout=1800,
            )
            self.ssh.run(
                ip_address,
                "command -v corosync && command -v corosync-quorumtool && "
                "command -v corosync-cfgtool && command -v crm_mon && "
                "command -v arping",
            )
