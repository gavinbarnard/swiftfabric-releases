"""Build and deploy the controller-side SwiftFabric API service."""

import base64
import binascii
import hashlib
import ipaddress
import json
import os
import re
import secrets
import shlex
import ssl
import subprocess
import tarfile
import tempfile
import uuid
from io import BytesIO
from pathlib import Path
from typing import Any, Dict, List

from deployment.ssh import SSHCommandRunner


LOCAL_API_PORT = 8080
CA_CERT_PATH = "/etc/swiftfabric/swiftfabric-ca.crt"
CA_KEY_PATH = "/var/lib/swiftfabric/ca/ca.key"
CA_CERTIFICATE_PATH = "/var/lib/swiftfabric/ca/ca.crt"
CA_SERIAL_PATH = "/var/lib/swiftfabric/ca/ca.srl"
CA_TRUST_ARCHIVE_DIR = "/var/lib/swiftfabric/ca/trust-anchors"
SERVER_KEY_PATH = "/etc/swiftfabric/tls/server.key"
SERVER_CERTIFICATE_PATH = "/etc/swiftfabric/tls/server.crt"
SEGMENT_MIN = 5000
SEGMENT_MAX = 50000


class ApiServiceDeployment:
    """Build a Debian package remotely and deploy it to controller VMs."""

    def __init__(self, private_key: str, package_path: Path = None):
        from rich.console import Console

        self.ssh = SSHCommandRunner(
            private_key,
            "ubuntu",
            "the SwiftFabric API service",
        )
        self.console = Console()
        self.project_root = Path(__file__).resolve().parents[2]
        self.package_path = Path(package_path) if package_path else None
        self._package_tempdir = None
        self._ca_trust_bundle = b""

    def build(self, version: str = "0.1.0") -> Path:
        """Build and retrieve the Debian package on the configured buildbox.

        This method is used by the separate package-build command, never by
        controller installation.
        """
        if not re.fullmatch(r"[A-Za-z0-9.+~:-]{1,128}", version):
            raise ValueError("package version contains unsupported characters")
        self.package_path = self._build_on_buildbox(version)
        return self.package_path

    def build_and_deploy(
        self,
        deployments: List[Dict[str, Any]],
        node_names: List[str],
        api_vip: str,
    ) -> Dict[str, Any]:
        """Install the prebuilt package, configure all controllers, and start the API."""
        nodes = self._get_nodes(deployments)
        if (
            len(node_names) != 3
            or len(set(node_names)) != 3
            or any(
                not name
                or not all(char.isalnum() or char in "-." for char in name)
                for name in node_names
            )
        ):
            raise ValueError("Exactly three unique valid Pacemaker node names are required.")
        try:
            api_vip = str(ipaddress.IPv4Address(api_vip))
        except ipaddress.AddressValueError as exc:
            raise ValueError("The API VIP must be a valid IPv4 address.") from exc
        package_path = self.package_path
        if package_path is None:
            package_path = self.find_package(self.project_root / "packages")
            self.package_path = package_path
        api_token = "sfk_" + secrets.token_hex(32)
        service_tokens = ["sfc_" + secrets.token_hex(32) for _ in nodes]
        controller_token_hashes = [
            hashlib.sha256(token.encode("ascii")).hexdigest() for token in service_tokens
        ]
        nft_rules = self._render_firewall(nodes)
        ca_certificate = self._provision_tls(nodes, api_vip)

        for node_id, ip_address in enumerate(nodes):
            self.console.print(
                f"Installing SwiftFabric API service on {ip_address}..."
            )
            self.ssh.run(
                ip_address,
                self._prepare_nginx_command()
                + "sudo systemctl disable --now nginx.service && "
                "sudo rm -f /etc/nginx/sites-enabled/default",
                timeout=300,
            )
            config = json.dumps({
                "node_id": node_id,
                "node_ips": nodes,
                "node_names": node_names,
                "api_vip": api_vip,
                "api_token": service_tokens[node_id],
                "initial_admin_token_hash": hashlib.sha256(api_token.encode("ascii")).hexdigest(),
                "controller_token_hashes": controller_token_hashes,
                "state_path": "/var/lib/swiftfabric/segments.json",
            }, separators=(",", ":")).encode("utf-8")
            self._install(
                ip_address,
                package_path.read_bytes(),
                "sudo install -D -o root -g root -m 0644 /dev/stdin "
                "/tmp/swiftfabric-api-service.deb",
            )
            self.ssh.run(
                ip_address,
                "sudo dpkg -i /tmp/swiftfabric-api-service.deb && "
                "sudo rm -f /tmp/swiftfabric-api-service.deb",
                timeout=300,
            )
            self._install(
                ip_address,
                config,
                "sudo install -D -o root -g root -m 0600 /dev/stdin "
                "/etc/swiftfabric/api-service.json",
            )
            self._install(
                ip_address,
                ca_certificate,
                "sudo install -D -o root -g root -m 0644 /dev/stdin "
                + CA_CERT_PATH,
            )
            self._install(
                ip_address,
                (api_token + "\n").encode("ascii"),
                "sudo install -D -o root -g root -m 0400 /dev/stdin "
                "/etc/swiftfabric/segment-manager.token",
            )
            self._install(
                ip_address,
                (service_tokens[node_id] + "\n").encode("ascii"),
                "sudo install -D -o root -g root -m 0400 /dev/stdin "
                "/etc/swiftfabric/controller-service.token",
            )
            self._install(
                ip_address,
                nft_rules.encode("utf-8"),
                "sudo install -D -o root -g root -m 0644 /dev/stdin "
                "/etc/swiftfabric/firewall.nft",
            )
            self._install(
                ip_address,
                self._render_nginx_config().encode("utf-8"),
                "sudo install -D -o root -g root -m 0644 /dev/stdin "
                "/etc/nginx/sites-available/swiftfabric-api",
            )
            self._install(
                ip_address,
                self._render_nginx_service_override().encode("utf-8"),
                "sudo install -D -o root -g root -m 0644 /dev/stdin "
                "/etc/systemd/system/nginx.service.d/swiftfabric-upstream.conf",
            )
            self.ssh.run(
                ip_address,
                "sudo install -d -o root -g valkey -m 0750 "
                "/etc/swiftfabric/valkey && "
                "sudo install -d -o root -g valkey -m 0750 /var/lib/swiftfabric && "
                "sudo systemctl disable --now valkey-server.service && "
                "sudo sysctl --system && "
                "sudo systemctl daemon-reload && "
                "sudo systemctl enable --now swiftfabric-controller-tuning.service && "
                "sudo systemctl enable --now swiftfabric-segment-firewall.service && "
                "sudo systemctl enable --now swiftfabric-api-service.service && "
                "sudo systemctl restart swiftfabric-api-service.service && "
                "sudo ln -sfn /etc/nginx/sites-available/swiftfabric-api "
                "/etc/nginx/sites-enabled/swiftfabric-api && "
                "sudo nginx -t && sudo systemctl enable nginx.service && "
                "sudo systemctl restart nginx.service && "
                "sudo systemctl enable --now swiftfabric-tls-renew.timer && "
                "sudo update-ca-certificates && "
                "systemctl is-active --quiet swiftfabric-segment-firewall.service && "
                "systemctl is-active --quiet swiftfabric-api-service.service && "
                "systemctl is-active --quiet nginx.service && "
                "test -z \"$(ss -H -lnt 'sport = :80')\" && "
                "curl --fail --silent --show-error --max-time 5 "
                f"--cacert {CA_CERT_PATH} --resolve {ip_address}:443:127.0.0.1 "
                f"https://{ip_address}/api/v1/health",
                timeout=120,
            )

        setup_body = json.dumps({"primary_ip": nodes[0]}, separators=(",", ":"))
        self.ssh.run(
            nodes[0],
            "curl --fail-with-body --silent --show-error -X POST "
            "-H "
            + shlex.quote(f"Authorization: Bearer {service_tokens[0]}")
            + " -H 'Content-Type: application/json' --data "
            + shlex.quote(setup_body)
            + f" http://127.0.0.1:{LOCAL_API_PORT}/api/v1/provisioning",
            timeout=300,
        )

        return {
            "nodes": nodes,
            "api_url": f"https://{api_vip}/api/v1/segments",
            "api_token": api_token,
            "ca_fingerprint_sha256": self._ca_fingerprint,
            "ca_certificate_path": CA_CERT_PATH,
            "ca_certificate": ca_certificate.decode("ascii"),
            "token_path": "/etc/swiftfabric/segment-manager.token",
            "minimum_segment_id": SEGMENT_MIN,
            "maximum_segment_id": SEGMENT_MAX,
        }

    def _get_nodes(self, deployments: List[Dict[str, Any]]) -> List[str]:
        if len(deployments) != 3:
            raise ValueError(
                f"API service deployment requires exactly 3 controllers; "
                f"got {len(deployments)}."
            )
        nodes = []
        for deployment in deployments:
            ip_address = deployment.get("ip_address")
            if not ip_address:
                raise ValueError(
                    f"Controller VM {deployment.get('vmid')} has no IP address."
                )
            nodes.append(str(ip_address))
        if len(set(nodes)) != len(nodes):
            raise ValueError("Controller IP addresses must be unique.")
        try:
            nodes = [str(ipaddress.IPv4Address(address)) for address in nodes]
        except ipaddress.AddressValueError as exc:
            raise ValueError("Controller addresses must be valid IPv4 addresses.") from exc
        return nodes

    def _provision_tls(self, nodes: List[str], api_vip: str) -> bytes:
        first = nodes[0]
        ca_state_command = (
            "install -d -o root -g root -m 0700 /var/lib/swiftfabric/ca "
            + CA_TRUST_ARCHIVE_DIR
            + "; "
            "if [ -e " + CA_CERTIFICATE_PATH + " ] || [ -e " + CA_KEY_PATH + " ]; then "
            "test -s " + CA_CERTIFICATE_PATH + " && test -s " + CA_KEY_PATH + " || "
            "{ echo \"incomplete controller CA state; refusing replacement\" >&2; exit 1; }; "
            "test \"$(stat -c '%u:%a' " + CA_KEY_PATH + ")\" = '0:600'; "
            "openssl verify -no_check_time -CAfile " + CA_CERTIFICATE_PATH + " "
            + CA_CERTIFICATE_PATH + "; "
            "openssl x509 -in " + CA_CERTIFICATE_PATH
            + " -noout -ext basicConstraints | grep -F 'CA:TRUE'; "
            "openssl x509 -in " + CA_CERTIFICATE_PATH
            + " -noout -ext keyUsage | grep -F 'Certificate Sign'; "
            "test \"$(openssl pkey -in " + CA_KEY_PATH
            + " -pubout -outform DER | sha256sum | cut -d' ' -f1)\" = "
            "\"$(openssl x509 -in " + CA_CERTIFICATE_PATH
            + " -pubkey -noout | openssl pkey -pubin -outform DER | "
            "sha256sum | cut -d' ' -f1)\"; "
            "if ! openssl x509 -in " + CA_CERTIFICATE_PATH
            + " -checkend 2592000 -noout >/dev/null 2>&1; then "
            "old_fingerprint=$(openssl x509 -in " + CA_CERTIFICATE_PATH
            + " -noout -fingerprint -sha256 | cut -d= -f2 | tr -d ':' | tr '[:upper:]' '[:lower:]'); "
            "case \"$old_fingerprint\" in *[!a-f0-9]*|'') "
            "echo \"invalid controller CA fingerprint; refusing rotation\" >&2; exit 1;; esac; "
            "old_archive=" + CA_TRUST_ARCHIVE_DIR
            + "/swiftfabric-deployment-ca-${old_fingerprint}.crt; "
            "if [ -e \"$old_archive\" ] && ! cmp -s "
            + CA_CERTIFICATE_PATH
            + " \"$old_archive\"; then "
            "{ echo \"controller CA archive conflicts with active certificate\" >&2; exit 1; }; fi; "
            "install -o root -g root -m 0644 " + CA_CERTIFICATE_PATH
            + " \"$old_archive\"; "
            "rm -f " + CA_KEY_PATH + ".new " + CA_CERTIFICATE_PATH + ".new; "
            "umask 077; "
            "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:3072 "
            "-out " + CA_KEY_PATH + ".new; "
            "openssl req -x509 -new -key " + CA_KEY_PATH + ".new -sha256 -days 3650 "
            "-subj \"/CN=SwiftFabric Deployment CA\" "
            "-addext \"basicConstraints=critical,CA:TRUE,pathlen:0\" "
            "-addext \"keyUsage=critical,keyCertSign,cRLSign\" "
            "-addext \"subjectKeyIdentifier=hash\" "
            "-out " + CA_CERTIFICATE_PATH + ".new; "
            "chmod 0600 " + CA_KEY_PATH + ".new; chmod 0644 "
            + CA_CERTIFICATE_PATH + ".new; "
            "mv -f " + CA_KEY_PATH + ".new " + CA_KEY_PATH + "; "
            "mv -f " + CA_CERTIFICATE_PATH + ".new " + CA_CERTIFICATE_PATH + "; "
            "fi; "
            "else "
            "umask 077; "
            "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:3072 "
            "-out " + CA_KEY_PATH + "; "
            "openssl req -x509 -new -key " + CA_KEY_PATH + " -sha256 -days 3650 "
            "-subj \"/CN=SwiftFabric Deployment CA\" "
            "-addext \"basicConstraints=critical,CA:TRUE,pathlen:0\" "
            "-addext \"keyUsage=critical,keyCertSign,cRLSign\" "
            "-addext \"subjectKeyIdentifier=hash\" "
            "-out " + CA_CERTIFICATE_PATH + "; "
            "chmod 0600 " + CA_KEY_PATH + "; chmod 0644 " + CA_CERTIFICATE_PATH + "; "
            "fi; "
            "test \"$(stat -c '%u:%a' " + CA_KEY_PATH + ")\" = '0:600'; "
            "openssl verify -CAfile " + CA_CERTIFICATE_PATH + " "
            + CA_CERTIFICATE_PATH + "; "
            "openssl x509 -in " + CA_CERTIFICATE_PATH
            + " -checkend 2592000 -noout; "
            "openssl x509 -in " + CA_CERTIFICATE_PATH
            + " -noout -ext basicConstraints | grep -F 'CA:TRUE'; "
            "openssl x509 -in " + CA_CERTIFICATE_PATH
            + " -noout -ext keyUsage | grep -F 'Certificate Sign'; "
            "test \"$(openssl pkey -in " + CA_KEY_PATH
            + " -pubout -outform DER | sha256sum | cut -d' ' -f1)\" = "
            "\"$(openssl x509 -in " + CA_CERTIFICATE_PATH
            + " -pubkey -noout | openssl pkey -pubin -outform DER | "
            "sha256sum | cut -d' ' -f1)\""
        )
        self.ssh.run(
            first,
            "sudo bash -eu -c " + shlex.quote(ca_state_command),
            timeout=120,
        )
        ca_certificate = self.ssh.run(
            first, "sudo cat " + CA_CERTIFICATE_PATH, timeout=15
        ).encode("ascii")
        fingerprint_output = self.ssh.run(
            first,
            "sudo openssl x509 -in " + CA_CERTIFICATE_PATH
            + " -noout -fingerprint -sha256",
            timeout=15,
        ).strip()
        fingerprint = fingerprint_output.rsplit("=", 1)[-1].replace(":", "").lower()
        if not re.fullmatch(r"[a-f0-9]{64}", fingerprint):
            raise RuntimeError("Controller CA returned an invalid SHA-256 fingerprint.")
        self._ca_fingerprint = fingerprint
        ca_key = self.ssh.run(first, "sudo cat " + CA_KEY_PATH, timeout=15).encode("ascii")
        archive_listing = self.ssh.run(
            first,
            "sudo find " + CA_TRUST_ARCHIVE_DIR
            + " -maxdepth 1 -type f -name 'swiftfabric-deployment-ca-*.crt' "
            "-printf '%f\\n' | sort",
            timeout=15,
        )
        archived_certificates = []
        archive_fingerprints = set()
        for filename in archive_listing.splitlines():
            if not re.fullmatch(r"swiftfabric-deployment-ca-[a-f0-9]{64}\.crt", filename):
                raise RuntimeError("Controller CA trust archive contains an invalid filename.")
            archived_fingerprint = filename.removeprefix(
                "swiftfabric-deployment-ca-"
            ).removesuffix(".crt")
            certificate = self.ssh.run(
                first,
                "sudo cat " + CA_TRUST_ARCHIVE_DIR + "/" + filename,
                timeout=15,
            ).encode("ascii")
            try:
                der = ssl.PEM_cert_to_DER_cert(certificate.decode("ascii"))
                if isinstance(der, str):
                    der = base64.b64decode(der, validate=True)
            except (binascii.Error, UnicodeDecodeError, ValueError) as exc:
                raise RuntimeError(
                    f"Archived controller CA {filename} is not valid PEM."
                ) from exc
            if hashlib.sha256(der).hexdigest().upper() != archived_fingerprint.upper():
                raise RuntimeError(
                    f"Archived controller CA {filename} has a fingerprint mismatch."
                )
            archive_fingerprints.add(archived_fingerprint.upper())
            archived_certificates.append(certificate)
        self._ca_trust_bundle = b"".join(archived_certificates) + ca_certificate

        for address in nodes:
            observed = self.ssh.run(
                address,
                "if sudo test -s " + CA_CERTIFICATE_PATH + "; then "
                "sudo openssl x509 -in " + CA_CERTIFICATE_PATH
                + " -noout -fingerprint -sha256; else echo missing; fi",
                timeout=15,
            ).strip()
            replacing_archived_ca = False
            if observed != "missing":
                current = observed.rsplit("=", 1)[-1].replace(":", "").lower()
                if current != fingerprint:
                    if current.upper() not in archive_fingerprints:
                        raise RuntimeError(
                            f"Controller CA identity on {address} differs from the "
                            "active and archived cluster CAs."
                        )
                    replacing_archived_ca = True
            else:
                self._install(
                    address,
                    ca_certificate,
                    "sudo install -D -o root -g root -m 0644 /dev/stdin "
                    + CA_CERTIFICATE_PATH,
                )
            key_matches = "missing"
            if not replacing_archived_ca:
                key_matches = self.ssh.run(
                    address,
                    "if ! sudo test -s " + CA_KEY_PATH + "; then echo missing; "
                    "elif test \"$(sudo openssl pkey -in " + CA_KEY_PATH
                    + " -pubout -outform DER | sha256sum | cut -d' ' -f1)\" = "
                    "\"$(sudo openssl x509 -in " + CA_CERTIFICATE_PATH
                    + " -pubkey -noout | openssl pkey -pubin -outform DER | "
                    "sha256sum | cut -d' ' -f1)\"; then echo valid; else echo mismatch; fi",
                    timeout=20,
                ).strip()
            if key_matches == "missing":
                self._install(
                    address,
                    ca_key,
                    "sudo install -D -o root -g root -m 0600 /dev/stdin "
                    + CA_KEY_PATH,
                )
            elif key_matches != "valid":
                raise RuntimeError(f"Could not verify the controller CA key on {address}.")
            self.ssh.run(
                address,
                "sudo chown root:root " + CA_KEY_PATH
                + " && sudo chmod 0600 " + CA_KEY_PATH
                + " && test \"$(sudo stat -c '%u:%a' " + CA_KEY_PATH
                + ")\" = '0:600'",
                timeout=20,
            )
            self.ssh.run(
                address,
                "sudo install -D -o root -g root -m 0644 "
                + CA_CERTIFICATE_PATH
                + " /usr/local/share/ca-certificates/swiftfabric-deployment-ca-"
                + hashlib.sha256(ca_certificate).hexdigest()
                + ".crt && "
                "sudo update-ca-certificates",
                timeout=60,
            )

        for index, address in enumerate(nodes):
            valid_leaf = self.ssh.run(
                address,
                "if sudo test -s " + SERVER_CERTIFICATE_PATH + " && "
                "sudo test -s " + SERVER_KEY_PATH + " && "
                "test \"$(sudo stat -c '%u:%a' " + SERVER_KEY_PATH + ")\" = '0:600' && "
                "sudo openssl verify -CAfile " + CA_CERTIFICATE_PATH + " "
                + SERVER_CERTIFICATE_PATH + " >/dev/null 2>&1 && "
                "sudo openssl x509 -in " + SERVER_CERTIFICATE_PATH
                + " -checkend 2592000 -noout >/dev/null 2>&1 && "
                "sudo openssl x509 -in " + SERVER_CERTIFICATE_PATH
                + " -checkip " + address + " -noout >/dev/null 2>&1 && "
                "sudo openssl x509 -in " + SERVER_CERTIFICATE_PATH
                + " -checkip " + api_vip + " -noout >/dev/null 2>&1 && "
                "test \"$(sudo openssl x509 -in " + SERVER_CERTIFICATE_PATH
                + " -pubkey -noout | openssl pkey -pubin -outform DER | "
                "sha256sum | cut -d' ' -f1)\" = "
                "\"$(sudo openssl pkey -in " + SERVER_KEY_PATH
                + " -pubout -outform DER | sha256sum | cut -d' ' -f1)\"; "
                "then echo valid; else echo renew; fi",
                timeout=20,
            ).strip()
            if valid_leaf == "valid":
                continue
            csr = self.ssh.run(
                address,
                "sudo bash -eu -c '"
                "install -d -o root -g root -m 0700 /etc/swiftfabric/tls; "
                "if [ ! -s " + SERVER_KEY_PATH + " ]; then "
                "umask 077; openssl genpkey -algorithm RSA "
                "-pkeyopt rsa_keygen_bits:3072 -out " + SERVER_KEY_PATH + "; fi; "
                "chmod 0600 " + SERVER_KEY_PATH + "; "
                "openssl req -new -key " + SERVER_KEY_PATH
                + " -subj \"/CN=" + address + "\" -out /tmp/swiftfabric-controller.csr; "
                "cat /tmp/swiftfabric-controller.csr; "
                "rm -f /tmp/swiftfabric-controller.csr'",
                timeout=60,
            )
            extensions = (
                "basicConstraints=critical,CA:FALSE\n"
                "keyUsage=critical,digitalSignature,keyEncipherment\n"
                "extendedKeyUsage=serverAuth\n"
                f"subjectAltName=IP:{address},IP:{api_vip}\n"
            ).encode("ascii")
            ext_path = f"/tmp/swiftfabric-controller-{index}.ext"
            self._install(
                first,
                extensions,
                "sudo install -o root -g root -m 0600 /dev/stdin " + ext_path,
            )
            leaf = self.ssh.run(
                first,
                "sudo openssl x509 -req -in /dev/stdin -CA "
                + CA_CERTIFICATE_PATH
                + " -CAkey " + CA_KEY_PATH
                + " -CAcreateserial -days 397 -sha256 -extfile " + ext_path
                + " -out /dev/stdout",
                timeout=60,
                input_data=csr.encode("ascii"),
            ).encode("ascii")
            full_chain = leaf + ca_certificate
            self._install(
                address,
                full_chain,
                "sudo install -D -o root -g root -m 0644 /dev/stdin "
                + SERVER_CERTIFICATE_PATH,
            )
            self.ssh.run(
                address,
                "sudo openssl verify -CAfile " + CA_CERTIFICATE_PATH + " "
                + SERVER_CERTIFICATE_PATH
                + " && sudo openssl x509 -in " + SERVER_CERTIFICATE_PATH
                + " -checkip " + address + " -noout && sudo openssl x509 -in "
                + SERVER_CERTIFICATE_PATH + " -checkip " + api_vip + " -noout",
                timeout=20,
            )

        serial_states = []
        for address in nodes:
            serial_state = self.ssh.run(
                address,
                "if sudo test -s " + CA_SERIAL_PATH + "; then "
                "echo present; else echo missing; fi",
                timeout=15,
            ).strip()
            if serial_state not in ("present", "missing"):
                raise RuntimeError(
                    f"Controller CA serial state is invalid on {address}."
                )
            serial_states.append(serial_state)

        serial_source = next(
            (
                address
                for address, serial_state in zip(nodes, serial_states)
                if serial_state == "present"
            ),
            None,
        )
        if serial_source is None:
            raise RuntimeError(
                "Controller CA serial file is missing on all controllers."
            )
        ca_serial = self.ssh.run(
            serial_source, "sudo cat " + CA_SERIAL_PATH, timeout=15
        )
        serial_value = ca_serial.strip()
        if not re.fullmatch(r"[0-9A-Fa-f]+", serial_value):
            raise RuntimeError("Controller CA serial file has an invalid value.")
        ca_serial = (serial_value + "\n").encode("ascii")
        for address, serial_state in zip(nodes, serial_states):
            if serial_state == "missing":
                self._install(
                    address,
                    ca_serial,
                    "sudo install -D -o root -g root -m 0600 /dev/stdin "
                    + CA_SERIAL_PATH,
                )

        self.console.print(
            "[bold]SwiftFabric deployment CA SHA-256 fingerprint:[/bold] "
            f"{fingerprint}"
        )
        return ca_certificate

    @staticmethod
    def _prepare_nginx_command() -> str:
        return (
            "set -e; for service in swiftfabric-api-service.service "
            "swiftfabric-segment-manager.service; do "
            "if systemctl is-active --quiet \"$service\"; then "
            "sudo systemctl stop \"$service\"; fi; done && "
            "sudo env DEBIAN_FRONTEND=noninteractive apt-get "
            "-o DPkg::Lock::Timeout=300 -y install nginx ca-certificates && "
        )

    @staticmethod
    def _render_nginx_config() -> str:
        return (
            "server {\n"
            "    listen 443 ssl default_server;\n"
            "    server_name _;\n"
            "    ssl_certificate " + SERVER_CERTIFICATE_PATH + ";\n"
            "    ssl_certificate_key " + SERVER_KEY_PATH + ";\n"
            "    ssl_protocols TLSv1.2 TLSv1.3;\n"
            "    ssl_session_cache shared:SwiftFabricTLS:10m;\n"
            "    ssl_session_timeout 10m;\n"
            "    location / {\n"
            "        proxy_pass http://127.0.0.1:8080;\n"
            "        proxy_set_header Host $http_host;\n"
            "        proxy_set_header X-Forwarded-For $remote_addr;\n"
            "        proxy_set_header X-Forwarded-Proto https;\n"
            "        proxy_set_header X-Forwarded-Host $host;\n"
            "    }\n"
            "}\n"
        )

    @staticmethod
    def _render_nginx_service_override() -> str:
        return (
            "[Unit]\n"
            "Requires=swiftfabric-api-service.service\n"
            "After=swiftfabric-api-service.service\n"
            "\n"
            "[Service]\n"
            "TimeoutStartSec=120\n"
            "ExecStartPost=/usr/bin/curl --fail --silent --show-error --max-time 5 "
            "--retry 40 --retry-delay 2 --retry-connrefused --retry-max-time 100 "
            "http://127.0.0.1:8080/api/v1/health\n"
        )

    @staticmethod
    def find_package(package_dir: Path) -> Path:
        """Require one prebuilt amd64 package in the install artifact folder."""
        packages = sorted(package_dir.glob("swiftfabric-api-service_*_amd64.deb"))
        if len(packages) != 1:
            raise FileNotFoundError(
                "Expected exactly one SwiftFabric API service .deb in "
                f"{package_dir}. Build it with ./build-api-service.sh."
            )
        return packages[0]

    def _build_on_buildbox(self, version: str) -> Path:
        """Upload source, build a .deb remotely, then retrieve the artifact."""
        buildbox = self._load_buildbox_config()
        buildbox_ssh = SSHCommandRunner(
            buildbox["buildbox_key"],
            buildbox["buildbox_username"],
            "the SwiftFabric API service package on the buildbox",
        )
        package_source = self.project_root / "controller-api" / "segment-manager"
        remote_root = f"/tmp/swiftfabric-api-service-{uuid.uuid4().hex}"
        remote_source = f"{remote_root}/segment-manager"
        remote_artifacts = f"{remote_root}/artifacts"
        archive = self._source_archive(package_source)
        fingerprint = self._source_fingerprint(package_source)
        source_date_epoch = os.environ.get("SWIFTFABRIC_SOURCE_DATE_EPOCH")
        if not source_date_epoch or not source_date_epoch.isdecimal():
            raise RuntimeError(
                "Set SWIFTFABRIC_SOURCE_DATE_EPOCH using the source commit timestamp."
            )
        agent_version = os.environ.get("SWIFTFABRIC_AGENT_VERSION", "")
        if not re.fullmatch(r"[A-Za-z0-9.+~:-]{1,128}", agent_version):
            raise RuntimeError(
                "Set SWIFTFABRIC_AGENT_VERSION using the host-agent submodule commit."
            )

        try:
            buildbox_ssh.run(
                buildbox["buildbox_ip"],
                f"install -d -m 0700 {remote_root} && "
                f"tar -xzf - --no-same-owner --no-same-permissions -C {remote_root}",
                timeout=60,
                input_data=archive,
            )
            build_output = buildbox_ssh.run(
                buildbox["buildbox_ip"],
                f"bash {remote_source}/build-deb.sh {remote_artifacts} {fingerprint} "
                f"{shlex.quote(version)} {shlex.quote(agent_version)} {source_date_epoch}",
                timeout=1800,
            )
            remote_package = build_output.strip().splitlines()[-1]
            self._package_tempdir = tempfile.TemporaryDirectory(
                prefix="swiftfabric-api-package-"
            )
            local_package = Path(self._package_tempdir.name) / Path(remote_package).name
            self._copy_from_buildbox(remote_package, local_package, buildbox)
            return local_package
        finally:
            try:
                buildbox_ssh.run(
                    buildbox["buildbox_ip"],
                    f"rm -rf -- {remote_root}",
                    timeout=30,
                )
            except (RuntimeError, TimeoutError):
                self.console.print(
                    f"[yellow]Could not remove temporary buildbox directory "
                    f"{remote_root}.[/yellow]"
                )

    def build_host_agent(self, output_dir: Path, fingerprint: str, version: str) -> Path:
        """Build the host-agent Debian package on the configured buildbox."""
        if not re.fullmatch(r"[A-Za-z0-9.+~:-]{1,128}", version):
            raise ValueError("host-agent version contains unsupported characters")
        source_date_epoch = os.environ.get("SWIFTFABRIC_SOURCE_DATE_EPOCH")
        if not source_date_epoch or not source_date_epoch.isdecimal():
            raise RuntimeError(
                "Set SWIFTFABRIC_SOURCE_DATE_EPOCH using the source commit timestamp."
            )
        buildbox = self._load_buildbox_config()
        buildbox_ssh = SSHCommandRunner(
            buildbox["buildbox_key"],
            buildbox["buildbox_username"],
            "the SwiftFabric host-agent package on the buildbox",
        )
        remote_root = f"/tmp/swiftfabric-host-agent-{uuid.uuid4().hex}"
        remote_artifacts = f"{remote_root}/artifacts"
        source_root = self.project_root / "host-agent"
        source_files = [
            *sorted((source_root / "swiftfabric_host").rglob("*.py")),
            *sorted((source_root / "tests").rglob("*.py")),
            source_root / "build-deb.sh",
            source_root / "config.example.json",
            source_root / "packaging" / "swiftfabric-host-agent.service",
            source_root / "packaging" / "swiftfabric-neighbors.service",
        ]
        for source_file in source_files:
            if not source_file.is_file():
                raise FileNotFoundError(
                    f"Required host-agent source file is missing: {source_file}"
                )
        archive_buffer = BytesIO()
        with tarfile.open(fileobj=archive_buffer, mode="w:gz") as archive:
            for source_file in source_files:
                archive.add(
                    source_file,
                    arcname=str(source_file.relative_to(self.project_root)),
                )
            for shared_file in (
                self.project_root / "build-environment.sh",
                self.project_root / "build-environment.lock",
                self.project_root / "prepare-buildbox.sh",
            ):
                archive.add(
                    shared_file,
                    arcname=f"host-agent/{shared_file.name}",
                )

        try:
            buildbox_ssh.run(
                buildbox["buildbox_ip"],
                f"install -d -m 0700 {remote_root} && "
                f"tar -xzf - --no-same-owner --no-same-permissions -C {remote_root}",
                timeout=60,
                input_data=archive_buffer.getvalue(),
            )
            remote_package = f"{remote_artifacts}/swiftfabric-host-agent_{version}_all.deb"
            buildbox_ssh.run(
                buildbox["buildbox_ip"],
                f"bash {remote_root}/host-agent/build-deb.sh "
                f"{remote_artifacts} {fingerprint} {shlex.quote(version)} "
                f"{source_date_epoch}",
                timeout=600,
            )
            local_package = output_dir / Path(remote_package).name
            self._copy_from_buildbox(remote_package, local_package, buildbox)
            return local_package
        finally:
            try:
                buildbox_ssh.run(
                    buildbox["buildbox_ip"],
                    f"rm -rf -- {remote_root}",
                    timeout=30,
                )
            except (RuntimeError, TimeoutError):
                self.console.print(
                    f"[yellow]Could not remove temporary buildbox directory "
                    f"{remote_root}.[/yellow]"
                )

    def _load_buildbox_config(self) -> Dict[str, str]:
        config_path = self.project_root / "build.json"
        try:
            config = json.loads(config_path.read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            raise FileNotFoundError(
                f"Buildbox configuration is missing: {config_path}. "
                "Copy build.example.json to build.json and set the buildbox IP, username, and SSH key path."
            ) from exc
        except (OSError, json.JSONDecodeError) as exc:
            raise ValueError(f"Could not read buildbox configuration {config_path}: {exc}") from exc
        required = ("buildbox_ip", "buildbox_username", "buildbox_key")
        missing = [key for key in required if not isinstance(config.get(key), str) or not config[key].strip()]
        if missing:
            raise ValueError(
                f"Buildbox configuration {config_path} requires non-empty string values for: "
                + ", ".join(missing)
            )
        try:
            ipaddress.IPv4Address(config["buildbox_ip"])
        except ipaddress.AddressValueError as exc:
            raise ValueError(
                f"buildbox_ip in {config_path} must be a valid IPv4 address"
            ) from exc
        if not re.fullmatch(r"[A-Za-z0-9._-]+", config["buildbox_username"]):
            raise ValueError(
                f"buildbox_username in {config_path} contains unsupported characters"
            )
        key_path = Path(config["buildbox_key"]).expanduser()
        if not key_path.is_absolute():
            key_path = config_path.parent / key_path
        if not key_path.is_file():
            raise FileNotFoundError(f"Buildbox SSH private key does not exist: {key_path}")
        config["buildbox_key"] = str(key_path.resolve())
        return config

    @staticmethod
    def _source_archive(package_source: Path) -> bytes:
        buffer = BytesIO()
        with tarfile.open(fileobj=buffer, mode="w:gz") as archive:
            for source_path, arcname in ApiServiceDeployment._source_files(
                package_source
            ):
                archive.add(source_path, arcname=arcname)
        return buffer.getvalue()

    @staticmethod
    def _source_files(package_source: Path):
        source_paths = [
            package_source / "Cargo.toml",
            package_source / "build-deb.sh",
            package_source / "src" / "main.rs",
            package_source / "src" / "hosts.rs",
            package_source / "src" / "management_pool.rs",
            package_source / "src" / "router_ha.rs",
            package_source / "src" / "neighbor_peers.rs",
            package_source / "src" / "ssh_trust.rs",
            package_source / "src" / "users.rs",
            package_source / "src" / "controller_keys.rs",
            package_source / "src" / "tenants.rs",
            package_source / "src" / "backup.rs",
            package_source / "router_runtime.py",
            package_source / "router_state_sync.py",
            package_source / "router_packet_gate.py",
            *sorted((package_source / "packaging").glob("*.service")),
            *sorted((package_source / "packaging").glob("*.timer")),
            package_source / "packaging" / "swiftfabric-renew-controller-cert",
            package_source / "packaging" / "swiftfabric-restore-controller",
            package_source / "tests" / "test_restore_worker.py",
            package_source / "packaging" / "swiftfabric-disable-thp",
            package_source / "packaging" / "90-swiftfabric.conf",
            package_source / "packaging" / "ocf" / "resource.d"
            / "swiftfabric" / "valkey-segment",
            package_source / "packaging" / "ocf" / "resource.d"
            / "swiftfabric" / "segment-manager-vip",
        ]
        source_paths.append(package_source / "ui" / "index.html")
        lockfile = package_source / "Cargo.lock"
        source_paths.append(lockfile)
        files = []
        for source_path in source_paths:
            if not source_path.is_file():
                raise FileNotFoundError(
                    f"Required API service source file is missing: {source_path}"
                )
            files.append(
                (
                    source_path,
                    f"segment-manager/{source_path.relative_to(package_source)}",
                )
            )
        project_root = package_source.parents[1]
        for shared_file in (
            "build-environment.sh",
            "build-environment.lock",
            "prepare-buildbox.sh",
        ):
            shared_path = project_root / shared_file
            if not shared_path.is_file():
                raise FileNotFoundError(
                    f"Required build environment file is missing: {shared_path}"
                )
            files.append((shared_path, f"segment-manager/{shared_file}"))
        agent_source = package_source.parents[1] / "host-agent"
        agent_files = [
            *sorted((agent_source / "swiftfabric_host").rglob("*.py")),
            agent_source / "packaging" / "swiftfabric-host-agent.service",
            agent_source / "packaging" / "swiftfabric-neighbors.service",
        ]
        if not agent_files:
            raise FileNotFoundError("Host agent sources are missing.")
        for agent_file in agent_files:
            files.append(
                (
                    agent_file,
                    f"segment-manager/host-agent/{agent_file.relative_to(agent_source)}",
                )
            )
        return files

    @staticmethod
    def _source_fingerprint(package_source: Path) -> str:
        manifest = hashlib.sha256()
        project_root = package_source.parents[1]
        for module in ("controller-api", "host-agent"):
            commit = subprocess.check_output(
                ["git", "-C", str(project_root / module), "rev-parse", "HEAD"],
                text=True,
            ).strip()
            manifest.update(f"{module} {commit}\n".encode("ascii"))
        for source_path, arcname in sorted(
            ApiServiceDeployment._source_files(package_source),
            key=lambda item: item[1],
        ):
            content_hash = hashlib.sha256(source_path.read_bytes()).hexdigest()
            manifest.update(f"{content_hash}  {arcname}\n".encode("utf-8"))
        return manifest.hexdigest()

    def _copy_from_buildbox(
        self,
        remote_path: str,
        local_path: Path,
        buildbox: Dict[str, str],
    ) -> None:
        local_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            result = subprocess.run(
                [
                    "scp",
                    "-i", buildbox["buildbox_key"],
                    "-o", "BatchMode=yes",
                    "-o", "ConnectTimeout=8",
                    "-o", "UserKnownHostsFile=/dev/null",
                    "-o", "GlobalKnownHostsFile=/dev/null",
                    "-o", "StrictHostKeyChecking=no",
                    f"{buildbox['buildbox_username']}@{buildbox['buildbox_ip']}:{remote_path}",
                    str(local_path),
                ],
                capture_output=True,
                text=True,
                check=False,
            )
        except FileNotFoundError as exc:
            raise RuntimeError(
                "The scp client is required to retrieve the package from the buildbox."
            ) from exc
        if result.returncode != 0:
            details = (result.stderr or result.stdout).strip()
            raise RuntimeError(
                f"Could not retrieve {remote_path} from the buildbox: {details}"
            )

    def _install(self, ip_address: str, content: bytes, command: str) -> None:
        self.ssh.run(ip_address, command, timeout=120, input_data=content)

    @staticmethod
    def _render_firewall(nodes: List[str]) -> str:
        addresses = ", ".join(nodes)
        return (
            "table inet swiftfabric_segment_manager {\n"
            "    set controller_nodes {\n"
            "        type ipv4_addr\n"
            f"        elements = {{ {addresses} }}\n"
            "    }\n"
            "    chain input {\n"
            "        type filter hook input priority -20; policy accept;\n"
            "        ct state established,related accept\n"
            "        iifname \"lo\" accept\n"
            "        tcp dport 80 drop\n"
            "        tcp dport 443 accept\n"
            "        tcp dport 8080 drop\n"
            "        ip saddr @controller_nodes tcp dport 4999 accept\n"
            "        tcp dport 4999 drop\n"
            "        ip saddr @controller_nodes tcp dport 5000-50000 accept\n"
            "        tcp dport 5000-50000 drop\n"
            "    }\n"
            "}\n"
        )
