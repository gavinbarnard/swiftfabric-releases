"""Start and verify Pacemaker on the Corosync controller cluster."""

import ipaddress
import re
import time
import xml.etree.ElementTree as ET
from typing import Any, Dict, List

from rich.console import Console

from deployment.ssh import SSHCommandRunner


class PacemakerCluster:
    """Enable Pacemaker and verify it recognizes all Corosync cluster nodes."""

    USERNAME = "ubuntu"
    RETRY_INTERVAL = 5
    VERIFY_TIMEOUT = 120

    def __init__(self, private_key: str):
        self.ssh = SSHCommandRunner(
            private_key,
            self.USERNAME,
            "the Pacemaker cluster",
        )
        self.console = Console()

    def configure_and_verify(
        self,
        deployments: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Start Pacemaker on each node and wait for full cluster membership."""
        if len(deployments) != 3:
            raise ValueError(
                f"Pacemaker setup requires exactly 3 controller VMs; "
                f"got {len(deployments)}."
            )

        nodes = []
        seen_ips = set()
        for deployment in deployments:
            ip_address = deployment.get("ip_address")
            if not ip_address:
                raise ValueError(
                    f"Controller VM {deployment.get('vmid')} has no IP address."
                )
            try:
                normalized_ip = str(ipaddress.ip_address(ip_address))
            except ValueError as exc:
                raise ValueError(
                    f"Controller VM {deployment.get('vmid')} has invalid IP "
                    f"address '{ip_address}'."
                ) from exc
            if normalized_ip in seen_ips:
                raise ValueError(f"Duplicate controller IP address: {normalized_ip}.")
            seen_ips.add(normalized_ip)
            nodes.append(normalized_ip)

        for ip_address in nodes:
            self.console.print(f"Starting Pacemaker on {ip_address}...")
            self.ssh.run(
                ip_address,
                "sudo systemctl enable pacemaker && "
                "sudo systemctl restart pacemaker",
                timeout=60,
            )

        self._wait_for_cluster(nodes)
        self.ssh.run(
            nodes[0],
            "sudo pcs property set stonith-enabled=false && "
            "sudo pcs property set no-quorum-policy=stop",
        )
        node_names = [
            self.ssh.run(ip_address, "sudo -n crm_node -n").strip()
            for ip_address in nodes
        ]
        if any(not name for name in node_names) or len(set(node_names)) != len(nodes):
            raise RuntimeError(
                f"Pacemaker returned invalid or duplicate node names: {node_names}."
            )
        return {"nodes": nodes, "node_names": node_names, "online": True}

    def configure_api_vip(
        self,
        vip_ip: str,
        cidr: int,
        gateway_ip: str,
        nodes: List[str],
    ) -> None:
        """Create the movable API address and probe its gateway when assigned."""
        try:
            normalized_ip = str(ipaddress.IPv4Address(vip_ip))
        except ipaddress.AddressValueError as exc:
            raise ValueError(f"Invalid API-service VIP: {vip_ip}") from exc
        try:
            gateway_address = ipaddress.IPv4Address(gateway_ip)
            normalized_gateway = str(gateway_address)
        except ipaddress.AddressValueError as exc:
            raise ValueError(f"Invalid API-service VIP gateway: {gateway_ip}") from exc
        if isinstance(cidr, bool) or not 1 <= cidr <= 32:
            raise ValueError(f"Invalid CIDR prefix for API-service VIP: {cidr}")
        vip_network = ipaddress.ip_network(f"{normalized_ip}/{cidr}", strict=False)
        if gateway_address not in vip_network:
            raise ValueError("The API-service VIP gateway must be in the VIP subnet.")
        if not nodes:
            raise ValueError("At least one controller is required to configure the API VIP.")

        resource_id = "swiftfabric-segment-manager-vip"
        exists = self.ssh.run(
            nodes[0],
            f"if sudo pcs resource config {resource_id} >/dev/null 2>&1; "
            "then printf yes; else printf no; fi",
        )
        if exists.strip() == "yes":
            self.ssh.run(
                nodes[0],
                f"sudo pcs resource update {resource_id} "
                f"ip={normalized_ip} cidr_netmask={cidr} "
                f"gateway={normalized_gateway} && "
                f"sudo pcs resource meta {resource_id} "
                "resource-stickiness=100 migration-threshold=1 && "
                f"sudo pcs resource enable {resource_id}",
                timeout=60,
            )
        else:
            self.ssh.run(
                nodes[0],
                "sudo pcs resource create "
                f"{resource_id} ocf:swiftfabric:segment-manager-vip "
                f"ip={normalized_ip} cidr_netmask={cidr} "
                f"gateway={normalized_gateway} "
                "op monitor interval=10s timeout=20s "
                "meta resource-stickiness=100 migration-threshold=1",
                timeout=60,
            )
        self._colocate_vip_with_primary(nodes[0], resource_id)
        deadline = time.monotonic() + self.VERIFY_TIMEOUT
        last_status = ""
        while time.monotonic() < deadline:
            last_status = self.ssh.run(
                nodes[0],
                f"sudo pcs resource status {resource_id}",
                timeout=30,
            )
            if re.search(r"\bstarted\b|\brunning on:\s*\S+", last_status, re.IGNORECASE):
                return
            time.sleep(min(self.RETRY_INTERVAL, max(0, deadline - time.monotonic())))

        cluster_status = self.ssh.run(
            nodes[0],
            "sudo pcs status --full",
            timeout=30,
        )
        if not re.search(r"\bstarted\b|\brunning on:\s*\S+", last_status, re.IGNORECASE):
            raise RuntimeError(
                f"Pacemaker did not start API VIP resource {resource_id} "
                f"within {self.VERIFY_TIMEOUT} seconds. Resource status: "
                f"{last_status.strip() or 'unavailable'}\nCluster status:\n"
                f"{cluster_status.strip()}"
            )

    def _colocate_vip_with_primary(self, node: str, vip_id: str) -> None:
        """Keep the API VIP on the node holding the provisioning Valkey primary.

        The API service creates the provisioning clone asynchronously after it
        starts, so wait for it before adding the constraint.
        """
        clone_id = "swiftfabric-valkey-4999-clone"
        deadline = time.monotonic() + self.VERIFY_TIMEOUT
        while True:
            present = self.ssh.run(
                node,
                f"if sudo pcs resource config {clone_id} >/dev/null 2>&1; "
                "then printf yes; else printf no; fi",
            )
            if present.strip() == "yes":
                break
            if time.monotonic() >= deadline:
                raise RuntimeError(
                    f"The provisioning Valkey clone {clone_id} did not appear within "
                    f"{self.VERIFY_TIMEOUT} seconds, so the API VIP cannot be colocated with it."
                )
            time.sleep(self.RETRY_INTERVAL)
        self.ssh.run(
            node,
            f"if ! sudo pcs constraint colocation config | grep -q '{vip_id}'; then "
            f"sudo pcs constraint colocation add {vip_id} with Promoted {clone_id} INFINITY; fi",
            timeout=60,
        )

    def _wait_for_cluster(self, nodes: List[str]) -> None:
        deadline = time.monotonic() + self.VERIFY_TIMEOUT
        last_errors = {}
        while True:
            pending = []
            for ip_address in nodes:
                try:
                    self._verify_node(ip_address, len(nodes))
                except (RuntimeError, TimeoutError, ET.ParseError) as exc:
                    pending.append(ip_address)
                    last_errors[ip_address] = str(exc)

            if not pending:
                return

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                details = "; ".join(
                    f"{ip_address}: {last_errors[ip_address]}"
                    for ip_address in pending
                )
                raise TimeoutError(
                    f"Pacemaker did not report all {len(nodes)} cluster nodes "
                    f"online within {self.VERIFY_TIMEOUT} seconds. {details}"
                )
            time.sleep(min(self.RETRY_INTERVAL, remaining))

    def _verify_node(self, ip_address: str, expected_nodes: int) -> None:
        self.ssh.run(ip_address, "systemctl is-active --quiet pacemaker")
        status_xml = self.ssh.run(
            ip_address,
            "sudo -n crm_mon --one-shot --output-as=xml",
        )
        status = ET.fromstring(status_xml)
        stack = status.find("./summary/stack")
        if stack is None or stack.get("type", "").strip() != "corosync":
            raise RuntimeError(
                f"Pacemaker on {ip_address} is not using the Corosync stack."
            )

        configured = status.find("./summary/nodes_configured")
        configured_count = int(configured.get("number", "0")) if configured is not None else 0
        online_nodes = [
            node for node in status.findall("./nodes/node")
            if node.get("online", "").lower() == "true"
        ]
        if configured_count != expected_nodes or len(online_nodes) != expected_nodes:
            raise RuntimeError(
                f"Pacemaker on {ip_address} reports {len(online_nodes)} of "
                f"{configured_count} configured nodes online; expected "
                f"{expected_nodes} of {expected_nodes}."
            )
