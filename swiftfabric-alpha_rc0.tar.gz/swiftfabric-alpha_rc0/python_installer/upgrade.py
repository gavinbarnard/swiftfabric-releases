"""Safely upgrade the controller package without redeploying the cluster."""

import argparse
import hashlib
import getpass
import ipaddress
import json
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import requests
from rich.console import Console
from rich.prompt import Confirm
from rich.table import Table

import agent_upgrade
from cli_args import token_arguments
from deployment.api_service import ApiServiceDeployment
from deployment.ssh import SSHCommandRunner
from main import (
    _controller_vm_ip,
    _deployment_from_config,
    _controller_vip,
    load_deployment_config,
)


console = Console()
CONTROLLER_COUNT = 3
API_RECOVERY_TIMEOUT = 120
LOCAL_HEALTH_RETRIES = 40
LOCAL_HEALTH_RETRY_DELAY = 3
CA_TRUST_REPUBLISH_PATH = "/api/v1/system/ca-trust/republish"


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description="Upgrade the SwiftFabric controller package without upgrading hosts."
    )
    parser.add_argument(
        "--config",
        required=True,
        help="Path to the original deployment config.json.",
    )
    parser.add_argument(
        "--token",
        nargs="?",
        const="",
        required=True,
        help="Current controller API bearer token; omit VALUE to prompt securely. "
             "Use --token=VALUE to unambiguously pass any dash-prefixed value.",
    )
    parser.add_argument("--prefix", default="", help="Controller VM name prefix.")
    parser.add_argument(
        "--controllername",
        default="swiftfabric-controller",
        help="Controller VM name stem (default: swiftfabric-controller).",
    )
    parser.add_argument(
        "--yes",
        action="store_true",
        help="Skip the confirmation prompt after displaying the upgrade plan.",
    )
    parser.add_argument(
        "--auto-agent-upgrade",
        action="store_true",
        help=(
            "After the controllers, also upgrade outdated North/South router and "
            "enrolled compute-host agents, live-migrating SwiftFabric-attached "
            "VMs off each host first. Without this flag those remain manual."
        ),
    )
    parser.add_argument(
        "--no-migrate-back",
        action="store_true",
        help="With --auto-agent-upgrade, leave evacuated VMs on their new hosts.",
    )
    parser.add_argument(
        "--migrate-local-disks",
        action="store_true",
        help="With --auto-agent-upgrade, allow live migration that copies local disks.",
    )
    parser.add_argument(
        "--migration-timeout",
        type=int,
        default=3600,
        metavar="SECONDS",
        help="With --auto-agent-upgrade, per-VM migration timeout (default: 3600).",
    )
    args = parser.parse_args(token_arguments(argv))
    if not args.auto_agent_upgrade and (
        args.no_migrate_back
        or args.migrate_local_disks
        or args.migration_timeout != 3600
    ):
        parser.error(
            "--no-migrate-back, --migrate-local-disks, and --migration-timeout "
            "require --auto-agent-upgrade."
        )
    if args.migration_timeout <= 0:
        parser.error("--migration-timeout must be positive.")
    return args


def resolve_api_token(token):
    if token == "":
        if not sys.stdin.isatty():
            raise ValueError("--token without a value requires an interactive terminal.")
        token = getpass.getpass("Controller API bearer token: ")
    token = token.strip()
    if not token:
        raise ValueError("The controller API token is empty.")
    return token


def _api_url(api_vip, path):
    return f"https://{api_vip}{path}"


def _request_cluster_status(api_vip, token, timeout=(3, 15), ca_cert=None):
    response = requests.get(
        _api_url(api_vip, "/api/v1/cluster"),
        headers={"Authorization": f"Bearer {token}"},
        timeout=timeout,
        verify=ca_cert or True,
    )
    response.raise_for_status()
    status = response.json()
    if not isinstance(status, dict):
        raise RuntimeError("Controller returned an invalid cluster status.")
    return status


def _verify_api_access(api_vip, token, ca_cert=None):
    try:
        return _request_cluster_status(api_vip, token, ca_cert=ca_cert)
    except requests.RequestException as exc:
        status_code = getattr(getattr(exc, "response", None), "status_code", None)
        if status_code == 401:
            raise RuntimeError(
                "The controller API rejected the bearer token for GET "
                "/api/v1/cluster."
            ) from exc
        raise RuntimeError(
            "Could not authenticate to the controller API VIP or read cluster status."
        ) from exc
    except ValueError as exc:
        raise RuntimeError("Controller returned invalid JSON for cluster status.") from exc


def _verify_admin_api_key(api_vip, token, ca_cert=None):
    try:
        response = requests.get(
            _api_url(api_vip, "/api/v1/system/me"),
            headers={"Authorization": f"Bearer {token}"},
            timeout=(3, 15),
            verify=ca_cert or True,
        )
    except requests.RequestException as exc:
        raise RuntimeError("Could not verify API administrator privileges.") from exc
    if response.status_code == 404:
        return False
    if response.status_code == 401:
        raise RuntimeError(
            "The controller API rejected the bearer token for GET "
            "/api/v1/system/me."
        )
    try:
        response.raise_for_status()
        identity = response.json()
    except (requests.RequestException, ValueError) as exc:
        raise RuntimeError("Controller returned an invalid API identity response.") from exc
    if not isinstance(identity, dict) or not isinstance(identity.get("is_admin"), bool):
        raise RuntimeError("Controller returned an invalid API identity response.")
    if not identity["is_admin"]:
        raise RuntimeError("Controller package upgrades require an admin API key.")
    return True


def _controller_service_token_fingerprint(ssh, controller):
    code = (
        "import hashlib, hmac, json, pathlib, sys\n"
        "config = json.loads(pathlib.Path('/etc/swiftfabric/api-service.json').read_text())\n"
        "configured = config.get('api_token')\n"
        "stored = pathlib.Path('/etc/swiftfabric/controller-service.token').read_text().strip()\n"
        "admin_hash = config.get('initial_admin_token_hash')\n"
        "if not isinstance(admin_hash, str) or len(admin_hash) != 64 or any(c not in '0123456789abcdef' for c in admin_hash):\n"
        "    sys.exit(1)\n"
        "if not isinstance(configured, str) or not hmac.compare_digest(configured, stored):\n"
        "    sys.exit(1)\n"
        "if not configured.startswith('sfc_') or len(configured) != 68 or any(c not in '0123456789abcdef' for c in configured[4:]):\n"
        "    sys.exit(1)\n"
        "if hmac.compare_digest(admin_hash, hashlib.sha256(configured.encode()).hexdigest()):\n"
        "    sys.exit(1)\n"
        "hashes = config.get('controller_token_hashes')\n"
        "node_id = config.get('node_id')\n"
        "if (not isinstance(hashes, list) or len(hashes) != 3\n"
        "    or any(not isinstance(h, str) or len(h) != 64 or any(c not in '0123456789abcdef' for c in h) for h in hashes)\n"
        "    or len(set(hashes)) != 3\n"
        "    or admin_hash in hashes\n"
        "    or type(node_id) is not int or not 0 <= node_id < 3\n"
        "    or hashes[node_id] != hashlib.sha256(configured.encode()).hexdigest()):\n"
        "    sys.exit(1)\n"
        "print(hashlib.sha256(configured.encode()).hexdigest())\n"
    )
    command = "sudo python3 -c " + _shell_quote(code)
    try:
        fingerprint = ssh.run(controller["ip_address"], command, timeout=20).strip()
    except RuntimeError as exc:
        raise RuntimeError(
            f"Could not verify separate controller service credentials on {controller['name']}; "
            "legacy deployments with shared admin/service or controller credentials require redeployment."
        ) from exc
    if not re.fullmatch(r"[a-f0-9]{64}", fingerprint):
        raise RuntimeError(
            f"Controller API token state is invalid on {controller['name']}."
        )
    return fingerprint


def _verify_controller_service_tokens(ssh, controllers):
    fingerprints = {
        _controller_service_token_fingerprint(ssh, controller)
        for controller in controllers
    }
    if len(fingerprints) != len(controllers):
        raise RuntimeError(
            "Controller API service tokens are shared between nodes; redeployment is required."
        )


def _request_local_api(ssh, controller, token, path):
    if any(character in token for character in "\r\n"):
        raise ValueError("The controller API token contains unsupported line breaks.")
    escaped_token = token.replace("\\", "\\\\").replace('"', '\\"')
    curl_config = f'header = "Authorization: Bearer {escaped_token}"\n'.encode("ascii")
    command = (
        "curl --silent --show-error --max-time 8 --config - "
        "--write-out '\\n%{http_code}' "
        f"http://127.0.0.1:8080{path}"
    )
    output = ssh.run(
        controller["ip_address"],
        command,
        timeout=15,
        input_data=curl_config,
    )
    try:
        body, status = output.rsplit("\n", 1)
        return int(status), body
    except (ValueError, TypeError) as exc:
        raise RuntimeError(
            f"Controller {controller['name']} returned an invalid local API response."
        ) from exc


def _verify_api_access_over_ssh(ssh, controller, token):
    status_code, body = _request_local_api(
        ssh, controller, token, "/api/v1/cluster"
    )
    if status_code == 401:
        raise RuntimeError("The controller API rejected the bearer token.")
    if not 200 <= status_code < 300:
        raise RuntimeError(
            f"Could not read cluster status through authenticated SSH "
            f"(HTTP {status_code})."
        )
    try:
        cluster_status = json.loads(body)
    except ValueError as exc:
        raise RuntimeError("Controller returned invalid JSON for cluster status.") from exc
    if not isinstance(cluster_status, dict):
        raise RuntimeError("Controller returned an invalid cluster status.")

    status_code, body = _request_local_api(
        ssh, controller, token, "/api/v1/system/me"
    )
    if status_code == 404:
        return cluster_status, False
    if status_code == 401:
        raise RuntimeError("The controller API rejected the bearer token.")
    if not 200 <= status_code < 300:
        raise RuntimeError(
            f"Could not verify API administrator privileges (HTTP {status_code})."
        )
    try:
        identity = json.loads(body)
    except ValueError as exc:
        raise RuntimeError("Controller returned invalid API identity JSON.") from exc
    if not isinstance(identity, dict) or not isinstance(identity.get("is_admin"), bool):
        raise RuntimeError("Controller returned an invalid API identity response.")
    if not identity["is_admin"]:
        raise RuntimeError("Controller package upgrades require an admin API key.")
    return cluster_status, True


def _api_vip_owner(ssh, controllers, api_vip):
    code = (
        "import json,subprocess,sys; "
        "interfaces=json.loads(subprocess.check_output("
        "['ip','-j','-4','address','show'],text=True)); "
        "vip=sys.argv[1]; "
        "print(str(any(address.get('local')==vip "
        "for interface in interfaces "
        "for address in interface.get('addr_info',[]))).lower())"
    )
    owners = []
    for controller in controllers:
        try:
            result = ssh.run(
                controller["ip_address"],
                "python3 -c " + _shell_quote(code) + " " + _shell_quote(api_vip),
                timeout=20,
            ).strip()
        except RuntimeError as exc:
            raise RuntimeError(
                f"Could not check API VIP ownership on {controller['name']}."
            ) from exc
        if result not in {"true", "false"}:
            raise RuntimeError(
                f"Controller {controller['name']} returned an invalid API VIP "
                "ownership result."
            )
        if result == "true":
            owners.append(controller)

    if not owners:
        raise RuntimeError(
            f"API VIP {api_vip} is not assigned to any controller; "
            "restore the Pacemaker VIP before upgrading."
        )
    if len(owners) != 1:
        names = ", ".join(controller["name"] for controller in owners)
        raise RuntimeError(
            f"API VIP {api_vip} is assigned to multiple controllers ({names}); "
            "refusing to upgrade."
        )
    return owners[0]


def _build_upgrade_plan(config, deployment, prefix, controllername):
    plan = deployment.find_controllers_to_destroy(
        prefix=prefix,
        controller_name=controllername,
        count=CONTROLLER_COUNT,
    )
    if plan["not_found"] or len(plan["matches"]) != CONTROLLER_COUNT:
        missing = ", ".join(plan["not_found"]) or "expected exactly three controllers"
        raise RuntimeError(
            f"Controller inventory is incomplete ({missing}); refusing to upgrade."
        )
    if any(controller["status"] != "running" for controller in plan["matches"]):
        stopped = ", ".join(
            controller["name"]
            for controller in plan["matches"]
            if controller["status"] != "running"
        )
        raise RuntimeError(
            f"All controllers must be running before upgrade; not running: {stopped}."
        )

    first_ip = ipaddress.IPv4Address(config["ip_range_start"])
    expected_ips = {
        str(ipaddress.IPv4Address(int(first_ip) + offset))
        for offset in range(CONTROLLER_COUNT)
    }
    controllers = []
    for controller in plan["matches"]:
        ip_address = _controller_vm_ip(deployment, controller)
        if ip_address not in expected_ips:
            raise RuntimeError(
                f"Controller '{controller['name']}' has an IP outside the original "
                "deployment range; refusing to upgrade."
            )
        controllers.append({**controller, "ip_address": ip_address})
    actual_ips = {controller["ip_address"] for controller in controllers}
    if actual_ips != expected_ips:
        raise RuntimeError(
            "Controller VM IPs do not match the three addresses in the original "
            "deployment config; refusing to upgrade."
        )
    return sorted(controllers, key=lambda item: int(ipaddress.IPv4Address(item["ip_address"])))


def _package_metadata(package_path):
    try:
        result = subprocess.run(
            ["dpkg-deb", "-f", str(package_path), "Version", "Architecture"],
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError as exc:
        raise RuntimeError("dpkg-deb is required to inspect the controller package.") from exc
    if result.returncode != 0:
        raise RuntimeError(
            "Could not read package metadata: "
            + (result.stderr or result.stdout).strip()
        )
    fields = {}
    for line in result.stdout.splitlines():
        name, separator, value = line.partition(":")
        if not separator or name not in {"Version", "Architecture"}:
            raise RuntimeError("Controller package has invalid version or architecture metadata.")
        fields[name] = value.strip()
    version = fields.get("Version", "")
    architecture = fields.get("Architecture", "")
    if (
        len(fields) != 2
        or not re.fullmatch(r"[A-Za-z0-9.+~:-]{1,128}", version)
        or not architecture
    ):
        raise RuntimeError("Controller package has invalid version or architecture metadata.")
    if architecture != "amd64":
        raise RuntimeError(
            f"Controller package architecture is {architecture!r}; expected 'amd64'."
        )
    return version


def _preflight_controller(ssh, controller, package_version, token, allow_admin_key=False):
    ip_address = controller["ip_address"]
    package_status = ssh.run(
        ip_address,
        "dpkg-query -W -f='${db:Status-Status}\\n${Version}\\n' "
        "swiftfabric-api-service",
        timeout=20,
    ).splitlines()
    if len(package_status) != 2 or package_status[0] != "installed":
        raise RuntimeError(
            f"SwiftFabric API package is not installed cleanly on {controller['name']}."
        )
    current_version = package_status[1]
    if not re.fullmatch(r"[A-Za-z0-9.+~:-]{1,128}", current_version):
        raise RuntimeError(
            f"Invalid installed package version reported by {controller['name']}."
        )

    ssh.run(
        ip_address,
        "test -s /etc/swiftfabric/api-service.json && "
        "test -s /etc/swiftfabric/segment-manager.token && "
        "test -s /etc/swiftfabric/controller-service.token && "
        "test -x /usr/bin/swiftfabric-api-service",
        timeout=20,
    )
    ssh.run(
        ip_address,
        "sudo dpkg --compare-versions "
        + _shell_quote(package_version)
        + " ge "
        + _shell_quote(current_version),
        timeout=20,
    )
    if not allow_admin_key:
        ssh.run(
            ip_address,
            "sudo cmp -s /dev/stdin /etc/swiftfabric/segment-manager.token",
            timeout=20,
            input_data=(token + "\n").encode("utf-8"),
        )
    return current_version


def _shell_quote(value):
    return "'" + value.replace("'", "'\\''") + "'"


def _show_plan(controllers, current_versions, target_version, auto_agent_upgrade=False):
    table = Table(title="SwiftFabric controller package upgrade")
    table.add_column("Name")
    table.add_column("Node")
    table.add_column("IP")
    table.add_column("VMID")
    table.add_column("From")
    table.add_column("To")
    for controller in controllers:
        table.add_row(
            controller["name"],
            controller["node"],
            controller["ip_address"],
            str(controller["vmid"]),
            current_versions[controller["name"]],
            target_version,
        )
    console.print(table)
    if auto_agent_upgrade:
        console.print(
            "[yellow]After the controllers, the agent upgrades below run "
            "automatically, one host or router at a time.[/yellow]"
        )
    else:
        console.print(
            "[yellow]This updates controller VMs only. Compute-host and router "
            "agent upgrades remain separate, user-initiated controller actions "
            "(or rerun with --auto-agent-upgrade).[/yellow]"
        )


def _wait_for_api(api_vip, token, ca_cert=None):
    deadline = time.monotonic() + API_RECOVERY_TIMEOUT
    last_error = None
    while time.monotonic() < deadline:
        try:
            _request_cluster_status(
                api_vip, token, timeout=(3, 5), ca_cert=ca_cert
            )
            return
        except (requests.RequestException, ValueError, RuntimeError) as exc:
            last_error = exc
            time.sleep(3)
    raise RuntimeError(
        "The authenticated controller API did not recover at the VIP after the "
        f"controller restart ({last_error})."
    ) from last_error


def _wait_for_local_health(ssh, controller, local_api_only=False):
    ip_address = controller["ip_address"]
    if local_api_only:
        health_url = "http://127.0.0.1:8080/api/v1/health"
        tls_options = ""
    else:
        health_url = f"https://{ip_address}/api/v1/health"
        tls_options = (
            f"--cacert /etc/swiftfabric/tls/ca-bundle.pem "
            f"--resolve {ip_address}:443:127.0.0.1 "
        )
    health_check = (
        "attempt=0; "
        "until sudo -n curl --fail --silent --show-error --max-time 2 "
        f"{tls_options}{health_url}; do "
        "if ! systemctl is-active --quiet swiftfabric-api-service.service; then "
        "echo 'SwiftFabric API service stopped before becoming healthy.' >&2; "
        "sudo systemctl --no-pager --full status swiftfabric-api-service.service >&2 || true; "
        "exit 1; "
        "fi; "
        f"attempt=$((attempt + 1)); "
        f"if [ \"$attempt\" -ge {LOCAL_HEALTH_RETRIES} ]; then "
        "echo 'Timed out waiting for the local SwiftFabric API health endpoint.' >&2; "
        "sudo systemctl --no-pager --full status swiftfabric-api-service.service >&2 || true; "
        "exit 1; "
        "fi; "
        f"sleep {LOCAL_HEALTH_RETRY_DELAY}; "
        "done"
    )
    ssh.run(ip_address, health_check, timeout=150)


def _fetch_admin_json(api_vip, token, path, ca_bundle):
    response = requests.get(
        _api_url(api_vip, path),
        headers={"Authorization": f"Bearer {token}"},
        timeout=(3, 15),
        verify=ca_bundle,
    )
    response.raise_for_status()
    try:
        return response.json()
    except ValueError as failure:
        raise RuntimeError(f"Controller returned invalid JSON for {path}.") from failure


def _upgrade_controller(
    ssh,
    controller,
    controller_ips,
    package_path,
    ca_certificate,
    ca_trust_bundle=None,
    defer_nginx_restart=False,
):
    ip_address = controller["ip_address"]
    ca_trust_bundle = ca_trust_bundle or ca_certificate
    console.print(f"Upgrading {controller['name']} ({ip_address})...")
    ssh.run(
        ip_address,
        "set -e; "
        "if systemctl is-active --quiet nginx.service && "
        "test -s /etc/swiftfabric/swiftfabric-ca.crt && "
        "test -z \"$(ss -H -lnt 'sport = :80')\"; then "
        "printf '%s\\n' 'Staging HTTPS controller upgrade without stopping services'; "
        "else "
        + ApiServiceDeployment._prepare_nginx_command()
        + "sudo systemctl disable --now nginx.service; "
        "fi && "
        "sudo rm -f /etc/nginx/sites-enabled/default && "
        "sudo python3 -c 'import json,pathlib; "
        "p=pathlib.Path(\"/etc/swiftfabric/api-service.json\"); "
        "c=json.loads(p.read_text()); "
        "c.pop(\"peer_https_enabled\",None); "
        "c.pop(\"http_compat_enabled\",None); "
        "p.write_text(json.dumps(c,separators=(\",\",\":\")))' "
        "&& sudo install -D -o root -g root -m 0644 /dev/stdin "
        "/etc/swiftfabric/swiftfabric-ca.crt",
        timeout=300,
        input_data=ca_certificate,
    )
    ssh.run(
        ip_address,
        "sudo install -D -o root -g root -m 0644 /dev/stdin "
        "/etc/swiftfabric/tls/ca-bundle.pem",
        timeout=30,
        input_data=ca_trust_bundle,
    )
    ssh.run(
        ip_address,
        "sudo install -D -o root -g root -m 0644 /dev/stdin "
        "/etc/nginx/sites-available/swiftfabric-api",
        timeout=30,
        input_data=ApiServiceDeployment._render_nginx_config().encode("utf-8"),
    )
    ssh.run(
        ip_address,
        "sudo install -D -o root -g root -m 0644 /dev/stdin "
        "/etc/swiftfabric/firewall.nft && "
        "sudo systemctl restart swiftfabric-segment-firewall.service",
        timeout=60,
        input_data=ApiServiceDeployment._render_firewall(
            controller_ips
        ).encode("utf-8"),
    )
    ssh.run(
        ip_address,
        "sudo install -D -o root -g root -m 0644 /dev/stdin "
        "/etc/systemd/system/nginx.service.d/swiftfabric-upstream.conf",
        timeout=30,
        input_data=ApiServiceDeployment._render_nginx_service_override().encode("utf-8"),
    )
    ssh.run(
        ip_address,
        "sudo install -D -o root -g root -m 0644 /dev/stdin "
        "/tmp/swiftfabric-api-service-upgrade.deb",
        timeout=120,
        input_data=package_path.read_bytes(),
    )
    ssh.run(
        ip_address,
        "sudo env DEBIAN_FRONTEND=noninteractive apt-get "
        "-o DPkg::Lock::Timeout=300 -y install "
        "/tmp/swiftfabric-api-service-upgrade.deb && "
        "sudo rm -f /tmp/swiftfabric-api-service-upgrade.deb && "
        "sudo systemctl daemon-reload && "
        "sudo systemctl enable swiftfabric-api-service.service && "
        "sudo systemctl restart swiftfabric-api-service.service && "
        "systemctl is-active --quiet swiftfabric-api-service.service && "
        "sudo ln -sfn /etc/nginx/sites-available/swiftfabric-api "
        "/etc/nginx/sites-enabled/swiftfabric-api && sudo nginx -t && "
        "sudo systemctl enable nginx.service && "
        + (
            "sudo systemctl enable --now swiftfabric-tls-renew.timer && "
            "test -z \"$(ss -H -lnt 'sport = :80')\""
            if defer_nginx_restart
            else "sudo systemctl restart nginx.service && "
            "sudo systemctl enable --now swiftfabric-tls-renew.timer && "
            "systemctl is-active --quiet nginx.service && "
            "test -z \"$(ss -H -lnt 'sport = :80')\""
        ),
        timeout=600,
    )
    _wait_for_local_health(ssh, controller, local_api_only=defer_nginx_restart)


def _activate_controller_tls(ssh, controller):
    ip_address = controller["ip_address"]
    ssh.run(
        ip_address,
        "sudo nginx -t && sudo systemctl restart nginx.service && "
        "systemctl is-active --quiet nginx.service && "
        "test -z \"$(ss -H -lnt 'sport = :80')\"",
        timeout=180,
    )
    _wait_for_local_health(ssh, controller)


def _publish_deployment_ca(agent_api, ca_certificate):
    certificate_fingerprint = hashlib.sha256(ca_certificate).hexdigest()
    _, result = agent_api.json(
        "POST",
        CA_TRUST_REPUBLISH_PATH,
        {
            "certificate": ca_certificate.decode("ascii"),
            "certificate_sha256": certificate_fingerprint,
        },
        max_time=1800,
    )
    if (
        not isinstance(result, dict)
        or result.get("complete") is not True
        or result.get("certificate_sha256") != certificate_fingerprint
        or type(result.get("host_count")) is not int
        or type(result.get("router_member_count")) is not int
    ):
        raise RuntimeError(
            "Controller did not confirm complete deployment CA trust publication."
        )
    console.print(
        "[green]✓ Deployment CA trust published to "
        f"{result['host_count']} host(s) and "
        f"{result['router_member_count']} router member(s).[/green]"
    )


def _upgrade_controllers(
    ssh,
    controllers,
    current_versions,
    package_version,
    package_path,
    api_vip,
    token,
    ca_certificate=b"",
    ca_bundle=None,
    ca_trust_bundle=None,
    ca_publisher=None,
):
    completed = []
    for index, controller in enumerate(controllers):
        name = controller["name"]
        try:
            if current_versions[name] == package_version:
                console.print(
                    f"{name} already has {package_version}; reconciling TLS configuration."
                )
            _upgrade_controller(
                ssh,
                controller,
                [item["ip_address"] for item in controllers],
                package_path,
                ca_certificate,
                ca_trust_bundle,
                index == 0,
            )
            completed.append(name)
            if index == 0:
                if ca_publisher is None:
                    raise RuntimeError(
                        "Deployment CA trust publisher is required before enabling "
                        "the first upgraded controller certificate."
                    )
                ca_publisher()
                _activate_controller_tls(ssh, controller)
        except Exception as exc:
            verified = ", ".join(completed) if completed else "none"
            raise RuntimeError(
                f"Upgrade failed while processing {name}. Controllers with a "
                f"healthy API package: {verified}. Remaining controllers were "
                f"not changed. Failure: {exc}"
            ) from exc
        console.print(f"[green]✓ {name} is at target version and healthy.[/green]")
    _wait_for_api(api_vip, token, ca_bundle)
    return completed


def run_upgrade(config_path, token, prefix="", controllername="swiftfabric-controller",
                yes=False, package_dir=None, auto_agent_upgrade=False,
                agent_options=None):
    config = load_deployment_config(config_path)
    token = resolve_api_token(token)
    api_vip = _controller_vip(config)
    deployment = _deployment_from_config(config)
    controllers = _build_upgrade_plan(config, deployment, prefix, controllername)
    package_dir = package_dir or Path(__file__).resolve().parents[1] / "packages"
    package_path = ApiServiceDeployment.find_package(Path(package_dir))
    package_version = _package_metadata(package_path)
    ssh = SSHCommandRunner(
        config["controller_priv_key"],
        "ubuntu",
        "the SwiftFabric controller package upgrade",
    )
    api_controller = _api_vip_owner(ssh, controllers, api_vip)
    _, has_user_management = _verify_api_access_over_ssh(
        ssh, api_controller, token
    )
    current_versions = {
        controller["name"]: _preflight_controller(
            ssh, controller, package_version, token, has_user_management
        )
        for controller in controllers
    }
    if has_user_management:
        _verify_controller_service_tokens(ssh, controllers)
    outdated_versions = {
        version for version in current_versions.values()
        if version != package_version
    }
    if len(outdated_versions) > 1:
        raise RuntimeError(
            "Controllers already being upgraded may be at the target package "
            "version, but all remaining controllers must share one prior version."
        )
    _show_plan(controllers, current_versions, package_version, auto_agent_upgrade)
    agent_target = None
    cluster_name = config.get("proxmox_cluster_name") or ""
    agent_options = agent_options or agent_upgrade.AgentUpgradeOptions()
    if auto_agent_upgrade:
        agent_target = agent_upgrade.package_agent_version(package_path)
        agent_api = agent_upgrade.ControllerApi(
            ssh, token, lambda: _api_vip_owner(ssh, controllers, api_vip)
        )
        workloads = agent_upgrade.ProxmoxWorkloads(deployment.client)
        agent_plan = agent_upgrade.build_plan(
            agent_api, workloads, agent_target, cluster_name, agent_options,
            runtime_target=package_version,
        )
        agent_upgrade.show_plan(agent_plan)
    prompt = (
        "[bold yellow]Upgrade these controller VMs one at a time, then the "
        "listed agents?[/bold yellow]"
        if auto_agent_upgrade
        else "[bold yellow]Upgrade these controller VMs one at a time?[/bold yellow]"
    )
    if not yes and not Confirm.ask(prompt, default=False):
        console.print("[yellow]Upgrade cancelled; no controllers were changed.[/yellow]")
        return

    tls_deployment = ApiServiceDeployment(
        config["controller_priv_key"], package_path
    )
    ca_certificate = tls_deployment._provision_tls(
        [controller["ip_address"] for controller in controllers],
        api_vip,
    )
    ca_trust_bundle = tls_deployment._ca_trust_bundle or ca_certificate
    ca_publisher = agent_upgrade.ControllerApi(
        ssh, token, lambda: controllers[0]
    )
    with tempfile.TemporaryDirectory(prefix="swiftfabric-controller-ca-") as directory:
        ca_bundle = Path(directory) / "swiftfabric-ca-bundle.crt"
        ca_bundle.write_bytes(ca_trust_bundle)
        ca_bundle.chmod(0o600)
        _upgrade_controllers(
            ssh,
            controllers,
            current_versions,
            package_version,
            package_path,
            api_vip,
            token,
            ca_certificate,
            str(ca_bundle),
            ca_trust_bundle,
            lambda: _publish_deployment_ca(ca_publisher, ca_certificate),
        )

    console.print(
        "[green]✓ Controller package upgrade completed. Controllers now serve "
        "the API over HTTPS only; the local API upstream remains loopback-only.[/green]"
    )
    if not auto_agent_upgrade:
        console.print(
            "[yellow]No compute-host or router agents were upgraded.[/yellow]"
        )
        return
    try:
        completed = agent_upgrade.run_agent_upgrades(
            agent_api, workloads, cluster_name, agent_target, agent_options,
            runtime_target=package_version,
        )
    except Exception as exc:
        raise RuntimeError(
            "Controllers were upgraded successfully, but the automated agent "
            f"upgrade stopped: {exc}\nRerun the same command to resume; "
            "upgraded controllers, hosts, and routers are skipped."
        ) from exc
    console.print(
        f"[green]✓ Automated agent upgrade completed "
        f"({len(completed)} host(s)/router(s); agent target {agent_target}, "
        f"router runtime target {package_version}).[/green]"
    )


def main(argv=None):
    args = parse_args(argv)
    try:
        run_upgrade(
            args.config,
            args.token,
            prefix=args.prefix,
            controllername=args.controllername,
            yes=args.yes,
            auto_agent_upgrade=args.auto_agent_upgrade,
            agent_options=agent_upgrade.AgentUpgradeOptions(
                migrate_back=not args.no_migrate_back,
                migrate_local_disks=args.migrate_local_disks,
                migration_timeout=args.migration_timeout,
            ),
        )
    except KeyboardInterrupt:
        console.print("\n[yellow]Upgrade interrupted.[/yellow]")
        return 130
    except Exception as exc:
        console.print(f"\n[red]✗ Upgrade failed: {exc}[/red]")
        console.print(
            "[yellow]If an upgrade had started, use the listed progress "
            "to determine which nodes or VMs require recovery.[/yellow]"
        )
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
