"""Prepare the configured remote buildbox with the pinned build environment."""

from __future__ import annotations

import argparse
import io
import shlex
import sys
import tarfile
import uuid
from pathlib import Path

from deployment.api_service import ApiServiceDeployment
from deployment.ssh import SSHCommandRunner


def prepare_buildbox(mode: str) -> None:
    project_root = Path(__file__).resolve().parents[1]
    deployment = ApiServiceDeployment(private_key="")
    buildbox = deployment._load_buildbox_config()
    ssh = SSHCommandRunner(
        buildbox["buildbox_key"],
        buildbox["buildbox_username"],
        "the pinned SwiftFabric build environment",
    )
    remote_root = f"/tmp/swiftfabric-buildbox-setup-{uuid.uuid4().hex}"
    files = (
        "build-environment.lock",
        "build-environment.sh",
        "prepare-buildbox.sh",
    )
    archive_buffer = io.BytesIO()
    with tarfile.open(fileobj=archive_buffer, mode="w:gz") as archive:
        for name in files:
            path = project_root / name
            if not path.is_file():
                raise FileNotFoundError(f"Required build setup file is missing: {path}")
            archive.add(path, arcname=name)

    remote_script = f"{remote_root}/prepare-buildbox.sh"
    operation_failed = False
    try:
        print(
            f"Uploading build setup files to {buildbox['buildbox_username']}@"
            f"{buildbox['buildbox_ip']}...",
            flush=True,
        )
        ssh.run(
            buildbox["buildbox_ip"],
            f"install -d -m 0700 {shlex.quote(remote_root)} && "
            f"tar -xzf - --no-same-owner --no-same-permissions "
            f"-C {shlex.quote(remote_root)}",
            timeout=60,
            input_data=archive_buffer.getvalue(),
        )
        print(
            f"Running {mode} on the configured buildbox. "
            "Package-manager output will appear below.",
            flush=True,
        )
        ssh.run(
            buildbox["buildbox_ip"],
            f"bash {shlex.quote(remote_script)} {shlex.quote(mode)} --local",
            timeout=1800 if mode == "--install" else 60,
            stream_output=True,
        )
    except Exception:
        operation_failed = True
        raise
    finally:
        try:
            ssh.run(
                buildbox["buildbox_ip"],
                f"rm -rf -- {shlex.quote(remote_root)}",
                timeout=30,
            )
        except (RuntimeError, TimeoutError) as exc:
            if not operation_failed:
                raise RuntimeError(
                    f"Could not remove temporary buildbox setup directory {remote_root}."
                ) from exc
            else:
                print(
                    f"Could not remove temporary buildbox setup directory "
                    f"{remote_root}: {exc}",
                    file=sys.stderr,
                )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Install or check the pinned build environment on the configured buildbox."
    )
    mode_group = parser.add_mutually_exclusive_group(required=True)
    mode_group.add_argument("--install", action="store_true")
    mode_group.add_argument("--check", action="store_true")
    args = parser.parse_args()
    prepare_buildbox("--install" if args.install else "--check")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
