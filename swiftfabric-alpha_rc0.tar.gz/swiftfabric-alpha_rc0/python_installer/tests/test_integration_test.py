import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location(
    "integration_test",
    ROOT / "python_installer" / "tests_integration" / "non_interactive.py",
)
integration_test = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(integration_test)
validate_package_fingerprint = integration_test.validate_package_fingerprint


class IntegrationTestTests(unittest.TestCase):
    def setUp(self):
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary_directory.cleanup)
        self.root = Path(self.temporary_directory.name)
        (self.root / "packages").mkdir()
        (self.root / "packages" / "swiftfabric-api-service_test_amd64.deb").touch()
        self.config_path = self.root / "config.json"
        self.config = {
            "auto_enroll_host_list": ["compute1"],
            "proxmox_cluster_name": "test-cluster",
            "vtep_vlan_id": 200,
            "vtep_ip_range_cidr": "192.0.2.0/24",
            "vtep_mtu": 9000,
            "vtep_interface": "eno2",
        }
        self.write_config()
        fingerprint_patch = mock.patch.object(
            integration_test, "validate_package_fingerprint"
        )
        self.fingerprint_check = fingerprint_patch.start()
        self.addCleanup(fingerprint_patch.stop)
        verifier_patch = mock.patch.object(
            integration_test, "verify_controller_configs", return_value=[],
        )
        self.verifier = verifier_patch.start()
        self.addCleanup(verifier_patch.stop)
        target_patch = mock.patch.object(integration_test, "require_empty_target")
        self.target_check = target_patch.start()
        self.addCleanup(target_patch.stop)
        forget_patch = mock.patch.object(
            integration_test, "forget_stale_controller_host_keys",
        )
        self.forget_keys = forget_patch.start()
        self.addCleanup(forget_patch.stop)

    def write_config(self):
        self.config_path.write_text(json.dumps(self.config), encoding="utf-8")

    def test_preflight_accepts_complete_enrollment_config(self):
        integration_test.preflight(self.config_path, self.root)
        self.fingerprint_check.assert_called_once_with(
            self.root / "packages" / "swiftfabric-api-service_test_amd64.deb",
            self.root,
        )
        self.target_check.assert_called_once_with(self.config, self.config_path.parent)
        self.forget_keys.assert_called_once_with(self.config)

    def test_existing_deployment_stops_before_install_or_cleanup(self):
        self.target_check.side_effect = ValueError(
            "Point the test kit at a system with no SwiftFabric installation active."
        )
        with mock.patch.object(integration_test, "run_lifecycle") as lifecycle, \
                mock.patch("builtins.print") as output:
            status = integration_test.main(["--yes", "--config", str(self.config_path)])
        self.assertEqual(status, 1)
        self.forget_keys.assert_not_called()
        lifecycle.assert_not_called()
        self.assertIn("no SwiftFabric installation active", str(output.call_args_list))

    def test_preflight_accepts_legacy_enrollment_key(self):
        self.config["proxmox_auto_enroll_host_list"] = self.config.pop(
            "auto_enroll_host_list"
        )
        self.write_config()

        integration_test.preflight(self.config_path, self.root)

    def test_preflight_rejects_missing_host_selection_or_vtep(self):
        for key in ("auto_enroll_host_list", "vtep_interface"):
            with self.subTest(key=key):
                original = self.config.pop(key)
                self.write_config()
                with self.assertRaises(ValueError):
                    integration_test.preflight(self.config_path, self.root)
                self.config[key] = original

    def test_preflight_rejects_ambiguous_api_package_set(self):
        (self.root / "packages" / "swiftfabric-api-service_other_amd64.deb").touch()

        with self.assertRaisesRegex(ValueError, "exactly one"):
            integration_test.preflight(self.config_path, self.root)

    def test_stale_package_stops_before_install(self):
        self.fingerprint_check.side_effect = ValueError("API-service package is stale")
        with mock.patch.object(integration_test, "run_lifecycle") as lifecycle, \
                mock.patch("builtins.print"):
            status = integration_test.main([
                "--yes", "--config", str(self.config_path),
            ])
        self.assertEqual(status, 1)
        lifecycle.assert_not_called()

    def test_install_failure_still_runs_auto_unenroll_destroy(self):
        results = [
            subprocess.CompletedProcess([], 1),
            subprocess.CompletedProcess([], 0),
        ]
        with mock.patch.object(
            integration_test.uuid,
            "uuid4",
            return_value=mock.Mock(hex="0123456789abcdef"),
        ), mock.patch.object(
            integration_test.subprocess, "run", side_effect=results
        ) as run, mock.patch("builtins.print"):
            status = integration_test.run_lifecycle(
                self.config_path,
                self.root,
            )

        self.assertEqual(status, 1)
        install_command, cleanup_command = [
            call.args[0] for call in run.call_args_list
        ]
        self.assertIn("--non-interactive", install_command)
        self.assertIn("--auto-unenroll", cleanup_command)
        self.assertIn("--destroy", cleanup_command)
        self.assertEqual(install_command[install_command.index("--prefix") + 1],
                         cleanup_command[cleanup_command.index("--prefix") + 1])

    def test_successful_install_requires_successful_cleanup(self):
        results = [
            subprocess.CompletedProcess([], 0),
            subprocess.CompletedProcess([], 1),
        ]
        with mock.patch(
            "builtins.print"
        ), mock.patch.object(
            integration_test.subprocess, "run", side_effect=results
        ):
            status = integration_test.run_lifecycle(self.config_path, self.root)

        self.assertEqual(status, 1)

    def test_successful_install_and_cleanup_pass(self):
        results = [
            subprocess.CompletedProcess([], 0),
            subprocess.CompletedProcess([], 0),
        ]
        with mock.patch(
            "builtins.print"
        ), mock.patch.object(
            integration_test.subprocess, "run", side_effect=results
        ):
            status = integration_test.run_lifecycle(self.config_path, self.root)

        self.assertEqual(status, 0)

    def test_retained_install_never_destroys_and_uses_supplied_prefix(self):
        for install_status in (0, 1):
            with self.subTest(install_status=install_status), \
                    mock.patch("builtins.print") as output, \
                    mock.patch.object(
                        integration_test.subprocess, "run",
                        return_value=subprocess.CompletedProcess([], install_status),
                    ) as run:
                status = integration_test.run_lifecycle(
                    self.config_path, self.root, keep_deployment=True, prefix="sf-dr-owned",
                )
            self.assertEqual(status, install_status)
            run.assert_called_once()
            command = run.call_args.args[0]
            self.assertNotIn("--destroy", command)
            self.assertEqual(command[command.index("--prefix") + 1], "sf-dr-owned")
            self.assertIn("Teardown only", str(output.call_args_list))

    def test_retained_install_still_fails_config_copy_validation(self):
        self.verifier.return_value = ["config mismatch"]
        with mock.patch("builtins.print"), mock.patch.object(
            integration_test.subprocess, "run",
            return_value=subprocess.CompletedProcess([], 0),
        ) as run:
            status = integration_test.run_lifecycle(
                self.config_path, self.root, keep_deployment=True,
            )
        self.assertEqual(status, 1)
        run.assert_called_once()

    def test_retained_install_interrupt_never_destroys(self):
        with mock.patch("builtins.print"), mock.patch.object(
            integration_test.subprocess, "run", side_effect=KeyboardInterrupt,
        ) as run:
            status = integration_test.run_lifecycle(
                self.config_path, self.root, keep_deployment=True,
            )
        self.assertEqual(status, 130)
        run.assert_called_once()

    def test_successful_install_checks_controller_copy_of_config(self):
        results = [
            subprocess.CompletedProcess([], 0),
            subprocess.CompletedProcess([], 0),
        ]
        self.verifier.return_value = ["192.0.2.10: missing"]
        with mock.patch("builtins.print"), mock.patch.object(
            integration_test.subprocess, "run", side_effect=results
        ) as run:
            status = integration_test.run_lifecycle(self.config_path, self.root)

        self.assertEqual(status, 1)
        self.assertEqual(run.call_count, 2)
        self.assertEqual(self.verifier.call_args.args[2], self.config_path.read_bytes())

    def test_failed_install_skips_controller_config_check(self):
        results = [
            subprocess.CompletedProcess([], 1),
            subprocess.CompletedProcess([], 0),
        ]
        with mock.patch("builtins.print"), mock.patch.object(
            integration_test.subprocess, "run", side_effect=results
        ):
            integration_test.run_lifecycle(self.config_path, self.root)
        self.verifier.assert_not_called()

    def test_interrupted_install_still_runs_cleanup(self):
        results = [
            KeyboardInterrupt,
            subprocess.CompletedProcess([], 0),
        ]
        with mock.patch(
            "builtins.print"
        ), mock.patch.object(
            integration_test.subprocess, "run", side_effect=results
        ) as run:
            status = integration_test.run_lifecycle(self.config_path, self.root)

        self.assertEqual(status, 130)
        self.assertEqual(run.call_count, 2)
        self.assertIn("--destroy", run.call_args_list[1].args[0])


class ControllerConfigCheckTests(unittest.TestCase):
    def test_checks_three_controllers_with_exact_root_only_copy(self):
        common = sys.modules["integration_common"]
        config = {"mgmt_ip_range_start": "192.0.2.10", "mgmt_priv_key": "controller"}
        outputs = [
            subprocess.CompletedProcess([], 0, stdout=b"600 root root\n"),
            subprocess.CompletedProcess([], 1, stdout=b""),
            subprocess.CompletedProcess([], 0, stdout=b"644 root root\n"),
        ]
        runner = mock.Mock(side_effect=outputs)

        problems = common.verify_controller_configs(config, Path("/cfg"), b"{}", runner)

        self.assertEqual(len(problems), 2)
        self.assertIn("192.0.2.11", problems[0])
        self.assertIn("644", problems[1])
        commands = [call.args[0] for call in runner.call_args_list]
        self.assertEqual([command[-2] for command in commands],
                         ["ubuntu@192.0.2.10", "ubuntu@192.0.2.11", "ubuntu@192.0.2.12"])
        self.assertTrue(all(command[2] == "/cfg/controller" for command in commands))
        self.assertTrue(all("/etc/swiftfabric/config.json" in command[-1] for command in commands))
        self.assertTrue(all(call.kwargs["input"] == b"{}" for call in runner.call_args_list))
        self.assertTrue(all("StrictHostKeyChecking=accept-new" in command for command in commands))
        self.assertTrue(all("UserKnownHostsFile=/dev/null" not in command for command in commands))


class AutomatedTofuTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.home = Path(temporary.name)
        patcher = mock.patch.object(Path, "home", return_value=self.home)
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_integration_entry_points_start_in_fresh_processes(self):
        for script in ("interactive.py", "non_interactive.py"):
            with self.subTest(script=script):
                result = subprocess.run(
                    [sys.executable,
                     str(ROOT / "python_installer" / "tests_integration" / script),
                     "--help"],
                    cwd=self.home, capture_output=True, text=True, timeout=15,
                )
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertIn("--yes", result.stdout)
                self.assertFalse((self.home / ".ssh").exists())

    def test_both_runners_scope_tofu_to_preflight_and_lifecycle(self):
        spec = importlib.util.spec_from_file_location(
            "tofu_interactive_test",
            ROOT / "python_installer" / "tests_integration" / "interactive.py",
        )
        interactive = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(interactive)
        variable = "SWIFTFABRIC_INTEGRATION_TOFU"
        for module in (integration_test, interactive):
            for failure in (False, True):
                with self.subTest(module=module.__name__, failure=failure), \
                        mock.patch.dict(os.environ, {variable: "previous"}):
                    def preflight(*_args):
                        self.assertEqual(os.environ[variable], "1")
                        if failure:
                            raise ValueError("preflight failed")
                        return {}

                    def lifecycle(*_args, **_kwargs):
                        self.assertEqual(os.environ[variable], "1")
                        child = subprocess.check_output(
                            [sys.executable, "-c",
                             f"import os; print(os.environ[{variable!r}])"],
                            text=True,
                        )
                        self.assertEqual(child.strip(), "1")
                        return 0

                    with mock.patch.object(module, "preflight", side_effect=preflight), \
                            mock.patch.object(module, "run_lifecycle", side_effect=lifecycle) as run, \
                            mock.patch("builtins.print"):
                        status = module.main(["--yes", "--config", "/tmp/test-config.json"])
                    self.assertEqual(status, 1 if failure else 0)
                    self.assertEqual(run.call_count, 0 if failure else 1)
                    self.assertEqual(os.environ[variable], "previous")

    def test_context_removes_new_variable_even_on_interrupt(self):
        common = sys.modules["integration_common"]
        variable = "SWIFTFABRIC_INTEGRATION_TOFU"
        with mock.patch.dict(os.environ):
            os.environ.pop(variable, None)
            with self.assertRaises(KeyboardInterrupt):
                with common.automated_ssh_tofu():
                    self.assertEqual(os.environ[variable], "1")
                    raise KeyboardInterrupt
            self.assertNotIn(variable, os.environ)

    def test_session_discards_stale_keys_then_preserves_pins_until_exit(self):
        common = sys.modules["integration_common"]
        path = self.home / ".ssh" / "swiftfabric-integration-known-hosts"
        path.parent.mkdir()
        path.write_text("stale pin from interrupted test\n")
        normal = path.with_name("known_hosts")
        normal.write_text("normal deployment pin\n")
        for interrupted in (False, True):
            with self.subTest(interrupted=interrupted), mock.patch.dict(os.environ):
                try:
                    with common.automated_ssh_tofu():
                        self.assertEqual(path.read_text(), "")
                        self.assertEqual(path.stat().st_mode & 0o777, 0o600)
                        runner = common.SSHCommandRunner(None, "ubuntu", "test")
                        self.assertEqual(runner.known_hosts_file, path)
                        with mock.patch.object(runner, "_scan_host_keys", return_value=[
                            "192.0.2.10 ssh-ed25519 c3ludGhldGljLWhvc3Qta2V5",
                        ]) as scan, mock.patch("builtins.input") as prompt:
                            runner.ensure_host_key("192.0.2.10")
                            saved = path.read_text()
                            runner.ensure_host_key("192.0.2.10")
                            self.assertEqual(path.read_text(), saved)
                            scan.assert_called_once()
                            prompt.assert_not_called()
                        self.assertEqual(common.forget_stale_controller_host_keys({}), [])
                        self.assertEqual(path.read_text(), saved)
                        if interrupted:
                            raise KeyboardInterrupt
                except KeyboardInterrupt:
                    pass
                self.assertFalse(path.exists())
                self.assertEqual(normal.read_text(), "normal deployment pin\n")

    def test_overlapping_run_cannot_clear_active_session_pins(self):
        common = sys.modules["integration_common"]
        with common.automated_ssh_tofu():
            path = Path(os.environ["SWIFTFABRIC_INTEGRATION_KNOWN_HOSTS"])
            path.write_text("active session pin\n")
            with self.assertRaisesRegex(ValueError, "Another integration test"):
                with common.automated_ssh_tofu():
                    self.fail("overlapping trust session accepted")
            self.assertEqual(path.read_text(), "active session pin\n")


class PackageFingerprintTests(unittest.TestCase):
    def test_package_marker_must_match_current_source(self):
        expected = "a" * 64
        for marker in (expected + "\n", "b" * 64, None):
            with self.subTest(marker=marker), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)

                def run(command, **kwargs):
                    if command[0] == "dpkg-deb" and marker is not None:
                        path = Path(command[-1]) / (
                            "usr/share/doc/swiftfabric-api-service/source-fingerprint"
                        )
                        path.parent.mkdir(parents=True)
                        path.write_text(marker, encoding="ascii")
                    return subprocess.CompletedProcess(command, 0, stdout=expected)

                with mock.patch.object(integration_test.subprocess, "run", side_effect=run):
                    if marker == expected + "\n":
                        validate_package_fingerprint(root / "package.deb", root)
                    else:
                        with self.assertRaisesRegex(ValueError, "stale"):
                            validate_package_fingerprint(root / "package.deb", root)

    def test_corrupt_package_is_not_accepted(self):
        with mock.patch.object(
            integration_test.subprocess, "run",
            side_effect=[
                subprocess.CompletedProcess([], 0, stdout="a" * 64),
                subprocess.CalledProcessError(2, ["dpkg-deb", "-x"]),
            ],
        ), self.assertRaises(subprocess.CalledProcessError):
            validate_package_fingerprint(Path("package.deb"), ROOT)


if __name__ == "__main__":
    unittest.main()
