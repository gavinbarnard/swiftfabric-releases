import hashlib
import json
import shlex
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import upgrade


class UpgradeTests(unittest.TestCase):
    def test_dash_prefixed_tokens_work_with_flags_and_equals(self):
        for token in ("-synthetic-token", "-" + "a" * 63, "--" + "b" * 62,
                      "--option-shaped-token"):
            forms = [[f"--token={token}"]]
            if not token.startswith("--") or len(token) == 64:
                forms.append(["--token", token])
            for form in forms:
                with self.subTest(token=token, form=form):
                    args = upgrade.parse_args([
                        "--config", "config.json", *form, "--auto-agent-upgrade",
                    ])
                    self.assertEqual(args.token, token)
                    self.assertTrue(args.auto_agent_upgrade)

    def test_bare_token_preserves_following_flags_and_rejects_unknown_options(self):
        args = upgrade.parse_args([
            "--config", "config.json", "--token", "--auto-agent-upgrade", "--yes",
        ])
        self.assertEqual(args.token, "")
        self.assertTrue(args.auto_agent_upgrade)
        self.assertTrue(args.yes)
        with mock.patch.object(upgrade.sys, "stderr"):
            with self.assertRaises(SystemExit):
                upgrade.parse_args(["--config", "config.json", "--token", "--typo"])

    def test_token_argument_is_required_and_can_prompt(self):
        with mock.patch.object(upgrade.sys, "stderr"):
            with self.assertRaises(SystemExit) as failure:
                upgrade.parse_args(["--config", "config.json"])
        self.assertEqual(failure.exception.code, 2)

        args = upgrade.parse_args(["--config", "config.json", "--token"])
        self.assertEqual(args.token, "")
        self.assertTrue(args.config)

        with mock.patch.object(upgrade.sys, "stderr"):
            with self.assertRaises(SystemExit):
                upgrade.parse_args(
                    ["--config", "config.json", "--token", "token", "--retire-http"]
                )

    def test_token_prompt_is_secure_and_requires_a_terminal(self):
        with mock.patch.object(
            upgrade.sys, "stdin", mock.Mock(isatty=lambda: True)
        ), mock.patch.object(
            upgrade.getpass, "getpass", return_value=" token-value "
        ) as prompt:
            self.assertEqual(upgrade.resolve_api_token(""), "token-value")
        prompt.assert_called_once_with("Controller API bearer token: ")

        with mock.patch.object(
            upgrade.sys, "stdin", mock.Mock(isatty=lambda: False)
        ):
            with self.assertRaisesRegex(ValueError, "interactive terminal"):
                upgrade.resolve_api_token("")

    def test_upgrade_preflight_uses_only_the_loopback_api_upstream(self):
        ssh = mock.Mock()
        ssh.run.return_value = '{"ok":true}\n200'

        status, body = upgrade._request_local_api(
            ssh,
            {"name": "controller-0", "ip_address": "192.0.2.10"},
            "api-token",
            "/api/v1/cluster",
        )

        command = ssh.run.call_args.args[1]
        self.assertEqual((status, body), (200, '{"ok":true}'))
        self.assertIn("http://127.0.0.1:8080/api/v1/cluster", command)
        self.assertNotIn("http://127.0.0.1:80/", command)
        self.assertNotIn("192.0.2.10:", command)

    def test_api_preflight_requires_valid_token_and_cluster_status(self):
        response = mock.Mock()
        response.json.return_value = {"corosync": "ok"}
        with mock.patch.object(upgrade.requests, "get", return_value=response) as get:
            status = upgrade._verify_api_access("192.0.2.13", "secret-token")

        self.assertEqual(status, {"corosync": "ok"})
        self.assertEqual(get.call_args.args[0], "https://192.0.2.13/api/v1/cluster")
        self.assertEqual(
            get.call_args.kwargs["headers"],
            {"Authorization": "Bearer secret-token"},
        )

        response.raise_for_status.side_effect = upgrade.requests.HTTPError(
            response=mock.Mock(status_code=401)
        )
        with mock.patch.object(upgrade.requests, "get", return_value=response):
            with self.assertRaisesRegex(
                RuntimeError, "rejected.*GET /api/v1/cluster"
            ):
                upgrade._verify_api_access("192.0.2.13", "bad-token")

    def test_api_vip_owner_selects_the_only_controller_with_vip_assigned(self):
        ssh = mock.Mock()
        ssh.run.side_effect = ["false\n", "true\n", "false\n"]
        controllers = [
            {"name": f"controller-{index}", "ip_address": f"192.0.2.{10 + index}"}
            for index in range(3)
        ]

        owner = upgrade._api_vip_owner(ssh, controllers, "192.0.2.13")

        self.assertIs(owner, controllers[1])
        self.assertEqual(ssh.run.call_count, 3)
        self.assertTrue(all("address" in call.args[1] for call in ssh.run.call_args_list))

    def test_api_vip_owner_rejects_missing_or_duplicate_assignment(self):
        controllers = [
            {"name": f"controller-{index}", "ip_address": f"192.0.2.{10 + index}"}
            for index in range(3)
        ]
        for owners, message in (
            (["false\n"] * 3, "not assigned"),
            (["true\n", "true\n", "false\n"], "multiple controllers"),
        ):
            with self.subTest(message=message):
                ssh = mock.Mock()
                ssh.run.side_effect = owners
                with self.assertRaisesRegex(RuntimeError, message):
                    upgrade._api_vip_owner(ssh, controllers, "192.0.2.13")

    def test_admin_api_key_check_supports_legacy_and_scoped_service(self):
        response = mock.Mock(status_code=404)
        with mock.patch.object(upgrade.requests, "get", return_value=response):
            self.assertFalse(
                upgrade._verify_admin_api_key("192.0.2.13", "legacy-token")
            )

        response = mock.Mock(status_code=200)
        response.json.return_value = {"username": "admin", "is_admin": True}
        with mock.patch.object(upgrade.requests, "get", return_value=response) as get:
            self.assertTrue(
                upgrade._verify_admin_api_key("192.0.2.13", "rotated-admin-key")
            )
        self.assertEqual(
            get.call_args.kwargs["headers"],
            {"Authorization": "Bearer rotated-admin-key"},
        )

        response.json.return_value = {"username": "limited", "is_admin": False}
        with mock.patch.object(upgrade.requests, "get", return_value=response):
            with self.assertRaisesRegex(RuntimeError, "admin API key"):
                upgrade._verify_admin_api_key("192.0.2.13", "limited-user-key")

        response.status_code = 401
        with mock.patch.object(upgrade.requests, "get", return_value=response):
            with self.assertRaisesRegex(
                RuntimeError, "rejected.*GET /api/v1/system/me"
            ):
                upgrade._verify_admin_api_key("192.0.2.13", "bad-token")

    def test_package_metadata_parses_dpkg_deb_labeled_fields(self):
        result = mock.Mock(
            returncode=0,
            stdout="Version: 1:0.1.0+40.master.abc123\nArchitecture: amd64\n",
        )
        with mock.patch.object(upgrade.subprocess, "run", return_value=result):
            self.assertEqual(
                upgrade._package_metadata(Path("service.deb")),
                "1:0.1.0+40.master.abc123",
            )

        result.stdout = "Version: 0.1.0\nArchitecture: arm64\n"
        with mock.patch.object(upgrade.subprocess, "run", return_value=result):
            with self.assertRaisesRegex(RuntimeError, "architecture"):
                upgrade._package_metadata(Path("service.deb"))

    def test_upgrade_plan_requires_exact_ip_set_and_running_controllers(self):
        controllers = [
            {"name": "swiftfabric-controller-2", "status": "running"},
            {"name": "swiftfabric-controller-0", "status": "running"},
            {"name": "swiftfabric-controller-1", "status": "running"},
        ]
        deployment = mock.Mock()
        deployment.find_controllers_to_destroy.return_value = {
            "matches": controllers,
            "not_found": [],
        }
        ips = {
            "swiftfabric-controller-0": "192.0.2.10",
            "swiftfabric-controller-1": "192.0.2.11",
            "swiftfabric-controller-2": "192.0.2.12",
        }
        with mock.patch.object(
            upgrade, "_controller_vm_ip", side_effect=lambda _dep, vm: ips[vm["name"]]
        ):
            plan = upgrade._build_upgrade_plan(
                {"ip_range_start": "192.0.2.10"},
                deployment,
                "",
                "swiftfabric-controller",
            )
        self.assertEqual(
            [controller["ip_address"] for controller in plan],
            ["192.0.2.10", "192.0.2.11", "192.0.2.12"],
        )

        deployment.find_controllers_to_destroy.return_value["not_found"] = [
            "swiftfabric-controller-2"
        ]
        with self.assertRaisesRegex(RuntimeError, "incomplete"):
            upgrade._build_upgrade_plan(
                {"ip_range_start": "192.0.2.10"},
                deployment,
                "",
                "swiftfabric-controller",
            )

    def test_preflight_requires_matching_existing_token_and_newer_version(self):
        ssh = mock.Mock()
        ssh.run.side_effect = [
            "installed\n0.1.0\n",
            "",
            "",
            "",
        ]
        controller = {"name": "controller-0", "ip_address": "192.0.2.10"}
        self.assertEqual(
            upgrade._preflight_controller(ssh, controller, "0.2.0", "api-token"),
            "0.1.0",
        )
        compare_command = ssh.run.call_args_list[2].args[1]
        self.assertIn("0.2.0", compare_command)
        self.assertIn("ge", compare_command)
        self.assertEqual(
            ssh.run.call_args_list[3].kwargs["input_data"],
            b"api-token\n",
        )

        ssh.run.side_effect = [
            "installed\n0.2.0\n",
            "",
            "",
            "",
        ]
        self.assertEqual(
            upgrade._preflight_controller(ssh, controller, "0.2.0", "api-token"),
            "0.2.0",
        )

    def test_preflight_accepts_admin_key_without_replacing_service_token(self):
        ssh = mock.Mock()
        ssh.run.side_effect = [
            "installed\n0.1.0\n",
            "",
            "",
        ]
        controller = {"name": "controller-0", "ip_address": "192.0.2.10"}
        self.assertEqual(
            upgrade._preflight_controller(
                ssh,
                controller,
                "0.2.0",
                "rotated-admin-key",
                allow_admin_key=True,
            ),
            "0.1.0",
        )
        self.assertEqual(ssh.run.call_count, 3)

    def test_controller_service_token_fingerprints_must_be_distinct(self):
        ssh = mock.Mock()
        fingerprint = "a" * 64
        ssh.run.side_effect = [fingerprint, "b" * 64, "c" * 64]
        controllers = [
            {"name": f"controller-{index}", "ip_address": f"192.0.2.{10 + index}"}
            for index in range(3)
        ]
        upgrade._verify_controller_service_tokens(ssh, controllers)
        self.assertEqual(ssh.run.call_count, 3)

        ssh.run.side_effect = [fingerprint, "b" * 64, fingerprint]
        with self.assertRaisesRegex(RuntimeError, "shared"):
            upgrade._verify_controller_service_tokens(ssh, controllers)

    def test_service_token_preflight_verifies_separate_service_file_not_admin_key(self):
        service_token = "sfc_" + "a" * 64
        admin_key = "sfk_initial-admin-key"
        config = {
            "api_token": service_token,
            "initial_admin_token_hash": hashlib.sha256(admin_key.encode()).hexdigest(),
            "node_id": 0,
            "controller_token_hashes": [
                hashlib.sha256(service_token.encode()).hexdigest(),
                hashlib.sha256(("sfc_" + "b" * 64).encode()).hexdigest(),
                hashlib.sha256(("sfc_" + "c" * 64).encode()).hexdigest(),
            ],
        }
        controller = {"name": "controller-0", "ip_address": "192.0.2.10"}

        def verify_remote(_address, command, **_kwargs):
            code = shlex.split(command)[-1]
            files = {
                "/etc/swiftfabric/api-service.json": json.dumps(config),
                "/etc/swiftfabric/controller-service.token": service_token + "\n",
            }
            with mock.patch.object(Path, "read_text", autospec=True,
                                   side_effect=lambda path: files[str(path)]), \
                    mock.patch("builtins.print") as output:
                exec(compile(code, "<service-token-preflight>", "exec"), {})
            return output.call_args.args[0]

        ssh = mock.Mock()
        ssh.run.side_effect = verify_remote
        self.assertEqual(
            upgrade._controller_service_token_fingerprint(ssh, controller),
            hashlib.sha256(service_token.encode()).hexdigest(),
        )
        for admin_hash in [None, "", hashlib.sha256(service_token.encode()).hexdigest()]:
            with self.subTest(admin_hash=admin_hash):
                config["initial_admin_token_hash"] = admin_hash
                with self.assertRaises(SystemExit):
                    upgrade._controller_service_token_fingerprint(ssh, controller)
        config["initial_admin_token_hash"] = hashlib.sha256(admin_key.encode()).hexdigest()
        hashes = config["controller_token_hashes"]
        for invalid in [None, {}, [], ["a" * 64] * 3, [{}, "b" * 64, "c" * 64],
                        ["a" * 64, "b" * 64, "c" * 64],
                        [hashes[0], config["initial_admin_token_hash"], hashes[2]]]:
            with self.subTest(hashes=invalid):
                config["controller_token_hashes"] = invalid
                with self.assertRaises(SystemExit):
                    upgrade._controller_service_token_fingerprint(ssh, controller)
        config["controller_token_hashes"] = hashes
        for invalid in [None, True, -1, 3, "0"]:
            with self.subTest(node_id=invalid):
                config["node_id"] = invalid
                with self.assertRaises(SystemExit):
                    upgrade._controller_service_token_fingerprint(ssh, controller)

    def test_upgrade_installs_controller_package_and_checks_local_health(self):
        ssh = mock.Mock()
        with tempfile.TemporaryDirectory() as directory:
            package = Path(directory) / "service.deb"
            package.write_bytes(b"controller-package")
            with mock.patch.object(upgrade, "_wait_for_api") as wait_for_api:
                upgrade._upgrade_controller(
                    ssh,
                    {"name": "controller-0", "ip_address": "192.0.2.10"},
                    ["192.0.2.10", "192.0.2.11", "192.0.2.12"],
                    package,
                    b"ca-certificate",
                )

        self.assertEqual(ssh.run.call_count, 8)
        prepare_command = ssh.run.call_args_list[0].args[1]
        self.assertIn("systemctl is-active --quiet nginx.service", prepare_command)
        self.assertIn("test -z \"$(ss -H -lnt 'sport = :80')\"", prepare_command)
        self.assertIn("Staging HTTPS controller upgrade without stopping services", prepare_command)
        self.assertLess(
            prepare_command.index("else"),
            prepare_command.index("sudo systemctl stop"),
        )
        self.assertLess(
            prepare_command.index("sudo systemctl stop"),
            prepare_command.index("apt-get"),
        )
        self.assertIn("nginx", prepare_command)
        shell_check = upgrade.subprocess.run(
            ["bash", "-n"], input=prepare_command, text=True,
            capture_output=True, check=False,
        )
        self.assertEqual(shell_check.returncode, 0, shell_check.stderr)
        self.assertIn('c.pop("peer_https_enabled",None)', prepare_command)
        self.assertIn('c.pop("http_compat_enabled",None)', prepare_command)
        trust_bundle_command = ssh.run.call_args_list[1].args[1]
        self.assertIn("/etc/swiftfabric/tls/ca-bundle.pem", trust_bundle_command)
        nginx_config = ssh.run.call_args_list[2].kwargs["input_data"].decode()
        self.assertIn("listen 443 ssl default_server;", nginx_config)
        self.assertNotIn("listen 80", nginx_config)
        firewall_command = ssh.run.call_args_list[3].args[1]
        self.assertIn("swiftfabric-segment-firewall.service", firewall_command)
        self.assertIn(
            "tcp dport 443 accept",
            ssh.run.call_args_list[3].kwargs["input_data"].decode(),
        )
        firewall = ssh.run.call_args_list[3].kwargs["input_data"].decode()
        self.assertIn("tcp dport 80 drop", firewall)
        install_command = ssh.run.call_args_list[5].args[1]
        self.assertIn("/tmp/swiftfabric-api-service-upgrade.deb", install_command)
        update_command = ssh.run.call_args_list[6].args[1]
        self.assertIn("apt-get", update_command)
        self.assertIn("-o DPkg::Lock::Timeout=300", update_command)
        self.assertIn("install /tmp/swiftfabric-api-service-upgrade.deb", update_command)
        self.assertNotIn("dpkg -i", update_command)
        self.assertEqual(ssh.run.call_args_list[6].kwargs["timeout"], 600)
        self.assertIn("systemctl restart swiftfabric-api-service.service", update_command)
        self.assertIn("test -z \"$(ss -H -lnt 'sport = :80')\"", update_command)
        self.assertNotIn("curl", update_command)
        shell_check = upgrade.subprocess.run(
            ["bash", "-n"],
            input=update_command,
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(shell_check.returncode, 0, shell_check.stderr)
        health_check = ssh.run.call_args_list[7].args[1]
        self.assertIn("until sudo -n curl", health_check)
        self.assertIn("https://192.0.2.10/api/v1/health", health_check)
        self.assertIn("/etc/swiftfabric/tls/ca-bundle.pem", health_check)
        self.assertIn(str(upgrade.LOCAL_HEALTH_RETRIES), health_check)
        self.assertIn("systemctl --no-pager --full status", health_check)
        self.assertNotIn("host-upgrade", health_check.lower())
        wait_for_api.assert_not_called()

    def test_first_controller_https_restart_is_deferred_until_trust_publication(self):
        ssh = mock.Mock()
        with tempfile.TemporaryDirectory() as directory:
            package = Path(directory) / "service.deb"
            package.write_bytes(b"controller-package")
            upgrade._upgrade_controller(
                ssh,
                {"name": "controller-0", "ip_address": "192.0.2.10"},
                ["192.0.2.10", "192.0.2.11", "192.0.2.12"],
                package,
                b"new-ca",
                b"old-ca\nnew-ca",
                True,
            )

        update_command = ssh.run.call_args_list[6].args[1]
        self.assertNotIn("sudo systemctl restart nginx.service", update_command)
        self.assertNotIn("systemctl is-active --quiet nginx.service", update_command)
        health_check = ssh.run.call_args_list[7].args[1]
        self.assertIn("http://127.0.0.1:8080/api/v1/health", health_check)
        self.assertNotIn("--cacert", health_check)

    def test_ca_publication_requires_matching_complete_acknowledgement(self):
        agent_api = mock.Mock()
        certificate = b"controller-ca"
        fingerprint = upgrade.hashlib.sha256(certificate).hexdigest()
        agent_api.json.return_value = (
            200,
            {
                "complete": True,
                "certificate_sha256": fingerprint,
                "host_count": 2,
                "router_member_count": 3,
            },
        )

        upgrade._publish_deployment_ca(agent_api, certificate)

        agent_api.json.assert_called_once_with(
            "POST",
            upgrade.CA_TRUST_REPUBLISH_PATH,
            {
                "certificate": "controller-ca",
                "certificate_sha256": fingerprint,
            },
            max_time=1800,
        )
        agent_api.json.return_value[1]["complete"] = False
        with self.assertRaisesRegex(RuntimeError, "did not confirm complete"):
            upgrade._publish_deployment_ca(agent_api, certificate)

    def test_upgrade_preparation_keeps_https_services_running_but_migrates_http(self):
        ssh = mock.Mock()
        with tempfile.TemporaryDirectory() as directory:
            package = Path(directory) / "service.deb"
            package.write_bytes(b"controller-package")
            certificate = Path(directory) / "ca.crt"
            certificate.write_text("test certificate")
            upgrade._upgrade_controller(
                ssh, {"name": "controller-0", "ip_address": "192.0.2.10"},
                ["192.0.2.10", "192.0.2.11", "192.0.2.12"], package,
                b"ca-certificate",
            )
            command = ssh.run.call_args_list[0].args[1].replace(
                "/etc/swiftfabric/swiftfabric-ca.crt",
                upgrade._shell_quote(str(certificate)),
            )
            for legacy_http in (False, True):
                with self.subTest(legacy_http=legacy_http):
                    output = upgrade.subprocess.run(
                        ["bash", "-c",
                         "systemctl() { return 0; }; "
                         "sudo() { printf '%s\\n' \"$*\" >&2; }; "
                         "ss() { " + ("echo listener;" if legacy_http else ":;") + " }; "
                         + command],
                        capture_output=True, text=True, check=False,
                    )
                    self.assertEqual(output.returncode, 0, output.stderr)
                    if legacy_http:
                        self.assertIn("systemctl stop swiftfabric-api-service.service", output.stderr)
                        self.assertIn("systemctl disable --now nginx.service", output.stderr)
                        self.assertIn("install nginx ca-certificates", output.stderr)
                    else:
                        self.assertIn("without stopping services", output.stdout)
                        self.assertNotIn("systemctl stop", output.stderr)
                        self.assertNotIn("systemctl disable", output.stderr)
                        self.assertNotIn("apt-get", output.stderr)

    def test_rollout_reconciles_already_upgraded_and_older_controllers(self):
        ssh = mock.Mock()
        controllers = [
            {"name": "controller-0", "ip_address": "192.0.2.10"},
            {"name": "controller-1", "ip_address": "192.0.2.11"},
            {"name": "controller-2", "ip_address": "192.0.2.12"},
        ]
        current_versions = {
            "controller-0": "0.2.0",
            "controller-1": "0.1.0",
            "controller-2": "0.1.0",
        }
        events = []
        ca_publisher = mock.Mock(side_effect=lambda: events.append("publish"))
        with mock.patch.object(
            upgrade,
            "_upgrade_controller",
            side_effect=lambda *_args: events.append("controller"),
        ) as deploy, \
                mock.patch.object(
                    upgrade,
                    "_activate_controller_tls",
                    side_effect=lambda *_args: events.append("activate"),
                ), \
                mock.patch.object(
                    upgrade,
                    "_wait_for_api",
                    side_effect=lambda *_args: events.append("vip"),
                ) as wait_for_api:
            completed = upgrade._upgrade_controllers(
                ssh,
                controllers,
                current_versions,
                "0.2.0",
                Path("service.deb"),
                "192.0.2.13",
                "api-token",
                b"ca-certificate",
                "/tmp/ca.crt",
                b"ca-trust-bundle",
                ca_publisher,
            )

        self.assertEqual(completed, ["controller-0", "controller-1", "controller-2"])
        self.assertEqual(deploy.call_count, 3)
        self.assertTrue(
            all(call.args[4] == b"ca-certificate" for call in deploy.call_args_list)
        )
        self.assertTrue(
            all(call.args[5] == b"ca-trust-bundle" for call in deploy.call_args_list)
        )
        self.assertEqual(
            [call.args[6] for call in deploy.call_args_list],
            [True, False, False],
        )
        ca_publisher.assert_called_once_with()
        wait_for_api.assert_called_once_with(
            "192.0.2.13", "api-token", "/tmp/ca.crt"
        )
        self.assertEqual(
            events,
            ["controller", "publish", "activate", "controller", "controller", "vip"],
        )


if __name__ == "__main__":
    unittest.main()
