import json
import os
import stat
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import main as installer

PUBLIC_KEY = (
    "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIOMqqnkVzrm0SdG6UOoqKLsabgH5C9okWi0dh2l9GKJl test"
)


class SavedConfigTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        (self.root / "proxmox").write_text("key", encoding="utf-8")
        (self.root / "controller").write_text("key", encoding="utf-8")

    def tearDown(self):
        self.temp.cleanup()

    def interactive_config(self):
        return {
            "deploy_api": "proxmox",
            "proxmox_cluster_ip": "192.168.1.100",
            "proxmox_port": 8006,
            "proxmox_user": "root@pam",
            "proxmox_tokenname": "swiftinstaller",
            "proxmox_apikey": "00000000-0000-0000-0000-000000000000",
            "proxmox_ssh_user": "root",
            "proxmox_ssh_key": str(self.root / "proxmox"),
            "controller_priv_key": str(self.root / "controller"),
            "controller_pub_key": PUBLIC_KEY,
            "vlan_id": None,
            "mgmt_ip_range_start": "172.16.255.50",
            "mgmt_ip_range_end": "172.16.255.80",
            "ip_range_start": "172.16.255.50",
            "ip_range_end": "172.16.255.80",
            "gateway_ip": "172.16.255.1",
            "dns_ip": "8.8.8.8",
            "ubuntu_mirror": "http://archive.ubuntu.com/ubuntu",
            "cidr": 24,
            "interface": "vmbr0",
            "storage_location": "local-lvm",
            "vm_memory": 8192,
            "vm_cores": 4,
            "admin_password": "secret-password",
        }

    def test_saved_config_round_trips_through_loader(self):
        target = self.root / "config.json"
        saved_path = installer.save_deployment_config(self.interactive_config(), target)

        self.assertEqual(saved_path, target.resolve())
        self.assertEqual(stat.S_IMODE(os.stat(target).st_mode), 0o600)
        raw = json.loads(target.read_text(encoding="utf-8"))
        self.assertIsNone(raw["admin_password"])
        self.assertNotIn("secret-password", target.read_text(encoding="utf-8"))
        self.assertNotIn("ip_range_start", raw)

        loaded = installer.load_deployment_config(target)
        self.assertEqual(loaded["ip_range_start"], "172.16.255.50")
        self.assertEqual(loaded["controller_pub_key"], PUBLIC_KEY)
        self.assertEqual(loaded["controller_priv_key"], str(self.root / "controller"))
        self.assertEqual(installer._controller_vip(loaded), "172.16.255.53")
        self.assertEqual([p.name for p in self.root.iterdir() if p.name.endswith(".tmp")], [])

    def test_existing_file_requires_overwrite(self):
        target = self.root / "config.json"
        target.write_text("{}", encoding="utf-8")
        with self.assertRaises(FileExistsError):
            installer.save_deployment_config(self.interactive_config(), target)
        installer.save_deployment_config(self.interactive_config(), target, overwrite=True)
        self.assertIn("proxmox_apikey", json.loads(target.read_text(encoding="utf-8")))

    def test_invalid_config_is_not_written(self):
        config = self.interactive_config()
        config["proxmox_apikey"] = "not-a-uuid"
        target = self.root / "config.json"
        with self.assertRaises(ValueError):
            installer.save_deployment_config(config, target)
        self.assertFalse(target.exists())
        self.assertEqual([p for p in self.root.iterdir() if p.suffix == ".tmp"], [])

    def test_non_interactive_install_never_writes_config(self):
        for restore_target in (False, True):
            with self.subTest(restore_target=restore_target):
                self.check_non_interactive_config(restore_target)

    def check_non_interactive_config(self, restore_target):
        from unittest import mock
        from deployment import bootstrap

        target = self.root / f"config-{restore_target}.json"
        installer.save_deployment_config(self.interactive_config(), target)
        original = target.read_bytes()
        original_stat = os.stat(target)
        original_listing = sorted(self.root.iterdir())
        deployment = mock.Mock()
        deployment.deploy_multiple_controllers.return_value = []
        deployment.find_controllers_to_destroy.return_value = {"matches": []}
        deployment.discover_resources.return_value = {
            "nodes": [{"node": "node1"}], "storage": [{"storage": "local-lvm"}],
            "available_interfaces": ["vmbr0"],
        }
        with mock.patch.object(installer, "_create_deployment", return_value=deployment), \
                mock.patch.object(installer, "_verify_and_configure_corosync", return_value={}), \
                mock.patch("deployment.api_service.ApiServiceDeployment"), \
                mock.patch.object(installer, "show_banner"), \
                mock.patch.object(installer, "console"), \
                mock.patch.object(installer, "ProgressIndicator"), \
                mock.patch.object(bootstrap, "bootstrap_deployment") as bootstrap_call, \
                mock.patch.object(installer, "save_deployment_config") as save, \
                mock.patch.object(installer, "publish_controller_config") as publish, \
                mock.patch.object(installer, "_offer_saved_deployment_config") as offer:
            installer.non_interactive_install(str(target), restore_target=restore_target)

        self.assertEqual(bootstrap_call.call_count, 0 if restore_target else 1)
        save.assert_not_called()
        offer.assert_not_called()
        self.assertEqual(publish.call_args.args[2], original)
        deployment.deploy_multiple_controllers.assert_called_once()
        self.assertEqual(target.read_bytes(), original)
        self.assertEqual(os.stat(target).st_mtime_ns, original_stat.st_mtime_ns)
        self.assertEqual(sorted(self.root.iterdir()), original_listing)

    def test_publish_installs_root_only_copy_on_each_controller(self):
        from unittest import mock

        config = {"controller_priv_key": "/keys/controller"}
        nodes = ["192.0.2.10", "192.0.2.11", "192.0.2.12"]
        with mock.patch("deployment.ssh.SSHCommandRunner") as runner, \
                mock.patch.object(installer, "console"):
            installer.publish_controller_config(config, {"nodes": nodes}, b"{}\n")

        runner.assert_called_once_with("/keys/controller", "ubuntu", mock.ANY)
        calls = runner.return_value.run.call_args_list
        self.assertEqual([call.args[0] for call in calls], nodes)
        for call in calls:
            self.assertEqual(
                call.args[1],
                "sudo install -D -o root -g root -m 0600 /dev/stdin "
                "/etc/swiftfabric/config.json",
            )
            self.assertEqual(call.kwargs["input_data"], b"{}\n")

    def test_publish_requires_three_controllers(self):
        from unittest import mock

        with mock.patch("deployment.ssh.SSHCommandRunner") as runner, \
                self.assertRaisesRegex(RuntimeError, "three controller"):
            installer.publish_controller_config(
                {"controller_priv_key": "k"}, {"nodes": ["192.0.2.10"]}, b"{}",
            )
        runner.return_value.run.assert_not_called()

    def test_default_path_never_uses_plain_config_json(self):
        now = datetime(2026, 10, 31, 18, 51, 23, tzinfo=timezone.utc)
        path = installer._default_saved_config_path
        self.assertEqual(
            path(self.root, now=now), self.root / "config-20261031185123.json"
        )
        self.assertEqual(
            path(self.root, prefix="lab", now=now),
            self.root / "config-lab-20261031185123.json",
        )
        self.assertEqual(
            path(self.root, controllername="ctl", now=now),
            self.root / "config-ctl-20261031185123.json",
        )
        self.assertEqual(
            path(self.root, prefix="lab", controllername="ctl", now=now),
            self.root / "config-lab-ctl-20261031185123.json",
        )
        self.assertRegex(path(self.root).name, r"^config-\d{14}\.json$")


if __name__ == "__main__":
    unittest.main()
