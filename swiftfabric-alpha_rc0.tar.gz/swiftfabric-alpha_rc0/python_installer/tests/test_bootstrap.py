import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path
from urllib.parse import quote
from unittest import mock

import requests

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import main as installer
from deployment import bootstrap
from deployment.api_service import ApiServiceDeployment
from deployment.controller import ControllerDeployment
from deployment.ssh import automated_tofu_for_hosts
from cloudinit.config import CloudInitConfig
from proxmox.vm import ProxmoxVM


class BootstrapTests(unittest.TestCase):
    def test_api_readiness_retries_only_transient_failures_on_same_session(self):
        session = mock.Mock()
        ready = mock.Mock(ok=True)
        session.get.side_effect = [
            requests.ConnectionError("sensitive connection detail"),
            requests.Timeout("sensitive timeout detail"),
            *[mock.Mock(ok=False, status_code=status) for status in (502, 503, 504)],
            ready,
        ]
        with mock.patch.object(bootstrap.time, "sleep") as sleep, \
                mock.patch.object(bootstrap, "Console") as console:
            self.assertIs(bootstrap.wait_for_api(session, "https://controller/api/v1/version"), ready)
        self.assertEqual(session.get.call_args_list, [
            mock.call("https://controller/api/v1/version", timeout=(3, 5)),
        ] * 6)
        self.assertEqual(sleep.call_args_list, [mock.call(2)] * 5)
        self.assertNotIn("sensitive", str(console.mock_calls))

    def test_api_readiness_bounds_retries_and_never_ignores_tls_or_authentication(self):
        for error, expected, attempts in (
            (requests.exceptions.SSLError("private certificate detail"), "TLS verification", 1),
            (requests.ConnectionError("private connection detail"), "become reachable", 30),
            (requests.Timeout("private timeout detail"), "become reachable", 30),
            *[(mock.Mock(ok=False, status_code=status), f"HTTP {status}", 1)
              for status in (400, 401, 403, 404, 500)],
            (mock.Mock(ok=False, status_code=503), "HTTP 503", 30),
        ):
            session = mock.Mock()
            if isinstance(error, Exception):
                session.get.side_effect = error
            else:
                session.get.return_value = error
            with self.subTest(error=expected), mock.patch.object(bootstrap.time, "sleep") as sleep, \
                    mock.patch.object(bootstrap, "Console"), \
                    self.assertRaisesRegex(RuntimeError, expected) as result:
                bootstrap.wait_for_api(session, "https://controller/api/v1/version")
            self.assertEqual(session.get.call_count, attempts)
            self.assertEqual(sleep.call_count, attempts - 1)
            self.assertNotIn("private", str(result.exception))

    def test_controller_placement_is_limited_to_enrollment_hosts(self):
        deployment = ControllerDeployment.__new__(ControllerDeployment)
        deployment.nodes = mock.Mock()
        deployment.nodes.list_nodes.return_value = [
            {"node": name, "status": "online"}
            for name in ("hunsn0", "hunsn2", "hunsn3", "hunsn4", "hunsn5")
        ]
        deployment.nodes.get_node_status.return_value = {
            "cpu": 0.1,
            "memory": {"used": 10, "total": 100},
        }
        deployment.storage = mock.Mock()
        deployment.storage.get_node_storage.return_value = [
            {"storage": "VMData", "active": 1, "enabled": 1},
        ]
        deployment.client = mock.Mock()
        deployment.client.get.return_value = {"data": []}
        deployment.console = mock.Mock()
        deployment.deploy_controller = mock.Mock(return_value={"deployed": True})

        deployment.deploy_multiple_controllers(
            node="hunsn0",
            base_vmid=100,
            count=3,
            storage="VMData",
            placement_node_allowlist=["hunsn3", "hunsn4", "hunsn5"],
        )

        placed_nodes = [
            call.kwargs["node"]
            for call in deployment.deploy_controller.call_args_list
        ]
        self.assertEqual(set(placed_nodes), {"hunsn3", "hunsn4", "hunsn5"})
        self.assertEqual(len(placed_nodes), 3)
        self.assertEqual(
            {call.args[0] for call in deployment.nodes.get_node_status.call_args_list},
            {"hunsn3", "hunsn4", "hunsn5"},
        )

    def test_deployment_summary_certificate_is_accepted_by_bootstrap(self):
        with tempfile.TemporaryDirectory() as directory:
            package = Path(directory) / "api-service.deb"
            package.write_bytes(b"synthetic-package")
            deployment = ApiServiceDeployment("", package_path=package)
            deployment.ssh = mock.Mock()
            deployment.console = mock.Mock()
            certificate = self.summary()["ca_certificate"]
            with mock.patch.object(deployment, "_get_nodes", return_value=[
                "192.0.2.10", "192.0.2.11", "192.0.2.12",
            ]), mock.patch.object(deployment, "_provision_tls", return_value=certificate.encode("ascii")), \
                    mock.patch.object(deployment, "_install") as install, \
                    mock.patch("deployment.api_service.secrets.token_hex",
                               side_effect=[char * 64 for char in "abcd"]):
                deployment._ca_fingerprint = "a" * 64
                summary = deployment.build_and_deploy(
                    [], ["controller1", "controller2", "controller3"], "192.0.2.13",
                )
            self.assertEqual(summary["ca_certificate"], certificate)
            admin_key = "sfk_" + "a" * 64
            self.assertEqual(summary["api_token"], admin_key)
            service_tokens = ["sfc_" + char * 64 for char in "bcd"]
            hashes = [hashlib.sha256(token.encode("ascii")).hexdigest() for token in service_tokens]
            for token in service_tokens:
                self.assertNotIn(token, json.dumps(summary))
            configs = [
                json.loads(call.args[1])
                for call in install.call_args_list
                if call.args[2].endswith("/etc/swiftfabric/api-service.json")
            ]
            self.assertEqual(len(configs), 3)
            for node_id, config in enumerate(configs):
                self.assertEqual(config["api_token"], service_tokens[node_id])
                self.assertEqual(config["controller_token_hashes"], hashes)
                self.assertEqual(
                    config["initial_admin_token_hash"],
                    hashlib.sha256(admin_key.encode("ascii")).hexdigest(),
                )
                self.assertNotIn(admin_key, json.dumps(config))
            for path, expected in [
                ("segment-manager.token", [admin_key] * 3),
                ("controller-service.token", service_tokens),
            ]:
                credentials = [
                    call for call in install.call_args_list
                    if call.args[2].endswith("/etc/swiftfabric/" + path)
                ]
                self.assertEqual(len(credentials), 3)
                for call, credential in zip(credentials, expected):
                    self.assertEqual(call.args[1], (credential + "\n").encode("ascii"))
                    self.assertIn("-o root -g root -m 0400", call.args[2])
            provisioning = [
                call.args[1] for call in deployment.ssh.run.call_args_list
                if "/api/v1/provisioning" in call.args[1]
            ]
            self.assertEqual(len(provisioning), 1)
            self.assertIn("Bearer " + service_tokens[0], provisioning[0])
            self.assertNotIn(admin_key, provisioning[0])
            session, _ = self.session(token=admin_key)
            config = {
                **self.config(), "proxmox_cluster_name": "",
                "auto_enroll_host_list": [],
            }
            with mock.patch.object(bootstrap.requests, "Session", return_value=session):
                bootstrap.bootstrap_deployment(config, summary)
            self.assertEqual(session.request.call_count, 2)
            self.assertEqual(session.headers["Authorization"], "Bearer " + admin_key)

    def config(self):
        return {
            "ip_range_start": "192.0.2.10", "ip_range_end": "192.0.2.30",
            "mgmt_ip_range_start": "192.0.2.10", "mgmt_ip_range_end": "192.0.2.30",
            "gateway_ip": "192.0.2.1", "cidr": 24, "dns_ip": "1.1.1.1",
            "interface": "vmbr0", "vlan_id": 100,
            "proxmox_cluster_name": "compute", "proxmox_cluster_ip": "192.0.2.200",
            "proxmox_port": 8006, "proxmox_user": "root@pam",
            "proxmox_tokenname": "test", "proxmox_apikey": "00000000-0000-0000-0000-000000000000",
            "proxmox_ssh_user": "root", "proxmox_ssh_key": "/synthetic/proxmox-key",
            "vtep_ip_range_cidr": "198.51.100.0/24", "vtep_mtu": 9000,
            "vtep_interface": "eno2", "vtep_vlan_id": 200, "auto_enroll_host_list": "node2",
        }

    def test_management_expansion_keeps_fourth_address_as_vip_and_legacy_range_is_strict(self):
        config = self.config()
        self.assertEqual(installer._controller_vip(config), "192.0.2.13")
        config["ip_range_end"] = config["mgmt_ip_range_end"] = "192.0.2.100"
        self.assertEqual(installer._controller_vip(config), "192.0.2.13")
        with self.assertRaisesRegex(ValueError, "exactly four"):
            installer._validate_controller_ip_range("192.0.2.10", "192.0.2.100", "192.0.2.1", 24)

    def test_host_selection_supports_all_single_and_lists_and_rejects_invalid_values(self):
        for value, expected in (("all", "all"), ("node1", ["node1"]), (["node2", "node1"], ["node2", "node1"]), ([], [])):
            config = {**self.config(), "auto_enroll_host_list": value}
            bootstrap.validate_bootstrap_config(config)
            self.assertEqual(config["auto_enroll_host_list"], expected)
        for value in ("", None, True, ["all"], ["node1", "node1"], [False], ["../node"]):
            with self.subTest(value=value), self.assertRaises(ValueError):
                bootstrap.validate_bootstrap_config({**self.config(), "auto_enroll_host_list": value})

    def test_bootstrap_validation_rejects_invalid_profiles_before_deployment(self):
        for key, value in (
            ("vtep_mtu", 1500), ("vtep_mtu", True), ("vtep_vlan_id", 0),
            ("vtep_ip_range_cidr", "192.0.2.0/24"), ("vtep_ip_range_cidr", "::/64"),
            ("vtep_interface", "bad interface"), ("proxmox_cluster_name", ""),
            ("proxmox_cluster_name", "../cluster"),
        ):
            with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                bootstrap.validate_bootstrap_config({**self.config(), key: value})

    def test_config_loader_normalizes_new_names_and_preserves_legacy_compatibility(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "key").touch()
            config = {
                **self.config(), "controller_priv_key": "key", "proxmox_ssh_key": str(root / "key"),
                "admin_password": "synthetic", "controller_pub_key": "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5",
            }
            del config["ip_range_start"], config["ip_range_end"]
            path = root / "deployment.json"
            path.write_text(json.dumps(config))
            loaded = installer.load_deployment_config(path)
            self.assertEqual(loaded["ip_range_end"], "192.0.2.30")
            self.assertEqual(installer._controller_vip(loaded), "192.0.2.13")
            config["ip_range_start"] = config.pop("mgmt_ip_range_start")
            config["ip_range_end"] = "192.0.2.13"
            del config["mgmt_ip_range_end"]
            path.write_text(json.dumps(config))
            self.assertEqual(installer._controller_vip(installer.load_deployment_config(path)), "192.0.2.13")
            config["mgmt_ip_range_start"] = "192.0.2.20"
            config["mgmt_ip_range_end"] = "192.0.2.30"
            path.write_text(json.dumps(config))
            with self.assertRaisesRegex(ValueError, "conflicts"):
                installer.load_deployment_config(path)

    def test_config_loader_accepts_renamed_management_and_enrollment_fields(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            key_path = root / "key"
            key_path.touch()
            config = {
                **self.config(),
                "controller_priv_key": str(key_path),
                "controller_pub_key": "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5",
                "admin_password": "synthetic",
                "proxmox_ssh_key": str(key_path),
                "mgmt_ip_range_start": "192.0.2.10",
                "mgmt_ip_range_end": "192.0.2.30",
            }
            renamed = {
                "controller_priv_key": "mgmt_priv_key",
                "controller_pub_key": "mgmt_pub_key",
                "vlan_id": "mgmt_vlan_id",
                "gateway_ip": "mgmt_gateway_ip",
                "dns_ip": "mgmt_dns_ip",
                "admin_password": "mgmt_vm_password",
                "cidr": "mgmt_cidr",
                "interface": "mgmt_interface",
                "auto_enroll_host_list": "proxmox_auto_enroll_host_list",
            }
            for old_key, new_key in renamed.items():
                config[new_key] = config.pop(old_key)
            config["mgmt_priv_key"] = str(key_path)
            path = root / "deployment.json"
            path.write_text(json.dumps(config))

            loaded = installer.load_deployment_config(path)

        self.assertEqual(loaded["controller_priv_key"], str(key_path))
        self.assertEqual(loaded["controller_pub_key"], "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5")
        self.assertEqual(loaded["vlan_id"], 100)
        self.assertEqual(loaded["gateway_ip"], "192.0.2.1")
        self.assertEqual(loaded["dns_ip"], "1.1.1.1")
        self.assertEqual(loaded["admin_password"], "synthetic")
        self.assertEqual(loaded["cidr"], 24)
        self.assertEqual(loaded["interface"], "vmbr0")
        self.assertEqual(loaded["auto_enroll_host_list"], ["node2"])

    def test_null_management_password_uses_key_only_cloud_init(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            key_path = root / "key"
            key_path.touch()
            config = {
                **self.config(),
                "mgmt_priv_key": str(key_path),
                "mgmt_pub_key": "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5",
                "mgmt_vm_password": None,
                "proxmox_ssh_key": str(key_path),
                "mgmt_ip_range_start": "192.0.2.10",
                "mgmt_ip_range_end": "192.0.2.30",
            }
            for key in (
                "controller_priv_key", "controller_pub_key", "admin_password",
                "ip_range_start", "ip_range_end",
            ):
                config.pop(key, None)
            path = root / "deployment.json"
            path.write_text(json.dumps(config))
            loaded = installer.load_deployment_config(path)

        self.assertIsNone(loaded["admin_password"])
        vendor_data = CloudInitConfig().generate_vendor_user_data(None)
        self.assertIn("ssh_pwauth: false", vendor_data)
        self.assertIn("disable_root: true", vendor_data)
        self.assertNotIn("chpasswd:", vendor_data)
        self.assertNotIn("password:", vendor_data)

        client = mock.Mock()
        client.configure_vm.return_value = {}
        ProxmoxVM(client).configure_cloudinit(
            "node1", 100, "controller", {}, sshkeys="ssh-ed25519 public-key", password=None,
        )
        kwargs = client.configure_vm.call_args.kwargs
        self.assertEqual(kwargs["sshkeys"], "ssh-ed25519 public-key")
        self.assertNotIn("password", kwargs)

    def test_controller_cloud_init_sets_network_and_key_without_password(self):
        deployment = ControllerDeployment.__new__(ControllerDeployment)
        deployment.client = mock.Mock()
        deployment.client.get.return_value = {
            "data": [{"volid": "local:import/base.qcow2"}],
        }
        deployment.client.configure_vm.return_value = {}
        deployment.client.start_vm.return_value = {}
        deployment.vm = mock.Mock()
        deployment.vm.create_vm_no_disk.return_value = {"data": "created"}
        deployment.vm.wait_for_vm_start.return_value = True
        deployment.console = mock.Mock()
        public_key = "ssh-ed25519 public-key"

        with mock.patch.object(
            deployment, "_install_cloudinit_vendor_data",
            return_value="local:snippets/vendor.yaml",
        ) as vendor_data:
            deployment.deploy_controller(
                node="node1",
                vmid=100,
                name="controller",
                ip_address="192.0.2.10",
                hostname="controller",
                admin_password=None,
                qcow2_image_path="/tmp/base.qcow2",
                controller_pub_key=public_key,
            )

        vendor_data.assert_called_once()
        self.assertIsNone(vendor_data.call_args.kwargs["password"])
        config = deployment.client.configure_vm.call_args.kwargs
        self.assertEqual(config["sshkeys"], quote(public_key, safe=""))
        self.assertIn("ipconfig0", config)
        self.assertNotIn("password", config)

    def session(self, nodes=None, token="synthetic-token"):
        session = mock.MagicMock()
        session.__enter__.return_value = session
        session.headers = {}
        session.get.return_value.ok = True
        calls = []

        def request(method, url, json=None, timeout=None):
            self.assertTrue(Path(session.verify).is_file())
            self.assertEqual(session.headers["Authorization"], "Bearer " + token)
            calls.append((method, url, json))
            response = mock.Mock()
            response.json.return_value = nodes if url.endswith("/nodes") else {}
            return response

        session.request.side_effect = request
        return session, calls

    def summary(self):
        return {"ca_certificate": "-----BEGIN CERTIFICATE-----\nsynthetic\n-----END CERTIFICATE-----\n",
                "api_token": "synthetic-token"}

    def test_bootstrap_uses_verified_tls_fixed_vip_and_selected_host_profile(self):
        session, calls = self.session([
            {"node": "node1", "status": "online"}, {"node": "node2", "status": "online"},
        ])
        with mock.patch.object(bootstrap.requests, "Session", return_value=session), \
                mock.patch.object(bootstrap.Path, "read_text", return_value="synthetic-private-key"):
            bootstrap.bootstrap_deployment(self.config(), self.summary())
        self.assertEqual(len(calls), 5)
        self.assertTrue(all(url.startswith("https://192.0.2.13/") for _, url, _ in calls))
        self.assertEqual(calls[0][2]["end_ip"], "192.0.2.30")
        self.assertEqual(calls[1][2], {"cidr": "198.51.100.0/24", "vtep_mtu": 9000})
        self.assertEqual(calls[-1][1], "https://192.0.2.13/api/v1/hosts/compute-node2")
        self.assertEqual(calls[-1][2], {"cluster": "compute", "node": "node2", "interface": "eno2", "vlan_id": 200})
        self.assertFalse(Path(session.verify).exists())

    def test_missing_vtep_field_skips_vtep_setup_and_host_enrollment(self):
        session, calls = self.session()
        config = self.config()
        del config["vtep_mtu"]
        with mock.patch.object(bootstrap.requests, "Session", return_value=session), \
                mock.patch.object(bootstrap.Path, "read_text", return_value="synthetic-private-key"):
            bootstrap.bootstrap_deployment(config, self.summary())

        urls = [url for _, url, _ in calls]
        self.assertTrue(any(url.endswith("/proxmox/clusters/compute") for url in urls))
        self.assertFalse(any(url.endswith("/vteps/pool") for url in urls))
        self.assertFalse(any("/hosts/" in url for url in urls))

    def test_missing_host_list_does_not_enroll_hosts(self):
        session, calls = self.session()
        config = self.config()
        del config["auto_enroll_host_list"]
        with mock.patch.object(bootstrap.requests, "Session", return_value=session), \
                mock.patch.object(bootstrap.Path, "read_text", return_value="synthetic-private-key"):
            bootstrap.bootstrap_deployment(config, self.summary())

        urls = [url for _, url, _ in calls]
        self.assertTrue(any(url.endswith("/vteps/pool") for url in urls))
        self.assertTrue(any(url.endswith("/proxmox/clusters/compute") for url in urls))
        self.assertFalse(any("/hosts/" in url for url in urls))

    def test_all_selection_checks_every_requested_node_before_any_enrollment(self):
        session, calls = self.session([
            {"node": "node1", "status": "online"}, {"node": "node2", "status": "offline"},
        ])
        with mock.patch.object(bootstrap.requests, "Session", return_value=session), \
                mock.patch.object(bootstrap.Path, "read_text", return_value="synthetic-private-key"), \
                self.assertRaisesRegex(RuntimeError, "not online"):
            bootstrap.bootstrap_deployment({**self.config(), "auto_enroll_host_list": "all"}, self.summary())
        self.assertFalse(any("/hosts/" in url for _, url, _ in calls))
        for selection in (["missing"], "all"):
            with self.assertRaises(RuntimeError):
                bootstrap._selected_nodes([], selection)

    def test_api_failures_do_not_continue_bootstrap_or_expose_secrets(self):
        session, _ = self.session()
        response = mock.Mock(status_code=403)
        session.request.side_effect = requests.HTTPError(response=response)
        with mock.patch.object(bootstrap.requests, "Session", return_value=session), \
                self.assertRaisesRegex(RuntimeError, "HTTP 403") as result:
            bootstrap.bootstrap_deployment(self.config(), self.summary())
        self.assertEqual(session.request.call_count, 1)
        self.assertNotIn("synthetic-token", str(result.exception))

    def test_bootstrap_never_disables_tls_on_missing_ca_or_certificate_failure(self):
        with self.assertRaisesRegex(RuntimeError, "CA certificate"):
            bootstrap.bootstrap_deployment(self.config(), {"api_token": "synthetic-token"})
        session, _ = self.session()
        session.get.side_effect = requests.exceptions.SSLError("synthetic certificate failure")
        with mock.patch.object(bootstrap.requests, "Session", return_value=session), \
                self.assertRaisesRegex(RuntimeError, "TLS verification"):
            bootstrap.bootstrap_deployment(self.config(), self.summary())
        session.request.assert_not_called()

    def test_unattended_install_bootstraps_after_verified_vip_and_does_not_claim_success_on_failure(self):
        config = {
            **installer.CONFIG_DEFAULTS, **self.config(),
            "controller_priv_key": "/synthetic/controller-key",
            "controller_pub_key": "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5",
            "admin_password": "synthetic",
        }
        deployment = mock.Mock()
        deployment.find_controllers_to_destroy.return_value = {"matches": []}
        deployment.discover_resources.return_value = {
            "nodes": [{"node": "node1"}], "storage": [{"storage": "local-lvm"}],
            "available_interfaces": ["vmbr0"],
        }
        deployment.deploy_multiple_controllers.return_value = [
            {"ip_address": f"192.0.2.{address}"}
            for address in (10, 11, 12)
        ]
        with mock.patch.object(installer, "load_deployment_config", return_value=config), \
                mock.patch.object(installer, "_create_deployment", return_value=deployment), \
                mock.patch.object(installer, "_verify_and_configure_corosync", return_value=self.summary()) as verify, \
                mock.patch("deployment.api_service.ApiServiceDeployment"), \
                mock.patch.object(installer, "show_banner"), \
                mock.patch.object(installer, "console"), \
                mock.patch.object(installer, "ProgressIndicator") as progress, \
                mock.patch.object(installer, "_read_config_snapshot", return_value=b"{}"), \
                mock.patch.object(installer, "publish_controller_config") as publish, \
                mock.patch.object(bootstrap, "bootstrap_deployment") as apply, \
                mock.patch(
                    "deployment.ssh.automated_tofu_for_hosts",
                    wraps=automated_tofu_for_hosts,
                ) as tofu:
            installer.non_interactive_install("/synthetic/config.json")
            publish.assert_called_once_with(config, self.summary(), b"{}")
            tofu.assert_called_once_with(["192.0.2.10", "192.0.2.11", "192.0.2.12"])
            self.assertEqual(verify.call_args.args[4], "192.0.2.13")
            apply.assert_called_once_with(config, self.summary())
            self.assertEqual(deployment.deploy_multiple_controllers.call_args.kwargs["ip_range_end"], "192.0.2.30")
            progress.return_value.show_success.assert_called_once()
            progress.return_value.reset_mock()
            apply.side_effect = RuntimeError("synthetic bootstrap failure")
            with self.assertRaisesRegex(RuntimeError, "bootstrap failure"):
                installer.non_interactive_install("/synthetic/config.json")
            progress.return_value.show_success.assert_not_called()
            publish.assert_called_once()


if __name__ == "__main__":
    unittest.main()
