import argparse
import importlib.util
import json
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location(
    "disaster_recovery", ROOT / "python_installer/tests_integration/disaster_recovery.py",
)
recovery = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(recovery)
installer = sys.modules["main"]


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)

    def arguments(self):
        config = self.directory / "config.json"
        config.write_text("{}")
        return argparse.Namespace(
            config=config, state=self.directory / "run", nodes=["n1", "n2", "n3"],
            image_volume="VMData:import/image.qcow2", dns_address="1.1.1.1",
            settle_seconds=35, first_segment_id=49100, subnet_start="10.253.244.0/24",
            supernet="10.0.0.0/8",
        )

    def run_object(self):
        args = self.arguments()
        args.state.mkdir(mode=0o700)
        with mock.patch.object(recovery, "load_deployment_config", return_value={
            "ip_range_start": "192.0.2.10", "controller_priv_key": "/synthetic/controller-key",
        }):
            return recovery.RecoveryRun(args)

    def test_passphrase_requires_private_external_file(self):
        path = self.directory / "passphrase"
        path.write_text("test-recovery-secret\n")
        path.chmod(0o600)
        self.assertEqual(recovery.read_passphrase(path, self.directory / "run"), "test-recovery-secret")
        path.chmod(0o644)
        with self.assertRaisesRegex(ValueError, "owner-only"):
            recovery.read_passphrase(path, self.directory / "run")
        path.chmod(0o600)
        with self.assertRaisesRegex(ValueError, "outside"):
            recovery.read_passphrase(path, self.directory)
        link = self.directory / "link"
        link.symlink_to(path)
        with self.assertRaises(OSError):
            recovery.read_passphrase(link, self.directory / "run")

    def test_passphrase_byte_limits(self):
        path = self.directory / "passphrase"
        for length in (11, 12, 1024, 1025):
            with self.subTest(length=length):
                path.write_bytes(b"x" * length + b"\n")
                path.chmod(0o600)
                if 12 <= length <= 1024:
                    self.assertEqual(len(recovery.read_passphrase(path, self.directory / "run")), length)
                else:
                    with self.assertRaises(ValueError):
                        recovery.read_passphrase(path, self.directory / "run")

    def test_acceptance_rejects_partial_or_failed_matrices(self):
        good = {"complete": True, "traffic_assertions": 3240, "api_assertions": 1}
        results = [{"passed": True}] * 3240
        recovery.private_write(self.directory / "acceptance.json", good)
        recovery.private_write(self.directory / "results.json", results)
        recovery.private_write(self.directory / "api-results.json", [{"passed": True}])
        recovery.verify_acceptance(self.directory)
        for acceptance, observations in (
            ({**good, "complete": False}, results),
            ({**good, "traffic_assertions": 810}, results),
            (good, results[:-1]),
            (good, [*results[:-1], {"passed": False}]),
        ):
            recovery.private_write(self.directory / "acceptance.json", acceptance)
            recovery.private_write(self.directory / "results.json", observations)
            with self.assertRaisesRegex(RuntimeError, "3,240"):
                recovery.verify_acceptance(self.directory)

    def test_failure_capture_filter_is_scoped_to_probe_addresses_and_ports(self):
        probes = [
            {
                "source": "10.0.0.1", "destination": "10.0.0.2",
                "protocol": "udp", "source_port": 20340, "destination_port": 18081,
            },
            {
                "source": "10.0.0.2", "destination": "10.0.0.1",
                "protocol": "icmp", "source_port": 20341, "destination_port": 18081,
            },
        ]
        packet_filter = recovery.failure_capture_filter(probes)
        self.assertIn("host 10.0.0.1", packet_filter)
        self.assertIn("host 10.0.0.2", packet_filter)
        self.assertIn("udp and (port 20340 or port 18081)", packet_filter)
        self.assertIn("icmp", packet_filter)
        with self.assertRaisesRegex(ValueError, "unsupported transport"):
            recovery.failure_capture_filter([{
                "source": "10.0.0.1", "destination": "10.0.0.2",
                "protocol": "raw", "source_port": 20340, "destination_port": 18081,
            }])

    def test_packet_capture_helper_uses_bounded_command_and_private_file(self):
        run = self.run_object()
        run.network_lab = mock.Mock()
        run.network_lab.pcap_packet_count.return_value = 2
        ssh = mock.Mock()
        ssh.private_key = "/synthetic/key"
        ssh.username = "ubuntu"
        ssh.known_hosts_file = Path("/synthetic/known_hosts")
        ssh.run.return_value = ""
        packet_data = b"synthetic-pcap-data" * 2

        def copy_files(command, **_kwargs):
            local = Path(command[-1])
            local.mkdir(mode=0o700, exist_ok=True)
            sources = [item for item in command if "@n1:" in item]
            for source in sources:
                filename = source.rsplit("/", 1)[-1]
                target = local / filename
                if filename == "capture.pcap":
                    target.write_bytes(packet_data)
                elif filename == "capture.json":
                    target.write_text(json.dumps({"complete": True}))
                else:
                    target.write_text("tcpdump log")
            return subprocess.CompletedProcess(command, 0, stdout="", stderr="")

        local = run.directory / "n1"
        local.mkdir(mode=0o700)
        with mock.patch.object(recovery, "subprocess") as subprocess_mock:
            subprocess_mock.run.side_effect = copy_files
            result = run._capture_failure_packets(
                ssh, "n1", "host 10.0.0.1", "/tmp/swiftfabric-diagnostics-deadbeef", local,
            )

        self.assertEqual(result, {
            "file": "n1/capture.pcap", "log": "n1/tcpdump.log",
            "bytes": len(packet_data), "packets": 2, "complete": True, "error": None,
        })
        path = local / "capture.pcap"
        self.assertEqual(path.read_bytes(), packet_data)
        self.assertEqual(path.stat().st_mode & 0o777, 0o600)
        remote_command = shlex.split(ssh.run.call_args.args[1])
        self.assertEqual(remote_command[:2], ["python3", "-c"])
        compile(remote_command[2], "<diagnostic capture>", "exec")
        self.assertIn("tcpdump", remote_command[2])
        self.assertIn("timeout", remote_command[2])
        self.assertIn('"-w", pcap', remote_command[2])
        self.assertNotIn("base64", remote_command[2])
        self.assertEqual(ssh.ensure_host_key.call_args.args, ("n1",))
        scp_command = subprocess_mock.run.call_args.args[0]
        self.assertEqual(scp_command[0], "scp")
        self.assertIn("StrictHostKeyChecking=yes", scp_command)

    def test_acceptance_captures_failed_traffic_only_when_opted_in(self):
        class DiagnosticFailure(RuntimeError):
            pass

        failure_results = [{"passed": False, "plane": "l2", "phase": 7}]
        for enabled in (False, True):
            self.directory = Path(self.temporary.name) / str(enabled)
            self.directory.mkdir()
            run = self.run_object()
            run.args.capture_failed_traffic = enabled
            run.network_lab = mock.Mock(TrafficPhaseFailure=DiagnosticFailure)
            run.lab = mock.Mock()
            run.lab.state = {"results": failure_results}
            run.lab.acceptance_test.side_effect = DiagnosticFailure("traffic phase failed")
            with self.subTest(enabled=enabled), \
                    mock.patch.object(run, "capture_failure_diagnostics") as capture, \
                    self.assertRaisesRegex(DiagnosticFailure, "traffic phase failed"):
                run.acceptance("after")
            if enabled:
                capture.assert_called_once_with(failure_results)
            else:
                capture.assert_not_called()

    def test_owner_only_atomic_journal(self):
        path = self.directory / "recovery.json"
        recovery.private_write(path, {"status": "incomplete"})
        recovery.private_write(path, {"status": "passed"})
        self.assertEqual(json.loads(path.read_text()), {"status": "passed"})
        self.assertEqual(path.stat().st_mode & 0o777, 0o600)
        self.assertFalse(path.with_suffix(".json.tmp").exists())

    def test_api_assertion_failure_invalidates_traffic_pass(self):
        recovery.private_write(self.directory / "acceptance.json", {
            "complete": True, "traffic_assertions": 3240, "api_assertions": 1,
        })
        recovery.private_write(self.directory / "results.json", [{"passed": True}] * 3240)
        for observations in ([], [{"passed": False}]):
            recovery.private_write(self.directory / "api-results.json", observations)
            with self.assertRaisesRegex(RuntimeError, "API checks"):
                recovery.verify_acceptance(self.directory)

    def test_backup_failure_preserves_validation_report_and_forbids_staging(self):
        run = self.run_object()
        report = {key: True for key in (
            "valid", "product_version_matches", "controller_ips_match", "api_vip_matches",
            "host_agent_payloads_available", "external_credentials_included",
            "operator_config_included", "recovery_credentials_included",
        )}
        run.api = mock.Mock()
        run.restorer = mock.Mock()
        for failed in ("host_agent_payloads_available", "recovery_credentials_included"):
            invalid = {**report, failed: False}
            run.api.request.side_effect = [
                mock.Mock(content=b"SWFTBAK1archive"), mock.Mock(json=mock.Mock(return_value=invalid)),
            ]
            with self.subTest(gate=failed), self.assertRaisesRegex(RuntimeError, failed):
                run.backup("synthetic-test-passphrase")
            self.assertEqual(json.loads((run.directory / "backup-validation.json").read_text()), invalid)
            run.restorer.stage.assert_not_called()

    def test_restore_waits_for_authenticated_version_after_pacemaker_unfencing(self):
        for observed in ("expected-version", "wrong-version"):
            self.directory = Path(self.temporary.name) / observed
            self.directory.mkdir()
            run = self.run_object()
            archive = run.directory / "backup.sfbak"
            archive.write_bytes(b"SWFTBAK1synthetic")
            run.state.update(
                backup_sha256=recovery.fingerprint(archive), backup_ca_sha256="ca",
                original_ca_der_sha256="ca-der", backup_product_version="expected-version",
            )
            run.api = mock.Mock(base_url="https://controller/api/v1")
            run.api.session.get.side_effect = [
                mock.Mock(ok=False, status_code=503),
                mock.Mock(ok=True, json=mock.Mock(return_value={"version": observed})),
            ]
            run.lab = mock.Mock(directory=run.directory)
            run.verify_recovered_agents = mock.Mock()
            run.verify_recovered_forwarding = mock.Mock()
            restorer = mock.Mock(nodes=["node1"], staged={"node1": {"ca_sha256_fingerprint": "ca"}})
            restorer.restore.return_value = {"complete": True}
            with self.subTest(version=observed), \
                    mock.patch.object(recovery, "ControllerRestore", return_value=restorer), \
                    mock.patch.object(recovery, "ca_fingerprint", return_value="ca-der"), \
                    mock.patch("deployment.bootstrap.time.sleep") as sleep, \
                    mock.patch("deployment.bootstrap.Console"):
                if observed == "expected-version":
                    run.restore("synthetic-passphrase")
                    run.verify_recovered_agents.assert_called_once()
                    run.verify_recovered_forwarding.assert_called_once()
                else:
                    with self.assertRaisesRegex(RuntimeError, "version differs"):
                        run.restore("synthetic-passphrase")
                    run.verify_recovered_agents.assert_not_called()
                    run.verify_recovered_forwarding.assert_not_called()
                self.assertEqual(run.api.session.get.call_count, 2)
                sleep.assert_called_once_with(2)

    def test_router_request_requires_empty_standalone_authorized_topology(self):
        good = {
            "node": "n1", "image_storage": "VMData", "image_volume": "import/ubuntu.qcow2",
            "wan_bridge": "vmbr0", "wan_address_cidr": "192.0.2.10/24",
            "wan_gateway": "192.0.2.1", "vtep_bridge": "vmbr0",
            "management_allowlist": ["192.0.2.2/32", "192.0.2.3/32", "192.0.2.4/32"],
        }
        recovery.validate_router_request(good, ["n1", "n2", "n3"])
        for change in (
            {"node": "unselected"}, {"deployment_mode": "active-standby"},
            {"synchronous_ha": True}, {"wan_egress_rules": [{}]},
            {"image_volume": ""}, {"wan_gateway": "198.51.100.1"},
            {"wan_address_cidr": "192.0.2.0/24"},
            {"management_allowlist": None}, {"management_allowlist": []},
            {"management_allowlist": "192.0.2.2/32"}, {"management_allowlist": [42]},
            {"management_allowlist": ["192.0.2.2"]}, {"management_allowlist": ["192.0.2.2/33"]},
            {"management_allowlist": ["::1/128"]}, {"management_allowlist": ["invalid"]},
            {"management_allowlist": ["192.0.2.2/32"] * 129},
        ):
            with self.subTest(change=change), self.assertRaises(ValueError):
                recovery.validate_router_request({**good, **change}, ["n1", "n2", "n3"])
        del good["management_allowlist"]
        with self.assertRaisesRegex(ValueError, "management_allowlist"):
            recovery.validate_router_request(good, ["n1", "n2", "n3"])

    def test_cleanup_order_requires_complete_host_unenrollment_before_destroy(self):
        run = self.run_object()
        run.config["proxmox_cluster_name"] = "compute"
        identity = {"id": "owned", "name": "owned", "vmid": 300}
        run.state.update(router=identity, router_requested="owned")
        run.lab = mock.Mock()
        run.api = mock.Mock()
        run.api.json.side_effect = [
            [identity], None, [], [{"host_id": "host"}],
            {"results": [{"result": "cleaned"}]}, [],
            [{"name": "compute"}], None, [],
        ]
        events = []
        run.lab.destroy.side_effect = lambda: events.append("lab")
        original = run.api.json.side_effect
        responses = iter(original)

        def request(method, path, body=None):
            events.append((method, path))
            return next(responses)

        run.api.json.side_effect = request
        with mock.patch.object(run, "installer", side_effect=lambda *args: events.append(args)):
            run.cleanup()
        self.assertEqual(events, [
            "lab", ("GET", "/north-south-routers"), ("DELETE", "/north-south-routers/owned"),
            ("GET", "/north-south-routers"), ("GET", "/hosts"),
            ("POST", "/proxmox/clusters/compute/cleanup"), ("GET", "/hosts"),
            ("GET", "/proxmox/clusters"), ("DELETE", "/proxmox/clusters/compute"),
            ("GET", "/proxmox/clusters"), ("--destroy", "--yes"),
        ])

    def test_failed_lab_cleanup_blocks_router_host_and_controller_deletion(self):
        run = self.run_object()
        run.lab = mock.Mock()
        run.lab.destroy.side_effect = RuntimeError("ownership changed")
        run.api = mock.Mock()
        with mock.patch.object(run, "installer") as installer, \
                self.assertRaisesRegex(RuntimeError, "ownership changed"):
            run.cleanup()
        run.api.json.assert_not_called()
        installer.assert_not_called()

    def test_failed_unenrollment_blocks_cluster_deletion_and_destroy(self):
        run = self.run_object()
        run.config["proxmox_cluster_name"] = "compute"
        identity = {"id": "owned", "name": "owned", "vmid": 300}
        run.state.update(router=identity, router_requested="owned")
        run.lab = mock.Mock()
        run.api = mock.Mock()
        run.api.json.side_effect = [
            [identity], None, [], [{"host_id": "host"}],
            {"results": [{"result": "failed", "message": "unreachable"}]},
        ]
        with mock.patch.object(run, "installer") as installer, \
                self.assertRaisesRegex(RuntimeError, "unenrollment incomplete"):
            run.cleanup()
        installer.assert_not_called()
        self.assertNotIn(
            mock.call("DELETE", "/proxmox/clusters/compute"), run.api.json.call_args_list,
        )

    def test_recovery_requires_new_heartbeats_with_real_enrolled_host_status(self):
        run = self.run_object()
        identity = {"host_id": "compute-n1", "cluster": "compute", "node": "n1", "agent_version": "v1"}
        router = {"id": "owned", "name": "owned", "vmid": 300}
        run.state.update(host_identities=[identity], router=router)
        run.api = mock.Mock()
        responses = []
        for seen in (100, 100, 101):
            responses.extend([
                [{**identity, "status": "enrolled", "last_seen_at": seen}],
                {"router": router, "health": "healthy", "agent_health": {"last_seen_at": seen}},
            ])
        run.api.json.side_effect = responses
        with mock.patch.object(recovery.time, "sleep") as sleep:
            run.verify_recovered_agents()
        self.assertEqual(sleep.call_count, 2)
        self.assertEqual(run.api.json.call_count, 6)

    def test_only_confirmed_routing_outage_makes_phase_inconclusive(self):
        for scenario in (
            "outage", "icmp-outage", "icmp-command-error",
            "recovered-before-phase", "unrelated", "isolation",
        ):
            self.directory = Path(self.temporary.name) / scenario
            self.directory.mkdir()
            run = self.run_object()
            run.config.update(proxmox_ssh_key="synthetic", proxmox_ssh_user="synthetic")
            run.lab = mock.Mock()
            run.lab.state = {"vms": [{"node": "n1"}, {"node": "n2"}]}
            result = {
                "passed": False, "expected": "drop" if scenario == "isolation" else "allow",
                "outcome": (
                    "allow" if scenario == "isolation"
                    else "error" if scenario in ("icmp-outage", "icmp-command-error")
                    else "drop"
                ),
                "protocol": "icmp" if scenario in ("icmp-outage", "icmp-command-error") else "tcp",
                "stage": "icmp" if scenario in ("icmp-outage", "icmp-command-error") else "connect",
                "detail": (
                    "PING 192.0.2.2 (192.0.2.2) : 56(84) bytes of data.\n"
                    "\n--- 192.0.2.2 ping statistics ---\n"
                    + ("1 packets transmitted, 0 received, 100% packet loss, time 0ms\n"
                       if scenario == "icmp-outage" else "ping: bad address\n")
                ),
                "source_node": "n1", "destination_node": "n2",
                "started_epoch": 1000, "elapsed_ms": 3000,
            }
            results = [result]
            if scenario == "icmp-outage":
                results.append({
                    **result, "outcome": "drop", "protocol": "tcp", "stage": "connect",
                    "detail": "no response within 3 seconds",
                })
            entries = [{
                "__REALTIME_TIMESTAMP": "999000000",
                "MESSAGE": "controller routing transport unavailable; forwarding recovery pending",
            }]
            if scenario == "recovered-before-phase":
                entries.append({
                    "__REALTIME_TIMESTAMP": "999500000",
                    "MESSAGE": "controller routing recovery complete; validated forwarding guards released",
                })
            if scenario == "unrelated":
                entries = []
            ssh = mock.Mock()
            ssh.run.return_value = "\n".join(json.dumps(entry) for entry in entries)
            run.verify_recovered_forwarding = mock.Mock()
            with self.subTest(scenario=scenario), mock.patch.object(
                recovery, "SSHCommandRunner", return_value=ssh,
            ), mock.patch.object(recovery.time, "sleep") as sleep, \
                    mock.patch.object(recovery.time, "monotonic", return_value=0), \
                    mock.patch("builtins.print"):
                passed = run.recover_interrupted_phase("l2", 1, results, 1, 1800)
            self.assertEqual(passed, scenario in ("outage", "icmp-outage"))
            if passed:
                sleep.assert_called_once_with(60)
                run.verify_recovered_forwarding.assert_called_once_with(deadline=1800)
                evidence, = (run.directory / "interrupted-phases").glob("*.json")
                self.assertEqual(json.loads(evidence.read_text())["results"], results)
            else:
                sleep.assert_not_called()
                run.verify_recovered_forwarding.assert_not_called()

    def test_forwarding_readiness_rejects_fences_and_missing_remote_programming(self):
        local = {
            "node": "n1", "port": "fwpr100p0", "mac": "bc:24:11:00:00:01",
            "vtep": "192.0.2.1",
        }
        remote = {
            "node": "n2", "port": "fwpr101p0", "mac": "bc:24:11:00:00:02",
            "vtep": "192.0.2.2",
        }
        expected = {5000: [local, remote]}
        snapshot = {
            "links": [{"ifname": local["port"], "master": "sf-br5000"}],
            "tables": {"nftables": []},
            "segments": {"5000": {
                "ports": {local["port"]: []},
                "remote": [{"options": {
                    "keys": {"dst_mac": remote["mac"]},
                    "actions": [{"kind": "tunnel_key", "dst_ip": remote["vtep"], "key_id": 5000}],
                }}],
                "fdb": [{"mac": remote["mac"], "ifname": "sf-tp5000", "state": "static"}],
            }},
        }
        self.assertEqual(recovery.forwarding_blockers(snapshot, expected, "n1"), [])
        for kind in ("routing-guard", "port-guard", "detached", "wrong-vtep", "missing-fdb"):
            broken = json.loads(json.dumps(snapshot))
            if kind == "routing-guard":
                broken["tables"]["nftables"] = [{"table": {"name": "swiftfabric_guard"}}]
            elif kind == "port-guard":
                broken["segments"]["5000"]["ports"][local["port"]] = [
                    {"pref": 49135, "options": {"actions": [{"kind": "gact"}]}},
                ]
            elif kind == "detached":
                broken["links"][0]["master"] = "other"
            elif kind == "wrong-vtep":
                broken["segments"]["5000"]["remote"][0]["options"]["actions"][0]["dst_ip"] = "192.0.2.99"
            else:
                broken["segments"]["5000"]["fdb"] = []
            with self.subTest(kind=kind):
                self.assertTrue(recovery.forwarding_blockers(broken, expected, "n1"))

    def test_forwarding_gate_requires_two_consecutive_complete_observations(self):
        for stalled in ("none", "kernel", "catalog"):
            self.directory = Path(self.temporary.name) / stalled
            self.directory.mkdir()
            run = self.run_object()
            run.config.update(proxmox_ssh_key="synthetic-key", proxmox_ssh_user="synthetic-user")
            identity = {"host_id": "host-n1", "node": "n1"}
            run.state["host_identities"] = [identity]
            guests = [
                {"vmid": segment * 10 + index, "node": "n1", "segment_id": segment,
                 "address": f"10.{segment - 49000}.0.{index + 10}"}
                for segment in range(49100, 49106) for index in range(3)
            ]
            run.lab = mock.Mock()
            run.lab.state = {"vms": guests}
            run.lab.vm_config.side_effect = lambda vm: {
                "net0": f"virtio=02:00:00:00:{vm['segment_id'] - 49100:02x}:{vm['vmid'] % 10:02x}",
            }
            hosts = [{**identity, "vtep_ip": "192.0.2.1"}]

            def response(method, path):
                if path == "/hosts":
                    return hosts
                segment = int(path.split("/")[2])
                entries = [{
                    "mac": f"02:00:00:00:{segment - 49100:02x}:{index:02x}",
                    "host_id": identity["host_id"], "vtep_ip": "192.0.2.1",
                    "ip": f"10.{segment - 49000}.0.{index + 10}",
                } for index in range(3)]
                return {"entries": [] if stalled == "catalog" else entries}

            run.api = mock.Mock()
            run.api.json.side_effect = response
            ssh = mock.Mock()
            ssh.run.return_value = "{}"
            checks = mock.Mock(side_effect=(
                [["still fenced"]] * 6 if stalled == "kernel"
                else [["still fenced"], [], [], [], [], []]
            ))
            clock = [0, 1, 2, 1801] if stalled != "none" else [0, 1, 2, 3]
            with self.subTest(stalled=stalled), mock.patch.object(
                recovery, "SSHCommandRunner", return_value=ssh,
            ), mock.patch.object(recovery, "forwarding_blockers", checks), \
                    mock.patch.object(recovery.time, "monotonic", side_effect=clock), \
                    mock.patch.object(recovery.time, "sleep") as sleep, \
                    mock.patch("builtins.print"):
                if stalled == "none":
                    run.verify_recovered_forwarding()
                    self.assertEqual(sleep.call_count, 2)
                else:
                    with self.assertRaisesRegex(TimeoutError, "unfenced kernel forwarding"):
                        run.verify_recovered_forwarding()
            report = json.loads((run.directory / "forwarding-readiness.json").read_text())
            self.assertEqual(report["passed"], stalled == "none")

    def test_heartbeats_cannot_mask_incomplete_enrollment_or_stale_agents(self):
        cases = (
            ("active", (100, 101), (100, 101)),
            ("enrolling", (100, 101), (100, 101)),
            ("failed", (100, 101), (100, 101)),
            ("enrolled", (100, 100), (100, 101)),
            ("enrolled", (100, 101), (100, 100)),
        )
        for index, (status, host_seen, router_seen) in enumerate(cases):
            self.directory = Path(self.temporary.name) / str(index)
            self.directory.mkdir()
            run = self.run_object()
            identity = {"host_id": "compute-n1", "cluster": "compute", "node": "n1", "agent_version": "v1"}
            router = {"id": "owned", "name": "owned", "vmid": 300}
            run.state.update(host_identities=[identity], router=router)
            responses = []
            for host_time, router_time in zip(host_seen, router_seen):
                responses.extend([
                    [{**identity, "status": status, "last_seen_at": host_time}],
                    {"router": router, "health": "healthy", "agent_health": {"last_seen_at": router_time}},
                ])
            run.api = mock.Mock()
            run.api.json.side_effect = responses
            with self.subTest(status=status, host=host_seen, router=router_seen), \
                    mock.patch.object(recovery.time, "monotonic", side_effect=[0, 1, 2, 1801]), \
                    mock.patch.object(recovery.time, "sleep"), \
                    self.assertRaisesRegex(TimeoutError, "fresh recovery heartbeats"):
                run.verify_recovered_agents()
            self.assertEqual(run.api.json.call_count, 4)

    def test_restored_router_identity_change_aborts_without_polling(self):
        run = self.run_object()
        identity = {"host_id": "compute-n1", "cluster": "compute", "node": "n1", "agent_version": "v1"}
        router = {"id": "owned", "name": "owned", "vmid": 300}
        run.state.update(host_identities=[identity], router=router)
        run.api = mock.Mock()
        run.api.json.side_effect = [
            [identity], {"router": {**router, "vmid": 999}, "health": "healthy"},
        ]
        with self.assertRaisesRegex(RuntimeError, "original workload VM"):
            run.verify_recovered_agents()

    def test_full_lifecycle_order_without_early_cleanup(self):
        run = self.run_object()
        package = self.directory / "package.deb"
        package.write_bytes(b"test")
        events = []
        names = ("install", "create_router", "create_lab", "backup", "fault", "redeploy", "restore", "cleanup")
        with mock.patch.object(recovery, "ROOT", self.directory), \
                mock.patch.object(Path, "glob", return_value=iter([package])), \
                mock.patch.object(run, "acceptance", side_effect=lambda name: events.append(name)), \
                mock.patch("builtins.print"):
            with mock.patch.multiple(run, **{
                name: mock.Mock(side_effect=lambda *_, label=name: events.append(label))
                for name in names
            }):
                run.run("never-logged-secret")
        self.assertEqual(events, [
            "install", "create_router", "create_lab", "before", "backup", "fault",
            "redeploy", "restore", "after", "cleanup",
        ])
        self.assertEqual(run.state["status"], "passed")
        self.assertNotIn("never-logged-secret", (run.directory / "recovery.json").read_text())

    def test_failure_preserves_resources_and_never_advances(self):
        for failed in ("install", "backup", "fault", "restore", "acceptance"):
            with self.subTest(failed=failed):
                run = self.run_object()
                package = self.directory / "package.deb"
                package.write_bytes(b"test")
                names = (
                    "install", "create_router", "create_lab", "acceptance",
                    "backup", "fault", "redeploy", "restore", "cleanup",
                )
                methods = {name: mock.Mock() for name in names}
                methods[failed].side_effect = RuntimeError("injected failure")
                with mock.patch.object(recovery, "ROOT", self.directory), \
                        mock.patch.object(Path, "glob", return_value=iter([package])), \
                        mock.patch.multiple(run, **methods), mock.patch("builtins.print"), \
                        self.assertRaisesRegex(RuntimeError, "injected"):
                    run.run("secret")
                methods["cleanup"].assert_not_called()
                if failed in ("install", "backup", "acceptance"):
                    methods["fault"].assert_not_called()
                self.assertEqual(run.state["status"], "failed")
                self.assertEqual(json.loads((run.directory / "recovery.json").read_text())["status"], "failed")
                (run.directory / "recovery.json").unlink()
                run.directory.rmdir()

    def test_failure_prints_saved_lab_cleanup_command(self):
        run = self.run_object()
        lab_directory = run.directory / "network-lab"
        lab_directory.mkdir()
        (lab_directory / "state.json").write_text("{}")
        with mock.patch.object(recovery, "ROOT", self.directory), \
                mock.patch("builtins.print") as print_output:
            run.print_failure_cleanup_command()
        message = print_output.call_args.args[0]
        self.assertEqual(shlex.split(message.splitlines()[-1]), [
            sys.executable, str(self.directory / "python_installer/tests_integration/recovery.py"),
            "--cleanup", "--state", str(run.directory),
        ])

    def test_failure_prints_full_cleanup_command_even_before_lab_creation(self):
        run = self.run_object()
        with mock.patch("builtins.print") as print_output:
            run.print_failure_cleanup_command()
        self.assertIn("--cleanup", print_output.call_args.args[0])

    def test_fresh_tenancy_failure_preserves_resources(self):
        run = self.run_object()
        run.args.workflow = "tenancy"
        package = self.directory / "package.deb"
        package.write_bytes(b"test")
        lab_directory = run.directory / "network-lab"

        def create_lab_state():
            lab_directory.mkdir()
            (lab_directory / "state.json").write_text("{}")

        with mock.patch.object(recovery, "ROOT", self.directory), \
                mock.patch.object(Path, "glob", return_value=iter([package])), \
                mock.patch.object(run, "install"), mock.patch.object(run, "create_router"), \
                mock.patch.object(run, "create_lab", side_effect=create_lab_state), \
                mock.patch.object(run, "acceptance", side_effect=RuntimeError("test failed")), \
                mock.patch.object(run, "cleanup") as cleanup, \
                mock.patch("builtins.print") as print_output, \
                self.assertRaisesRegex(RuntimeError, "test failed"):
            run.run(None)
        cleanup.assert_not_called()
        self.assertEqual(run.state["status"], "failed")
        self.assertIn(str(run.directory), print_output.call_args.args[0])
        self.assertIn("network_tenancy.py", print_output.call_args.args[0])

    def test_saved_cleanup_loads_existing_lab_and_keeps_failure_evidence(self):
        run = self.run_object()
        run.state.update(status="failed", current_stage="revalidate")
        run.save()
        lab_directory = run.directory / "network-lab"
        lab_directory.mkdir()
        recovery.private_write(lab_directory / "state.json", {
            "config": str(run.args.config), "router": run.state["prefix"] + "-nsr", "tenancy": True,
        })
        with mock.patch.object(recovery, "RecoveryRun", return_value=run), \
                mock.patch.object(run, "connect_proxmox"), \
                mock.patch.object(recovery, "controller_inventory", return_value=[]), \
                mock.patch.object(recovery, "ControllerAPI") as api, \
                mock.patch.object(recovery.importlib, "import_module") as module, \
                mock.patch.object(run, "cleanup") as cleanup, mock.patch("builtins.print"):
            recovery.cleanup_saved_run(run.directory)
        module.return_value.TenantLab.assert_called_once_with(lab_directory)
        cleanup.assert_called_once_with()
        api.return_value.close.assert_called_once_with()
        saved = json.loads((run.directory / "recovery.json").read_text())
        self.assertEqual(saved["cleanup_status"], "complete")
        self.assertEqual(saved["status"], "failed")
        self.assertEqual(saved["current_stage"], "revalidate")

    def test_saved_cleanup_refuses_changed_config_before_opening_clients(self):
        run = self.run_object()
        run.save()
        run.args.config.write_text('{"changed": true}')
        with mock.patch.object(recovery, "ControllerAPI") as api, \
                self.assertRaisesRegex(ValueError, "configuration changed"):
            recovery.cleanup_saved_run(run.directory)
        api.assert_not_called()

    def test_saved_cleanup_refuses_foreign_router_before_opening_clients(self):
        run = self.run_object()
        run.state["router"] = {"id": "other-run", "name": "other-run", "vmid": 109}
        run.save()
        with mock.patch.object(recovery, "ControllerAPI") as api, \
                self.assertRaisesRegex(ValueError, "NSR does not belong"):
            recovery.cleanup_saved_run(run.directory)
        api.assert_not_called()

    def test_saved_cleanup_failure_does_not_claim_success(self):
        run = self.run_object()
        run.state.update(status="failed", current_stage="revalidate")
        run.save()
        with mock.patch.object(recovery, "RecoveryRun", return_value=run), \
                mock.patch.object(run, "connect_proxmox"), \
                mock.patch.object(recovery, "controller_inventory", return_value=[]), \
                mock.patch.object(recovery, "ControllerAPI", side_effect=RuntimeError("API unavailable")), \
                mock.patch.object(run, "cleanup") as cleanup, \
                mock.patch("builtins.print"), self.assertRaisesRegex(RuntimeError, "API unavailable"):
            recovery.cleanup_saved_run(run.directory)
        cleanup.assert_not_called()
        self.assertEqual(json.loads((run.directory / "recovery.json").read_text())["cleanup_status"], "incomplete")

    def test_saved_cleanup_refuses_replaced_controllers(self):
        run = self.run_object()
        run.state["controllers"] = [{"vmid": 100}]
        run.save()
        with mock.patch.object(recovery, "RecoveryRun", return_value=run), \
                mock.patch.object(run, "connect_proxmox"), \
                mock.patch.object(recovery, "controller_inventory", return_value=[{"vmid": 999}]), \
                mock.patch.object(recovery, "ControllerAPI") as api, \
                mock.patch.object(run, "cleanup") as cleanup, mock.patch("builtins.print"), \
                self.assertRaisesRegex(RuntimeError, "Controller ownership"):
            recovery.cleanup_saved_run(run.directory)
        api.assert_not_called()
        cleanup.assert_not_called()

    def test_fresh_tenancy_installs_tests_and_cleans_without_disaster(self):
        run = self.run_object()
        run.args.workflow = "tenancy"
        package = self.directory / "package.deb"
        package.write_bytes(b"test")
        events = []
        names = ("install", "create_router", "create_lab", "backup", "fault", "redeploy", "restore", "cleanup")
        methods = {
            name: mock.Mock(side_effect=lambda *_, label=name: events.append(label))
            for name in names
        }
        with mock.patch.object(Path, "glob", return_value=iter([package])), \
                mock.patch.multiple(run, **methods), \
                mock.patch.object(run, "acceptance", side_effect=lambda name: events.append(name)), \
                mock.patch("builtins.print"):
            run.run(None)
        self.assertEqual(events, ["install", "create_router", "create_lab", "before", "cleanup"])
        self.assertEqual(run.state["status"], "passed")
        self.assertEqual(len(run.state["stages"]), 5)

    def test_fault_requires_unchanged_backup_and_passing_baseline(self):
        run = self.run_object()
        backup = run.directory / "backup.sfbak"
        backup.write_bytes(b"backup")
        run.state["backup_sha256"] = recovery.fingerprint(backup)
        backup.write_bytes(b"changed")
        with mock.patch.object(recovery, "verify_acceptance"), \
                mock.patch.object(recovery, "delete_owned_controllers") as delete, \
                self.assertRaisesRegex(RuntimeError, "backup changed"):
            run.fault()
        delete.assert_not_called()

    def test_binary_upload_keeps_passphrase_out_of_url_and_uses_verified_tls(self):
        api = recovery.ControllerAPI.__new__(recovery.ControllerAPI)
        api.session = mock.Mock()
        api.base_url = "https://192.0.2.13/api/v1"
        api.session.request.return_value.ok = True
        api.request("POST", "/backup-restore/restore", archive=b"archive", passphrase="never-log-this")
        args, kwargs = api.session.request.call_args
        self.assertNotIn("never-log-this", args[1])
        self.assertEqual(
            kwargs["headers"]["X-SwiftFabric-Recovery-Passphrase"],
            "never-log-this",
        )
        self.assertNotIn("verify", kwargs)
        self.assertEqual(kwargs["data"], b"archive")

    def test_api_errors_withhold_sensitive_response_bodies(self):
        api = recovery.ControllerAPI.__new__(recovery.ControllerAPI)
        api.session = mock.Mock()
        api.base_url = "https://192.0.2.13/api/v1"
        api.session.request.return_value.ok = False
        api.session.request.return_value.status_code = 500
        api.session.request.return_value.text = "private archive or credentials"
        with self.assertRaises(RuntimeError) as raised:
            api.request("POST", "/backup-restore/restore")
        self.assertIn("HTTP 500", str(raised.exception))
        self.assertNotIn("private archive", str(raised.exception))

    def test_api_delete_accepts_no_content_response(self):
        api = recovery.ControllerAPI.__new__(recovery.ControllerAPI)
        response = mock.Mock(content=b"")
        with mock.patch.object(api, "request", return_value=response):
            self.assertIsNone(api.json("DELETE", "/north-south-routers/owned"))
        response.json.assert_not_called()

    def test_help_requires_no_live_access(self):
        result = subprocess.run(
            [sys.executable, str(ROOT / "python_installer/tests_integration/disaster_recovery.py"), "--help"],
            cwd=self.directory, text=True, capture_output=True, timeout=15,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("--recovery-passphrase-file", result.stdout)
        self.assertIn("--yes", result.stdout)

    def test_restore_target_is_exclusive_to_non_interactive_install(self):
        for arguments in (
            ["--restore-target"],
            ["--restore-target", "--destroy", "--non-interactive"],
        ):
            with self.subTest(arguments=arguments), \
                    mock.patch.object(sys, "argv", ["install.py", *arguments]), \
                    mock.patch("sys.stderr"), self.assertRaises(SystemExit):
                installer.parse_args()
        with mock.patch.object(sys, "argv", ["install.py", "--non-interactive", "--restore-target"]):
            self.assertTrue(installer.parse_args().restore_target)


class ControllerFaultTests(unittest.TestCase):
    def setUp(self):
        self.client = mock.Mock()
        self.resources = [
            {"type": "qemu", "name": f"sf-test-swiftfabric-controller-{index}", "vmid": 100 + index, "node": f"n{index}"}
            for index in range(3)
        ]
        self.configs = {
            f"/nodes/n{index}/qemu/{100 + index}/config": {
                "name": resource["name"], "cicustom": f"vendor=VMData:snippets/swiftfabric-vm-{100 + index}-vendor.yaml",
                "scsi0": f"VMData:vm-{100 + index}-disk-0", "digest": "initial",
            }
            for index, resource in enumerate(self.resources)
        }
        self.stopped = set()

        def get(path, params=None):
            if path == "/cluster/resources":
                return {"data": list(self.resources)}
            if path.endswith("/status/current"):
                return {"data": {"status": "stopped" if path in self.stopped else "running"}}
            return {"data": dict(self.configs[path])}

        def stop(path):
            self.stopped.add(path.removesuffix("/stop") + "/current")
            return {"data": "UPID:n0:stop"}

        def delete(path, params=None):
            vmid = int(path.rsplit("/", 1)[1])
            self.resources[:] = [vm for vm in self.resources if vm["vmid"] != vmid]
            return {"data": "UPID:n0:delete"}

        self.client.get.side_effect = get
        self.client.post.side_effect = stop
        self.client.delete.side_effect = delete
        self.expected = recovery.controller_inventory(self.client, "sf-test")

    def test_stops_all_controllers_before_deleting_only_recorded_vms(self):
        self.client.reset_mock()
        recovery.delete_owned_controllers(self.client, "sf-test", self.expected)
        calls = self.client.mock_calls
        mutations = [call for call in calls if call[0] in ("post", "delete")]
        self.assertEqual([call[0] for call in mutations], ["post"] * 3 + ["delete"] * 3)
        self.assertEqual([call.args[0] for call in mutations[3:]], [
            f"/nodes/n{index}/qemu/{100 + index}" for index in range(3)
        ])
        self.assertEqual(self.client.wait_for_task.call_count, 6)

    def test_config_change_stops_before_any_mutation(self):
        self.configs["/nodes/n1/qemu/101/config"]["scsi0"] = "VMData:unrelated-disk"
        with self.assertRaisesRegex(RuntimeError, "changed"):
            recovery.delete_owned_controllers(self.client, "sf-test", self.expected)
        self.client.post.assert_not_called()
        self.client.delete.assert_not_called()

    def test_duplicate_controller_or_missing_marker_stops_before_any_mutation(self):
        self.resources.append(dict(self.resources[0], vmid=999))
        with self.assertRaisesRegex(RuntimeError, "exactly one"):
            recovery.delete_owned_controllers(self.client, "sf-test", self.expected)
        self.resources.pop()
        self.configs["/nodes/n1/qemu/101/config"]["cicustom"] = ""
        with self.assertRaisesRegex(RuntimeError, "ownership"):
            recovery.delete_owned_controllers(self.client, "sf-test", self.expected)
        self.client.post.assert_not_called()

    def test_missing_task_identifier_fails_explicitly(self):
        self.client.post.side_effect = None
        self.client.post.return_value = {"data": None}
        with self.assertRaisesRegex(RuntimeError, "task identifier"):
            recovery.delete_owned_controllers(self.client, "sf-test", self.expected)
        self.client.delete.assert_not_called()


if __name__ == "__main__":
    unittest.main()
