import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import textwrap
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location(
    "interactive_integration_test",
    ROOT / "python_installer" / "tests_integration" / "interactive.py",
)
interactive = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(interactive)

API_KEY = "00000000-0000-0000-0000-000000000000"


def source_config():
    return {
        "deploy_api": "proxmox",
        "proxmox_cluster_ip": "192.0.2.10",
        "proxmox_port": 8006,
        "proxmox_user": "root@pam",
        "proxmox_tokenname": "swiftinstaller",
        "proxmox_apikey": API_KEY,
        "proxmox_ssh_user": "root",
        "proxmox_ssh_key": "/keys/proxmox",
        "proxmox_auto_enroll_host_list": ["compute1"],
        "ubuntu_mirror": "http://mirror.example/ubuntu/",
        "mgmt_priv_key": "controller",
        "mgmt_pub_key": "controller.pub",
        "mgmt_vlan_id": 50,
        "mgmt_ip_range_start": "172.16.255.2",
        "mgmt_ip_range_end": "172.16.255.254",
        "mgmt_gateway_ip": "172.16.255.1",
        "mgmt_dns_ip": "192.0.2.53",
        "mgmt_vm_password": None,
        "mgmt_cidr": 24,
        "mgmt_interface": "vmbr0",
        "storage_location": "VMData",
    }


class AnswerTests(unittest.TestCase):
    def test_existing_deployment_stops_before_tui_or_cleanup(self):
        with tempfile.TemporaryDirectory() as directory:
            config_path = Path(directory) / "config.json"
            config_path.write_text(json.dumps(source_config()), encoding="utf-8")
            with mock.patch.object(interactive, "validate_api_package"), \
                    mock.patch.object(interactive, "require_empty_target") as check, \
                    mock.patch.object(interactive, "run_lifecycle") as lifecycle, \
                    mock.patch("builtins.print") as output:
                check.side_effect = ValueError(
                    "Point the test kit at a system with no SwiftFabric installation active."
                )
                status = interactive.main(["--yes", "--config", str(config_path)])
            self.assertEqual(status, 1)
            check.assert_called_once_with(source_config(), config_path.parent)
            lifecycle.assert_not_called()
            self.assertIn("no SwiftFabric installation active", str(output.call_args_list))

    def test_aliases_and_relative_keys_resolve_like_non_interactive(self):
        answers = interactive.normalize_answer_config(source_config(), Path("/cfg"))

        self.assertEqual(answers["vlan_id"], 50)
        self.assertEqual(answers["interface"], "vmbr0")
        self.assertEqual(answers["controller_priv_key"], "/cfg/controller")
        self.assertEqual(answers["controller_pub_key"], "/cfg/controller.pub")
        self.assertEqual(answers["ubuntu_mirror"], "http://mirror.example/ubuntu")

    def test_missing_pub_key_uses_private_key_pair_and_inline_key_is_kept(self):
        config = source_config()
        del config["mgmt_pub_key"]
        answers = interactive.normalize_answer_config(config, Path("/cfg"))
        self.assertEqual(answers["controller_pub_key"], "/cfg/controller.pub")

        config["mgmt_pub_key"] = "ssh-ed25519 AAAA test"
        answers = interactive.normalize_answer_config(config, Path("/cfg"))
        self.assertEqual(answers["controller_pub_key"], "ssh-ed25519 AAAA test")

    def test_missing_required_answer_is_rejected(self):
        config = source_config()
        del config["mgmt_gateway_ip"]
        with self.assertRaisesRegex(ValueError, "gateway_ip"):
            interactive.normalize_answer_config(config, Path("/cfg"))

    def test_script_marks_secrets_and_ends_with_confirmation(self):
        answers = interactive.normalize_answer_config(source_config(), Path("/cfg"))
        script = interactive.prompt_script(answers, "pw")

        secrets = {label for label, _, secret in script if secret}
        self.assertEqual(secrets, {
            "Proxmox API Key", "Ubuntu Account Password", "Confirm Ubuntu Account Password",
        })
        self.assertEqual(
            script[-1], ("Do you want to proceed with this configuration?", "y", False),
        )
        self.assertIn(("VLAN ID (or 'none' for no VLAN)", "50", False), script)

    def test_null_vlan_answers_none(self):
        config = source_config()
        config["mgmt_vlan_id"] = None
        answers = interactive.normalize_answer_config(config, Path("/cfg"))
        script = dict((label, value) for label, value, _ in
                      interactive.prompt_script(answers, "pw"))
        self.assertEqual(script["VLAN ID (or 'none' for no VLAN)"], "none")

    def test_prompt_detection_requires_input_point(self):
        self.assertTrue(interactive.prompt_is_waiting("x\nProxmox Port (8006): ", "Proxmox Port"))
        self.assertTrue(interactive.prompt_is_waiting(
            "Do you want to proceed with this configuration? [y/n] (y): ",
            "Do you want to proceed with this configuration?",
        ))
        self.assertFalse(interactive.prompt_is_waiting("Proxmox Port (8006): 8006\n", "Proxmox Port"))


class PtySessionTests(unittest.TestCase):
    def run_fake_tui(self, body, script):
        with tempfile.TemporaryDirectory() as directory:
            program = Path(directory) / "tui.py"
            program.write_text(textwrap.dedent(body), encoding="utf-8")
            output = io.BytesIO()
            session = interactive.PtySession(
                [sys.executable, str(program)], cwd=directory, output=output,
            )
            try:
                for label, value, secret in script:
                    session.expect_prompt(label, 10)
                    session.send(label, value, secret)
                status = session.wait(10)
            finally:
                session.terminate()
            return status, output.getvalue().decode("utf-8", "replace")

    def test_answers_plain_and_secret_prompts_without_echoing_secret(self):
        status, output = self.run_fake_tui(
            """
            import getpass, sys
            name = input("Proxmox Port (8006): ")
            print("\\x1b[1mbanner\\x1b[0m")
            secret = getpass.getpass("Proxmox API Key: ")
            sys.exit(0 if (name, secret) == ("8006", "hidden-value") else 3)
            """,
            [("Proxmox Port", "8006", False), ("Proxmox API Key", "hidden-value", True)],
        )
        self.assertEqual(status, 0)
        self.assertNotIn("hidden-value", output)

    def test_secret_is_not_typed_into_an_echoing_prompt(self):
        with mock.patch.object(interactive.PtySession, "echo_off_timeout", 1), \
                self.assertRaisesRegex(interactive.InteractiveError, "echo"):
            self.run_fake_tui(
                """
                input("Proxmox API Key: ")
                """,
                [("Proxmox API Key", "hidden-value", True)],
            )

    def test_installer_error_stops_script(self):
        with self.assertRaisesRegex(interactive.InteractiveError, "error"):
            self.run_fake_tui(
                """
                print("✗ Error discovering resources: boom")
                input("Network Interface Name: ")
                """,
                [("Network Interface Name", "vmbr0", False)],
            )

    def test_early_exit_is_reported(self):
        with self.assertRaisesRegex(interactive.InteractiveError, "exited"):
            self.run_fake_tui("print('bye')\n", [("Proxmox Port", "8006", False)])


class RealTuiTests(unittest.TestCase):
    """Drive the real interactive_install prompts so ordering, label, or masking
    drift fails fast. Only the Proxmox deployment itself is replaced."""

    def drive(self, fail):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "proxmox").write_text("key", encoding="utf-8")
            (root / "controller").write_text("key", encoding="utf-8")
            (root / "controller.pub").write_text(
                "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIOMqqnkVzrm0SdG6UOoqKLsabgH5C9okWi0dh2l9GKJl t\n",
                encoding="utf-8",
            )
            config = source_config()
            config["proxmox_ssh_key"] = str(root / "proxmox")
            answers = interactive.normalize_answer_config(config, root)
            saved_path = root / "saved.json"
            published = root / "published.json"
            script = interactive.prompt_script(answers, "Ubuntu-Pass-1")
            program = root / "tui.py"
            program.write_text(textwrap.dedent(f"""
                import sys
                from unittest import mock
                sys.path.insert(0, {str(ROOT / "python_installer")!r})
                import main
                deployment = mock.Mock()
                deployment.discover_resources.return_value = {{
                    "nodes": [{{"node": "node1"}}],
                    "storage": [{{"storage": "local-lvm"}}, {{"storage": "VMData"}}],
                    "available_interfaces": ["vmbr0", "vmbr1", "vmbr2", "vmbr3"],
                }}
                def deploy(*args, **kwargs):
                    print("DEPLOY-RAN")
                    if {fail!r}:
                        raise RuntimeError("boom")
                    return {{"nodes": ["192.0.2.10", "192.0.2.11", "192.0.2.12"]}}
                def publish(config, summary, content):
                    with open({str(published)!r}, "wb") as handle:
                        handle.write(content)
                with mock.patch.object(main, "_create_deployment", return_value=deployment), \\
                        mock.patch.object(main, "_ensure_controller_names_available"), \\
                        mock.patch.object(main, "_deploy_interactive", side_effect=deploy), \\
                        mock.patch.object(main, "publish_controller_config", side_effect=publish):
                    try:
                        main.interactive_install("sf-iit-test")
                    except RuntimeError:
                        sys.exit(1)
            """), encoding="utf-8")
            output = io.BytesIO()
            session = interactive.PtySession(
                [sys.executable, str(program)], cwd=directory, output=output,
            )
            try:
                status = interactive.drive_install(session, script, saved_path, 30, 30)
            finally:
                session.terminate()

            transcript = output.getvalue().decode("utf-8", "replace")
            self.assertNotIn(API_KEY, transcript)
            self.assertNotIn("Ubuntu-Pass-1", transcript)
            self.assertEqual(
                interactive.verify_saved_config(saved_path, answers, "Ubuntu-Pass-1"), [],
            )
            published_content = published.read_bytes() if published.exists() else None
            if status == 0:
                self.assertEqual(published_content, saved_path.read_bytes())
            else:
                self.assertIsNone(published_content)
            return status, interactive.ANSI_PATTERN.sub("", transcript)

    def test_config_is_offered_after_successful_deployment(self):
        status, transcript = self.drive(False)

        self.assertEqual(status, 0, transcript)
        self.assertLess(transcript.index("DEPLOY-RAN"), transcript.index(interactive.SAVE_PROMPT))
        self.assertIn("Upgrade later with:", transcript)

    def test_config_is_offered_after_failed_deployment(self):
        status, transcript = self.drive(True)

        self.assertEqual(status, 1, transcript)
        self.assertLess(transcript.index("boom"), transcript.index(interactive.SAVE_PROMPT))
        self.assertIn("Remove the partial deployment with:", transcript)
        self.assertIn("--prefix sf-iit-test", transcript)


class FakeSession:
    def __init__(self, status=0, write_config=True, mode=0o600, saved=None, error=None):
        self.status = status
        self.write_config = write_config
        self.mode = mode
        self.saved = saved
        self.error = error
        self.exit_status = None
        self.command = None

    def __call__(self, command, cwd):
        self.command = command
        return self

    def expect_prompt(self, label, timeout, check_failures=True):
        pass

    def send(self, label, value, secret=False):
        if label == interactive.SAVE_PROMPT and self.write_config:
            path = Path(value)
            path.write_text(json.dumps(self.saved), encoding="utf-8")
            os.chmod(path, self.mode)
        if self.error is not None:
            raise self.error

    def wait(self, timeout=None):
        self.exit_status = self.status
        return self.status

    def terminate(self):
        self.exit_status = 130
        return 130


class LifecycleTests(unittest.TestCase):
    def setUp(self):
        self.answers = interactive.normalize_answer_config(source_config(), Path("/cfg"))
        self.saved = {key: self.answers[key] for key in interactive.ROUND_TRIP_KEYS}
        self.saved["admin_password"] = None
        self.verifier = mock.Mock(return_value=[])
        print_patch = mock.patch("builtins.print")
        print_patch.start()
        self.addCleanup(print_patch.stop)

    def run_lifecycle(self, session, cleanup_status=0):
        workdirs = []
        real_mkdtemp = tempfile.mkdtemp

        def mkdtemp(**kwargs):
            path = real_mkdtemp(**kwargs)
            workdirs.append(Path(path))
            self.addCleanup(lambda: __import__("shutil").rmtree(path, ignore_errors=True))
            return path

        runner = mock.Mock(return_value=subprocess.CompletedProcess([], cleanup_status))
        with mock.patch.object(interactive.tempfile, "mkdtemp", side_effect=mkdtemp):
            status = interactive.run_lifecycle(
                Path("/cfg/config.json"), self.answers, ROOT,
                runner=runner, session_factory=session, verifier=self.verifier,
            )
        return status, runner, workdirs[0]

    def destroy_config(self, runner):
        command = runner.call_args.args[0]
        return command[command.index("--config") + 1], command

    def test_destroy_uses_config_saved_by_interactive_install(self):
        session = FakeSession(saved=self.saved)
        status, runner, workdir = self.run_lifecycle(session)

        self.assertEqual(status, 0)
        self.assertNotIn("--non-interactive", session.command)
        config, command = self.destroy_config(runner)
        self.assertEqual(Path(config).parent, workdir)
        self.assertIn("--auto-unenroll", command)
        self.assertEqual(command[command.index("--prefix") + 1],
                         session.command[session.command.index("--prefix") + 1])
        self.assertFalse(workdir.exists())

    def test_controller_copies_are_checked_against_saved_config(self):
        session = FakeSession(saved=self.saved)
        self.verifier.return_value = ["192.0.2.10: differs"]
        status, runner, workdir = self.run_lifecycle(session)

        self.assertEqual(status, 1)
        runner.assert_called_once()
        saved_path = Path(self.destroy_config(runner)[0])
        self.assertEqual(self.verifier.call_args.args[1], saved_path.parent)
        self.assertEqual(json.loads(self.verifier.call_args.args[2]), self.saved)

    def test_missing_saved_config_falls_back_and_fails(self):
        status, runner, workdir = self.run_lifecycle(FakeSession(write_config=False))

        self.assertEqual(status, 1)
        self.assertEqual(self.destroy_config(runner)[0], "/cfg/config.json")
        self.assertTrue(workdir.exists())

    def test_saved_config_must_be_private_and_faithful(self):
        for mode, change in ((0o644, {}), (0o600, {"storage_location": "other"}),
                             (0o600, {"admin_password": "leaked"})):
            with self.subTest(mode=mode, change=change):
                saved = {**self.saved, **change}
                status, runner, _ = self.run_lifecycle(FakeSession(mode=mode, saved=saved))
                self.assertEqual(status, 1)
                runner.assert_called_once()

    def test_driver_failure_terminates_installer_and_still_cleans_up(self):
        session = FakeSession(saved=self.saved, error=interactive.InteractiveError("boom"))
        status, runner, _ = self.run_lifecycle(session)

        self.assertEqual(status, 1)
        self.assertEqual(session.exit_status, 130)
        runner.assert_called_once()

    def test_interrupt_still_cleans_up(self):
        session = FakeSession(saved=self.saved, error=KeyboardInterrupt())
        status, runner, _ = self.run_lifecycle(session)

        self.assertEqual(status, 130)
        runner.assert_called_once()

    def test_cleanup_failure_fails_test(self):
        status, _, workdir = self.run_lifecycle(FakeSession(saved=self.saved), cleanup_status=2)

        self.assertEqual(status, 2)
        self.assertTrue(workdir.exists())


if __name__ == "__main__":
    unittest.main()
