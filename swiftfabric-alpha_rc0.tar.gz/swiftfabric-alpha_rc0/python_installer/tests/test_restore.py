import copy
import io
import json
import sys
import unittest
import tarfile
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from deployment.restore import ControllerRestore, WORKER
from deployment.api_service import ApiServiceDeployment


class RestoreBuildSourceTests(unittest.TestCase):
    def test_buildbox_archive_and_fingerprint_include_worker_and_tests(self):
        source = Path(__file__).resolve().parents[2] / "controller-api" / "segment-manager"
        required = (
            "segment-manager/packaging/swiftfabric-restore-controller",
            "segment-manager/tests/test_restore_worker.py",
        )
        manifest = {name for _, name in ApiServiceDeployment._source_files(source)}
        with tarfile.open(fileobj=io.BytesIO(ApiServiceDeployment._source_archive(source)), mode="r:gz") as archive:
            for name in required:
                self.assertIn(name, manifest)
                self.assertEqual(archive.extractfile(name).read(), (source.parent / name).read_bytes())


class ControllerRestoreTests(unittest.TestCase):
    def setUp(self):
        self.ssh = mock.Mock()
        self.restore = ControllerRestore({
            "ip_range_start": "192.0.2.10", "controller_priv_key": "/synthetic/key",
        }, ssh=self.ssh)
        self.archive = b"SWFTBAK1encrypted-fixture"
        self.report = {
            "status": "staged", "schema_version": 3, "staging_id": "a" * 32,
            "controller_ips": self.restore.nodes, "ca_sha256_fingerprint": "b" * 64,
        }

    def stage(self):
        import hashlib

        def result(node, command, **kwargs):
            if "sha256sum" in command:
                return hashlib.sha256(self.archive).hexdigest() + "  backup\n"
            if "--restore-stage-archive" in command:
                return json.dumps(self.report)
            return ""

        self.ssh.run.side_effect = result
        return self.restore.stage(self.archive, "recovery-secret")

    def test_stages_archive_on_all_three_controllers_without_private_output(self):
        self.assertEqual(self.stage(), self.report)
        self.assertEqual(set(self.restore.staged), set(self.restore.nodes))
        calls = self.ssh.run.call_args_list
        self.assertEqual(len(calls), 9)
        for node in self.restore.nodes:
            matching = [call for call in calls if call.args[0] == node]
            self.assertEqual(len(matching), 3)
            self.assertEqual(matching[0].kwargs["input_data"], self.archive)
            self.assertEqual(matching[2].kwargs["input_data"], b"recovery-secret\n")
            self.assertNotIn("recovery-secret", matching[2].args[1])

    def test_staging_rejects_legacy_schema_and_changed_topology(self):
        for change in (
            {"schema_version": 2}, {"staging_id": "../../ca.key"},
            {"controller_ips": list(reversed(self.restore.nodes))},
        ):
            with self.subTest(change=change):
                original = copy.deepcopy(self.report)
                self.report.update(change)
                with self.assertRaises(RuntimeError):
                    self.stage()
                self.report = original

    def test_upload_checksum_failure_stops_before_decryption(self):
        self.ssh.run.side_effect = ["", "c" * 64 + " backup"]
        with self.assertRaisesRegex(RuntimeError, "changed"):
            self.restore.stage(self.archive, "recovery-secret")
        self.assertEqual(self.ssh.run.call_count, 2)

    def test_capabilities_require_supported_worker_on_each_controller(self):
        self.ssh.run.return_value = json.dumps({
            "complete": True, "protocol_version": 1, "supported_schema": 3,
        })
        self.restore.capabilities()
        self.assertEqual(self.ssh.run.call_count, 3)
        for call in self.ssh.run.call_args_list:
            self.assertEqual(call.args[1], f"sudo -n {WORKER}")
            self.assertEqual(json.loads(call.kwargs["input_data"])["operation"], "capabilities")

    def test_worker_failure_is_never_completed_restore(self):
        self.ssh.run.return_value = '{"complete":false}'
        with self.assertRaisesRegex(RuntimeError, "did not complete"):
            self.restore.worker(self.restore.nodes[0], "apply")

    def test_maintenance_requires_cib_convergence_everywhere(self):
        self.ssh.run.side_effect = [
            "", '<cib><configuration><crm_config><cluster_property_set>'
            '<nvpair name="maintenance-mode" value="false"/>'
            '</cluster_property_set></crm_config></configuration></cib>',
        ]
        with mock.patch("deployment.restore.time.monotonic", side_effect=[0, 61]), \
                self.assertRaisesRegex(RuntimeError, "did not converge"):
            self.restore.maintenance(True)

    def operations(self, failed=None, rollback_failed=False):
        events = []
        self.restore.staged = {node: dict(self.report) for node in self.restore.nodes}

        def worker(node, operation):
            events.append((operation, node))
            if operation == failed and node == self.restore.nodes[1]:
                raise RuntimeError("injected worker failure")
            if rollback_failed and operation == "rollback":
                raise RuntimeError("injected rollback failure")
            return {"complete": True}

        patches = mock.patch.multiple(
            self.restore,
            worker=mock.Mock(side_effect=worker),
            maintenance=mock.Mock(side_effect=lambda enabled: events.append(("maintenance", enabled))),
            stop=mock.Mock(side_effect=lambda: events.append(("stop",))),
            start=mock.Mock(side_effect=lambda: events.append(("start",))),
        )
        return events, patches

    def test_restore_fences_every_node_before_import_and_verifies_before_unfencing(self):
        events, patches = self.operations()
        with patches:
            report = self.restore.restore()
        nodes = self.restore.nodes
        self.assertEqual(events, [
            *[("plan", node) for node in nodes],
            ("maintenance", True), ("stop",),
            *[("apply", node) for node in nodes],
            ("cib", nodes[0]), ("start",),
            *[("verify", node) for node in nodes],
            ("maintenance", False),
        ])
        self.assertTrue(report["complete"])

    def test_partial_apply_rolls_back_all_nodes_including_unattempted_nodes(self):
        events, patches = self.operations(failed="apply")
        with patches, self.assertRaisesRegex(RuntimeError, "fresh target restored"):
            self.restore.restore()
        for node in self.restore.nodes:
            self.assertIn(("rollback", node), events)
        self.assertEqual(events[-3:], [
            ("rollback-cib", self.restore.nodes[0]), ("start",), ("maintenance", False),
        ])
        self.assertNotIn(("verify", self.restore.nodes[0]), events)

    def test_rollback_failure_keeps_cluster_fenced(self):
        events, patches = self.operations(failed="verify", rollback_failed=True)
        with patches, self.assertRaisesRegex(RuntimeError, "remain fenced"):
            self.restore.restore()
        self.assertNotIn(("maintenance", False), events)
        self.assertEqual(events.count(("start",)), 1)

    def test_plan_failure_has_no_live_mutation_or_unfencing(self):
        events, patches = self.operations(failed="plan")
        with patches, self.assertRaisesRegex(RuntimeError, "injected worker failure"):
            self.restore.restore()
        self.assertTrue(all(operation == "plan" for operation, _ in events))

    def test_restore_without_every_staged_controller_refuses_before_mutation(self):
        self.restore.staged = {self.restore.nodes[0]: self.report}
        with mock.patch.object(self.restore, "worker") as worker, \
                self.assertRaisesRegex(RuntimeError, "all three"):
            self.restore.restore()
        worker.assert_not_called()


if __name__ == "__main__":
    unittest.main()
