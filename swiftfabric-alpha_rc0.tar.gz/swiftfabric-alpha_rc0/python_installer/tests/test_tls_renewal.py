import importlib.machinery
import importlib.util
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest import mock


SOURCE = (
    Path(__file__).resolve().parents[2]
    / "controller-api"
    / "segment-manager"
    / "packaging"
    / "swiftfabric-renew-controller-cert"
)
LOADER = importlib.machinery.SourceFileLoader("swiftfabric_tls_renew", str(SOURCE))
SPEC = importlib.util.spec_from_loader(LOADER.name, LOADER)
tls_renew = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(tls_renew)


class ControllerTlsRenewalTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        root = Path(self.temporary.name)
        ca_dir = root / "ca"
        tls_dir = root / "tls"
        ca_dir.mkdir(mode=0o700)
        tls_dir.mkdir(mode=0o700)
        tls_renew.CA_DIR = ca_dir
        tls_renew.CA_CERT = ca_dir / "ca.crt"
        tls_renew.CA_KEY = ca_dir / "ca.key"
        tls_renew.CA_SERIAL = ca_dir / "ca.srl"
        tls_renew.TLS_DIR = tls_dir
        tls_renew.LEAF_CERT = tls_dir / "server.crt"
        tls_renew.LEAF_KEY = tls_dir / "server.key"
        subprocess.run(
            [
                "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
                "-keyout", str(tls_renew.CA_KEY), "-out", str(tls_renew.CA_CERT),
                "-days", "3650", "-subj", "/CN=Test SwiftFabric CA",
                "-addext", "basicConstraints=critical,CA:TRUE,pathlen:0",
                "-addext", "keyUsage=critical,keyCertSign,cRLSign",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        tls_renew.CA_KEY.chmod(0o600)
        subprocess.run(
            [
                "openssl", "genpkey", "-algorithm", "RSA",
                "-pkeyopt", "rsa_keygen_bits:2048",
                "-out", str(tls_renew.LEAF_KEY),
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        tls_renew.LEAF_KEY.chmod(0o600)

    def test_renews_leaf_and_keeps_valid_cert_without_reload(self):
        original_run = subprocess.run
        reload_calls = []

        def run(command, **kwargs):
            if command[:2] == ["systemctl", "reload"]:
                reload_calls.append(command)
                return subprocess.CompletedProcess(command, 0, "", "")
            return original_run(command, **kwargs)

        with (
            mock.patch.object(tls_renew, "require_root_private_key"),
            mock.patch.object(tls_renew.subprocess, "run", side_effect=run),
        ):
            tls_renew.renew("192.0.2.10", "192.0.2.13")
            self.assertTrue(
                tls_renew.valid_current_certificate("192.0.2.10", "192.0.2.13")
            )
            tls_renew.renew("192.0.2.10", "192.0.2.13")

        self.assertEqual(len(reload_calls), 1)
        subprocess.run(
            [
                "openssl", "verify", "-CAfile", str(tls_renew.CA_CERT),
                str(tls_renew.LEAF_CERT),
            ],
            check=True,
            capture_output=True,
            text=True,
        )

    def test_reload_failure_removes_uncommitted_leaf(self):
        original_run = subprocess.run

        def run(command, **kwargs):
            if command[:2] == ["systemctl", "reload"]:
                raise subprocess.CalledProcessError(
                    1, command, output="", stderr="nginx reload failed"
                )
            return original_run(command, **kwargs)

        with (
            mock.patch.object(tls_renew, "require_root_private_key"),
            mock.patch.object(tls_renew.subprocess, "run", side_effect=run),
        ):
            with self.assertRaisesRegex(RuntimeError, "reload failed"):
                tls_renew.renew("192.0.2.10", "192.0.2.13")

        self.assertFalse(tls_renew.LEAF_CERT.exists())


if __name__ == "__main__":
    unittest.main()
