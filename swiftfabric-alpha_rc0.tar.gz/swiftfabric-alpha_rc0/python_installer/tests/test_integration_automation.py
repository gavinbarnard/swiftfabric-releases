import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tests_integration"))
import automation


class AutomationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.path = self.directory / "integration-test.json"
        self.settings = {
            "allow_destructive": True, "config": "config.json",
            "router_config": "nsr.json", "nodes": ["n1", "n2", "n3"],
            "image_volume": "VMData:import/image.qcow2",
            "state_root": str(self.directory / "runs"),
            "recovery_passphrase_file": "passphrase",
        }

    def arguments(self, workflow="recovery"):
        self.path.write_text(json.dumps(self.settings))
        return automation.command_arguments(self.path, workflow)

    def test_requires_explicit_boolean_destructive_authorization(self):
        for value in (False, None, "true", 1):
            self.settings["allow_destructive"] = value
            with self.subTest(value=value), self.assertRaisesRegex(ValueError, "allow_destructive"):
                self.arguments()

    def test_relative_paths_and_unique_external_state(self):
        first = self.arguments()
        second = self.arguments()
        self.assertIn(str(self.directory / "config.json"), first)
        self.assertIn(str(self.directory / "nsr.json"), first)
        self.assertIn(str(self.directory / "passphrase"), first)
        self.assertEqual(first[first.index("--nodes") + 1:first.index("--nodes") + 4], ["n1", "n2", "n3"])
        state = Path(first[first.index("--state") + 1])
        self.assertEqual(state.parent, self.directory / "runs")
        self.assertFalse(state.exists())
        self.assertNotEqual(first, second)

    def test_tenancy_needs_no_passphrase(self):
        del self.settings["recovery_passphrase_file"]
        self.assertNotIn("--recovery-passphrase-file", self.arguments("tenancy"))
        with self.assertRaisesRegex(ValueError, "recovery_passphrase_file"):
            self.arguments()

    def test_invalid_settings_fail_before_live_runner(self):
        for change in (
            {"nodes": "n1 n2 n3"}, {"nodes": ["n1", "n2"]},
            {"unexpected": True}, {"config": ""}, {"state_root": str(automation.ROOT / "runs")},
        ):
            settings = {**self.settings, **change}
            self.path.write_text(json.dumps(settings))
            with self.subTest(change=change), mock.patch.object(automation.disaster_recovery, "main") as run, \
                    mock.patch("builtins.print"):
                self.assertEqual(automation.main("recovery", ["--test-config", str(self.path)]), 1)
            run.assert_not_called()

    def test_runner_exit_status_is_propagated(self):
        self.arguments()
        for workflow in ("recovery", "tenancy"):
            with mock.patch.object(automation.disaster_recovery, "main", return_value=130) as run:
                self.assertEqual(automation.main(workflow, ["--test-config", str(self.path)]), 130)
            self.assertEqual(run.call_args.kwargs, {"workflow": workflow})

    def test_failure_capture_option_is_forwarded_only_for_recovery(self):
        self.arguments()
        with mock.patch.object(automation.disaster_recovery, "main", return_value=0) as run:
            self.assertEqual(automation.main("recovery", [
                "--test-config", str(self.path), "--capture-failed-traffic",
            ]), 0)
        self.assertIn("--capture-failed-traffic", run.call_args.args[0])

        with mock.patch("sys.stderr"), self.assertRaises(SystemExit):
            automation.main("tenancy", [
                "--test-config", str(self.path), "--capture-failed-traffic",
            ])

    def test_cleanup_uses_saved_state_without_new_test_configuration(self):
        for workflow in ("recovery", "tenancy"):
            with mock.patch.object(automation.disaster_recovery, "cleanup_saved_run") as cleanup, \
                    mock.patch.object(automation.disaster_recovery, "automated_ssh_tofu"), \
                    mock.patch.object(automation, "command_arguments") as arguments:
                self.assertEqual(automation.main(workflow, [
                    "--cleanup", "--state", str(self.directory / "run"),
                ]), 0)
            cleanup.assert_called_once_with(self.directory / "run")
            arguments.assert_not_called()

    def test_cleanup_and_state_must_be_supplied_together(self):
        for arguments in (["--cleanup"], ["--state", str(self.directory)]):
            with mock.patch("sys.stderr"), self.assertRaises(SystemExit):
                automation.main("recovery", arguments)

    def test_cleanup_failure_returns_nonzero(self):
        with mock.patch.object(automation.disaster_recovery, "automated_ssh_tofu"), \
                mock.patch.object(automation.disaster_recovery, "cleanup_saved_run",
                                  side_effect=RuntimeError("NSR cleanup blocked")), \
                mock.patch("builtins.print"):
            self.assertEqual(automation.main("recovery", [
                "--cleanup", "--state", str(self.directory),
            ]), 1)


if __name__ == "__main__":
    unittest.main()
