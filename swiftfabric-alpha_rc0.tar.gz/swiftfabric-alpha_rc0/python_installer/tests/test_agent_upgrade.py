import json
import sys
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import agent_upgrade
import upgrade


TARGET = "1:0.2.0+5.main.abc"


def host(host_id, node, version="legacy", status="enrolled", cluster="compute"):
    return {
        "host_id": host_id, "node": node, "cluster": cluster,
        "agent_version": version, "status": status,
    }


class FakeApi:
    def __init__(self, hosts=(), routers=()):
        self.hosts = [dict(item) for item in hosts]
        self.routers = [dict(item) for item in routers]
        self.calls = []
        self.host_upgrade_error = None
        self.recovery_revision = 0
        self.recovery_records = []

    def json(self, method, path, body=None, max_time=30, allowed=()):
        self.calls.append((method, path, body))
        if path == agent_upgrade.AgentUpgradeRecoveryJournal.PATH:
            if method == "GET":
                return 200, {
                    "revision": self.recovery_revision,
                    "records": [dict(record) for record in self.recovery_records],
                }
            if method == "PUT":
                if body["expected_revision"] != self.recovery_revision:
                    return 409, {
                        "revision": self.recovery_revision,
                        "records": [dict(record) for record in self.recovery_records],
                    }
                self.recovery_revision += 1
                self.recovery_records = [dict(record) for record in body["records"]]
                return 200, {
                    "revision": self.recovery_revision,
                    "records": [dict(record) for record in self.recovery_records],
                }
        if path == "/api/v1/hosts":
            return 200, [dict(item) for item in self.hosts]
        if path == "/api/v1/north-south-routers":
            return 200, [dict(item) for item in self.routers]
        if path.endswith("/upgrade") and path.startswith("/api/v1/hosts/"):
            host_id = path.split("/")[4]
            if self.host_upgrade_error:
                raise agent_upgrade.AgentUpgradeError(self.host_upgrade_error)
            record = next(item for item in self.hosts if item["host_id"] == host_id)
            record["agent_version"] = TARGET
            return 200, dict(record)
        if path.endswith("/upgrade"):
            router_id = path.split("/")[4]
            router = next(item for item in self.routers if item["id"] == router_id)
            router.update(runtime_version=TARGET, agent_version=TARGET)
            return 200, {"upgrade_started": True}
        raise AssertionError(path)


class FakeProxmox:
    def __init__(self, placement, attached):
        self.placement = dict(placement)
        self.attached = attached
        self.migrations = []
        self.task_states = {}
        self.next_task = 0
        self.nodes = {
            "pve1": {"node": "pve1", "maxmem": 64, "mem": 10},
            "pve2": {"node": "pve2", "maxmem": 64, "mem": 40},
            "pve3": {"node": "pve3", "maxmem": 64, "mem": 5},
        }
        self.local = {}

    def online_nodes(self):
        return self.nodes

    def attached_running_vms(self, node):
        return [
            dict(vm) for vm in self.attached
            if self.placement[vm["vmid"]] == node
        ]

    def precondition(self, node, vmid, target):
        return {"local_disks": self.local.get(vmid, [])}

    def vm_location(self, vmid):
        node = self.placement.get(vmid)
        return {"vmid": vmid, "node": node, "status": "running"} if node else None

    def task_status(self, upid):
        return self.task_states.get(upid, {"status": "stopped", "exitstatus": "OK"})

    def migrate(self, vmid, source, target, with_local_disks, timeout, on_task=None):
        assert self.placement[vmid] == source
        self.next_task += 1
        upid = f"UPID:{source}:task-{self.next_task}"
        if on_task is not None:
            on_task(upid)
        self.task_states[upid] = {"status": "stopped", "exitstatus": "OK"}
        self.placement[vmid] = target
        self.migrations.append((vmid, source, target, with_local_disks))


class AgentUpgradeTests(unittest.TestCase):
    def test_flag_is_opt_in_and_guards_dependent_options(self):
        args = upgrade.parse_args(["--config", "c.json", "--token"])
        self.assertFalse(args.auto_agent_upgrade)
        args = upgrade.parse_args(
            ["--config", "c.json", "--token", "--auto-agent-upgrade", "--no-migrate-back"]
        )
        self.assertTrue(args.auto_agent_upgrade)
        self.assertTrue(args.no_migrate_back)
        for extra in (["--no-migrate-back"], ["--migrate-local-disks"],
                      ["--migration-timeout", "5"]):
            with mock.patch.object(upgrade.sys, "stderr"):
                with self.assertRaises(SystemExit):
                    upgrade.parse_args(["--config", "c.json", "--token", *extra])

    def test_package_agent_version_reads_single_payload(self):
        listing = (
            "drwxr-xr-x root/root 0 2026 ./usr/share/swiftfabric/host-agents/\n"
            f"drwxr-xr-x root/root 0 2026 ./usr/share/swiftfabric/host-agents/{TARGET}/\n"
            f"-rw-r--r-- root/root 9 2026 ./usr/share/swiftfabric/host-agents/{TARGET}/a.deb\n"
            "-rwxr-xr-x root/root 9 2026 ./usr/bin/swiftfabric-api-service\n"
        )
        result = mock.Mock(returncode=0, stdout=listing, stderr="")
        with mock.patch.object(agent_upgrade.subprocess, "run", return_value=result):
            self.assertEqual(agent_upgrade.package_agent_version("p.deb"), TARGET)
        result.stdout = listing + "-rw-r--r-- r/r 1 2026 ./usr/share/swiftfabric/host-agents/x/b\n"
        with mock.patch.object(agent_upgrade.subprocess, "run", return_value=result):
            with self.assertRaisesRegex(agent_upgrade.AgentUpgradeError, "exactly one"):
                agent_upgrade.package_agent_version("p.deb")

    def test_segment_bridges_match_controller_rules(self):
        config = {
            "net0": "virtio=aa,bridge=sf-br5000,firewall=1",
            "net1": "virtio=bb,bridge=vmbr0",
            "net2": "virtio=cc,bridge=sf-br5001,link_down=1",
            "net3": "virtio=dd,bridge=sf-br4999",
            "net4": "virtio=ee,bridge=sf-br05000",
            "net5": "virtio=ff,bridge=sf-br50000",
            "unused0": "bridge=sf-br5002",
        }
        self.assertEqual(
            agent_upgrade.segment_bridges(config), ["sf-br5000", "sf-br50000"]
        )

    def test_controller_api_passes_secrets_and_body_on_stdin(self):
        ssh = mock.Mock()
        ssh.run.return_value = '{"ok":true}\n200'
        api = agent_upgrade.ControllerApi(
            ssh, "tok\"en", lambda: {"ip_address": "192.0.2.10"}
        )
        status, body = api.json("POST", "/api/v1/hosts/h1/upgrade", {"a": "b"}, max_time=900)
        self.assertEqual((status, body), (200, {"ok": True}))
        command = ssh.run.call_args.args[1]
        stdin = ssh.run.call_args.kwargs["input_data"].decode()
        self.assertIn("http://127.0.0.1:8080/api/v1/hosts/h1/upgrade", command)
        self.assertIn("--max-time 900", command)
        self.assertNotIn("tok", command)
        self.assertIn('header = "Authorization: Bearer tok\\"en"', stdin)
        self.assertIn('request = "POST"', stdin)
        self.assertIn('data-binary = "{\\"a\\":\\"b\\"}"', stdin)

    def test_controller_api_does_not_retry_failed_posts(self):
        ssh = mock.Mock()
        ssh.run.side_effect = TimeoutError("lost")
        api = agent_upgrade.ControllerApi(ssh, "t", lambda: {"ip_address": "192.0.2.10"})
        with self.assertRaises(agent_upgrade.AgentUpgradeError):
            api.request("POST", "/api/v1/hosts/h1/upgrade")
        self.assertEqual(ssh.run.call_count, 1)

    def test_controller_api_follows_moved_vip(self):
        ssh = mock.Mock()
        ssh.run.side_effect = [
            '{"error":"API VIP is not active on this controller"}\n503',
            "[]\n200",
        ]
        owners = iter([{"ip_address": "192.0.2.10"}, {"ip_address": "192.0.2.11"}])
        api = agent_upgrade.ControllerApi(ssh, "t", lambda: next(owners))
        with mock.patch.object(agent_upgrade.time, "sleep"):
            self.assertEqual(api.json("GET", "/api/v1/hosts"), (200, []))
        self.assertEqual(ssh.run.call_args.args[0], "192.0.2.11")

    def test_plan_collects_every_blocker_before_changes(self):
        api = FakeApi(
            hosts=[
                host("h1", "pve1"),
                host("h2", "pve2", status="failed"),
                host("h3", "other", cluster="remote"),
                host("h4", "pve3", version=TARGET),
            ],
            routers=[
                {"id": "r1", "name": "edge", "status": "active", "vmid": 300,
                 "runtime_version": "legacy", "agent_version": "legacy",
                 "pending_configuration": {"x": 1}},
                {"id": "r2", "name": "ha", "status": "active", "vmid": 301,
                 "ha_state_sync_enabled": True, "ha_replication_mode": "edge-local",
                 "member_runtime_versions": {"a": "old", "b": "old"}},
            ],
        )
        proxmox = FakeProxmox({101: "pve1"}, [{"vmid": 101, "name": "vm", "mem": 1, "bridges": ["sf-br5000"]}])
        proxmox.local[101] = [{"volid": "local-lvm:vm-101-disk-0"}]
        with self.assertRaises(agent_upgrade.AgentUpgradeError) as failure:
            agent_upgrade.build_plan(
                api, proxmox, TARGET, "compute", agent_upgrade.AgentUpgradeOptions()
            )
        message = str(failure.exception)
        self.assertIn("--migrate-local-disks", message)
        self.assertIn("status 'failed'", message)
        self.assertIn("cluster 'remote'", message)
        self.assertIn("pending configuration", message)
        self.assertIn("restore paired replication", message)
        self.assertFalse([call for call in api.calls if call[0] != "GET"])

    def test_preflight_rejects_zero_and_aggregate_insufficient_capacity(self):
        api = FakeApi(hosts=[
            host("h1", "pve1"), host("h2", "pve2", version=TARGET),
        ])
        cases = [
            (
                {"maxmem": 8, "mem": 8},
                [{"vmid": 101, "name": "a", "mem": 4, "bridges": ["sf-br5000"]}],
            ),
            (
                {"maxmem": 10, "mem": 4},
                [
                    {"vmid": 101, "name": "a", "mem": 4, "bridges": ["sf-br5000"]},
                    {"vmid": 102, "name": "b", "mem": 4, "bridges": ["sf-br5001"]},
                ],
            ),
        ]
        for capacity, workloads in cases:
            with self.subTest(capacity=capacity, workloads=len(workloads)):
                proxmox = FakeProxmox(
                    {vm["vmid"]: "pve1" for vm in workloads}, workloads
                )
                proxmox.nodes["pve2"].update(capacity)
                proxmox.nodes["pve3"]["status"] = "offline"
                with self.assertRaisesRegex(
                    agent_upgrade.AgentUpgradeError,
                    "No enrolled host has capacity",
                ):
                    agent_upgrade.build_plan(
                        api, proxmox, TARGET, "compute",
                        agent_upgrade.AgentUpgradeOptions(),
                    )

    def test_preflight_accepts_aggregate_capacity_that_fits_all_workloads(self):
        api = FakeApi(hosts=[
            host("h1", "pve1"), host("h2", "pve2", version=TARGET),
        ])
        workloads = [
            {"vmid": 101, "name": "a", "mem": 4, "bridges": ["sf-br5000"]},
            {"vmid": 102, "name": "b", "mem": 4, "bridges": ["sf-br5001"]},
        ]
        proxmox = FakeProxmox({101: "pve1", 102: "pve1"}, workloads)
        proxmox.nodes["pve2"].update(maxmem=12, mem=4)
        proxmox.nodes["pve3"]["status"] = "offline"
        plan = agent_upgrade.build_plan(
            api, proxmox, TARGET, "compute", agent_upgrade.AgentUpgradeOptions()
        )
        self.assertEqual(len(plan.hosts), 1)

    def test_plan_selects_rolling_upgrade_for_synchronized_pairs(self):
        api = FakeApi(routers=[
            {"id": "r1", "name": "edge", "status": "active", "vmid": 300,
             "runtime_version": TARGET, "agent_version": "old"},
            {"id": "r2", "name": "ha", "status": "active", "vmid": 301,
             "ha_state_sync_enabled": True, "ha_replication_mode": "paired",
             "agent_version": "old",
             "member_runtime_versions": {"a": TARGET, "b": "old"}},
            {"id": "r3", "name": "done", "status": "active", "vmid": 302,
             "ha_state_sync_enabled": True, "agent_version": "old",
             "member_runtime_versions": {"a": TARGET, "b": TARGET}},
        ])
        plan = agent_upgrade.build_plan(
            api, FakeProxmox({}, []), TARGET, "compute", agent_upgrade.AgentUpgradeOptions()
        )
        self.assertEqual(
            [(router.router_id, router.method) for router in plan.routers],
            [("r1", "in-place"), ("r2", "rolling HA")],
        )

    def test_controller_only_change_upgrades_routers_not_compute_agents(self):
        runtime_target = "1:0.2.0+controller"
        api = FakeApi(
            hosts=[host("h1", "pve1", version=TARGET)],
            routers=[
                {"id": "r1", "status": "active", "vmid": 300,
                 "runtime_version": "old-controller", "agent_version": TARGET},
                {"id": "r2", "status": "active", "vmid": 301,
                 "ha_state_sync_enabled": True, "agent_version": TARGET,
                 "member_runtime_versions": {"a": "old-controller", "b": "old-controller"}},
                {"id": "r3", "status": "active", "vmid": 302,
                 "runtime_version": runtime_target, "agent_version": TARGET},
            ],
        )
        plan = agent_upgrade.build_plan(
            api, FakeProxmox({}, []), TARGET, "compute",
            agent_upgrade.AgentUpgradeOptions(), runtime_target=runtime_target,
        )
        self.assertEqual(plan.hosts, [])
        self.assertEqual(plan.target_runtime_version, runtime_target)
        self.assertEqual(
            [(router.router_id, router.method) for router in plan.routers],
            [("r1", "in-place"), ("r2", "rolling HA")],
        )

    def test_router_completion_checks_independent_runtime_and_agent_targets(self):
        router = {
            "runtime_version": "controller-target",
            "agent_version": TARGET,
        }
        self.assertFalse(agent_upgrade._router_needs_upgrade(
            router, TARGET, "controller-target"
        ))
        self.assertTrue(agent_upgrade._router_needs_upgrade(
            router, TARGET, "next-controller"
        ))
        router.update(
            ha_state_sync_enabled=True,
            member_runtime_versions={"a": "controller-target", "b": "controller-target"},
        )
        self.assertFalse(agent_upgrade._router_needs_upgrade(
            router, TARGET, "controller-target"
        ))
        router["member_runtime_versions"]["b"] = "old-controller"
        self.assertTrue(agent_upgrade._router_needs_upgrade(
            router, TARGET, "controller-target"
        ))

    def test_runtime_target_reaches_rolling_upgrade(self):
        api = FakeApi(routers=[{
            "id": "ha", "status": "active", "vmid": 301,
            "ha_state_sync_enabled": True, "agent_version": TARGET,
            "member_runtime_versions": {"a": "old", "b": "old"},
        }])
        with mock.patch.object(agent_upgrade, "upgrade_router_rolling") as rolling:
            agent_upgrade.run_agent_upgrades(
                api, FakeProxmox({}, []), "compute", TARGET,
                agent_upgrade.AgentUpgradeOptions(), runtime_target="controller-target",
            )
        self.assertEqual(rolling.call_args.args[2], "controller-target")

    def test_host_upgrade_evacuates_to_most_free_host_and_returns(self):
        api = FakeApi(hosts=[host("h1", "pve1"), host("h2", "pve2"), host("h3", "pve3")])
        proxmox = FakeProxmox(
            {101: "pve1", 102: "pve1", 103: "pve2"},
            [
                {"vmid": 101, "name": "a", "mem": 4, "bridges": ["sf-br5000"]},
                {"vmid": 102, "name": "b", "mem": 4, "bridges": ["sf-br5001"]},
                {"vmid": 103, "name": "c", "mem": 4, "bridges": ["sf-br5000"]},
            ],
        )
        plan = agent_upgrade.HostPlan("h1", "pve1", "compute", "legacy")
        agent_upgrade.upgrade_host(
            api, proxmox, plan, TARGET, agent_upgrade.AgentUpgradeOptions()
        )
        self.assertEqual(proxmox.migrations[:2], [
            (101, "pve1", "pve3", False), (102, "pve1", "pve3", False),
        ])
        self.assertEqual(proxmox.placement, {101: "pve1", 102: "pve1", 103: "pve2"})
        self.assertEqual(api.hosts[0]["agent_version"], TARGET)
        upgrade_calls = [call for call in api.calls if call[0] == "POST"]
        self.assertEqual(upgrade_calls, [("POST", "/api/v1/hosts/h1/upgrade", None)])

    def test_refreshed_memory_does_not_double_count_completed_migrations(self):
        api = FakeApi(hosts=[host("h1", "pve1"), host("h2", "pve2")])
        workloads = [
            {"vmid": 101, "name": "a", "mem": 4, "bridges": ["sf-br5000"]},
            {"vmid": 102, "name": "b", "mem": 4, "bridges": ["sf-br5001"]},
        ]
        proxmox = FakeProxmox({101: "pve1", 102: "pve1"}, workloads)
        proxmox.nodes["pve2"].update(maxmem=12, mem=4)
        proxmox.nodes["pve3"]["status"] = "offline"
        migrate = proxmox.migrate

        def migrate_with_memory_update(vmid, source, target, local_disks, timeout, on_task=None):
            migrate(vmid, source, target, local_disks, timeout, on_task=on_task)
            memory = next(vm["mem"] for vm in workloads if vm["vmid"] == vmid)
            proxmox.nodes[source]["mem"] -= memory
            proxmox.nodes[target]["mem"] += memory

        proxmox.migrate = migrate_with_memory_update
        agent_upgrade.upgrade_host(
            api, proxmox, agent_upgrade.HostPlan("h1", "pve1", "compute", "legacy"),
            TARGET, agent_upgrade.AgentUpgradeOptions(),
        )
        self.assertEqual(proxmox.placement, {101: "pve1", 102: "pve1"})

    def test_host_upgrade_can_leave_workloads_evacuated(self):
        api = FakeApi(hosts=[host("h1", "pve1"), host("h2", "pve2")])
        proxmox = FakeProxmox({101: "pve1"}, [{"vmid": 101, "name": "a", "mem": 4, "bridges": ["sf-br5000"]}])
        agent_upgrade.upgrade_host(
            api, proxmox, agent_upgrade.HostPlan("h1", "pve1", "compute", "legacy"),
            TARGET, agent_upgrade.AgentUpgradeOptions(migrate_back=False),
        )
        self.assertEqual(proxmox.placement, {101: "pve2"})

    def test_failed_host_upgrade_returns_workloads_and_reports(self):
        api = FakeApi(hosts=[host("h1", "pve1"), host("h2", "pve2")])
        api.host_upgrade_error = "rolled back"
        proxmox = FakeProxmox({101: "pve1"}, [{"vmid": 101, "name": "a", "mem": 4, "bridges": ["sf-br5000"]}])
        with self.assertRaisesRegex(agent_upgrade.AgentUpgradeError, "rolled back"):
            agent_upgrade.upgrade_host(
                api, proxmox, agent_upgrade.HostPlan("h1", "pve1", "compute", "legacy"),
                TARGET, agent_upgrade.AgentUpgradeOptions(),
            )
        self.assertEqual(proxmox.placement, {101: "pve1"})

    def test_move_then_timeout_reconciles_placement_and_returns_vm(self):
        api = FakeApi(hosts=[host("h1", "pve1"), host("h2", "pve2")])
        proxmox = FakeProxmox(
            {101: "pve1"},
            [{"vmid": 101, "name": "a", "mem": 4, "bridges": ["sf-br5000"]}],
        )
        migrate = proxmox.migrate
        first = True

        def move_then_timeout(vmid, source, target, local_disks, timeout, on_task=None):
            nonlocal first
            if first:
                first = False
                upid = "UPID:pve1:ambiguous"
                if on_task is not None:
                    on_task(upid)
                proxmox.placement[vmid] = target
                proxmox.task_states[upid] = {"status": "stopped", "exitstatus": "OK"}
                raise TimeoutError("task watcher timed out after move")
            return migrate(vmid, source, target, local_disks, timeout, on_task=on_task)

        proxmox.migrate = move_then_timeout
        with self.assertRaisesRegex(agent_upgrade.AgentUpgradeError, "task watcher timed out"):
            agent_upgrade.upgrade_host(
                api, proxmox, agent_upgrade.HostPlan("h1", "pve1", "compute", "legacy"),
                TARGET, agent_upgrade.AgentUpgradeOptions(),
            )
        self.assertEqual(proxmox.placement, {101: "pve1"})
        self.assertEqual(
            proxmox.migrations,
            [(101, "pve2", "pve1", False)],
        )

    def test_active_original_migration_is_not_returned_during_recovery(self):
        api = FakeApi(hosts=[host("h1", "pve1"), host("h2", "pve2")])
        proxmox = FakeProxmox(
            {101: "pve1"},
            [{"vmid": 101, "name": "a", "mem": 4, "bridges": ["sf-br5000"]}],
        )

        def move_then_timeout(vmid, source, target, _local_disks, _timeout, on_task=None):
            upid = "UPID:pve1:still-running"
            if on_task is not None:
                on_task(upid)
            proxmox.placement[vmid] = target
            proxmox.task_states[upid] = {"status": "running"}
            raise TimeoutError("task watcher timed out")

        proxmox.migrate = move_then_timeout
        with self.assertRaisesRegex(
            agent_upgrade.AgentUpgradeError,
            "original migration task UPID:pve1:still-running is not confirmed stopped",
        ):
            agent_upgrade.upgrade_host(
                api, proxmox, agent_upgrade.HostPlan("h1", "pve1", "compute", "legacy"),
                TARGET, agent_upgrade.AgentUpgradeOptions(),
            )
        self.assertEqual(proxmox.placement, {101: "pve2"})
        self.assertEqual(proxmox.migrations, [])

    def test_rerun_resumes_failed_return_from_controller_journal(self):
        api = FakeApi(hosts=[
            host("h1", "pve1"), host("h2", "pve2", version=TARGET),
        ])
        proxmox = FakeProxmox(
            {101: "pve1"},
            [{"vmid": 101, "name": "a", "mem": 4, "bridges": ["sf-br5000"]}],
        )
        recovery = agent_upgrade.AgentUpgradeRecoveryJournal(api)
        migrate = proxmox.migrate
        fail_return = True

        def fail_first_return(vmid, source, target, local_disks, timeout, on_task=None):
            nonlocal fail_return
            if source == "pve2" and fail_return:
                fail_return = False
                upid = "UPID:pve2:return-retry"
                if on_task is not None:
                    on_task(upid)
                proxmox.task_states[upid] = {"status": "stopped", "exitstatus": "ERROR"}
                raise RuntimeError("temporary return failure")
            return migrate(vmid, source, target, local_disks, timeout, on_task=on_task)

        proxmox.migrate = fail_first_return
        with self.assertRaisesRegex(agent_upgrade.AgentUpgradeError, "temporary return failure"):
            agent_upgrade.upgrade_host(
                api, proxmox, agent_upgrade.HostPlan("h1", "pve1", "compute", "legacy"),
                TARGET, agent_upgrade.AgentUpgradeOptions(), recovery,
            )
        self.assertEqual(proxmox.placement, {101: "pve2"})
        self.assertEqual(api.recovery_records[0]["phase"], "returning")

        completed = agent_upgrade.run_agent_upgrades(
            api, proxmox, "compute", TARGET, agent_upgrade.AgentUpgradeOptions()
        )
        self.assertEqual(completed, [])
        self.assertEqual(proxmox.placement, {101: "pve1"})
        self.assertEqual(api.recovery_records, [])

    def test_rerun_preserves_intentional_no_migrate_back(self):
        api = FakeApi(hosts=[
            host("h1", "pve1"), host("h2", "pve2", version=TARGET),
        ])
        proxmox = FakeProxmox(
            {101: "pve1"},
            [{"vmid": 101, "name": "a", "mem": 4, "bridges": ["sf-br5000"]}],
        )
        recovery = agent_upgrade.AgentUpgradeRecoveryJournal(api)
        agent_upgrade.upgrade_host(
            api, proxmox, agent_upgrade.HostPlan("h1", "pve1", "compute", "legacy"),
            TARGET, agent_upgrade.AgentUpgradeOptions(migrate_back=False), recovery,
        )
        self.assertEqual(api.recovery_records[0]["phase"], "no_return")
        agent_upgrade.run_agent_upgrades(
            api, proxmox, "compute", TARGET, agent_upgrade.AgentUpgradeOptions()
        )
        self.assertEqual(proxmox.placement, {101: "pve2"})
        self.assertEqual(api.recovery_records[0]["phase"], "no_return")

    def test_failed_host_left_failed_keeps_workloads_evacuated(self):
        api = FakeApi(hosts=[host("h1", "pve1"), host("h2", "pve2")])
        api.host_upgrade_error = "rollback failed"

        original = api.json

        def json_with_failed_host(method, path, *args, **kwargs):
            result = original(method, path, *args, **kwargs)
            return result

        def fail_host(*args, **kwargs):
            api.hosts[0]["status"] = "failed"
            raise agent_upgrade.AgentUpgradeError("rollback failed")

        proxmox = FakeProxmox({101: "pve1"}, [{"vmid": 101, "name": "a", "mem": 4, "bridges": ["sf-br5000"]}])
        with mock.patch.object(api, "json", side_effect=lambda m, p, *a, **k: (
            fail_host() if m == "POST" else json_with_failed_host(m, p, *a, **k)
        )):
            with self.assertRaisesRegex(agent_upgrade.AgentUpgradeError, "a \\(101\\) on pve2"):
                agent_upgrade.upgrade_host(
                    api, proxmox, agent_upgrade.HostPlan("h1", "pve1", "compute", "legacy"),
                    TARGET, agent_upgrade.AgentUpgradeOptions(),
                )
        self.assertEqual(proxmox.placement, {101: "pve2"})

    def test_in_place_router_upgrade_polls_until_finished(self):
        api = FakeApi(routers=[{"id": "r1", "name": "edge", "status": "active",
                                "runtime_version": "old", "agent_version": "old"}])
        with mock.patch.object(agent_upgrade.time, "sleep"):
            agent_upgrade.upgrade_router_in_place(
                api, agent_upgrade.RouterPlan("r1", "edge", "in-place", "old"), TARGET
            )
        self.assertIn(("POST", "/api/v1/north-south-routers/r1/upgrade", None), api.calls)

    def test_in_place_router_upgrade_accepts_independent_runtime_target(self):
        api = FakeApi(routers=[{
            "id": "r1", "name": "edge", "status": "active",
            "runtime_version": "old", "agent_version": TARGET,
        }])
        original = api.json

        def upgrade_runtime(method, path, *args, **kwargs):
            result = original(method, path, *args, **kwargs)
            if method == "POST":
                api.routers[0]["runtime_version"] = "controller-target"
            return result

        with mock.patch.object(api, "json", side_effect=upgrade_runtime), \
                mock.patch.object(agent_upgrade.time, "sleep"):
            agent_upgrade.upgrade_router_in_place(
                api, agent_upgrade.RouterPlan("r1", "edge", "in-place", "old"),
                TARGET, runtime_target="controller-target",
            )
        self.assertIn(("POST", "/api/v1/north-south-routers/r1/upgrade", None), api.calls)

    def test_in_place_router_upgrade_reports_rollback(self):
        api = FakeApi(routers=[{"id": "r1", "name": "edge", "status": "active",
                                "runtime_version": "old", "agent_version": "old"}])

        def no_upgrade(method, path, *args, **kwargs):
            if method == "POST":
                api.routers[0]["status_message"] = "restored previous software"
                return 200, {}
            return FakeApi.json(api, method, path, *args, **kwargs)

        with mock.patch.object(api, "json", side_effect=no_upgrade), \
                mock.patch.object(agent_upgrade.time, "sleep"):
            with self.assertRaisesRegex(agent_upgrade.AgentUpgradeError, "restored previous"):
                agent_upgrade.upgrade_router_in_place(
                    api, agent_upgrade.RouterPlan("r1", "edge", "in-place", "old"), TARGET
                )

    def test_rolling_upgrade_resumes_pending_identity(self):
        api = mock.Mock()
        api.json.return_value = (200, {
            "available_version": TARGET, "generation": 9,
            "pending": {"source_generation": 7, "target_version": TARGET},
        })
        api.request.return_value = (200, json.dumps({"completed": True}))
        agent_upgrade.upgrade_router_rolling(
            api, agent_upgrade.RouterPlan("r2", "ha", "rolling HA", "old"), TARGET
        )
        self.assertEqual(
            api.request.call_args.args[2],
            {"source_generation": 7, "target_version": TARGET},
        )

    def test_rolling_upgrade_starts_from_current_generation(self):
        api = mock.Mock()
        api.json.side_effect = [
            (200, {"available_version": TARGET, "generation": 4, "pending": None}),
            (200, [{"id": "r2", "ha_state_sync_enabled": True,
                    "member_runtime_versions": {"a": "old", "b": "old"}}]),
        ]
        api.request.return_value = (200, json.dumps({"completed": True}))
        agent_upgrade.upgrade_router_rolling(
            api, agent_upgrade.RouterPlan("r2", "ha", "rolling HA", "old"), TARGET
        )
        self.assertEqual(
            api.request.call_args.args[2],
            {"source_generation": 4, "target_version": TARGET},
        )


class RunUpgradeWiringTests(unittest.TestCase):
    def _run(self, auto):
        events = []
        controllers = [{"name": "c0", "ip_address": "192.0.2.10"}]
        patches = [
            mock.patch.object(upgrade, "load_deployment_config",
                              return_value={"controller_priv_key": "k",
                                            "proxmox_cluster_name": "compute"}),
            mock.patch.object(upgrade, "_controller_vip", return_value="192.0.2.20"),
            mock.patch.object(upgrade, "_deployment_from_config",
                              return_value=mock.Mock(client="pve-client")),
            mock.patch.object(upgrade, "_build_upgrade_plan", return_value=controllers),
            mock.patch.object(upgrade.ApiServiceDeployment, "find_package",
                              return_value=Path("p.deb")),
            mock.patch.object(upgrade, "_package_metadata", return_value="2"),
            mock.patch.object(upgrade, "SSHCommandRunner"),
            mock.patch.object(upgrade, "_api_vip_owner", return_value=controllers[0]),
            mock.patch.object(upgrade, "_verify_api_access_over_ssh",
                              return_value=({}, False)),
            mock.patch.object(upgrade, "_preflight_controller", return_value="1"),
            mock.patch.object(upgrade, "_show_plan"),
            mock.patch.object(upgrade.ApiServiceDeployment, "_provision_tls",
                              return_value=b"ca"),
            mock.patch.object(upgrade, "_upgrade_controllers",
                              side_effect=lambda *a, **k: events.append("controllers")),
            mock.patch.object(agent_upgrade, "package_agent_version", return_value=TARGET),
            mock.patch.object(agent_upgrade, "build_plan",
                              side_effect=lambda *a, **k: events.append("preflight")
                              or agent_upgrade.AgentUpgradePlan(TARGET)),
            mock.patch.object(agent_upgrade, "run_agent_upgrades",
                              side_effect=lambda *a, **k: events.append("agents") or []),
        ]
        for patcher in patches:
            patcher.start()
            self.addCleanup(patcher.stop)
        upgrade.run_upgrade("c.json", "token", yes=True, auto_agent_upgrade=auto)
        if auto:
            self.assertEqual(agent_upgrade.build_plan.call_args.kwargs["runtime_target"], "2")
            self.assertEqual(
                agent_upgrade.run_agent_upgrades.call_args.kwargs["runtime_target"], "2"
            )
        return events

    def test_default_upgrade_leaves_agents_manual(self):
        self.assertEqual(self._run(False), ["controllers"])

    def test_auto_agent_upgrade_preflights_before_controllers(self):
        self.assertEqual(self._run(True), ["preflight", "controllers", "agents"])


if __name__ == "__main__":
    unittest.main()
