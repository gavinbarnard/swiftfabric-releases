import importlib.util
import os
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location(
    "integration_target_common",
    ROOT / "python_installer/tests_integration/integration_common.py",
)
common = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(common)


class TargetSafetyTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        (self.directory / "key").touch()
        self.config = {
            "proxmox_cluster_ip": "192.0.2.1",
            "proxmox_user": "root@pam",
            "proxmox_tokenname": "test",
            "proxmox_apikey": "test-key",
            "proxmox_ssh_user": "root",
            "proxmox_ssh_key": "key",
            "mgmt_ip_range_start": "192.0.2.10",
            "mgmt_ip_range_end": "192.0.2.13",
        }
        self.nodes = [
            {"node": "compute1", "status": "online"},
            {"node": "compute2", "status": "online"},
        ]
        self.resources = []
        self.vm_config = {}
        self.client = mock.Mock()
        self.client.get.side_effect = self.get
        self.runner = mock.Mock(return_value=subprocess.CompletedProcess(
            [], 0, stdout="SWIFTFABRIC_TARGET_CHECK_COMPLETE\n", stderr="",
        ))

    def get(self, endpoint):
        if endpoint == "/nodes":
            return {"data": self.nodes}
        if endpoint == "/cluster/resources":
            return {"data": self.resources}
        return {"data": self.vm_config}

    def test_forget_stale_controller_host_keys_covers_controllers_and_vip(self):
        ssh_runner = mock.Mock()
        ssh_runner.forget_host_keys.return_value = ["192.0.2.10"]
        with mock.patch("sys.stderr"):
            removed = common.forget_stale_controller_host_keys(
                self.config, ssh_runner=ssh_runner,
            )
        self.assertEqual(removed, ["192.0.2.10"])
        ssh_runner.forget_host_keys.assert_called_once_with(
            ["192.0.2.10", "192.0.2.11", "192.0.2.12", "192.0.2.13"]
        )

    def test_forget_stale_controller_host_keys_reports_failure(self):
        ssh_runner = mock.Mock()
        ssh_runner.forget_host_keys.side_effect = common.SSHHostKeyError("locked")
        with self.assertRaisesRegex(ValueError, "stale controller SSH host keys"):
            common.forget_stale_controller_host_keys(self.config, ssh_runner=ssh_runner)

    def check(self):
        common.require_empty_target(
            self.config, self.directory, client=self.client, runner=self.runner,
        )

    def vm(self, name):
        self.resources = [{"type": "qemu", "node": "compute1", "vmid": 100, "name": name}]

    def test_empty_cluster_checks_every_host_and_relative_key(self):
        self.vm("unrelated-guest")
        self.check()
        self.assertEqual(self.runner.call_count, 2)
        commands = [call.args[0] for call in self.runner.call_args_list]
        self.assertEqual([command[-2] for command in commands],
                         ["root@compute1", "root@compute2"])
        self.assertEqual(commands[0][2], str(self.directory / "key"))
        self.assertIn("dpkg-query", commands[0][-1])
        self.assertIn("/etc/swiftfabric", commands[0][-1])
        self.assertIn("/var/lib/swiftfabric", commands[0][-1])

    def test_existing_controller_names_block_even_when_stopped_or_other_prefix(self):
        for name in ("swiftfabric-controller-1", "sf-it-old-swiftfabric-controller-2",
                     "controller-3", "lab-controller-1"):
            with self.subTest(name=name):
                self.vm(name)
                self.resources[0]["status"] = "stopped"
                with self.assertRaisesRegex(ValueError, "no SwiftFabric installation active"):
                    self.check()
        self.runner.assert_not_called()

    def test_custom_controller_name_detected_by_vendor_data(self):
        self.vm("custom-control-plane")
        self.vm_config = {"cicustom": "vendor=local:snippets/swiftfabric-vm-100-vendor.yaml"}
        with self.assertRaisesRegex(ValueError, "Existing SwiftFabric deployment"):
            self.check()
        self.runner.assert_not_called()

    def test_occupied_controller_or_vip_address_blocks(self):
        self.vm("unrelated-guest")
        for address in ("192.0.2.10", "192.0.2.11", "192.0.2.12", "192.0.2.13"):
            with self.subTest(address=address):
                self.vm_config = {"ipconfig0": f"ip={address}/24,gw=192.0.2.1"}
                with self.assertRaisesRegex(ValueError, "already uses test management address"):
                    self.check()
        self.runner.assert_not_called()

    def test_host_installation_enrollment_and_incomplete_checks_block(self):
        for output in ("existing SwiftFabric configuration or state\n",
                       "swiftfabric-host-agent installed\nSWIFTFABRIC_TARGET_CHECK_COMPLETE\n",
                       "swiftfabric-host-agent unpacked\nSWIFTFABRIC_TARGET_CHECK_COMPLETE\n",
                       ""):
            with self.subTest(output=output):
                self.runner.return_value.stdout = output
                with self.assertRaises(ValueError) as failure:
                    self.check()
                self.assertIn("no enrolled hosts", str(failure.exception))
                if output:
                    self.assertIn("Remote check output", str(failure.exception))

    def test_ssh_failure_and_timeout_block(self):
        self.runner.return_value.returncode = 255
        with self.assertRaisesRegex(ValueError, "Cannot inspect Proxmox host"):
            self.check()
        self.runner.side_effect = subprocess.TimeoutExpired("ssh", 60)
        with self.assertRaisesRegex(ValueError, "no SwiftFabric installation active"):
            self.check()

    def test_offline_or_missing_nodes_block(self):
        for nodes in ([], [{"node": "compute1", "status": "offline"}], [{}]):
            with self.subTest(nodes=nodes):
                self.nodes = nodes
                with self.assertRaisesRegex(ValueError, "Target safety check failed"):
                    self.check()
        self.runner.assert_not_called()

    def test_api_failure_and_malformed_inventory_block(self):
        from proxmox.client import ProxmoxAPIError

        self.client.get.side_effect = ProxmoxAPIError("permission denied", 403)
        with self.assertRaisesRegex(ValueError, "no SwiftFabric installation active"):
            self.check()
        for response in ({}, {"data": {}}, {"data": [None]}):
            with self.subTest(response=response):
                self.client.get.side_effect = None
                self.client.get.return_value = response
                with self.assertRaisesRegex(ValueError, "Invalid Proxmox inventory"):
                    self.check()
        self.runner.assert_not_called()

    def test_non_root_check_requires_noninteractive_sudo(self):
        self.config["proxmox_ssh_user"] = "operator"
        self.check()
        self.assertTrue(self.runner.call_args.args[0][-1].startswith("sudo -n sh -c "))

    def test_root_side_inventory_detects_hidden_vms_and_missing_inventory(self):
        self.check()
        command = self.runner.call_args.args[0][-1]
        script = shlex.split(command.split("python3 -c ", 1)[1])[0]
        inventory = self.directory / "nodes"
        guest_dir = inventory / "compute1" / "qemu-server"
        guest_dir.mkdir(parents=True)
        (inventory / "compute2").mkdir()
        path = guest_dir / "100.conf"
        script = script.replace("'/etc/pve/nodes'", repr(str(inventory)))
        for config in (
            "name: other-prefix-controller-1\n",
            "name: renamed\ncicustom: vendor=local:snippets/swiftfabric-vm-100-vendor.yaml\n",
            "name: renamed\nipconfig0: ip=192.0.2.13/24\n",
        ):
            with self.subTest(config=config):
                path.write_text(config, encoding="utf-8")
                result = subprocess.run(
                    [sys.executable, "-c", script],
                    capture_output=True, text=True, check=True,
                )
                self.assertIn("existing deployment", result.stdout)
        path.write_text("name: unrelated\nipconfig0: ip=198.51.100.1/24\n", encoding="utf-8")
        result = subprocess.run(
            [sys.executable, "-c", script],
            capture_output=True, text=True, check=True,
        )
        self.assertEqual(result.stdout.strip(), "SWIFTFABRIC_TARGET_CHECK_COMPLETE")
        result = subprocess.run(
            [sys.executable, "-c", script.replace(str(inventory), str(inventory / "missing"))],
            capture_output=True, text=True, check=False,
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn("SWIFTFABRIC_TARGET_CHECK_COMPLETE", result.stdout)
        (inventory / "hidden-compute").mkdir()
        result = subprocess.run(
            [sys.executable, "-c", script],
            capture_output=True, text=True, check=False,
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("node inventory is incomplete", result.stderr)

    def test_remote_shell_rejects_packages_state_and_failed_package_inspection(self):
        self.check()
        command = self.runner.call_args.args[0][-1]
        inventory = self.directory / "nodes"
        inventory.mkdir()
        for node in self.nodes:
            (inventory / node["node"]).mkdir()
        command = command.replace("/etc/pve/nodes", str(inventory))
        command = command.replace("/etc/swiftfabric", str(self.directory / "config"))
        command = command.replace("/var/lib/swiftfabric", str(self.directory / "state"))
        dpkg = self.directory / "dpkg-query"
        env = {**os.environ, "PATH": f"{self.directory}:{os.defpath}"}
        for output, status, safe in (
            ("unrelated installed", 0, True),
            ("swiftfabric-host-agent installed", 0, False),
            ("swiftfabric-host-agent half-configured", 0, False),
            ("swiftfabric-api-service installed", 0, False),
            ("", 2, False),
        ):
            with self.subTest(output=output, status=status):
                dpkg.write_text(
                    f"#!/bin/sh\nprintf '%s\\n' {shlex.quote(output)}\nexit {status}\n",
                    encoding="utf-8",
                )
                dpkg.chmod(0o700)
                result = subprocess.run(
                    ["sh", "-c", command], env=env,
                    capture_output=True, text=True, check=False,
                )
                self.assertEqual(
                    result.returncode == 0
                    and result.stdout.strip() == "SWIFTFABRIC_TARGET_CHECK_COMPLETE",
                    safe,
                )
        (self.directory / "state").mkdir()
        result = subprocess.run(
            ["sh", "-c", command], env=env,
            capture_output=True, text=True, check=False,
        )
        self.assertIn("existing SwiftFabric configuration or state", result.stdout)
        self.assertIn(str(self.directory / "state"), result.stdout)
        self.assertNotIn("SWIFTFABRIC_TARGET_CHECK_COMPLETE", result.stdout)

    def test_missing_key_or_invalid_config_blocks(self):
        for field, value in (("proxmox_ssh_key", "missing"),
                             ("mgmt_ip_range_start", "invalid"),
                             ("proxmox_ssh_user", "-invalid"),
                             ("proxmox_apikey", "")):
            with self.subTest(field=field):
                original = self.config[field]
                self.config[field] = value
                with self.assertRaisesRegex(ValueError, "no SwiftFabric installation active"):
                    self.check()
                self.config[field] = original
        self.runner.assert_not_called()


if __name__ == "__main__":
    unittest.main()
