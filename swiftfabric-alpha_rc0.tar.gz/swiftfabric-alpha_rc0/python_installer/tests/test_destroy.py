import hashlib
import io
import os
import shlex
import subprocess
import sys
import tempfile
import tarfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import main as installer_main
from deployment.api_service import ApiServiceDeployment
from deployment import api_service


class DestroyTests(unittest.TestCase):
    def _run_ca_provision_script(self, command, directory, expiration_days):
        directory.mkdir()
        key_path = directory / "ca.key"
        certificate_path = directory / "ca.crt"
        subprocess.run(
            [
                "openssl", "genpkey", "-algorithm", "RSA",
                "-pkeyopt", "rsa_keygen_bits:2048", "-out", str(key_path),
            ],
            check=True,
            capture_output=True,
        )
        subprocess.run(
            [
                "openssl", "req", "-x509", "-new", "-key", str(key_path),
                "-sha256", "-days", str(expiration_days),
                "-subj", "/CN=SwiftFabric Deployment CA",
                "-addext", "basicConstraints=critical,CA:TRUE,pathlen:0",
                "-addext", "keyUsage=critical,keyCertSign,cRLSign",
                "-addext", "subjectKeyIdentifier=hash", "-out",
                str(certificate_path),
            ],
            check=True,
            capture_output=True,
        )
        key_path.chmod(0o600)
        original_fingerprint = subprocess.run(
            ["openssl", "x509", "-in", str(certificate_path),
             "-noout", "-fingerprint", "-sha256"],
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()

        script = shlex.split(command)[-1]
        script = script.replace(
            "/var/lib/swiftfabric/ca",
            str(directory),
        )
        script = script.replace(
            "install -d -o root -g root -m 0700",
            "install -d -m 0700",
        )
        script = script.replace(
            "install -o root -g root -m 0644",
            "install -m 0644",
        )
        script = script.replace(
            f"test \"$(stat -c '%u:%a' {directory / 'ca.key'})\" = '0:600'",
            f"test -s {directory / 'ca.key'}",
        )
        result = subprocess.run(
            ["bash", "-eu", "-c", script],
            check=False,
            capture_output=True,
            text=True,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        active_fingerprint = subprocess.run(
            ["openssl", "x509", "-in", str(certificate_path),
             "-noout", "-fingerprint", "-sha256"],
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()
        archives = tuple((directory / "trust-anchors").glob("*.crt"))
        return original_fingerprint, active_fingerprint, archives

    def test_destroy_accepts_dash_prefixed_tokens_and_preserves_flags(self):
        for token in ("-synthetic-token", "-" + "a" * 63, "--" + "b" * 62):
            for form in (["--token", token], [f"--token={token}"]):
                with self.subTest(token=token, form=form), mock.patch.object(
                    sys, "argv", ["install.py", "--destroy", *form, "--auto-unenroll", "--yes"],
                ):
                    args = installer_main.parse_args()
                    self.assertEqual(args.token, token)
                    self.assertTrue(args.auto_unenroll)
                    self.assertTrue(args.yes)
        with mock.patch.object(
            sys, "argv", ["install.py", "--destroy", "--token", "--auto-unenroll", "--yes"],
        ):
            self.assertEqual(installer_main.parse_args().token, "")

    def _run_vip_monitor(self, systemctl_script):
        agent = (
            Path(__file__).resolve().parents[2]
            / "controller-api"
            / "segment-manager"
            / "packaging"
            / "ocf"
            / "resource.d"
            / "swiftfabric"
            / "segment-manager-vip"
        )
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            bin_dir = root / "bin"
            bin_dir.mkdir()
            ip_command = bin_dir / "ip"
            ip_command.write_text(
                "#!/bin/sh\n"
                "case \"$*\" in\n"
                "  '-o -4 address show'|'-o -4 address show dev eth0') "
                "printf '%s\\n' '2: eth0 inet 192.0.2.13/24 scope global eth0' ;;\n"
                "  '-o -4 route get 192.0.2.13') "
                "printf '%s\\n' '192.0.2.13 dev eth0 src 192.0.2.10' ;;\n"
                "  *) exit 1 ;;\n"
                "esac\n"
            )
            ip_command.chmod(0o755)
            systemctl_command = bin_dir / "systemctl"
            systemctl_command.write_text(systemctl_script)
            systemctl_command.chmod(0o755)
            sleep_command = bin_dir / "sleep"
            sleep_command.write_text("#!/bin/sh\nexit 0\n")
            sleep_command.chmod(0o755)
            result = subprocess.run(
                [str(agent), "monitor"],
                env={
                    **os.environ,
                    "PATH": f"{bin_dir}:{os.environ['PATH']}",
                    "STATE_FILE": str(root / "systemctl-state"),
                    "OCF_ROOT": str(root / "ocf"),
                    "OCF_RESKEY_ip": "192.0.2.13",
                    "OCF_RESKEY_cidr_netmask": "24",
                    "OCF_RESKEY_gateway": "192.0.2.1",
                },
                capture_output=True,
                text=True,
                check=False,
            )

        return result

    def test_vip_monitor_tolerates_brief_api_service_restart(self):
        result = self._run_vip_monitor(
            "#!/bin/sh\n"
            "if [ ! -e \"$STATE_FILE\" ]; then "
            "touch \"$STATE_FILE\"; exit 3; fi\n"
            "exit 0\n"
        )

        self.assertEqual(result.returncode, 0, result.stderr)

    def test_vip_monitor_fails_if_api_service_stays_down(self):
        result = self._run_vip_monitor("#!/bin/sh\nexit 3\n")

        self.assertEqual(result.returncode, 7, result.stderr)

    def test_controller_tls_listener_and_firewall_are_loopback_only_upstream(self):
        nginx = ApiServiceDeployment._render_nginx_config()
        firewall = ApiServiceDeployment._render_firewall(
            ["192.0.2.10", "192.0.2.11", "192.0.2.12"]
        )

        self.assertIn("listen 443 ssl default_server;", nginx)
        self.assertNotIn("listen 80", nginx)
        self.assertIn("ssl_protocols TLSv1.2 TLSv1.3;", nginx)
        self.assertIn("proxy_pass http://127.0.0.1:8080;", nginx)
        self.assertIn("proxy_set_header X-Forwarded-For $remote_addr;", nginx)
        self.assertNotIn("$proxy_add_x_forwarded_for", nginx)
        self.assertIn("proxy_set_header X-Forwarded-Proto https;", nginx)
        self.assertIn("tcp dport 443 accept", firewall)
        self.assertIn("tcp dport 80 drop", firewall)
        self.assertIn("tcp dport 8080 drop", firewall)

    def test_nginx_service_waits_for_api_upstream_with_bounded_retries(self):
        override = ApiServiceDeployment._render_nginx_service_override()
        self.assertIn("TimeoutStartSec=120", override)
        self.assertIn("--retry 40 --retry-delay 2 --retry-connrefused", override)
        self.assertIn("--retry-max-time 100", override)
        self.assertIn("http://127.0.0.1:8080/api/v1/health", override)

    def test_tls_provisioning_validates_rooted_ca_and_leaf_key_state(self):
        deployment = ApiServiceDeployment.__new__(ApiServiceDeployment)
        deployment.ssh = mock.Mock()
        deployment.console = mock.Mock()
        fingerprint = "A" * 64

        def ssh_result(_address, command, **_kwargs):
            if command.startswith("sudo bash -eu -c"):
                return ""
            if command == "sudo cat " + api_service.CA_CERTIFICATE_PATH:
                return "public-ca-certificate"
            if command == "sudo cat " + api_service.CA_KEY_PATH:
                return "private-ca-key"
            if command == "sudo cat " + api_service.CA_SERIAL_PATH:
                return "03\n"
            if "-fingerprint -sha256" in command:
                return "sha256 Fingerprint=" + ":".join(
                    fingerprint[index:index + 2]
                    for index in range(0, len(fingerprint), 2)
                )
            if command.startswith("if sudo test -s " + api_service.CA_CERTIFICATE_PATH):
                return "SHA256 Fingerprint=" + ":".join(
                    fingerprint[index:index + 2]
                    for index in range(0, len(fingerprint), 2)
                )
            if command.startswith("if ! sudo test -s " + api_service.CA_KEY_PATH):
                return "valid"
            if command.startswith("if sudo test -s " + api_service.CA_SERIAL_PATH):
                return "present" if _address == "192.0.2.10" else "missing"
            if command.startswith("if sudo test -s " + api_service.SERVER_CERTIFICATE_PATH):
                return "valid"
            return ""

        deployment.ssh.run.side_effect = ssh_result
        ca_certificate = deployment._provision_tls(
            ["192.0.2.10", "192.0.2.11", "192.0.2.12"], "192.0.2.13"
        )

        self.assertEqual(ca_certificate, b"public-ca-certificate")
        self.assertEqual(
            deployment._ca_trust_bundle,
            b"public-ca-certificate",
        )
        first_command = deployment.ssh.run.call_args_list[0].args[1]
        syntax = subprocess.run(
            ["bash", "-n", "-c", first_command],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(syntax.returncode, 0, syntax.stderr)
        ca_state_script = shlex.split(first_command)[-1]
        self.assertIn("stat -c '%u:%a'", ca_state_script)
        self.assertIn("CA:TRUE", ca_state_script)
        self.assertIn("keyCertSign", ca_state_script)
        self.assertIn("-checkend 2592000", ca_state_script)
        self.assertIn("old_archive=", first_command)
        self.assertIn(api_service.CA_TRUST_ARCHIVE_DIR, first_command)
        self.assertIn("mv -f " + api_service.CA_KEY_PATH + ".new", first_command)
        self.assertTrue(
            any(
                "chmod 0600 " + api_service.CA_KEY_PATH in call.args[1]
                for call in deployment.ssh.run.call_args_list
            )
        )
        serial_installs = [
            call
            for call in deployment.ssh.run.call_args_list
            if api_service.CA_SERIAL_PATH in call.args[1]
            and call.args[1].startswith("sudo install -D")
        ]
        self.assertEqual(
            [call.args[0] for call in serial_installs],
            ["192.0.2.11", "192.0.2.12"],
        )
        self.assertTrue(
            all(call.kwargs["input_data"] == b"03\n" for call in serial_installs)
        )
        self.assertTrue(
            any(
                "swiftfabric-deployment-ca-"
                + hashlib.sha256(ca_certificate).hexdigest()
                in call.args[1]
                for call in deployment.ssh.run.call_args_list
            )
        )
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            expiring = self._run_ca_provision_script(
                first_command, root / "expiring", 20
            )
            current = self._run_ca_provision_script(
                first_command, root / "current", 40
            )
        self.assertNotEqual(expiring[0], expiring[1])
        self.assertEqual(len(expiring[2]), 1)
        self.assertEqual(current[0], current[1])
        self.assertEqual(current[2], ())

    def test_api_service_controller_addresses_must_be_ipv4(self):
        with self.assertRaisesRegex(ValueError, "valid IPv4"):
            ApiServiceDeployment._get_nodes(
                object(),
                [
                    {"ip_address": "controller-1"},
                    {"ip_address": "192.0.2.11"},
                    {"ip_address": "192.0.2.12"},
                ],
            )

    def test_api_build_archive_includes_all_rust_modules(self):
        deployment = ApiServiceDeployment(private_key="")
        source_files = ApiServiceDeployment._source_files(
            deployment.project_root / "controller-api" / "segment-manager"
        )
        archived_paths = {arcname for _, arcname in source_files}
        self.assertIn("segment-manager/src/main.rs", archived_paths)
        self.assertIn("segment-manager/src/hosts.rs", archived_paths)
        self.assertIn("segment-manager/src/users.rs", archived_paths)
        self.assertIn("segment-manager/src/tenants.rs", archived_paths)
        self.assertIn("segment-manager/src/backup.rs", archived_paths)
        package_source = deployment.project_root / "controller-api" / "segment-manager"
        for source in (package_source / "src").rglob("*.rs"):
            self.assertIn(
                f"segment-manager/{source.relative_to(package_source)}", archived_paths,
            )
        self.assertIn(
            "segment-manager/host-agent/packaging/swiftfabric-neighbors.service",
            archived_paths,
        )
        self.assertIn(
            "segment-manager/host-agent/swiftfabric_host/neighbors.py", archived_paths,
        )
        fingerprint = (deployment.project_root / "build-host-agent.sh").read_text(encoding="ascii")
        self.assertIn("host-agent/packaging/swiftfabric-neighbors.service", fingerprint)

    def test_controller_build_uses_independent_host_agent_version(self):
        deployment = ApiServiceDeployment(private_key="")
        buildbox = {
            "buildbox_ip": "192.0.2.10",
            "buildbox_username": "builder",
            "buildbox_key": "/tmp/buildbox-key",
        }
        with mock.patch.object(
            deployment, "_load_buildbox_config", return_value=buildbox
        ), mock.patch(
            "deployment.api_service.SSHCommandRunner"
        ) as ssh_runner, mock.patch.object(
            deployment, "_copy_from_buildbox"
        ), mock.patch.dict(os.environ, {
            "SWIFTFABRIC_SOURCE_DATE_EPOCH": "1234567890",
            "SWIFTFABRIC_AGENT_VERSION": "1:0.1.0+agent",
        }):
            ssh_runner.return_value.run.side_effect = [
                "", "/tmp/swiftfabric-api-service_controller_amd64.deb", "",
            ]
            deployment._build_on_buildbox("1:0.1.0+controller")
        self.addCleanup(deployment._package_tempdir.cleanup)
        command = ssh_runner.return_value.run.call_args_list[1].args[1]
        self.assertIn("1:0.1.0+controller 1:0.1.0+agent 1234567890", command)

    def test_api_build_manifest_includes_router_state_modules(self):
        package_source = Path(__file__).resolve().parents[2] / "controller-api" / "segment-manager"
        archived = dict(
            (arcname, source) for source, arcname in
            ApiServiceDeployment._source_files(package_source)
        )
        for name in ("router_runtime.py", "router_state_sync.py", "router_packet_gate.py"):
            self.assertEqual(archived[f"segment-manager/{name}"], package_source / name)

    def test_host_agent_build_uses_buildbox_and_retrieves_package(self):
        with tempfile.TemporaryDirectory() as directory:
            output_dir = Path(directory)
            deployment = ApiServiceDeployment(private_key="")
            buildbox = {
                "buildbox_ip": "192.0.2.10",
                "buildbox_username": "builder",
                "buildbox_key": "/tmp/buildbox-key",
            }
            with mock.patch.object(
                deployment, "_load_buildbox_config", return_value=buildbox
            ), mock.patch(
                "deployment.api_service.SSHCommandRunner"
            ) as ssh_runner, mock.patch.object(
                deployment, "_copy_from_buildbox"
            ) as copy_from_buildbox, mock.patch.dict(
                "os.environ", {"SWIFTFABRIC_SOURCE_DATE_EPOCH": "1234567890"}
            ):
                package = deployment.build_host_agent(
                    output_dir, "fingerprint", "0.1.0"
                )

        self.assertEqual(
            package.name,
            "swiftfabric-host-agent_0.1.0_all.deb",
        )
        ssh = ssh_runner.return_value
        with tarfile.open(fileobj=io.BytesIO(ssh.run.call_args_list[0].kwargs["input_data"]), mode="r:gz") as archive:
            self.assertIn("host-agent/packaging/swiftfabric-neighbors.service", archive.getnames())
            self.assertIn("host-agent/swiftfabric_host/neighbors.py", archive.getnames())
        build_command = ssh.run.call_args_list[1].args[1]
        self.assertIn("bash ", build_command)
        self.assertIn("/host-agent/build-deb.sh ", build_command)
        self.assertIn("1234567890", build_command)
        self.assertEqual(copy_from_buildbox.call_args.args[0].rsplit("/", 1)[-1], package.name)
        self.assertEqual(copy_from_buildbox.call_args.args[1], package)

    def test_auto_unenroll_is_destroy_only(self):
        with mock.patch.object(sys, "argv", ["install.py", "--auto-unenroll"]):
            with self.assertRaises(SystemExit) as failure:
                installer_main.parse_args()
        self.assertEqual(failure.exception.code, 2)

    def test_token_is_destroy_only_and_can_be_prompted(self):
        with mock.patch.object(sys, "argv", ["install.py", "--token", "secret"]):
            with self.assertRaises(SystemExit) as failure:
                installer_main.parse_args()
        self.assertEqual(failure.exception.code, 2)

        with mock.patch.object(
            sys, "argv", ["install.py", "--destroy", "--token"]
        ):
            self.assertEqual(installer_main.parse_args().token, "")
        with mock.patch.object(
            sys, "argv", ["install.py", "--destroy", "--token", "token-value"]
        ):
            self.assertEqual(installer_main.parse_args().token, "token-value")

        with mock.patch.object(
            installer_main.sys, "stdin", mock.Mock(isatty=lambda: True)
        ), mock.patch.object(
            installer_main.getpass, "getpass", return_value=" prompted-token "
        ) as prompt:
            self.assertEqual(installer_main._resolve_api_token(""), "prompted-token")
        prompt.assert_called_once_with("Controller API bearer token: ")

    def test_token_prompt_requires_a_terminal(self):
        with mock.patch.object(
            installer_main.sys, "stdin", mock.Mock(isatty=lambda: False)
        ):
            with self.assertRaisesRegex(RuntimeError, "interactive terminal"):
                installer_main._resolve_api_token("")

    def test_destroy_forgets_host_keys_only_after_verified_deletion(self):
        deployment = mock.Mock()
        plan = {"matches": [
            {"name": "c-0", "node": "n1", "vmid": 100},
            {"name": "c-1", "node": "n2", "vmid": 101},
        ]}
        events = []
        deployment.destroy_controllers.side_effect = lambda _m: (
            events.append("destroy") or {"deleted": ["c-0", "c-1"], "verified": ["c-0", "c-1"]}
        )
        addresses = {"c-0": "192.0.2.10", "c-1": "192.0.2.11"}
        with mock.patch.object(
            installer_main, "_controller_vm_ip",
            side_effect=lambda _d, vm: addresses[vm["name"]],
        ), mock.patch.object(
            installer_main, "_forget_destroyed_host_keys",
            side_effect=lambda ips: events.append(("forget", ips)),
        ):
            installer_main._destroy_confirmed(deployment, plan, None, "192.0.2.13")

        self.assertEqual(
            events,
            ["destroy", ("forget", ["192.0.2.10", "192.0.2.11", "192.0.2.13"])],
        )

    def test_failed_destroy_keeps_host_keys(self):
        deployment = mock.Mock()
        deployment.destroy_controllers.side_effect = RuntimeError("still present")
        plan = {"matches": [{"name": "c-0", "node": "n1", "vmid": 100}]}
        with mock.patch.object(
            installer_main, "_controller_vm_ip", return_value="192.0.2.10"
        ), mock.patch.object(installer_main, "_forget_destroyed_host_keys") as forget:
            with self.assertRaises(RuntimeError):
                installer_main._destroy_confirmed(deployment, plan, None, "192.0.2.13")
        forget.assert_not_called()

    def test_interactive_destroy_passes_proxmox_ssh_settings_from_config(self):
        config = {
            "deploy_api": "proxmox",
            "proxmox_cluster_ip": "192.0.2.1",
            "proxmox_port": 8006,
            "proxmox_user": "root@pam",
            "proxmox_tokenname": "swiftinstaller",
            "proxmox_apikey": "synthetic-api-key",
            "proxmox_ssh_user": "operator",
            "proxmox_ssh_key": "/tmp/proxmox-key",
        }
        deployment = mock.Mock()
        deployment.find_controllers_to_destroy.return_value = {
            "matches": [],
            "not_found": [],
        }
        with mock.patch.object(installer_main, "show_banner"), mock.patch.object(
            installer_main, "load_deployment_config", return_value=config
        ), mock.patch.object(
            installer_main, "_deployment_from_config", return_value=deployment
        ) as create_deployment, mock.patch.object(
            installer_main, "_print_destroy_plan"
        ):
            installer_main.interactive_destroy(config_path="config.json")

        self.assertEqual(
            create_deployment.call_args.args[0],
            {
                "deploy_api": "proxmox",
                "proxmox_cluster_ip": "192.0.2.1",
                "proxmox_port": 8006,
                "proxmox_user": "root@pam",
                "proxmox_tokenname": "swiftinstaller",
                "proxmox_apikey": "synthetic-api-key",
                "proxmox_ssh_user": "operator",
                "proxmox_ssh_key": "/tmp/proxmox-key",
            },
        )

    def test_interactive_destroy_without_config_prompts_for_proxmox_ssh(self):
        config_form = mock.Mock()
        config_form.config = {
            "proxmox_cluster_ip": "192.0.2.1",
            "proxmox_port": 8006,
            "proxmox_user": "root@pam",
            "proxmox_tokenname": "swiftinstaller",
            "proxmox_apikey": "synthetic-api-key",
            "proxmox_ssh_user": "operator",
            "proxmox_ssh_key": "/tmp/proxmox-key",
        }
        deployment = mock.Mock()
        deployment.find_controllers_to_destroy.return_value = {
            "matches": [],
            "not_found": [],
        }
        with mock.patch.object(installer_main, "show_banner"), mock.patch.object(
            installer_main, "ConfigForm", return_value=config_form
        ), mock.patch.object(
            installer_main, "_deployment_from_config", return_value=deployment
        ) as create_deployment, mock.patch.object(
            installer_main, "_print_destroy_plan"
        ):
            installer_main.interactive_destroy()

        config_form.collect_proxmox_config.assert_called_once_with()
        self.assertEqual(
            create_deployment.call_args.args[0]["proxmox_ssh_user"],
            "operator",
        )
        self.assertEqual(
            create_deployment.call_args.args[0]["proxmox_ssh_key"],
            "/tmp/proxmox-key",
        )

    def test_destroy_refuses_registered_hosts_without_auto_unenroll(self):
        deployment = mock.Mock()
        plan = {"matches": [{"name": "swiftfabric-controller-1"}]}
        management = ("https://192.0.2.13", "token", None)
        with mock.patch.object(installer_main, "_controller_api_access", return_value=management), \
                mock.patch.object(
                    installer_main, "_controller_api_request",
                    return_value={"is_admin": True},
                ), \
                mock.patch.object(
                    installer_main,
                    "_controller_enrollment_state",
                    return_value=([{"name": "pve-lab"}], [{"host_id": "pve-lab-node1"}]),
                ):
            with self.assertRaisesRegex(RuntimeError, "Destroy refused"):
                installer_main._prepare_controller_cleanup(
                    deployment, plan, "/tmp/controller-key", False
                )

    def test_destroy_requires_active_admin_identity_before_inventory(self):
        management = ("https://192.0.2.13", "replacement-key", "/tmp/ca.crt")
        for auto_unenroll in (False, True):
            with self.subTest(auto_unenroll=auto_unenroll), mock.patch.object(
                installer_main, "_controller_api_access", return_value=management
            ), mock.patch.object(
                installer_main, "_controller_api_request", return_value={"is_admin": True}
            ) as request, mock.patch.object(
                installer_main, "_controller_enrollment_state", return_value=([], [])
            ) as inventory:
                result = installer_main._prepare_controller_cleanup(
                    mock.Mock(), {"matches": []}, "/tmp/controller-key", auto_unenroll
                )
                request.assert_called_once_with(management, "GET", "/api/v1/system/me")
                inventory.assert_called_once_with(management)
                self.assertEqual(result, management if auto_unenroll else None)

    def test_destroy_rejects_non_admin_or_invalid_identity_without_inventory(self):
        for identity in ({"is_admin": False}, {"is_admin": 1}, {}, [], None):
            with self.subTest(identity=identity), mock.patch.object(
                installer_main, "_controller_api_access",
                return_value=("https://192.0.2.13", "key", "/tmp/ca.crt"),
            ), mock.patch.object(
                installer_main, "_controller_api_request", return_value=identity
            ), mock.patch.object(installer_main, "_controller_enrollment_state") as inventory:
                with self.assertRaisesRegex(RuntimeError, "active admin API key"):
                    installer_main._prepare_controller_cleanup(
                        mock.Mock(), {"matches": []}, "/tmp/controller-key", False
                    )
                inventory.assert_not_called()

    def test_destroy_rejects_revoked_deployment_key_before_inventory_or_cleanup(self):
        response = mock.Mock(status_code=401)
        response.raise_for_status.side_effect = installer_main.requests.HTTPError(
            "401 Unauthorized", response=response
        )
        for auto_unenroll in (False, True):
            with self.subTest(auto_unenroll=auto_unenroll), mock.patch.object(
                installer_main, "_controller_api_access",
                return_value=("https://192.0.2.13", "revoked-key", "/tmp/ca.crt"),
            ), mock.patch.object(
                installer_main.requests, "request", return_value=response
            ) as request, mock.patch.object(
                installer_main, "_controller_enrollment_state", return_value=([], [])
            ) as inventory:
                with self.assertRaisesRegex(RuntimeError, "system/me"):
                    installer_main._prepare_controller_cleanup(
                        mock.Mock(), {"matches": []}, "/tmp/controller-key", auto_unenroll
                    )
                self.assertEqual(request.call_args.args[1], "https://192.0.2.13/api/v1/system/me")
                inventory.assert_not_called()

    def test_confirmed_destroy_never_deletes_vms_when_admin_authentication_fails(self):
        deployment = mock.Mock()
        deployment.find_controllers_to_destroy.return_value = {"matches": [{"name": "controller-0"}]}
        with mock.patch.object(
            installer_main, "load_deployment_config", return_value={"controller_priv_key": "/tmp/key"}
        ), mock.patch.object(
            installer_main, "_deployment_from_config", return_value=deployment
        ), mock.patch.object(
            installer_main, "_controller_vip", return_value="192.0.2.13"
        ), mock.patch.object(
            installer_main, "_print_destroy_plan"
        ), mock.patch.object(
            installer_main, "_controller_api_access",
            return_value=("https://192.0.2.13", "revoked-key", "/tmp/ca.crt"),
        ), mock.patch.object(
            installer_main, "_controller_api_request",
            side_effect=RuntimeError("401 Unauthorized: /api/v1/system/me"),
        ), mock.patch.object(installer_main, "_auto_unenroll") as cleanup:
            with self.assertRaisesRegex(RuntimeError, "401 Unauthorized"):
                installer_main.non_interactive_destroy(
                    "/tmp/config.json", assume_yes=True, auto_unenroll=True,
                    api_token="revoked-key",
                )
        deployment.destroy_controllers.assert_not_called()
        cleanup.assert_not_called()

    def test_controller_api_access_uses_configured_vip_for_zero_based_vm_names(self):
        deployment = mock.Mock()
        plan = {
            "matches": [{
                "name": "swiftfabric-controller-0",
                "node": "pve1",
                "vmid": 100,
                "status": "running",
            }]
        }
        with tempfile.TemporaryDirectory() as ca_dir, mock.patch(
            "deployment.ssh.SSHCommandRunner"
        ) as ssh_runner, mock.patch.object(
            installer_main, "_controller_vm_ip", return_value="192.0.2.10"
        ) as controller_ip, mock.patch.object(
            installer_main.ssl, "create_default_context"
        ) as create_context:
            ssh_runner.return_value.run.side_effect = [
                "token",
                "-----BEGIN CERTIFICATE-----\npublic-ca\n-----END CERTIFICATE-----",
            ]
            result = installer_main._controller_api_access(
                deployment, plan, "/tmp/controller-key", "192.0.2.13",
                ca_dir=ca_dir,
            )
            written_ca = Path(ca_dir, "swiftfabric-ca.crt").read_text()

        self.assertEqual(
            result,
            (
                "https://192.0.2.13",
                "token",
                str(Path(ca_dir) / "swiftfabric-ca.crt"),
            ),
        )
        self.assertEqual(
            written_ca,
            "-----BEGIN CERTIFICATE-----\npublic-ca\n-----END CERTIFICATE-----\n",
        )
        self.assertEqual(
            [call.args[1] for call in ssh_runner.return_value.run.call_args_list],
            [
                "sudo cat /etc/swiftfabric/segment-manager.token",
                "sudo cat /etc/swiftfabric/swiftfabric-ca.crt",
            ],
        )
        create_context.assert_called_once()
        controller_ip.assert_called_once_with(deployment, plan["matches"][0])

    def test_controller_api_access_uses_explicit_ca_without_ssh(self):
        deployment = mock.Mock()
        plan = {
            "matches": [{
                "name": "swiftfabric-controller-0",
                "node": "pve1",
                "vmid": 100,
                "status": "running",
            }]
        }
        with mock.patch(
            "deployment.ssh.SSHCommandRunner"
        ) as ssh_runner, mock.patch.object(
            installer_main, "_controller_vm_ip", return_value="192.0.2.10"
        ) as controller_ip:
            ssh_runner.return_value.run.return_value = "token"
            result = installer_main._controller_api_access(
                deployment, plan, "/tmp/controller-key", "192.0.2.13",
                "api-token", "/tmp/controller-ca.crt",
            )

        self.assertEqual(
            result,
            ("https://192.0.2.13", "api-token", "/tmp/controller-ca.crt"),
        )
        ssh_runner.assert_not_called()
        controller_ip.assert_not_called()

    def test_controller_api_access_fetches_ca_with_explicit_token(self):
        deployment = mock.Mock()
        plan = {
            "matches": [{
                "name": "swiftfabric-controller-0",
                "node": "pve1",
                "vmid": 100,
                "status": "running",
            }]
        }
        with tempfile.TemporaryDirectory() as ca_dir, mock.patch(
            "deployment.ssh.SSHCommandRunner"
        ) as ssh_runner, mock.patch.object(
            installer_main, "_controller_vm_ip", return_value="192.0.2.10"
        ) as controller_ip, mock.patch.object(
            installer_main.ssl, "create_default_context"
        ):
            ssh_runner.return_value.run.return_value = (
                "-----BEGIN CERTIFICATE-----\npublic-ca\n-----END CERTIFICATE-----"
            )
            result = installer_main._controller_api_access(
                deployment,
                plan,
                "/tmp/controller-key",
                "192.0.2.13",
                "api-token",
                ca_dir=ca_dir,
            )

        self.assertEqual(
            result,
            (
                "https://192.0.2.13",
                "api-token",
                str(Path(ca_dir) / "swiftfabric-ca.crt"),
            ),
        )
        ssh_runner.return_value.run.assert_called_once_with(
            "192.0.2.10",
            "sudo cat /etc/swiftfabric/swiftfabric-ca.crt",
            timeout=15,
        )
        controller_ip.assert_called_once_with(deployment, plan["matches"][0])

    def test_api_vip_fallback_supports_zero_based_controller_names(self):
        deployment = mock.Mock()
        controllers = [
            {
                "name": f"swiftfabric-controller-{index}",
                "node": "pve1",
                "vmid": 100 + index,
                "status": "running" if index == 0 else "stopped",
            }
            for index in range(3)
        ]
        with tempfile.TemporaryDirectory() as ca_dir, mock.patch.object(
            installer_main,
            "_controller_vm_ip",
            side_effect=["192.0.2.10", "192.0.2.11", "192.0.2.12", "192.0.2.10"],
        ), mock.patch(
            "deployment.ssh.SSHCommandRunner"
        ) as ssh_runner, mock.patch.object(
            installer_main.ssl, "create_default_context"
        ):
            ssh_runner.return_value.run.side_effect = [
                "token",
                "-----BEGIN CERTIFICATE-----\npublic-ca\n-----END CERTIFICATE-----",
            ]
            result = installer_main._controller_api_access(
                deployment, {"matches": controllers}, "/tmp/controller-key",
                ca_dir=ca_dir,
            )

        self.assertEqual(result[:2], ("https://192.0.2.13", "token"))

    def test_controller_api_request_uses_ca_bundle_for_verified_https(self):
        response = mock.Mock(status_code=200, content=b"[]")
        response.json.return_value = []
        management = (
            "https://192.0.2.13",
            "token",
            "/tmp/session/swiftfabric-ca.crt",
        )
        with mock.patch.object(
            installer_main.requests, "request", return_value=response
        ) as request:
            result = installer_main._controller_api_request(
                management, "GET", "/api/v1/hosts"
            )
            installer_main._controller_api_request(
                management,
                "POST",
                "/api/v1/proxmox/clusters/cluster/cleanup",
                json_body={"enrolled_only": True},
            )

        self.assertEqual(result, [])
        self.assertEqual(
            request.call_args.kwargs["verify"],
            "/tmp/session/swiftfabric-ca.crt",
        )
        self.assertEqual(
            request.call_args.kwargs["json"],
            {"enrolled_only": True},
        )

    def test_auto_unenroll_cleans_before_removing_cluster(self):
        management = ("https://192.0.2.13", "token", None)
        with mock.patch.object(
            installer_main,
            "_controller_enrollment_state",
            side_effect=[
                ([{"name": "pve lab"}], [{"host_id": "pve-node1"}]),
                ([], []),
            ],
        ), mock.patch.object(
            installer_main,
            "_controller_api_request",
            side_effect=[
                {"results": [{"node": "node1", "result": "cleaned", "message": ""}]},
                None,
            ],
        ) as request:
            installer_main._auto_unenroll(management)

        self.assertEqual(
            request.call_args_list,
            [
                mock.call(
                    management,
                    "POST",
                    "/api/v1/proxmox/clusters/pve%20lab/cleanup",
                    json_body={"enrolled_only": True},
                ),
                mock.call(
                    management,
                    "DELETE",
                    "/api/v1/proxmox/clusters/pve%20lab",
                ),
            ],
        )

    def test_auto_unenroll_keeps_controller_vms_when_node_cleanup_is_incomplete(self):
        management = ("https://192.0.2.13", "token", None)
        with mock.patch.object(
            installer_main,
            "_controller_enrollment_state",
            return_value=([{"name": "pve-lab"}], [{"host_id": "pve-node1"}]),
        ), mock.patch.object(
            installer_main,
            "_controller_api_request",
            return_value={"results": [{"node": "node1", "result": "skipped", "message": "offline"}]},
        ) as request:
            with self.assertRaisesRegex(RuntimeError, "controller VMs were not destroyed"):
                installer_main._auto_unenroll(management)

        self.assertEqual(request.call_count, 1)
        self.assertEqual(request.call_args.args[1], "POST")


if __name__ == "__main__":
    unittest.main()
