import json
import ssl
import subprocess
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from unittest import mock

import requests

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from deployment import proxmox_ca
from proxmox.client import ProxmoxAPIError, ProxmoxClient


class ProxmoxTlsTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.ca_cert, self.ca_key = self._create_ca("expected")
        self.other_ca_cert, _ = self._create_ca("other")
        self.server_cert, self.server_key = self._create_server_certificate()

    def _create_ca(self, name):
        cert = self.directory / f"{name}-ca.pem"
        key = self.directory / f"{name}-ca.key"
        subprocess.run(
            [
                "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
                "-keyout", str(key), "-out", str(cert), "-days", "2",
                "-subj", f"/CN={name} Proxmox CA",
                "-addext", "basicConstraints=critical,CA:TRUE,pathlen:0",
                "-addext", "keyUsage=critical,keyCertSign,cRLSign",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        return cert, key

    def _create_server_certificate(self):
        key = self.directory / "server.key"
        request = self.directory / "server.csr"
        cert = self.directory / "server.pem"
        extensions = self.directory / "server.ext"
        extensions.write_text(
            "basicConstraints=critical,CA:FALSE\n"
            "keyUsage=critical,digitalSignature,keyEncipherment\n"
            "extendedKeyUsage=serverAuth\n"
            "subjectAltName=IP:127.0.0.1\n",
            encoding="ascii",
        )
        subprocess.run(
            [
                "openssl", "req", "-new", "-newkey", "rsa:2048", "-nodes",
                "-keyout", str(key), "-out", str(request), "-subj", "/CN=localhost",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        subprocess.run(
            [
                "openssl", "x509", "-req", "-in", str(request),
                "-CA", str(self.ca_cert), "-CAkey", str(self.ca_key),
                "-CAcreateserial", "-out", str(cert), "-days", "2",
                "-extfile", str(extensions),
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        return cert, key

    def _start_server(self):
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                body = json.dumps({"data": {"version": "test"}}).encode("ascii")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *_):
                pass

        server = HTTPServer(("127.0.0.1", 0), Handler)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(str(self.server_cert), str(self.server_key))
        server.socket = context.wrap_socket(server.socket, server_side=True)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.shutdown)
        self.addCleanup(server.server_close)
        self.addCleanup(thread.join, 2)
        return server

    def _client(self, host, port, ca_path):
        client = ProxmoxClient(
            host,
            port,
            token_name="test",
            api_key="test-key",
            verify_ssl=ca_path,
        )
        client.session.trust_env = False
        self.addCleanup(client.session.close)
        return client

    def test_api_uses_supplied_root_and_preserves_hostname_checks(self):
        server = self._start_server()
        client = self._client("127.0.0.1", server.server_port, str(self.ca_cert))
        self.assertEqual(client.get("/version")["data"]["version"], "test")

        wrong_ca_client = self._client(
            "127.0.0.1",
            server.server_port,
            str(self.other_ca_cert),
        )
        with self.assertRaises(ProxmoxAPIError) as wrong_chain:
            wrong_ca_client.get("/version")
        self.assertIsInstance(wrong_chain.exception.__cause__, requests.exceptions.SSLError)

        wrong_hostname_client = self._client(
            "localhost",
            server.server_port,
            str(self.ca_cert),
        )
        with self.assertRaises(ProxmoxAPIError) as wrong_hostname:
            wrong_hostname_client.get("/version")
        self.assertIsInstance(
            wrong_hostname.exception.__cause__,
            requests.exceptions.SSLError,
        )

    def test_tls_verification_cannot_be_disabled(self):
        with self.assertRaisesRegex(ValueError, "cannot be disabled"):
            ProxmoxClient("proxmox.example", verify_ssl=False)
        self.assertTrue(ProxmoxClient("proxmox.example").session.verify)

    def test_ca_bootstrap_checks_fingerprints_on_every_online_node(self):
        certificate = self.ca_cert.read_text(encoding="ascii")
        with mock.patch.object(proxmox_ca, "SSHCommandRunner") as runner_type:
            ssh = runner_type.return_value
            ssh.run.return_value = certificate
            trust = proxmox_ca.ProxmoxCATrust(
                "192.0.2.1",
                "root",
                "/keys/proxmox",
            )
            self.addCleanup(trust.close)
            client = mock.Mock()
            client.get_nodes.return_value = {
                "data": [
                    {"node": "pve1", "status": "online"},
                    {"node": "pve2", "status": "offline"},
                    {"node": "pve3", "status": "online"},
                ],
            }

            trust.verify_cluster_nodes(client)

        self.assertEqual(
            [call.args[0] for call in ssh.run.call_args_list],
            ["192.0.2.1", "pve1", "pve3"],
        )

    def test_ca_bootstrap_rejects_mismatched_online_node(self):
        expected = self.ca_cert.read_text(encoding="ascii")
        mismatched = self.other_ca_cert.read_text(encoding="ascii")
        with mock.patch.object(proxmox_ca, "SSHCommandRunner") as runner_type:
            ssh = runner_type.return_value
            ssh.run.side_effect = [expected, mismatched]
            trust = proxmox_ca.ProxmoxCATrust(
                "192.0.2.1",
                "root",
                "/keys/proxmox",
            )
            self.addCleanup(trust.close)
            client = mock.Mock()
            client.get_nodes.return_value = {
                "data": [{"node": "pve1", "status": "online"}],
            }

            with self.assertRaisesRegex(ValueError, "fingerprint mismatch on node pve1"):
                trust.verify_cluster_nodes(client)


if __name__ == "__main__":
    unittest.main()
