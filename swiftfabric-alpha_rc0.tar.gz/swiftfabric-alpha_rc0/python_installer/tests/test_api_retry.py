import unittest
from unittest import mock

import requests
from deployment import api_retry


class ApiRetryTests(unittest.TestCase):
    def test_transient_read_then_success(self):
        session = mock.Mock()
        session.request.side_effect = [
            requests.exceptions.ConnectionError("down"),
            mock.Mock(status_code=503),
            mock.Mock(status_code=200),
        ]
        with mock.patch.object(api_retry.time, "sleep") as sleep, \
                self.assertLogs("deployment.api_retry"):
            response = api_retry.request_with_retry(session, "GET", "https://controller", timeout=(5, 120))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(sleep.call_args_list, [mock.call(1), mock.call(3)])

    def test_backoff_and_window_without_count_limit(self):
        for duration in (0, 7):
            now = [0]
            waits = []
            def wait(seconds):
                waits.append(seconds)
                now[0] += seconds
            session = mock.Mock()
            def unavailable(*args, **kwargs):
                now[0] += min(duration, sum(kwargs["timeout"]))
                raise requests.exceptions.Timeout("down")
            session.request.side_effect = unavailable
            with mock.patch.object(api_retry.time, "monotonic", side_effect=lambda: now[0]), \
                    mock.patch.object(api_retry.time, "sleep", side_effect=wait), \
                    self.assertLogs("deployment.api_retry"), self.assertRaises((requests.exceptions.Timeout, TimeoutError)):
                api_retry.request_with_retry(session, "GET", "https://controller", timeout=(5, 120))
            self.assertEqual(waits[:8], [1, 3, 5, 10, 20, 40, 60, 60])
            self.assertEqual(now[0], 1800)
            self.assertTrue(all(delay <= 60 for delay in waits))
            if duration == 0:
                self.assertGreater(session.request.call_count, 31)

    def test_success_after_more_than_thirty_retries(self):
        now = [0]
        def wait(seconds):
            now[0] += seconds
        session = mock.Mock()
        session.request.side_effect = [requests.exceptions.Timeout("down")] * 32 + [mock.Mock(status_code=200)]
        with mock.patch.object(api_retry.time, "monotonic", side_effect=lambda: now[0]), \
                mock.patch.object(api_retry.time, "sleep", side_effect=wait), \
                self.assertLogs("deployment.api_retry"):
            response = api_retry.request_with_retry(session, "GET", "https://controller", timeout=(5, 120))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(session.request.call_count, 33)

    def test_late_response_is_closed_and_rejected(self):
        now = [0]
        response = mock.Mock(status_code=200)
        session = mock.Mock()
        def late(*args, **kwargs):
            now[0] += 1800
            return response
        session.request.side_effect = late
        with mock.patch.object(api_retry.time, "monotonic", side_effect=lambda: now[0]), \
                self.assertRaises(TimeoutError):
            api_retry.request_with_retry(session, "GET", "https://controller", timeout=(5, 120))
        response.close.assert_called_once()

    def test_http_outage_closes_responses_and_clamps_final_wait(self):
        now = [0]
        waits = []
        timeouts = []
        response = mock.Mock(status_code=503)
        session = mock.Mock()
        def unavailable(*args, **kwargs):
            timeouts.append(kwargs["timeout"])
            return response
        def wait(seconds):
            waits.append(seconds)
            now[0] += seconds
        session.request.side_effect = unavailable
        with mock.patch.object(api_retry.time, "monotonic", side_effect=lambda: now[0]), \
                mock.patch.object(api_retry.time, "sleep", side_effect=wait), \
                self.assertLogs("deployment.api_retry"), self.assertRaises(TimeoutError):
            api_retry.request_with_retry(session, "GET", "https://controller", timeout=(5, 120))
        self.assertEqual(now[0], 1800)
        self.assertEqual(waits[-1], 41)
        self.assertLessEqual(sum(timeouts[-1]), 41)
        self.assertEqual(response.close.call_count, session.request.call_count)

    def test_connect_timeout_write_can_retry_but_http_write_cannot(self):
        session = mock.Mock()
        session.request.side_effect = [requests.exceptions.ConnectTimeout("not sent"), mock.Mock(status_code=200)]
        with mock.patch.object(api_retry.time, "sleep") as sleep, self.assertLogs("deployment.api_retry"):
            self.assertEqual(api_retry.request_with_retry(
                session, "POST", "https://controller", timeout=(5, 120),
            ).status_code, 200)
        sleep.assert_called_once_with(1)
        session.request.side_effect = None
        session.request.return_value.status_code = 503
        with mock.patch.object(api_retry.time, "sleep") as sleep:
            self.assertEqual(api_retry.request_with_retry(
                session, "POST", "https://controller", timeout=(5, 120),
            ).status_code, 503)
        sleep.assert_not_called()

    def test_no_tls_or_ambiguous_write_retry(self):
        for failure in (requests.exceptions.SSLError("untrusted"), requests.exceptions.ReadTimeout("ambiguous")):
            session = mock.Mock()
            session.request.side_effect = failure
            with mock.patch.object(api_retry.time, "sleep") as sleep, self.assertRaises(type(failure)):
                api_retry.request_with_retry(session, "POST", "https://controller", timeout=(5, 120))
            sleep.assert_not_called()
            self.assertEqual(session.request.call_count, 1)
        session = mock.Mock()
        session.request.return_value.status_code = 401
        with mock.patch.object(api_retry.time, "sleep") as sleep:
            self.assertEqual(api_retry.request_with_retry(
                session, "GET", "https://controller", timeout=(5, 120),
            ).status_code, 401)
        sleep.assert_not_called()
