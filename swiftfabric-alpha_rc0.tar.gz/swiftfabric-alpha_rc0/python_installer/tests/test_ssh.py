import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from deployment.ssh import (
    SSHCommandRunner,
    SSHHostKeyError,
    automated_tofu_for_hosts,
    integration_ssh_options,
)


class SSHCommandRunnerTests(unittest.TestCase):
    def test_integration_store_is_shared_without_affecting_normal_defaults(self):
        variables = {
            "SWIFTFABRIC_INTEGRATION_TOFU": "1",
            "SWIFTFABRIC_INTEGRATION_KNOWN_HOSTS": "/test/session-known-hosts",
        }
        with mock.patch.dict(os.environ, variables):
            runner = SSHCommandRunner(None, "ubuntu", "test")
            self.assertEqual(runner.known_hosts_file, Path("/test/session-known-hosts"))
            self.assertEqual(integration_ssh_options(), [
                "-o", "UserKnownHostsFile=/test/session-known-hosts",
                "-o", "GlobalKnownHostsFile=/dev/null",
            ])
            os.environ["SWIFTFABRIC_INTEGRATION_TOFU"] = "0"
            self.assertEqual(integration_ssh_options(), [])
            self.assertEqual(
                SSHCommandRunner(None, "ubuntu", "normal").known_hosts_file,
                Path.home() / ".ssh" / "known_hosts",
            )

    def test_changed_key_in_session_is_rejected_without_repinning(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "known_hosts"
            original = "192.0.2.10 ssh-ed25519 c3ludGhldGljLWhvc3Qta2V5\n"
            path.write_text(original)
            runner = SSHCommandRunner(None, "ubuntu", "test", str(path))
            with (
                mock.patch.dict(os.environ, {"SWIFTFABRIC_INTEGRATION_TOFU": "1"}),
                mock.patch.object(runner, "_scan_host_keys") as scan,
                mock.patch.object(runner, "forget_host_keys") as forget,
                mock.patch("deployment.ssh.subprocess.run", side_effect=[
                    mock.Mock(returncode=0, stdout="found", stderr=""),
                    mock.Mock(returncode=255, stdout="",
                              stderr="REMOTE HOST IDENTIFICATION HAS CHANGED"),
                ]),
                self.assertRaisesRegex(RuntimeError, "IDENTIFICATION HAS CHANGED"),
            ):
                runner.run("192.0.2.10", "true")
            scan.assert_not_called()
            forget.assert_not_called()
            self.assertEqual(path.read_text(), original)

    def test_integration_tofu_pins_without_terminal_or_prompt(self):
        with tempfile.TemporaryDirectory() as directory:
            known_hosts = Path(directory) / "known_hosts"
            runner = SSHCommandRunner(
                "/keys/controller", "ubuntu", "integration test",
                known_hosts_file=str(known_hosts),
            )
            key = "192.0.2.10 ssh-ed25519 c3ludGhldGljLWhvc3Qta2V5"
            with (
                mock.patch.dict(os.environ, {"SWIFTFABRIC_INTEGRATION_TOFU": "1"}),
                mock.patch.object(runner, "_host_is_pinned", return_value=False),
                mock.patch.object(runner, "_scan_host_keys", return_value=[key]),
                mock.patch("deployment.ssh.sys.stdin.isatty", return_value=False),
                mock.patch("builtins.input") as prompt,
            ):
                runner.ensure_host_key("192.0.2.10")
            prompt.assert_not_called()
            self.assertEqual(known_hosts.read_text(), key + "\n")
            self.assertEqual(known_hosts.stat().st_mode & 0o777, 0o600)

    def test_integration_tofu_keeps_keys_for_session_without_rescanning(self):
        with tempfile.TemporaryDirectory() as directory:
            known_hosts = Path(directory) / "known_hosts"
            key = "192.0.2.10 ssh-ed25519 c3ludGhldGljLWhvc3Qta2V5"
            runner = SSHCommandRunner(
                "/keys/controller", "ubuntu", "integration test",
                known_hosts_file=str(known_hosts),
            )
            with (
                mock.patch.dict(os.environ, {"SWIFTFABRIC_INTEGRATION_TOFU": "1"}),
                mock.patch.object(runner, "_scan_host_keys", return_value=[key]) as scan,
                mock.patch.object(runner, "forget_host_keys") as forget,
                mock.patch("builtins.input") as prompt,
            ):
                runner.ensure_host_key("192.0.2.10")
                runner.ensure_host_key("192.0.2.10")
            scan.assert_called_once()
            forget.assert_not_called()
            prompt.assert_not_called()
            self.assertEqual(known_hosts.read_text(), key + "\n")

    def test_default_uses_standard_openssh_known_hosts_file(self):
        runner = SSHCommandRunner("/keys/controller", "ubuntu", "controller setup")
        self.assertEqual(
            runner.known_hosts_file,
            Path.home() / ".ssh" / "known_hosts",
        )

    def test_first_use_requires_confirmation_and_persists_host_key(self):
        with tempfile.TemporaryDirectory() as directory:
            known_hosts = Path(directory) / "swiftfabric_known_hosts"
            runner = SSHCommandRunner(
                "/keys/controller",
                "ubuntu",
                "controller setup",
                known_hosts_file=str(known_hosts),
            )
            keyscan = (
                "192.0.2.10 ssh-ed25519 "
                "c3ludGhldGljLWhvc3Qta2V5\n"
            )

            def subprocess_result(command, **_kwargs):
                if command[0] == "ssh-keygen":
                    return mock.Mock(returncode=1, stdout="", stderr="")
                if command[0] == "ssh-keyscan":
                    return mock.Mock(returncode=0, stdout=keyscan, stderr="")
                self.fail(f"unexpected subprocess: {command}")

            with (
                mock.patch("deployment.ssh.subprocess.run", side_effect=subprocess_result),
                mock.patch("deployment.ssh.sys.stdin.isatty", return_value=True),
                mock.patch("builtins.input", return_value="yes") as prompt,
            ):
                runner.ensure_host_key("192.0.2.10")

            self.assertIn("192.0.2.10 ssh-ed25519", known_hosts.read_text())
            self.assertEqual(os.stat(known_hosts).st_mode & 0o777, 0o600)
            prompt.assert_called_once()

            with mock.patch(
                "deployment.ssh.subprocess.run",
                return_value=mock.Mock(returncode=0, stdout="found", stderr=""),
            ) as check_pinned:
                runner.ensure_host_key("192.0.2.10")
            self.assertEqual(check_pinned.call_count, 1)

    def test_automated_tofu_is_limited_to_scoped_hosts(self):
        with tempfile.TemporaryDirectory() as directory:
            known_hosts = Path(directory) / "known_hosts"
            runner = SSHCommandRunner(
                "/keys/controller",
                "ubuntu",
                "controller setup",
                known_hosts_file=str(known_hosts),
            )

            def scan_host(ip_address):
                return [
                    f"{ip_address} ssh-ed25519 "
                    "c3ludGhldGljLWhvc3Qta2V5"
                ]

            with (
                mock.patch.object(runner, "_host_is_pinned", return_value=False),
                mock.patch.object(runner, "_scan_host_keys", side_effect=scan_host),
                mock.patch("deployment.ssh.sys.stdin.isatty", return_value=False),
                mock.patch("builtins.input") as prompt,
            ):
                with automated_tofu_for_hosts(["192.0.2.10"]):
                    runner.ensure_host_key("192.0.2.10")
                    self.assertIn("192.0.2.10 ssh-ed25519", known_hosts.read_text())
                    with self.assertRaisesRegex(
                        SSHHostKeyError, "no interactive terminal"
                    ):
                        runner.ensure_host_key("192.0.2.11")
                prompt.assert_not_called()

    def test_forget_host_keys_removes_only_requested_pins(self):
        with tempfile.TemporaryDirectory() as directory:
            known_hosts = Path(directory) / "known_hosts"
            known_hosts.write_text(
                "192.0.2.10 ssh-ed25519 c3RhbGUtY29udHJvbGxlcg==\n"
                "192.0.2.20 ssh-ed25519 a2VlcC10aGlzLWhvc3Q=\n",
                encoding="ascii",
            )
            runner = SSHCommandRunner(
                None, "ubuntu", "cleanup", known_hosts_file=str(known_hosts),
            )

            removed = runner.forget_host_keys(["192.0.2.10", "192.0.2.30"])

            self.assertEqual(removed, ["192.0.2.10"])
            remaining = known_hosts.read_text()
            self.assertNotIn("192.0.2.10", remaining)
            self.assertIn("192.0.2.20 ssh-ed25519", remaining)

    def test_forget_host_keys_without_file_is_noop(self):
        with tempfile.TemporaryDirectory() as directory:
            known_hosts = Path(directory) / "known_hosts"
            runner = SSHCommandRunner(
                None, "ubuntu", "cleanup", known_hosts_file=str(known_hosts),
            )
            self.assertEqual(runner.forget_host_keys(["192.0.2.10"]), [])
            self.assertFalse(known_hosts.exists())

    def test_wait_for_ssh_fails_fast_on_changed_host_key(self):
        from deployment.validation import DeploymentValidator

        changed = mock.Mock(
            returncode=255,
            stdout="",
            stderr="WARNING: REMOTE HOST IDENTIFICATION HAS CHANGED!",
        )
        with (
            mock.patch.object(SSHCommandRunner, "ensure_host_key"),
            mock.patch("deployment.validation.subprocess.run", return_value=changed) as run,
            mock.patch("deployment.validation.time.sleep") as sleep,
        ):
            with self.assertRaisesRegex(RuntimeError, "ssh-keygen -R 192.0.2.10"):
                DeploymentValidator(mock.Mock()).wait_for_ssh(
                    "192.0.2.10", "/keys/controller",
                )
        run.assert_called_once()
        sleep.assert_not_called()

    def test_first_use_rejects_noninteractive_environment(self):
        with tempfile.TemporaryDirectory() as directory:
            runner = SSHCommandRunner(
                "/keys/controller",
                "ubuntu",
                "controller setup",
                known_hosts_file=str(Path(directory) / "known_hosts"),
            )
            keyscan = (
                "192.0.2.10 ssh-ed25519 "
                "c3ludGhldGljLWhvc3Qta2V5\n"
            )

            def subprocess_result(command, **_kwargs):
                if command[0] == "ssh-keygen":
                    return mock.Mock(returncode=1, stdout="", stderr="")
                return mock.Mock(returncode=0, stdout=keyscan, stderr="")

            with (
                mock.patch("deployment.ssh.subprocess.run", side_effect=subprocess_result),
                mock.patch("deployment.ssh.sys.stdin.isatty", return_value=False),
                self.assertRaisesRegex(SSHHostKeyError, "no interactive terminal"),
            ):
                runner.ensure_host_key("192.0.2.10")

    def test_declined_first_use_does_not_store_key(self):
        with tempfile.TemporaryDirectory() as directory:
            known_hosts = Path(directory) / "known_hosts"
            runner = SSHCommandRunner(
                "/keys/controller",
                "ubuntu",
                "controller setup",
                known_hosts_file=str(known_hosts),
            )
            keyscan = (
                "192.0.2.10 ssh-ed25519 "
                "c3ludGhldGljLWhvc3Qta2V5\n"
            )

            def subprocess_result(command, **_kwargs):
                if command[0] == "ssh-keygen":
                    return mock.Mock(returncode=1, stdout="", stderr="")
                return mock.Mock(returncode=0, stdout=keyscan, stderr="")

            with (
                mock.patch("deployment.ssh.subprocess.run", side_effect=subprocess_result),
                mock.patch("deployment.ssh.sys.stdin.isatty", return_value=True),
                mock.patch("builtins.input", return_value="no"),
                self.assertRaisesRegex(SSHHostKeyError, "was not accepted"),
            ):
                runner.ensure_host_key("192.0.2.10")

            self.assertEqual(known_hosts.read_text(), "")

    def test_commands_require_saved_host_key_verification(self):
        with tempfile.TemporaryDirectory() as directory:
            known_hosts = Path(directory) / "known_hosts"
            runner = SSHCommandRunner(
                "/keys/controller",
                "ubuntu",
                "controller setup",
                known_hosts_file=str(known_hosts),
            )
            with (
                mock.patch.object(runner, "ensure_host_key"),
                mock.patch(
                    "deployment.ssh.subprocess.run",
                    return_value=mock.Mock(returncode=0, stdout="ok", stderr=""),
                ) as execute,
            ):
                self.assertEqual(runner.run("192.0.2.10", "true"), "ok")

            command = execute.call_args.args[0]
            self.assertIn(f"UserKnownHostsFile={known_hosts}", command)
            self.assertIn("StrictHostKeyChecking=yes", command)
            self.assertNotIn("StrictHostKeyChecking=no", command)
            self.assertNotIn("GlobalKnownHostsFile=/dev/null", command)


if __name__ == "__main__":
    unittest.main()
