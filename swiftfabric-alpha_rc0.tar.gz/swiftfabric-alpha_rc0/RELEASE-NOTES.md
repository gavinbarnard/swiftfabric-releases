# SwiftFabric release alpha_rc0

Built from supervisor `main` at `367cf5e0b577ee50606f73e601681f60e70d4d99`.

## Contents

- `install.sh`, `upgrade.sh` and `python_installer/`: deployment and upgrade tooling.
- `packages/`: prebuilt Debian packages (no local build required).
- `test-report/before/report.html` and `test-report/after/report.html`: full L2, L3 East/West and L3 North/South tenancy reports before and after disaster recovery.
- `RELEASE.json`: versions, commits, checksums and report summary.
- `SHA256SUMS`: checksums for every file in this bundle (verify with `sha256sum -c SHA256SUMS`).

## Packages

- `swiftfabric-api-service_1:0.1.0+20261104062352.7c5acf735abac3d2e40951bd057175ec1a425ad5.ee3ad80db4bcf0fd682bb4c61de8d0deb0409af0_amd64.deb` (version `1:0.1.0+20261104062352.7c5acf735abac3d2e40951bd057175ec1a425ad5.ee3ad80db4bcf0fd682bb4c61de8d0deb0409af0`)
- `swiftfabric-host-agent_1:0.1.0+20261104062352.ee3ad80db4bcf0fd682bb4c61de8d0deb0409af0_all.deb` (version `1:0.1.0+20261104062352.ee3ad80db4bcf0fd682bb4c61de8d0deb0409af0`)

## Disaster recovery acceptance

All ten disaster recovery stages passed, including ordered cleanup.

### Before

Run `142502fff2b7467eb68e818c74e5fb01`: **PASS**, tenancy enabled.
- east-west: 2160 traffic assertions passed
- health: 432 traffic assertions passed
- l2: 432 traffic assertions passed
- north-south: 216 traffic assertions passed
- API/RBAC: 372 assertions passed

### After

Run `142502fff2b7467eb68e818c74e5fb01`: **PASS**, tenancy enabled.
- east-west: 2160 traffic assertions passed
- health: 432 traffic assertions passed
- l2: 432 traffic assertions passed
- north-south: 216 traffic assertions passed
- API/RBAC: 372 assertions passed


## Install

Requirements: Python 3 with `venv`, network access to PyPI for the installer dependencies, and SSH/API access to the target Proxmox cluster.

```sh
sha256sum -c SHA256SUMS
./pull-images.sh            # downloads the Ubuntu cloud image into images/generic
cp config.example.json config.json   # then edit for your environment
./install.sh --non-interactive --config config.json
```

## Upgrades

upgrade.sh upgrades the controller packages (and, with --auto-agent-upgrade, compute-host and North/South router agents) of an existing deployment. Releases are not yet guaranteed to be upgrade-compatible: breaking changes may require a full redeployment (./install.sh --destroy, then a fresh install) until a supported upgrade starting release is declared.

```sh
./upgrade.sh --config config.json --token
```

Supported upgrade starting release: **none declared yet**. Treat every upgrade between releases as potentially breaking; if an upgrade fails or the release notes call for it, redeploy with `./install.sh --destroy --auto-unenroll` followed by a fresh install (controller state is lost).
