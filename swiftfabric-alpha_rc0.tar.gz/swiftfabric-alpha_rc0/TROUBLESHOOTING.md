# SwiftFabric troubleshooting guide

This guide covers controller HA, Proxmox compute networking, North/South routers
(NSRs), and manual Valkey inspection. Commands describe the current
implementation; older deployed packages may have different capabilities.

## Contents

- [Safety and evidence](#safety-and-evidence)
- [Quick symptom triage](#quick-symptom-triage)
- [Controller services and API](#controller-services-and-api)
- [TLS certificate, trust, and renewal](#tls-certificate-trust-and-renewal)
- [Corosync and Pacemaker](#corosync-and-pacemaker)
- [Compute-node network paths](#compute-node-network-paths)
- [NSR network paths](#nsr-network-paths)
- [Manual Valkey inspection and table dumps](#manual-valkey-inspection-and-table-dumps)
- [Deployment, upgrades, and enrollment](#deployment-upgrades-and-enrollment)
- [Incident handoff checklist](#incident-handoff-checklist)

## Safety and evidence

Run node commands as root, normally with `sudo -i`. Examples use Bash. Run
controller checks on the **SwiftFabric controller VMs**, compute checks on the
**Proxmox hosts**, and NSR checks **inside the router VM**. Proxmox has its own
Corosync cluster; do not confuse its configuration or membership with the
three-controller SwiftFabric cluster.

Most commands below only read state. Exceptions are explicitly identified:
packet probes generate traffic, NSR diagnostic ping temporarily adds a scoped
firewall rule, evidence commands create files, and recovery actions change
running services or cluster state. Execute recovery actions only with an
approved maintenance plan.

Before restarting anything:

1. Record the UTC incident time, affected VM/MAC/IP/segment, source and
   destination hosts, traffic direction, and package versions.
2. Collect logs and counters on both ends while reproducing one specific flow.
3. Compare controller-registered state with kernel-programmed state.
4. Fix the first failing boundary, then retest the original flow.

Do not flush nftables, delete qdiscs, clear whole FDBs, disable the PVE firewall,
force quorum, manually promote Valkey, or tear down/re-enroll a production
host as a diagnostic shortcut. These can remove isolation, interrupt unrelated
traffic, or lose state. Agent restarts also rebuild tunnel ports and forwarding
state, so collect evidence first.

Logs, captures, CIB exports, configuration, and database dumps can contain
credentials, private keys, password hashes, VM payloads, and tenant addresses.
Keep originals root-only and local; redact copies before sharing. Never dump
private-key files or paste full configuration into tickets.

Useful common checks:

```sh
date -u
hostname
uptime
timedatectl status
df -h
df -i
free -h
systemctl --failed --no-pager
journalctl -k --since '-30 minutes' --no-pager
dpkg-query -W swiftfabric-api-service swiftfabric-host-agent
```

Only one of the two packages may be installed on a given node; a missing-package
error is expected for the other role. Check for OOM kills, full disks/inodes,
clock skew, link resets, and process restart loops. Tools used below include
`ip`, `bridge`, `tc`, `nft`, `ping`, `curl`, and role-specific `pcs`,
`valkey-cli`, `sf-cli`, and `tcpdump`. JSON formatting examples additionally
use `jq`. A missing diagnostic tool is not evidence of a data-plane failure.

## Quick symptom triage

| Symptom | Start here | Important distinction |
|---|---|---|
| UI/API VIP unreachable | Controller listener, VIP ownership, quorum, neighbor caches | API systemd service runs on all controllers; public management routes require the VIP owner |
| HTTPS API request fails certificate verification | TLS certificate, CA fingerprint, SAN, and client trust checks | Do not use `curl -k`, disable verification, or retry over HTTP |
| HTTPS connection refused or times out | nginx listener, controller firewall, route, and TCP 443 reachability | Separate a network/listener failure from a certificate or HTTP response |
| Port 80 still listens | Controller nginx configuration and other local listeners | Remote API access is HTTPS-only; HTTP is permitted only on loopback upstreams |
| API returns 503 for cluster status | Local Corosync/Pacemaker commands and VIP owner | Tool failures are reported, not replaced with empty status |
| MAC write returns 409 | Segment primary discovery | Each segment can have a different promoted controller |
| API/agent returns 401 or 403 | Token identity, scope, rotation state | Host/router credentials are not administrator credentials |
| Same-host VM traffic works, cross-host fails | VTEP route/MTU, UDP 6081, FDB and TC | Underlay ping alone does not prove Geneve forwarding |
| ARP unresolved | Agent logs, learned IP, controller ARP/MAC hashes | ARP uses proxy/discovery, not ordinary cross-host broadcast flooding |
| Small packets work, large packets fail | Source-bound DF probes and complete underlay MTU stack | Segment MTU and VTEP MTU are different values |
| East/West routing fails | Gateway, host IPv4 forwarding, both segment ACLs | Agent does not enable forwarding on Proxmox |
| VM cannot reach WAN | VM-facing TC, NSR segment capture, route policy, WAN ACL/NAT | NSR WAN ping tests local OUTPUT, not forwarded VM traffic |
| NSR healthy on SSH but routing dead | Namespace, proxy, host agent, runtime policy retrieval | Management networking is separate from routing |
| NSR shows stale code after controller upgrade | Router runtime/package version and upgrade status | Updating controllers does not itself update running guests or compute agents |
| Broadcast/multicast missing remotely | Registered segment MAC inventory and replication rules | Only VTEPs with registered segment MACs receive copies |

## Controller services and API

### TLS certificate, trust, and renewal

Use the deployment CA as the trust anchor and verify its SHA-256 fingerprint
through the authenticated provisioning channel before trusting a copied
certificate. The CA certificate is public; never copy or disclose
`/var/lib/swiftfabric/ca/ca.key`. Do not work around TLS errors with
`curl -k`, disabled certificate verification, or an HTTP retry.

On each controller, inspect the served leaf certificate and verify that it is
valid for that controller's management IP. Controller certificates must also
contain the API VIP SAN so HTTPS continues to work after VIP failover:

```sh
CA_CERT='/etc/swiftfabric/swiftfabric-ca.crt'
CONTROLLER_IP='<controller-management-ip>'
API_VIP='<api-vip>'

sudo openssl x509 -in "$CA_CERT" -noout -fingerprint -sha256
sudo openssl x509 -in /etc/swiftfabric/tls/server.crt \
  -noout -subject -issuer -serial -dates -ext subjectAltName
sudo openssl verify -purpose sslserver -CAfile "$CA_CERT" \
  -verify_ip "$CONTROLLER_IP" \
  /etc/swiftfabric/tls/server.crt
sudo openssl verify -purpose sslserver -CAfile "$CA_CERT" \
  -verify_ip "$API_VIP" \
  /etc/swiftfabric/tls/server.crt
sudo nginx -t
sudo systemctl status nginx.service --no-pager
sudo ss -lntp | grep -E ':(80|443|8080)\b'
```

Repeat the certificate and local HTTPS checks on all three controllers, not
only the current VIP owner. To test a controller directly while preserving
the IP identity check, use the local-loopback `curl --resolve` command in
[Authenticated API checks](#authenticated-api-checks). A curl certificate
verification error points to an untrusted CA, an expired/not-yet-valid leaf,
or a URL IP/DNS name missing from the certificate SAN. A refused connection
or timeout instead calls for checking nginx, TCP 443 firewall rules, and
network reachability. Do not expose the API application's loopback port 8080.

If a client cannot validate the server, compare the CA fingerprint on that
client with the installer output and confirm the deployment CA is installed
in its operating-system trust store. During enrollment or agent upgrades,
trust installation must succeed before the node is switched to an HTTPS API
URL; a failed trust update is not a reason to disable verification. Operator
clients may use an explicit CA bundle with `curl --cacert` while system-wide
trust is being arranged.

Controller leaf renewal runs daily and renews certificates within 30 days of
expiry. If renewal or nginx reload fails, inspect the timer, service log, and
certificate dates before retrying:

```sh
sudo systemctl status swiftfabric-tls-renew.timer \
  swiftfabric-tls-renew.service --no-pager
sudo journalctl -u swiftfabric-tls-renew.service \
  --since '-30 days' --no-pager
sudo openssl x509 -in /etc/swiftfabric/tls/server.crt \
  -noout -subject -serial -dates
```

The renewal path validates a replacement and restores the prior certificate
if nginx cannot reload it. Do not delete CA or certificate state, create a
replacement CA, or manually overwrite the live leaf as a troubleshooting
shortcut. Protected CA-key backup/restore and CA compromise/rotation procedures
are not yet implemented; retain the CA state and treat its loss as a recovery
incident rather than regenerating it.

### Local services, files, and listeners

On each controller:

```sh
systemctl status swiftfabric-api-service corosync pacemaker \
  swiftfabric-segment-firewall swiftfabric-controller-tuning --no-pager
journalctl -u swiftfabric-api-service -u corosync -u pacemaker \
  --since '-30 minutes' --no-pager
systemctl list-units 'swiftfabric-valkey@*' --all --no-pager
ss -lntup
ip -br address
ip -4 route show
nft -a list ruleset
```

Expected:

- API application on `127.0.0.1:8080` and nginx on TCP 443 on all three
  controllers.
- TCP 80 has no listener and is blocked remotely; HTTP is limited to local
  loopback connections to the API application.
- API VIP assigned to one controller and colocated with the promoted
  provisioning Valkey instance (`4999`).
- One Valkey TCP port per instance: provisioning `4999`, public segments
  `5000` through `50000`.
- Controller firewall permits Valkey access only from the configured
  controller IPs. Failure to connect from a Proxmox host or workstation is
  therefore not a reason to open those ports.

Important controller paths:

| Path | Purpose |
|---|---|
| `/etc/swiftfabric/api-service.json` | Node-specific API configuration; sensitive |
| `/etc/swiftfabric/segment-manager.token` | Deployment/inter-controller bearer token; sensitive |
| `/var/lib/swiftfabric/segments.json` | Default local segment metadata state; includes secrets; `state_path` can override it |
| `/etc/swiftfabric/valkey/<id>.conf` | Instance configuration and authentication secret |
| `/var/lib/swiftfabric/valkey/<id>/` | Instance data, including provisioning persistence |
| `/var/lib/swiftfabric/host-agents/` | Retained versioned host-agent payloads; do not prune |

### Authenticated API checks

Use the VIP for management queries. This Bash helper reads the controller's
token without printing it and passes the HTTP header through stdin rather
than putting the bearer value in curl's command-line arguments. Do not enable
shell tracing (`set -x`) or curl verbose/trace output while using credentials.

```sh
CA_CERT='/etc/swiftfabric/swiftfabric-ca.crt'
API_BASE='https://<api-vip>'
TOKEN="$(cat /etc/swiftfabric/segment-manager.token)"
sf_get() {
    printf 'Authorization: Bearer %s\n' "$TOKEN" |
        curl --silent --show-error --fail-with-body \
          --cacert "$CA_CERT" --connect-timeout 3 --max-time 15 \
          --header @- "$1"
}

sf_get "$API_BASE/api/v1/health"
sf_get "$API_BASE/api/v1/version"
sf_get "$API_BASE/api/v1/cluster"
sf_get "$API_BASE/api/v1/cluster/corosync"
sf_get "$API_BASE/api/v1/cluster/pacemaker"
sf_get "$API_BASE/api/v1/cluster/vip"
sf_get "$API_BASE/api/v1/segments"
sf_get "$API_BASE/api/v1/segments/5001/routing"
sf_get "$API_BASE/api/v1/segments/5001/primary"
sf_get "$API_BASE/api/v1/vteps/primary"
```

Replace `<api-vip>` before use. `/health` alone is not a cluster, replication,
or forwarding test. Preserve HTTP error bodies. Check the installed CA's
fingerprint against the value recorded through the authenticated deployment
channel:

```sh
sudo openssl x509 -in "$CA_CERT" -noout -fingerprint -sha256
```

To distinguish a controller's HTTPS identity from VIP routing, test its
management IP against the matching SAN while resolving that IP to the local
loopback listener:

```sh
CONTROLLER_IP='<controller-management-ip>'
curl --silent --show-error --fail-with-body --max-time 5 \
  --cacert "$CA_CERT" --resolve "$CONTROLLER_IP:443:127.0.0.1" \
  "https://$CONTROLLER_IP/api/v1/health"
```

A healthy local process does not guarantee public routes work on a non-VIP
controller. For segment MAC writes, discover `/segments/<id>/primary`;
the response identifies the current primary and `mac_api_url`. HTTP 409 can
mean primary movement; an ownership conflict on MAC deletion also uses 409,
so read the body. Replica reads are allowed for MAC lookups and may lag.

After these checks, clear the helper and token from the shell:

```sh
unset TOKEN
unset -f sf_get
```

For an existing deployment, migrate enrolled compute hosts and deployed NSRs
to HTTPS before upgrading the controllers. Their supported enrollment and
agent-upgrade paths install the deployment CA before configuring the HTTPS
API URL. Compute hosts may need VM evacuation; NSR upgrades can interrupt
forwarding. Controller upgrades remove the TCP 80 listener and block remote
port 80 without a separate retirement flag or heartbeat gate. An endpoint
still configured for HTTP will lose API connectivity until it is migrated;
never restore remote HTTP as a workaround. Operator clients must also trust
the deployment CA and use HTTPS.

Before an in-place upgrade, take coordinated snapshots of all three
controllers. If rollback is required, restore all three together; restoring
only a subset can desynchronize controller state, tokens, and the CA. These
pre-upgrade snapshots do not replace a protected backup of the post-upgrade
CA signing key.

The CA certificate is public; the signing key at
`/var/lib/swiftfabric/ca/ca.key` is private and must remain root-owned with
mode `0600`. Do not display, paste, or copy it through ordinary support
channels. Protected offline backup/restore and CA compromise/rotation
procedures have not yet been implemented and remain production recovery
gates. Daily leaf renewal is handled by
`swiftfabric-tls-renew.timer`; inspect its status and logs with:

```sh
systemctl status swiftfabric-tls-renew.timer swiftfabric-tls-renew.service --no-pager
journalctl -u swiftfabric-tls-renew.service --since '-30 days' --no-pager
openssl x509 -in /etc/swiftfabric/tls/server.crt -noout -subject -serial -dates
```

For an operator workstation, copy only the public CA certificate over the
authenticated controller SSH channel, then compare its fingerprint with the
installer output before using it:

```sh
scp ubuntu@<controller-management-ip>:/etc/swiftfabric/swiftfabric-ca.crt ./swiftfabric-ca.crt
openssl x509 -in ./swiftfabric-ca.crt -noout -fingerprint -sha256
curl --cacert ./swiftfabric-ca.crt https://<api-vip>/api/v1/health
```

Installer destroy/auto-unenroll retrieves the public deployment CA from a
running controller over SSH when `--ca-cert` is omitted, then uses it only for
verified HTTPS requests during that run. It does not modify the workstation's
system trust store. Pass `--ca-cert /path/to/swiftfabric-ca.crt` to use an
already obtained CA certificate instead. Non-interactive destroy also requires
`--yes` after reviewing the controller VM list. Controller upgrades obtain CA
trust over the configured SSH path and verify HTTPS after each controller
restart.

Destroy and auto-unenroll require an active Administrators-group API key.
Before inventory checks or deletion, the installer verifies `/api/v1/system/me`.
After revoking the deployment key, pass `--token` to securely enter its
replacement; automatic SSH retrieval still reads the original admin token
and cannot restore its revoked user access. Rejected, unavailable, or invalid
identity responses stop destruction, including with `--yes`.

Fresh deployments use a unique credential per controller in root-only
`/etc/swiftfabric/controller-service.token` and `api-service.json` (`api_token`).
`/etc/swiftfabric/segment-manager.token` contains the initial admin key, not
the service credential. Never use the service credential for installer destroy
or UI login. Clusters sharing an admin/service credential or a single service
credential across controllers require redeployment; no automatic migration is
supported. New configs require three distinct `controller_token_hashes`.

Administrators can find each **Controller service** key under **My API keys**.
Rotation requires all three controllers to be reachable and does not restart
services. If rotation fails, restore controller connectivity and use **Retry
rotation** on the pending entry. The old credential is not retired until the
owning controller confirms its replacement authenticates to all three peers.
Do not manually edit token files or bootstrap hashes to complete a rotation.

## Corosync and Pacemaker

### 1. Establish membership and quorum

Run on **each controller**, not only the VIP owner:

```sh
systemctl is-active corosync pacemaker
corosync-quorumtool -s
corosync-quorumtool -l
corosync-cfgtool -s
crm_node -n
pcs status --full
crm_mon --one-shot --output-as=xml
journalctl -u corosync -u pacemaker --since '-30 minutes' --no-pager
```

Normal full health is three members, expected votes `3`, total votes `3`,
`Quorate: Yes`, connected KNET links, and all three Pacemaker nodes online.
Two surviving votes can retain quorum; that is degraded service, not full
health. One isolated controller must not continue managing resources alone.

The installer configures Corosync 3 KNET with controller management addresses,
node IDs `1`, `2`, `3`, and `expected_votes: 3`. Inspect
`/etc/corosync/corosync.conf` on all three controllers for identical membership
and correct addresses. Compare authentication-file checksums locally across
the controllers without printing or copying their contents:

```sh
sha256sum /etc/corosync/corosync.conf /etc/corosync/authkey
stat -c '%a %U:%G %n' /etc/corosync/authkey
ss -lunp
ip -s link show
```

The installer writes the authkey root-owned with mode `0400`. Treat its checksum
as internal evidence too. For an unreachable peer, replace these examples:

```sh
LOCAL_CONTROLLER_IP='192.0.2.51'
PEER_CONTROLLER_IP='192.0.2.52'
CONTROLLER_IF='ens18'
ip -4 route get "$PEER_CONTROLLER_IP" from "$LOCAL_CONTROLLER_IP"
ping -4 -n -I "$LOCAL_CONTROLLER_IP" -c 3 -W 2 "$PEER_CONTROLLER_IP"
timeout 20 tcpdump -ni "$CONTROLLER_IF" -c 100 \
  "host $PEER_CONTROLLER_IP and udp"
```

Use actual sockets/configuration to identify the KNET UDP ports; the common
default starts at 5405. A capture of all peer UDP avoids assuming a fixed
port. Check both directions, hypervisor bridge/VLAN placement, guest and PVE
firewalls, MTU/loss, duplicate IPs, and clock/service logs. A ping reply alone
does not prove the cluster's authenticated UDP transport works.

**Do not** lower expected votes, set `no-quorum-policy=ignore`, or create an
independent cluster on an isolated node. Restore connectivity and membership.
The current proof-of-concept installer sets `stonith-enabled=false` and
`no-quorum-policy=stop`; this is not a fenced production HA design. Never use
that setting as justification to force two partitions active.

### 2. Inspect resources, failures, and placement

```sh
pcs resource status
pcs resource failcount show
pcs property config
pcs constraint config
pcs resource config swiftfabric-segment-manager-vip
pcs resource config swiftfabric-valkey-4999
pcs resource config swiftfabric-valkey-5001
```

**Sensitive output:** Valkey resource configuration includes its password;
keep that output private. Constraint output explains placement preferences,
colocation, and any manual bans/moves. Look for maintenance mode, unmanaged or
disabled resources, standby nodes, failed actions, timeouts, and fail counts.

Expected resource layout:

- `swiftfabric-segment-manager-vip`: custom
  `ocf:swiftfabric:segment-manager-vip` resource.
- `swiftfabric-valkey-<id>`: custom `ocf:swiftfabric:valkey-segment` resource.
- `swiftfabric-valkey-<id>-clone`: promotable clone, three instances,
  one Promoted and two Unpromoted when all controllers are healthy.
- VIP colocation with the **Promoted** `swiftfabric-valkey-4999-clone`;
  the VIP need not share a node with every public segment primary.

Inspect an affected instance without restarting it:

```sh
systemctl status swiftfabric-valkey@5001 --no-pager
journalctl -u swiftfabric-valkey@5001 --since '-30 minutes' --no-pager
journalctl --since '-30 minutes' --no-pager \
  --grep='valkey-segment|segment-manager-vip|swiftfabric-valkey'
```

Check missing configs, permissions, port conflicts, disk capacity, tuning-unit
failure, authentication errors, and replication connectivity. Use the
[Valkey checks](#manual-valkey-inspection-and-table-dumps) to compare actual
roles against Pacemaker.

### 3. VIP present in Pacemaker, but unreachable

```sh
pcs resource status swiftfabric-segment-manager-vip
ip -4 address show
ip -4 route show
ip neigh show
```

Verify the VIP is present **only on its reported owner**, on the expected
subnet/interface. On a same-subnet client, inspect its neighbor entry for the
VIP and compare it to the owner's interface MAC. Check VLAN consistency,
duplicate addressing, PVE filtering, upstream routing, and gateway neighbors.

The VIP agent sends two gratuitous ARP requests and one VIP-source gateway
ping at activation. Failures are warnings and do not prevent activation, so
`Started` is not proof that upstream neighbors updated. Gratuitous ARP reaches
only the local broadcast domain; off-subnet clients depend on routers.

### 4. Recovery after the cause is fixed

**State-changing; approved maintenance only.** Target cleanup to the affected
resource/node, using the actual Pacemaker node name from `crm_node -n`:

```sh
pcs resource cleanup swiftfabric-valkey-5001 node=<controller-node-name>
pcs status --full
```

Cleanup clears failure history and triggers rediscovery/recovery; it is not
just a log cleanup and may cause resource actions. Check `pcs resource cleanup
--help` for the deployed version's clone/instance targeting options. Do not
run a blanket cleanup or manually start/promote a Pacemaker-managed Valkey
instance. Coordinate any resource restart through Pacemaker rather than
competing with its resource agent using `systemctl restart`.

After recovery, verify quorum on all nodes, resource roles and VIP placement,
Valkey replication, authenticated API access, and an affected VM flow. Do not
call recovery complete after only clearing a red status indicator.

## Compute-node network paths

### 1. Identify the flow and compare sf-cli views

On the affected Proxmox node, replace these example values:

```sh
SEG=5001
LOCAL_VTEP='192.0.2.11'
PEER_VTEP='192.0.2.12'
VTEP_DEV='sf-vtep'
VM_PORT='tap101i0'
REMOTE_MAC='02:00:00:00:00:12'

systemctl status swiftfabric-host-agent --no-pager
journalctl -u swiftfabric-host-agent --since '-30 minutes' --no-pager
sf-cli --help
sf-cli --list --vtep
sf-cli --list --segment "$SEG" --mac
sf-cli --list --segment "$SEG" --mac --controller
sf-cli --list --segment "$SEG" --mac --controller --json
```

Inventory commands display sorted tables by default; add `--json` when piping
their output to scripts. NSR diagnostics already use native human-readable
network-tool output.

In local `--segment` MAC output, the **Dynamic VTEP bindings** table shows each
remote MAC the agent programmed on demand and its remote VTEP. `fdb-only` or
`tc-only` status means only half of the binding (static FDB entry on
`sf-tp<segment>` or `tunnel_key` rule on `sf-tq<segment>`) exists. Raw view:
`bridge fdb show br sf-br$SEG dev sf-tp$SEG` and
`tc -s filter show dev sf-tq$SEG ingress`.

Use `/etc/swiftfabric/host-agent.json` locally to identify the configured
`vtep_ip`, `vtep_interface`, `vtep_vlan`, `vtep_mtu`, `geneve_port`, and
`interfaces_file`; do not print the `api_token`. `sf-vtep` is the managed VLAN
device when a VTEP VLAN is configured; without one, use the configured
underlay interface. Do not assume the physical NIC has the VTEP address.

`sf-cli --list --vtep --controller` queries administrator host records.
An ordinary host token cannot authorize it. Prefer the administrator UI/API,
or an existing protected administrator configuration with `--config`; do not
replace the running host agent's scoped token or put an admin token in shell
history. Controller MAC listing works with the host's scoped token.

Local sf-cli views combine interfaces-file stanzas, addresses, FDB, and TC
rules; they are not an active connectivity test. If the file is wrong, use
`--interfaces-file /path/to/interfaces`. If sf-cli fails, retain stderr and
use the raw commands below; missing devices or malformed command output can
be the actual failure, not just a CLI problem.

### 2. Know the packet path

For segment `5001`:

```text
VM tap/veth (or PVE fwpr port)
  -> sf-br5001
     -> local destination port                         [same-host L2]
     -> sf-sk5001 <-> sf-ag5001 -> agent                [discovery/proxy ARP]
     -> sf-tp5001 <-> sf-tq5001 ingress TC -> sf-gnv     [remote unicast]
        -> underlay UDP 6081, VNI 5001 -> remote VTEP
        -> remote sf-gnv ingress TC -> sf-tq5001
        -> sf-tp5001 -> sf-br5001 -> destination VM
```

North/South external IPv4 uses a separate TC shortcut on the VM-facing
bridge port: gateway-destined frames are encapsulated directly toward the
attached router's VTEP. Known SwiftFabric destination subnets pass to the
existing East/West path. Invalid/missing router metadata causes external
IPv4 to be dropped, not leaked into the Proxmox default route.

### 3. Raw link, bridge, FDB, and TC diagnostics

These are read-only alternatives when sf-cli is unavailable:

```sh
ip -br address
ip -d link show dev sf-gnv
ip -s link show dev "$VTEP_DEV"
ip -d link show dev "sf-br$SEG"
ip -o link show master "sf-br$SEG"
bridge -d link show
bridge fdb show br "sf-br$SEG"
bridge vlan show
ip neigh show dev "sf-br$SEG"

tc -s -d qdisc show dev sf-gnv
tc -s -d filter show dev sf-gnv ingress
tc -s -d qdisc show dev "sf-tq$SEG"
tc -s -d filter show dev "sf-tq$SEG" ingress
tc -s -d filter show dev "$VM_PORT" ingress
```

For machine-readable output, use `ip -j addr show`, `bridge -j fdb show br
"sf-br$SEG"`, and `tc -j filter show dev "sf-tq$SEG" ingress`. Raw text with
`-s -d` is usually more useful for action counters.

| Device/filter | Expected programming | What to check |
|---|---|---|
| `sf-gnv` | External/metadata Geneve device, configured UDP port, `clsact` | Link up; no single fixed remote/VNI is expected in metadata mode |
| `sf-tp<ID>` | Static remote-MAC FDB entries; learning off | Remote MAC points here, not an old VM port |
| `sf-sk<ID>` | Learning off | Injected ARP replies must not teach false MAC locations |
| `sf-tq<ID>` ingress priority `10` | `flower dst_mac`, `tunnel_key set src_ip/dst_ip/id/dst_port`, `mirred egress redirect dev sf-gnv` | Correct remote VTEP, VNI=segment ID, and counter growth |
| `sf-tq<ID>` ingress priority `20` | Mark-matching `u32` replication filters with tunnel/redirect actions | One per remote VTEP with registered segment MACs; not one per enrolled host |
| `sf-tq<ID>` ingress priority `100` | `matchall action drop` | Intentional terminal drop for traffic without a programmed rule |
| `sf-gnv` ingress priority `1000 + ID` | `flower enc_key_id ID`, redirect to `sf-tq<ID>` | Correct inbound VNI and target port; `6001` for segment `5001` |
| VM-facing ingress priority `49150` | Internal-destination IPv4 `flower` pass rules | Known SwiftFabric subnets must bypass WAN steering |
| VM-facing ingress priority `49151` | Gateway-MAC match, tunnel to NSR, or explicit drop | Router metadata and VTEP; gateway MAC for `5001` is `02:53:46:00:13:89` |
| VM-facing ingress priority `49152` | Terminal external-IPv4 drop | Fail-closed guard, not a rule to remove |

To narrow a noisy view:

```sh
bridge fdb show br "sf-br$SEG" | grep -F "$REMOTE_MAC"
tc -s -d filter show dev "sf-tq$SEG" ingress pref 10
tc -s -d filter show dev "sf-tq$SEG" ingress pref 20
tc -s -d filter show dev sf-gnv ingress pref "$((1000 + SEG))"
tc -s -d filter show dev "$VM_PORT" ingress pref 49151
```

Take two counter readings around the same generated VM flow. No filter-counter
increase means the packet did not reach/match that stage. Redirect counters
increasing without packets on the destination underlay point to a later
encapsulation/route/link issue. A zero counter on an idle rule is not a fault.
Do not add replacement rules by hand: their ownership, handles, priorities,
and reconciliation belong to the agent.

Remote unicast entries are installed **on demand**, so an unused remote MAC
need not already have a TC rule. Known programmed unicast stays in the kernel;
agent/API failure may break new discovery while existing flows still pass.
Restarting the agent can destroy that useful evidence.

### 4. PVE firewall-backed VM ports

With the VM NIC firewall enabled, the path includes `tap` -> `fwbr` ->
`fwln`/`fwpr` -> `sf-br<ID>`. The agent steers on the **`fwpr<VMID>p<NIC>`**
port attached to the SwiftFabric bridge, not the tap behind `fwbr`.

```sh
qm config 101
ip -o link show master "sf-br$SEG"
bridge link show
tc -s -d filter show dev fwpr101p0 ingress
ip -s link show dev fwpr101p0
```

Set `VM_PORT` to that `fwpr` device for the preceding checks. Direct taps and
container veths remain supported. Do not expect agent steering on `fwbr`,
`fwln`, management NICs, or its own sink/tunnel ports. Check PVE firewall logs
and rules on the full path without disabling them. Older compute agents may
not discover firewall-backed ports; upgrading only the controller/NSR cannot
fix old compute-side discovery.

### 5. Underlay reachability, VLAN, MTU, and captures

```sh
ip -4 route get "$PEER_VTEP" from "$LOCAL_VTEP"
ip neigh show dev "$VTEP_DEV"
ping -4 -n -I "$LOCAL_VTEP" -c 3 -W 2 "$PEER_VTEP"

# Example for a configured VTEP MTU of 9000: 9000 - IPv4/ICMP headers (28).
ping -4 -n -I "$LOCAL_VTEP" -c 3 -W 2 -M do -s 8972 "$PEER_VTEP"
ip -d link show dev "$VTEP_DEV"
bridge vlan show
```

Use `vtep_mtu - 28` for the DF payload, not always `8972`. Test both directions
and both small and required-size packets. A failed ICMP probe can also mean
ICMP filtering; compare captures and actual Geneve traffic before deciding
the path is down.

Inspect MTUs on the VTEP VLAN, bridge, bond, bond members/physical NICs, virtual
NICs, and switches along the path. Enrollment/startup validates host backing
devices and does **not** raise their MTUs automatically. A bridge advertising
9000 does not prove its lower devices or the switch support it.

Current segment MTUs are 1500 through 8050, while VTEP MTU is separately
configured (1600 through 9000). The agent budgets Geneve overhead; do not set
guest MTU equal to underlay MTU. Check guest NICs and PVE firewall links too.

Run bounded captures in separate terminals on both hosts while the VM sends
traffic; substitute the configured Geneve port if not 6081:

```sh
timeout 20 tcpdump -ni "$VM_PORT" -e -c 100 'arp or icmp'
timeout 20 tcpdump -ni "sf-tq$SEG" -e -c 100
timeout 20 tcpdump -ni "$VTEP_DEV" -c 100 \
  "host $PEER_VTEP and udp port 6081"
```

Follow one direction: VM packet, sender TC, sender underlay, receiver underlay,
receiver VNI rule, receiver bridge, destination port. Then repeat for the reply.
For NSR-bound traffic, use the **router VTEP**, not another compute VTEP.
Check outer source/destination IPs and decoded Geneve VNI against the segment.
An outer UDP packet arriving does not prove successful decapsulation.

For VLAN trouble, inspect `ip -d link`, bridge VLAN membership/PVIDs, and
captures on both the logical VTEP device and its backing NIC. Tagged NSR VM
NICs require VLAN-aware PVE bridges. Do not enable VLAN filtering on a live
bridge as an experiment; fix the planned host configuration under maintenance.

### 6. ARP, MAC movement, replication, and East/West routing

For unresolved IPv4 neighbors, compare:

1. Guest IP/mask/gateway and its neighbor table.
2. Local bridge FDB ownership and agent registration logs.
3. Controller MAC record and IP-to-MAC ARP hash on the segment primary.
4. Destination host traffic: an idle guest may not yet have supplied its IPv4
   address. A MAC can be known while its IP is still unknown.

The agent learns IPv4 from guest traffic, proxies ARP for learned remote
targets, and requests best-effort discovery for unknown targets. It does not
answer an unknown mapping speculatively. Non-ARP broadcast/multicast uses
agent fan-out and marked TC copies; there is no multicast-group pruning.
Check registered MAC inventory and priority-20 rules before assuming every
enrolled VTEP should receive a copy.

For migration/stale ownership, compare MAC `host_id`/`vtep_ip` on the promoted
controller, old/new host FDBs, and priority-10 destinations. Segment sync runs
about every 10 seconds; remote verification, inventory refresh, statistics,
and health reports generally run about every 30 seconds. Event updates can be
faster, but an old replica or cached lookup is not proof that migration failed.

For routed East/West traffic:

```sh
sf-cli --list --segment "$SEG" --routing
sf-cli --list --segment "$SEG" --routing --json
sf-cli --list --segment "$SEG" --routing --controller
sf-cli --list --segment "$SEG" --routing --controller --json
```

The local view reports actual bridge gateway addresses/MAC/MTU, forwarding,
routes through the segment bridge, ordered nftables ACL/forward rules, and
ingress TC on attached VM ports. The controller view reports defined policy
(gateway, MTU, ACLs, IP sets, and North/South attachment). Compare both; controller
policy is not proof of kernel programming. `--json` preserves native records
for scripts. These commands only inspect state; local inspection requires root
and never queries the controller. Missing routing tables/chains are explicit;
command or API failures return nonzero and stderr. Older agents may not support
`--routing`; the following native commands are read-only alternatives:

```sh
ip -4 address show dev "sf-br$SEG"
ip -j -d address show dev "sf-br$SEG"
ip link show dev "sf-br$SEG"
ip -4 route show
ip -j -4 route show table all dev "sf-br$SEG"
sysctl net.ipv4.ip_forward
nft -a list table inet swiftfabric_routing
nft -a list chain inet swiftfabric_routing "sf_${SEG}_ingress"
nft -a list chain inet swiftfabric_routing "sf_${SEG}_egress"
nft -a list chain inet swiftfabric_routing forward
nft -j -a list table inet swiftfabric_routing
bridge -j link show master "sf-br$SEG"

# Repeat on each VM-facing tap/fwpr/veth attached to this segment.
VM_PORT='<attached-vm-port>'
tc -s filter show dev "$VM_PORT" ingress
tc -j filter show dev "$VM_PORT" ingress
```

Gateway addresses programmed by the agent carry the `sf-br<SEG>:sf` label.
Routes scoped to the bridge omit other host routes; use the full route dump
above to diagnose management/underlay paths. The shared `forward` chain applies
source egress and destination ingress policy; inspect both segments for a flow.
VM-port ingress TC exposes internal-destination exceptions, North/South
gateway-MAC tunnel actions, and terminal external-IPv4 drops. No attached
router or invalid router metadata must not steer external traffic into a host
default route. An absent nftables table can be normal with no routed segments;
on a routed segment, missing gateway/ACL state needs agent-log investigation.

The Proxmox host must already have IPv4 forwarding enabled through its managed
configuration. The agent reports an error rather than enabling it. Check both
the source segment's egress ACL and destination segment's ingress ACL.
Established/related traffic can remain allowed; reproduce with a new flow
when testing changed policy. Empty allowlists deny new inter-segment traffic.
Check other host/PVE firewall hooks too; an accept in one table does not
override a drop elsewhere.

## NSR network paths

### 1. Management versus routing namespaces

The NSR VM's default namespace contains management IP/default route/DNS/SSH.
WAN, VTEP, Geneve, segment bridges, forwarding, routing policy, and data-plane
firewall live inside **`sf-router`**. A default-namespace `ip route` or
`tcpdump -i any` does not inspect that isolated data plane.

Inside the NSR VM:

```sh
systemctl status swiftfabric-router-netns swiftfabric-api-proxy \
  swiftfabric-router swiftfabric-host-agent --no-pager
journalctl -u swiftfabric-router-netns -u swiftfabric-api-proxy \
  -u swiftfabric-router -u swiftfabric-host-agent \
  --since '-30 minutes' --no-pager
ip netns list
systemctl cat swiftfabric-host-agent
sf-cli nsr status
sf-cli nsr links
sf-cli nsr routes
sf-cli nsr neighbors
sf-cli nsr firewall
```

`systemctl cat` shows the installed namespace/configuration drop-in; review
locally and redact before sharing. Runtime configuration normally lives at
`/etc/swiftfabric/router.json`. Use `sf-cli nsr --config /path/to/router.json
status` if needed. The generated host-agent unit/configuration is authoritative;
do not assume a compute-host command automatically enters the NSR namespace.

The private management control veths are `sf-proxy0` in the default namespace
and `sf-proxy1` in `sf-router`, with link-local addresses
`169.254.254.1`/`169.254.254.2` and proxy port 3128. They carry restricted
controller API requests, **not** a WAN next hop.

If `/api/v1/segments` returns 401 in the router host-agent log, the scoped
router token must be accepted on its segment data-plane endpoints. Missing
bridges then cause runtime waits and fail-closed policy. Correct authorization,
proxy connectivity, or rotation state; do not substitute an admin token or
open the WAN firewall.

### 2. sf-cli probes, forwarded route lookup, and captures

Replace the addresses/segment with the affected flow:

```sh
sf-cli nsr route 1.1.1.1 --source 172.16.81.4 --ingress-segment 5001
sf-cli nsr ping 1.1.1.1 --source wan
sf-cli nsr ping 192.0.2.11 --source vtep --size 8972 --df
sf-cli nsr ping 172.16.81.4 --source segment:5001
sf-cli nsr capture segment:5001 --filter 'host 172.16.81.4'
sf-cli nsr capture vtep --filter 'udp port 6081'
sf-cli nsr capture wan --filter 'host 1.1.1.1'
```

Captures run until interrupted; Ctrl-C when finished. Run captures in separate
terminals while the **VM** generates the actual failing connection.

**NSR ping is a bounded, temporary firewall change.** It inserts an OUTPUT
allow for only the chosen source IP, resolved output interface, destination,
and ICMP echo request, then removes its rule/set. The destination set expires
after the probe deadline if the process is killed uncatchably. It does not
modify FORWARD or NAT. Reconciliation may replace the temporary rule and the
command reports that condition. Ping accepts 1-10 packets, 1-5 seconds per
packet, numeric IPv4, optional payload size, and DF.

A successful WAN ping does **not** prove a VM's egress ACL, NAT, or return
path. A ping sourced from a segment gateway is also not equivalent to a
forwarded VM packet and may have no upstream return route.

### 3. If sf-cli is broken: runtime and raw kernel commands

The CLI delegates NSR diagnostics to the installed runtime; if only the CLI
wrapper is broken:

```sh
python3 /usr/lib/swiftfabric/router_runtime.py --inspect status
python3 /usr/lib/swiftfabric/router_runtime.py --inspect firewall
python3 /usr/lib/swiftfabric/router_runtime.py \
  --route-get 1.1.1.1 --source 172.16.81.4 --ingress-segment 5001
python3 /usr/lib/swiftfabric/router_runtime.py --capture wan
```

If the runtime/configuration is broken too, inspect kernel state directly.
Replace interface names with those in the deployed router configuration:

```sh
SEG=5001
WAN_IF='ens19'
VTEP_IF='ens20'
VM_IP='172.16.81.4'
DEST_IP='1.1.1.1'
NSR_VTEP='192.0.2.20'
COMPUTE_VTEP='192.0.2.11'

ip netns exec sf-router ip -br address
ip netns exec sf-router ip -d link show
ip netns exec sf-router ip -s link show
ip netns exec sf-router ip -4 rule show
ip netns exec sf-router ip -4 route show table all
ip netns exec sf-router ip neigh show
ip netns exec sf-router sysctl net.ipv4.ip_forward
ip netns exec sf-router nft -a list table inet swiftfabric_router
ip netns exec sf-router bridge fdb show br "sf-br$SEG"
ip netns exec sf-router tc -s -d filter show dev "sf-tq$SEG" ingress
ip netns exec sf-router tc -s -d filter show dev sf-gnv ingress
```

The same tunnel-port and Geneve TC programming described for compute nodes
applies **inside the namespace**. For the forwarded route lookup, the runtime
uses routing table/mark `10000 + segment ID`:

```sh
TABLE="$((10000 + SEG))"
ip netns exec sf-router ip -4 route show table "$TABLE"
ip netns exec sf-router ip -4 route get "$DEST_IP" from "$VM_IP" \
  iif "sf-br$SEG" mark "$TABLE"
ip netns exec sf-router ip -4 route get "$COMPUTE_VTEP" from "$NSR_VTEP"
```

Omitting ingress and mark can select the wrong path and is not equivalent to
`sf-cli nsr route ... --ingress-segment`. Verify the namespace's WAN default
route and next-hop neighbor, not the management default route.

Raw bounded captures:

```sh
timeout 20 ip netns exec sf-router tcpdump -ni "sf-br$SEG" -e \
  -c 100 "host $VM_IP"
timeout 20 ip netns exec sf-router tcpdump -ni "$WAN_IF" \
  -c 100 "host $DEST_IP"
timeout 20 ip netns exec sf-router tcpdump -ni "$VTEP_IF" \
  -c 100 'udp port 6081'
```

For a raw VTEP probe, the existing VTEP ICMP policy normally permits:

```sh
ip netns exec sf-router ping -4 -n -I "$NSR_VTEP" \
  -c 3 -W 2 -M do -s 8972 "$COMPUTE_VTEP"
```

Use the configured MTU minus 28. A raw WAN/segment-source ping may be blocked
by OUTPUT policy: unlike sf-cli/runtime diagnostic ping, it does not install
the temporary allow. Do not flush rules to make that probe succeed.

### 4. Trace VM-to-WAN and WAN-to-VM failures

For a new VM-to-WAN flow, check these boundaries in order:

1. Guest uses the segment gateway; compute VM-facing TC selects the attached
   router VTEP with the correct VNI, without rewriting the inner frame.
2. NSR VTEP capture sees Geneve; ingress TC selects the segment.
3. NSR segment capture sees the original VM source/destination.
4. Forwarded policy lookup selects the correct segment table/WAN route.
5. Router `wan_egress_rules` allows the original source/destination/protocol/ports.
6. Outbound fixed-port mapping matches, or the source CIDR is explicitly in
   `masquerade_source_cidrs` for that attached segment.
7. WAN capture sees the expected translated source; upstream routing and
   firewall allow replies.
8. Reply arrives at WAN, matches conntrack, routes back to the right segment,
   and reaches the compute VTEP/VM.

Missing/empty `masquerade_source_cidrs` disables masquerade; unmatched traffic
is not automatically NATed. ACL and NAT are separate checks. Changing NAT
policy does not rewrite existing conntrack decisions; test a new connection.

For inbound port mappings, check the public WAN destination/port, DNAT private
IP/port, and `wan_ingress_rules` **after DNAT**. The private IP must belong to
exactly one attached segment. Unsolicited WAN traffic is denied by default.
If already installed, inspect conntrack without deleting entries:

```sh
ip netns exec sf-router conntrack -L -f ipv4 -s "$VM_IP"
```

Also inspect default-namespace management/proxy policy separately:

```sh
ip -br address
ip -4 route show
ss -lntp
ip -s link show dev sf-proxy0
ip netns exec sf-router ip -s link show dev sf-proxy1
nft -a list table inet swiftfabric_management
```

When controller policy retrieval/application fails, the runtime replaces
namespace policy with default-drop rules. Missing allow rules may be the
**result** of a control-plane failure rather than an operator ACL edit.
Inspect proxy/runtime logs before altering policy. WAN-originated echo requests
are denied normally; do not use unsolicited WAN ping as the sole health test.

## Manual Valkey inspection and table dumps

### 1. Select the correct instance and authenticate safely

Run locally on a controller as root. SwiftFabric uses **separate Valkey
processes/ports**, not one shared server with a database per segment.
Application data uses DB 0. Port `4999` contains persistent provisioning
records; port `<segment ID>` contains that segment's MAC/ARP/statistics hashes.
Primaries can differ by instance. Use Pacemaker and `INFO replication` on all
three controllers before drawing conclusions from a replica.

The API token is **not** the Valkey password. Each instance has its own
64-hex-character password in the root-readable instance configuration.
This Bash subshell extracts the generated `requirepass` value without printing
it or putting it in `valkey-cli -a` arguments. It exits on a missing/invalid
secret. Do not use shell tracing.

```sh
(
    set -e
    PORT=5001                         # Change to 4999 for provisioning.
    case "$PORT" in
        ''|*[!0-9]*) printf 'Invalid port\n' >&2; exit 1 ;;
    esac
    VALKEYCLI_AUTH="$(awk '$1 == "requirepass" {print $2}' \
        "/etc/swiftfabric/valkey/$PORT.conf")"
    if [[ ! "$VALKEYCLI_AUTH" =~ ^[[:xdigit:]]{64}$ ]]; then
        printf 'Missing/invalid instance password; stop and inspect locally\n' >&2
        exit 1
    fi
    export VALKEYCLI_AUTH
    vk() { valkey-cli -e --raw -h 127.0.0.1 -p "$PORT" -n 0 "$@"; }

    vk PING
    vk ROLE
    vk INFO replication
    vk INFO persistence
    vk INFO memory
    vk INFO stats
    vk DBSIZE
    vk --scan --pattern 'swiftfabric:*'
)
```

For subsequent examples, insert the relevant commands **inside that subshell
after the `vk` definition**, replacing or following its diagnostic commands.
The closing parenthesis removes the function/authentication environment.
`-e` makes server errors fail the CLI instead of looking like successful
output; check exit status as well as text. An environment variable is still
sensitive to privileged process inspection; use a trusted root session.

Expected replication: one `role:master`, two `role:slave` with
`master_link_status:up` and the correct current primary. Compare offsets,
sync-in-progress state, replica lag, and logs. `NOAUTH`/`WRONGPASS` means
authentication trouble; `READONLY` usually means a write reached a replica.
Do not fix role mismatches with `REPLICAOF NO ONE` or `CONFIG SET`.

### 2. Dump a public segment's tables

With `PORT=5001`:

```sh
vk TYPE "swiftfabric:segment:$PORT:macs"
vk HLEN "swiftfabric:segment:$PORT:macs"
vk HGETALL "swiftfabric:segment:$PORT:macs"
vk HGETALL "swiftfabric:segment:$PORT:arp"
vk HGETALL "swiftfabric:segment:$PORT:adapter-stats"

# Targeted lookups reduce output and server work.
vk HGET "swiftfabric:segment:$PORT:macs" '02:00:00:00:00:12'
vk HGET "swiftfabric:segment:$PORT:arp" '172.16.81.4'
vk HGET "swiftfabric:segment:$PORT:adapter-stats" '02:00:00:00:00:12'
```

| Hash | Field | Value |
|---|---|---|
| `swiftfabric:segment:<id>:macs` | Normalized MAC | JSON MAC record with host/VTEP and optional learned IP |
| `swiftfabric:segment:<id>:arp` | IPv4 address | MAC address |
| `swiftfabric:segment:<id>:adapter-stats` | MAC | Latest JSON sample; counters are decimal strings, with deltas after a second successful sample |

`HGETALL --raw` output alternates field/value lines; it is not a JSON document.
An absent hash returns no entries; `TYPE` returns `none`. Check the port,
primary, learning state, and replication before interpreting an empty table.

`HGETALL` is appropriate for small tables but blocks while traversing a large
hash. For large registries use:

```sh
vk HSCAN "swiftfabric:segment:$PORT:macs" 0 COUNT 100
```

The first output item is the next cursor. Repeat with that cursor until it
returns `0`; `COUNT` is a hint, not a limit. SCAN/HSCAN can duplicate entries
and are not point-in-time snapshots while writes continue. Avoid `KEYS *`
and unbounded `MONITOR` during incidents.

### 3. Dump provisioning tables

Start the authentication subshell with **`PORT=4999`**. The following are hash
tables:

```sh
vk HGETALL swiftfabric:vteps:pool
vk HGETALL swiftfabric:vteps:hosts
vk HGETALL swiftfabric:vteps:owners
vk HGETALL swiftfabric:vteps:reservations
vk HGETALL swiftfabric:hosts
vk HGETALL swiftfabric:host:heartbeats
vk HGETALL swiftfabric:host:liveness
vk HGETALL swiftfabric:proxmox:clusters
vk HGETALL swiftfabric:north_south_routers
vk HGETALL swiftfabric:users
vk HGETALL swiftfabric:groups
```

The allocation cursor, migration marker, and system settings are strings,
not hashes (system settings is a JSON document):

```sh
vk GET swiftfabric:vteps:cursor
vk GET swiftfabric:groups:initialized
vk GET swiftfabric:system:settings
```

Named IPv4 ACL address groups are stored in the **provisioning instance**
(`4999`) as one JSON string, not as a Valkey hash or one key per group:

```sh
vk TYPE swiftfabric:ip_sets
IP_SETS_JSON="$(vk GET swiftfabric:ip_sets)"
printf '%s\n' "$IP_SETS_JSON" | jq .
printf '%s\n' "$IP_SETS_JSON" |
    jq -r '.[] | "\(.name)\t\(.cidrs | join(", "))"'
```

The value is a JSON array of `{ "name": "...", "cidrs": [...] }` objects.
Resolve one ACL group name to its configured IPv4 addresses/CIDRs with:

```sh
SET_NAME='trusted_clients'
printf '%s\n' "$IP_SETS_JSON" |
    jq -er --arg name "$SET_NAME" '
      [.[] | select(.name == $name) | .cidrs[]]
      | if length == 0 then error("IP set not found or empty") else .[] end
    '
```

Segment ACL rules themselves are **not stored in Valkey**. They are in the
controller's `segments.json` state file (default
`/var/lib/swiftfabric/segments.json`; `state_path` in
`/etc/swiftfabric/api-service.json` can override it). Inspect the ACL for a
segment and resolve every referenced group against the Valkey value:

```sh
SEG=5001
ACL_JSON="$(jq -c --arg id "$SEG" \
    '.[$id].acl // error("segment ACL not found in local state")' \
    /var/lib/swiftfabric/segments.json)"

jq -n --argjson acl "$ACL_JSON" --argjson sets "$IP_SETS_JSON" '
  ($sets | map(.name)) as $names
  | [$acl.ingress[], $acl.egress[]][]
  | .source, .destination
  | select(. as $value | $names | index($value))
  | . as $name
  | {name: $name, cidrs: ($sets[] | select(.name == $name) | .cidrs)}
'
```

This prints each referenced set name with its members; repeated references
can produce repeated rows. Use the authenticated `GET /api/v1/segments/<id>/acl`
endpoint instead of the local file when checking live API state. If a set name
is referenced by an ACL but absent from `swiftfabric:ip_sets`, verify that
you queried port `4999` on the current provisioning primary and that
replication is healthy before treating the value as missing. Keep ACL and
address-group dumps restricted; they may disclose internal network layout.

Interpretation:

- `vteps:pool` includes start/end allocation bounds, CIDR, and required VTEP
  MTU; allocation bookkeeping can store IPv4 addresses as decimal integers.
- `vteps:hosts` and `vteps:owners` are forward/reverse assignment indexes;
  reservations are time-bounded, not enrolled hosts.
- `hosts` and `north_south_routers` contain JSON enrollment/deployment records.
  Router records and Proxmox cluster records are especially sensitive.
- `host:heartbeats` contains the last health samples and per-peer checks.
  Router heartbeat fields use `router:<router-id>`.
- `host:liveness` records failure-tracking state; it is not a packet counter.
- User/group tables contain authorization metadata and hashes; they are not
  needed for an ordinary forwarding incident.

Credential indexes are also hashes, but inspect **counts/type first**, not
their full contents:

```sh
vk HLEN swiftfabric:host:tokens
vk HLEN swiftfabric:host:token_by_host
vk HLEN swiftfabric:host:pending_token_by_host
vk HLEN swiftfabric:user:token_index
```

If required for an approved local authentication investigation, `HGETALL` can
read each of those keys too. They can expose machine credentials or credential
indexes; do not include them in routine support dumps or tickets.

Prefer targeted reads when possible:

```sh
vk HGET swiftfabric:hosts '<host-id>'
vk HGET swiftfabric:host:heartbeats '<host-id>'
vk HGET swiftfabric:host:heartbeats 'router:<router-id>'
vk HGET swiftfabric:north_south_routers '<router-id>'
```

Health reports are normally sent every 30 seconds; the UI treats reports older
than 90 seconds as stale. VTEP peer checks test source-bound IPv4 DF reachability,
not every tenant forwarding rule. Current controller liveness cleanup combines
missing heartbeats with peer-confirmed VTEP failures over repeated checks;
a stale timestamp alone is not proof that all MACs should be removed.

### 4. Save a restricted diagnostic dump

**Creates files, reads live data; does not mutate Valkey.** Inside the
authenticated subshell, with a public segment selected:

```sh
umask 077
OUT="$(mktemp -d "/root/swiftfabric-valkey-$PORT-XXXXXXXX")"
vk INFO replication > "$OUT/replication.txt"
vk HGETALL "swiftfabric:segment:$PORT:macs" > "$OUT/macs.txt"
vk HGETALL "swiftfabric:segment:$PORT:arp" > "$OUT/arp.txt"
vk HGETALL "swiftfabric:segment:$PORT:adapter-stats" > "$OUT/adapter-stats.txt"
printf 'Restricted diagnostic files: %s\n' "$OUT"
```

This is a human-readable diagnostic dump, **not a restorable backup** or an
atomic snapshot. For provisioning, save only the specifically needed keys
with the same root-only permissions. Review/redact before sharing.

Provisioning (`4999`) enables AOF with `appendfsync everysec`; public segment
instances disable AOF and RDB persistence and rely on agents to repopulate
MAC state. Losing/restarting every segment instance can therefore yield empty
tables until agents relearn/register. Losing provisioning data is a different,
potentially destructive incident: preserve its data directory and local
segment metadata, and recover from a verified backup/replica under a separate
plan. Do not use `FLUSHDB`, `DEL`, `HSET`, `SAVE`, or direct data-file edits as
troubleshooting steps.

## Deployment, upgrades, and enrollment

### Dash-prefixed bearer tokens

URL-safe generated tokens can start with `-` or `--`. Shell quotes preserve
the value but do not prevent argument parsers from interpreting it as an option.
Prefer the secure prompt; no token value appears in shell history or process
arguments:

```sh
./upgrade.sh --config config.json --token --auto-agent-upgrade
```

If explicitly passing an existing shell variable, attach the value with `=`;
this works on older installers too:

```sh
./upgrade.sh --config config.json --token="$token" --auto-agent-upgrade
```

The installer destroy path likewise accepts `--token="$token"`. Current
installer/upgrade parsers also accept spaced single-dash token values and
64-character generated URL-safe tokens starting with either `-` or `--`.
For arbitrary long-option-shaped values, use `--token=VALUE` or the secure
prompt. Unknown long options still report errors, and a bare `--token` followed
by workflow flags still prompts. Credentials are not regenerated or modified
to work around parsing.

- **Check the executing version, not just the controller package.** Controller
  upgrades, compute **Upgrade agent**, and NSR runtime/agent upgrades are
  separate operations. Compare package versions, UI-recorded versions,
  `sf-cli --help`, unit files, and a fresh heartbeat.
- **Host upgrade blocked:** running VMs with connected NICs on SwiftFabric
  bridges must be migrated away. The error names the blocking VMs/bridges.
  Stopped VMs and `link_down=1` NICs are ignored. Do not bypass this check.
- **Agent rollback:** failed upgrades attempt to restore the prior artifact.
  Read both upgrade and rollback results; a failed rollback is not a healthy
  host. Retain every published payload in
  `/var/lib/swiftfabric/host-agents/`; legacy enrolled hosts may need theirs.
- **Controller upgrade interrupted:** preserve the reported completed/remaining
  controller list. The supported upgrader can resume with the same prebuilt
  target package when already-upgraded nodes match that target and remaining
  nodes share their prior version. Use the authenticated sequential
  `./upgrade.sh --config config.json --token` workflow; do not redeploy VMs
  or rewrite tokens/state to resolve an upgrade.
- **Automated agent upgrade stopped (`--auto-agent-upgrade`):** the error lists
  completed hosts/routers and any VMs not back on their original host. A host
  whose upgrade rolled back has its VMs returned; a host left `failed` keeps
  them evacuated until it is repaired. Fix the reported blocker, then rerun the
  same command; already-upgraded controllers, hosts, and routers are skipped
  and a pending HA rolling upgrade is resumed by its original identity.
- **Key rotation stalls:** old credentials remain valid while a replacement
  is staged. Completion requires an authenticated heartbeat using the new
  key. Review deployment/proxy/agent logs and pending rotation state before
  retrying. NSR rotation restarts routing-related services and briefly
  interrupts forwarding.
- **NSR deployment stuck:** inspect controller API logs, Proxmox task result,
  `qm config <VMID>`, guest SSH/cloud-init, disk capacity, and the four router
  services. Inside the guest use `cloud-init status --long`,
  `journalctl -u cloud-final --no-pager`, and local
  `/var/log/cloud-init-output.log` (sensitive). Storage must support the
  required import/snippet workflow. Tagged NICs require VLAN-aware bridges.
- **NSR retry/redeploy is not a read-only diagnostic:** retry removes a partial
  VM, and force redeployment replaces the VM while retaining attachments.
  Cancellation can leave a partial VM for later cleanup. Preserve logs first.
- **VTEP pool cannot change/unlock:** assigned hosts or unexpired reservations
  may still occupy it. Inspect allocation/host records and the API conflict
  details; do not delete indexes to bypass ownership checks.
- **Destroy refused:** enrolled hosts/registered clusters must be cleaned
  first. Auto-unenroll refuses to destroy when reachable-node cleanup is
  incomplete. Do not bypass the guard or discard offline-node records.

Build/package recovery must follow the repository's buildbox workflow. Do not
compile locally on an affected node. See [BUILDING.md](BUILDING.md) for build
details and the repository operational instructions for the required remote
build policy. Commit intended source changes only with explicit approval
before using the clean-worktree build workflow. Installation consumes
prebuilt packages and requires exactly one API-service package in `packages/`.

## Incident handoff checklist

Provide a redacted report containing:

- Incident UTC interval, topology, affected segment/VM/MAC/IP, and exact
  source/destination/protocol/ports; whether the reverse direction works.
- Controller, compute-agent, and NSR versions; last upgrade, migration, policy,
  enrollment, or VLAN/MTU change.
- All controllers' quorum/membership, Pacemaker status, VIP owner, affected
  segment primary, Valkey role/link status, and API error bodies.
- Host bridge/FDB/TC state and counter deltas, source-bound VTEP DF results,
  required/configured MTUs, and peer-health report ages.
- NSR namespace links/routes/rules, relevant ACL/NAT configuration, and where
  the packet disappears between segment and WAN.
- Bounded, filtered captures from both sides and matching service log windows.
- Recovery actions already attempted, their exact outcomes, and whether the
  original application flow was retested successfully.

Keep raw secrets, private keys, full CIB/Valkey exports, and unredacted captures
out of the shared report.

## Related references

- [Host-agent operation and sf-cli](host-agent/README.md)
- [L2 replication and traffic flow](host-agent/L2-REPLICATION-SPECIFICATION.md)
- [NSR runtime and firewall behavior](controller-api/router-runtime/README.md)
- [Controller API and provisioning](controller-api/segment-manager/README.md)
- [Segmentation and routing specification](NETWORKING-SEGMENTATION-AND-ROUTING-SPEC.md)
- [North/South HA design](NORTH-SOUTH-HA-FAILOVER-DESIGN.md)
  (design context, not proof that a particular failover feature is deployed)
