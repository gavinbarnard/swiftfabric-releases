#!/bin/bash
# SwiftFabric TUI Installer Bootstrap Script
# Creates Python venv and launches the installer

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
"$SCRIPT_DIR/check-submodules.sh" python_installer

# Destroy-only runs do not need an API-service package.
destroy_only=false
for arg in "$@"; do
    if [[ "$arg" == "--destroy" || "$arg" == "--delete" ]]; then
        destroy_only=true
    fi
done

if [[ "$destroy_only" != true ]]; then
    package_count="$(find packages -maxdepth 1 -type f \
        -name 'swiftfabric-api-service_*_amd64.deb' -print 2>/dev/null | wc -l)"
    if [[ "$package_count" -ne 1 ]]; then
        echo "ERROR: Expected exactly one SwiftFabric API service .deb in $SCRIPT_DIR/packages/." >&2
        echo "Build it first with: ./build-api-service.sh" >&2
        exit 1
    fi
fi

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "Creating Python virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Install dependencies
echo "Installing dependencies..."
pip install --quiet --no-cache-dir \
    'rich>=13.0.0' \
    'requests>=2.31.0' \
    'typer>=0.9.0'

# Launch Python installer
# Forward CLI options such as --prefix, --controllername, and --destroy/--delete.
echo "Launching SwiftFabric Installer..."
python python_installer/main.py "$@"
