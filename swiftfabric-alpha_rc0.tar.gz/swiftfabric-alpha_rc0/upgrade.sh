#!/bin/bash
# Bootstrap and run the controller upgrade workflow (and, with
# --auto-agent-upgrade, automated router and compute-host agent upgrades).

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
"$SCRIPT_DIR/check-submodules.sh" python_installer

package_count="$(find packages -maxdepth 1 -type f \
    -name 'swiftfabric-api-service_*_amd64.deb' -print 2>/dev/null | wc -l)"
if [[ "$package_count" -ne 1 ]]; then
    echo "ERROR: Expected exactly one SwiftFabric API service .deb in $SCRIPT_DIR/packages/." >&2
    echo "Build it first with: ./build-api-service.sh" >&2
    exit 1
fi

if [ ! -d "venv" ]; then
    echo "Creating Python virtual environment..."
    python3 -m venv venv
fi

source venv/bin/activate

echo "Installing dependencies..."
pip install --quiet --no-cache-dir \
    'rich>=13.0.0' \
    'requests>=2.31.0' \
    'typer>=0.9.0'

echo "Launching SwiftFabric upgrade..."
python python_installer/upgrade.py "$@"
