#!/bin/bash

SCRIPT_DIR=$(dirname "$0")

cd $SCRIPT_DIR

rm -rf images
mkdir -p images/generic

cd images
cd generic
wget -O ubuntu-resolute-server-cloudimg-amd64.qcow2 \
    https://cloud-images.ubuntu.com/resolute/current/resolute-server-cloudimg-amd64.img